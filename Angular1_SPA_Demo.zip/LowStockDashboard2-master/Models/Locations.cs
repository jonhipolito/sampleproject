﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LowStockDashboard.Models
{
    public class Location
    {
        public string LocationId;
        public string LocationName;
    }
}