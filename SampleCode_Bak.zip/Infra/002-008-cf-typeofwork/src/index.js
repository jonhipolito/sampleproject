exports.processTOW = async (req, res) => {
    const uuid = require('uuidv4');
    const { Spanner } = require('@google-cloud/spanner');    

    const projectId = process.env.X_GOOGLE_GCLOUD_PROJECT;

    const spanner = new Spanner({
        projectId: projectId,
    });
    
    const instanceId = 'si-27354-mmc';
    const databaseId = 'db-27354-mmc-db';

    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);
    const towTable = database.table('TypeOfWork');
    var insertedCount;
    var updatedCount;
    try {
        const [rowsDump_insert] = await database.run({
            sql: `SELECT dump.TypeOfWorkCd, dump.TypeOfWorkDesc 
            FROM MRDRTypeOfWorkDump AS dump 
            LEFT JOIN TypeOfWork tow on dump.TypeOfWorkCd = tow.TypeOfWorkCd 
            WHERE tow.TypeOfWorkCd IS NULL`
        });

        if (rowsDump_insert.length > 0) {
            let rowBase = [];

            rowsDump_insert.forEach(row => {
                let tempRow = row.toJSON();
                tempRow.TypeOfWorkKey = uuid();
                tempRow.CreateUserId = 'MMC_JOB_USER';
                tempRow.UpdateUserId = 'MMC_JOB_USER';
                tempRow.CreateDttm = new Date();
                tempRow.UpdateDttm = new Date();
                rowBase.push(tempRow);
            });
            console.log('Insert new Type Of Work - IN PROGRESS');
            await towTable.insert(rowBase);
            insertedCount = rowsDump_insert.length;
            console.log('Insert new Type Of Work - DONE');
        }

        const [rowsDump_update] = await database.run({
            sql: `SELECT tow.TypeOfWorkKey, tow.TypeOfWorkCd, dump.TypeOfWorkDesc
            FROM TypeOfWork tow
            INNER JOIN MRDRTypeOfWorkDump dump on tow.TypeOfWorkCd = dump.TypeOfWorkCd
            WHERE tow.TypeOfWorkDesc <> dump.TypeOfWorkDesc`
        });

        if (rowsDump_update.length > 0) {
            let rowRef = [];

            rowsDump_update.forEach(row => {
                let tempRow = row.toJSON();
                tempRow.UpdateUserId = 'MMC_JOB_USER';
                tempRow.UpdateDttm = (new Date());
                rowRef.push(tempRow);
            });
            console.log('Update Type Of Work - IN PROGRESS');
            await towTable.update(rowRef);
            updatedCount = rowsDump_update.length;
            console.log('Update Type Of Work - DONE');
        }
    } catch (err) {
        console.error('ERROR:', err);
    } finally {
        database.close();
        const { PubSub } = require('@google-cloud/pubsub');
        const pubsub = new PubSub({ projectId });
        const dataBuffer = Buffer.from("typeofwork");
        await pubsub.topic("JobEvents").publish(dataBuffer);
        res.status(200).json({
            data: 'Records Inserted: ' + insertedCount + ' Records Updated: ' + updatedCount
        });

    }
};