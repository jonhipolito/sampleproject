/**
 * Triggered from a message on a Cloud Pub/Sub topic.
 *
 * @param {!Object} event Event payload.
 * @param {!Object} context Metadata for the event.
 */
var Excel = require('exceljs');
var XLSX = require('xlsx');
const { Storage } = require('@google-cloud/storage');
const { Spanner } = require('@google-cloud/spanner');

const storage = new Storage();

const projectId = process.env.X_GOOGLE_GCLOUD_PROJECT,
        instanceId = 'si-27354-mmc',
        databaseId = 'db-27354-mmc-db';

const spanner = new Spanner({
        projectId: projectId,
});
const instance = spanner.instance(instanceId);
const database = instance.database(databaseId);

function Authenticate(token) {
        return new Promise(resolve => {
                var jwt = require('jsonwebtoken');
                var jwksClient = require('jwks-rsa');
                var client = jwksClient({
                        jwksUri: 'https://login.microsoftonline.com/common/discovery/v2.0/keys'
                });

                function getKey(header, callback) {
                        client.getSigningKey(header.kid, function (err, key) {
                                var signingKey = key.publicKey || key.rsaPublicKey;
                                callback(null, signingKey);
                        });
                }
                token = token.replace("Bearer ", "");
                jwt.verify(token, getKey, {
                        issuer: [
                                "https://sts.windows.net/f3211d0e-125b-42c3-86db-322b19a65a22/",
                                "https://sts.windows.net/e0793d39-0939-496d-b129-198edd916feb/"
                        ]
                }, function (err, decoded) {
                        resolve(decoded);
                });
        })

}


async function QueryDnO(body) {
        let filter;
        if (body.ContractNbr) {
                filter = `ContractNbr = '${body.ContractNbr}'`
        }
        else if (body.CustomerNbr) {
                filter = `CustomerNbr = '${body.CustomerNbr}'`
        }
        else if (body.MasterClientNbr) {
                filter = `MasterClientNbr = '${body.MasterClientNbr}'`
        }
        const [rows] = await database.run({
                sql: `SELECT DetailID,DelivsObligationsTypeCd,DelivsObligationsNm,DelivsObligationsDesc,SubmissionLevelCd,SubmissionDelivStatusCd,RAGStatusCd,ResponsiblePartyArr,IsCritical,DueDt,SubmissionDt,SubmissionCompletedBy,SubmissionReviewPeriod,CreateDttm,CreateUserId
        FROM DeliverablesObligations
        WHERE ${filter} 
        ORDER BY DetailID`
        });
        return rows;
}

async function QueryCodeDetail() {
        const [rows] = await database.run({
                sql: `SELECT *
        FROM CodeDetail
        WHERE CodeHeaderId IN (1023, 1024, 1025, 1026, 1027)`
        });
        let items = [];
        rows.forEach(x => {
                let item = x.toJSON();
                items.push(item);
        })
        return items;
}

function GetPrimaryDecodeTxt(codedetails, value) {
        let row = codedetails.find(x => x.CodeDetailId == value);
        if (row) {
                return row.PrimaryDecodeTxt;
        }
        else {
                return '';
        }

}

function GetResponsible(codedetails, respArray) {
        let vals = [];
        respArray.forEach(x => {
                let val = GetPrimaryDecodeTxt(codedetails, x);
                if (val) {
                        vals.push(val)
                }

        })
        return vals.sort().join(', ');
}
async function GetDnOExportDetails(body) {
        let codedetail = await QueryCodeDetail();
        let dno = await QueryDnO(body);
        let details = [];
        dno.forEach(row => {
                let item = row.toJSON();
                item.ID = item.DetailID;
                item.Type = GetPrimaryDecodeTxt(codedetail, item.DelivsObligationsTypeCd);
                item.Name = item.DelivsObligationsNm;
                item.Description = item.DelivsObligationsDesc;
                item.Acceptance = GetPrimaryDecodeTxt(codedetail, item.SubmissionLevelCd);
                item.DeliveryStatus = GetPrimaryDecodeTxt(codedetail, item.SubmissionDelivStatusCd);
                item.RAGStatus = GetPrimaryDecodeTxt(codedetail, item.RAGStatusCd);
                item.Responsible = GetResponsible(codedetail, item.ResponsiblePartyArr);
                item.Critical = item.IsCritical == "Y" ? "Yes" : "No";
                item.DueDt = new Date(item.DueDt);
                item.SubmittedDate = item.SubmissionDt ? new Date(item.SubmissionDt) : null;
                item.SubmittedBy = item.SubmissionCompletedBy;
                item.ReviewPeriod = item.SubmissionReviewPeriod;
                item.Date = new Date(item.CreateDttm);
                item.By = item.CreateUserId;
                details.push(item);
        });
        return details;
}

function GenerateTemplate(details, Filename) {
        return new Promise(async (resolve) => {
                let file = storage.bucket("npd-27354-oriondev-mrdr").file(`User-Exports/${Filename}`)
                if(details) {
                        let readstream = storage.bucket("npd-27354-oriondev-mrdr").file("excel-templates/Template.xlsx").createReadStream();
                        var workbook = new Excel.Workbook();
                        let writeStream = workbook.xlsx.createInputStream();
                        readstream.pipe(writeStream);
                        writeStream.on('done', () => {
                                let ws = workbook.getWorksheet("Insert Deliverables Information");
                                let ctr = 2;
                                details.forEach(d => {
                                        ws.getCell(ctr, 1).value = d.ID
                                        ws.getCell(ctr, 2).value = d.Type
                                        ws.getCell(ctr, 3).value = d.Name
                                        ws.getCell(ctr, 4).value = d.Description
                                        ws.getCell(ctr, 5).value = d.Acceptance
                                        ws.getCell(ctr, 6).value = d.DeliveryStatus
                                        ws.getCell(ctr, 7).value = d.RAGStatus
                                        ws.getCell(ctr, 8).value = d.Responsible
                                        ws.getCell(ctr, 9).value = d.Critical
                                        ws.getCell(ctr, 10).value = d.DueDt
                                        ws.getCell(ctr, 11).value = d.SubmittedDate
                                        ws.getCell(ctr, 12).value = d.SubmittedBy
                                        ws.getCell(ctr, 13).value = d.ReviewPeriod
                                        ws.getCell(ctr, 14).value = d.Date
                                        ws.getCell(ctr, 15).value = d.By
                                        ctr++;
                                });
                                workbook.xlsx.writeBuffer()
                                        .then(function (buffer) {
                                                file.save(buffer).then(() => {
                                                        var expiry = new Date((new Date()).getTime() + 300000);
                                                        file.download(function (err, contents) {
                                                                resolve(contents);
                                                        });
                                                });
                                        });
                        });
                }
                else {
                        let file = storage.bucket("npd-27354-oriondev-mrdr").file(`excel-templates/Template.xlsx`)
                        file.download(function (err, contents) {
                                resolve(contents);
                        });
                }
                
        });

}

exports.dnoexport = async (req, res) => {
        res.set('Access-Control-Allow-Origin', '*');
        res.set('Access-Control-Allow-Headers', '*');
        if (req.method == 'OPTIONS') {

                res.send();
                return;
        }
        if (req.method !== 'POST') {
                res.send("Not POST");
                return;
        }


        // let decodedToken = await Authenticate(req.headers.authorization);
        // if (!decodedToken) {
        //         res.status(401).send('Not Authorized');
        //         return false;
        // }
        // console.log("decodedToken", decodedToken);
        let param = req.body;
        let user //= decodedToken.upn.split('@')[0];
        let Filename = `${param.ContractNbr}-${user}.xlsx`
        let details = null;
        if(param.ExportType == 'Existing') {
                details = await GetDnOExportDetails(param);        }
         
        try {                
                let data = await GenerateTemplate(details, Filename);
                res.set('Response-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                res.send(data)
        } catch (error) {
                console.log("Index - Catch", error);
        } finally {
        }
}