
const   deletedata = require('./deletetemp'),
        { Spanner } = require('@google-cloud/spanner'),
        projectId = process.env.X_GOOGLE_GCLOUD_PROJECT,
        instanceId = 'si-27354-mmc',
        databaseId = 'db-27354-mmc-db',
        // projectId = 'sbx-27354-nmmcsbxdev-a9ab6909', //For Local Testing
        // instanceId = 'nextgenmmc', //For Local Testing
        // databaseId = 'mmcdb', //For Local Testing
        spanner = new Spanner({ projectId: projectId, }),
        instance = spanner.instance(instanceId),
        database = instance.database(databaseId);

 exports.deletetemp = async() => {
    try {
        console.log("Start: Delete Temporary Tables");
     console.log(`CONTROL FLOW 1 - DELETE ALL ROWS IN TEMPCONTRACTSTAGE - IN PROGRESS`);
         await deletedata.truncateTempContractStage(database);       //control flow 1         

         console.log(`CONTROL FLOW 1 - DELETE ALL ROWS IN TEMPCONTRACT - IN PROGRESS`);
         await deletedata.truncateTempContract(database);       //control flow 1         

         console.log(`CONTROL FLOW 1 - DELETE ALL ROWS IN TEMPPROFITCENTERHIERARCHY - IN PROGRESS`);
         await deletedata.truncateTempProfitCenterHierarchy(database); //control flow 1

         console.log(`CONTROL FLOW 1 - DELETE ALL ROWS IN TEMPCONTRACTSTAGEPREVIOUS - IN PROGRESS`);
         await deletedata.truncateTempContractStagePrevious(database);//control flow 1
         console.log("End: Delete Temporary Tables");
    }
    catch (err) {
        console.error("Error: ", err);
    }
    finally{
        await database.close();
    }
    
}

//Run - Local
//  (async function() {
//    console.log(`CONTROL FLOW 1 - DELETE ALL ROWS IN TEMPCONTRACTSTAGE - IN PROGRESS`);
//    await deletedata.truncateTempContractStage(database);       //control flow 1         

//    console.log(`CONTROL FLOW 1 - DELETE ALL ROWS IN TEMPCONTRACT - IN PROGRESS`);
//    await deletedata.truncateTempContract(database);       //control flow 1         

//    console.log(`CONTROL FLOW 1 - DELETE ALL ROWS IN TEMPPROFITCENTERHIERARCHY - IN PROGRESS`);
//    await deletedata.truncateTempProfitCenterHierarchy(database); //control flow 1
   
//    console.log(`CONTROL FLOW 1 - DELETE ALL ROWS IN TEMPCONTRACTSTAGEPREVIOUS - IN PROGRESS`);
//    await deletedata.truncateTempContractStagePrevious(database);//control flow 1
//  }())