
truncateTempContractStage = async(database) =>{

    try{ 
        const [truncTempContractStage] = await database.runPartitionedUpdate({sql:`DELETE FROM TempContractStage WHERE true`}); 
        console.log(`TempContractStage: ${truncTempContractStage} row/s deleted`);      
    }
    catch(error){
        console.log(error);
        return error;
    }  
}

truncateTempContract = async(database) => {    
    try{
        const [truncTempContract] = await database.runPartitionedUpdate({sql:`DELETE FROM TempContract WHERE true`}); 
        console.log(`TempContract: ${truncTempContract} row/s deleted`);                
    }
    catch(error){
        console.log(error);
        return error;
    }   
}

truncateTempProfitCenterHierarchy = async function(database){      
    try{
        const [truncTempProfitCenterHierarchy] = await database.runPartitionedUpdate({sql:`DELETE FROM TempProfitCenterHierarchy WHERE true`});
        console.log(`TempProfitCenterHierarchy: ${truncTempProfitCenterHierarchy} row/s deleted`);
    }
    catch(error){
        console.log(error);
        return error;
    }
}

truncateTempContractStagePrevious = async function(database){
    try{
        const [truncTempContractStagePrevious] = await database.runPartitionedUpdate(`DELETE FROM TempContractStagePrevious WHERE true`
        );
        console.log(`TempContractStagePrevious: ${truncTempContractStagePrevious} row/s deleted`);
    }
    catch(error){
        return error;
    }
}
module.exports = {
    truncateTempContractStage,
    truncateTempContract,
    truncateTempProfitCenterHierarchy,
    truncateTempContractStagePrevious
}

