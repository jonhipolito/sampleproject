exports.processCustRel = async (req, res) => {
    const uuid = require('uuidv4');
    const { Spanner } = require('@google-cloud/spanner');

    const projectId = process.env.X_GOOGLE_GCLOUD_PROJECT;

    const spanner = new Spanner({
        projectId: projectId,
    });

    const instanceId = 'si-27354-mmc';
    const databaseId = 'db-27354-mmc-db';

    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);
    const towTable = database.table('TempCustomerRelationship');
    var insertedCount;
    try {
        const [rowsDump_insert] = await database.run({
            sql: `SELECT mc.CustomerNbr
                    , cra.CustomerRelationshipNbr
                    ,cra.ContentValue
                    FROM  MRDRCustomerDump mc
                    INNER JOIN MRDRCustomerRelationshipDump cr
                        ON  mc.CustomerNbr = cr.CustomerNbr
                    INNER JOIN MRDRCustomerRelationshipAttributeDump cra
                        ON cr.CustomerRelationshipNbr = cra.CustomerRelationshipNbr
                    WHERE  mc.CustomerNbr NOT IN (SELECT CustomerNbr FROM Customer) AND mc.CustomerNbr LIKE '001%'
                        AND LTRIM(RTRIM(cra.AttributeCd)) = 'CRSTDE'`
        });

        if (rowsDump_insert.length > 0) {
            rowsDump_insert.forEach(row => {
                let rowBase = [];
                let tempRow = row.toJSON();
                tempRow.CreateUserId = 'MMC_JOB_USER';
                tempRow.UpdateUserId = 'MMC_JOB_USER';
                tempRow.CreateDttm = new Date();
                tempRow.UpdateDttm = new Date();
                rowBase.push(tempRow);
                towTable.insert(rowBase);
            });
            console.log('Insert new Type Of Work - IN PROGRESS');
            insertedCount = rowsDump_insert.length;
            console.log('Insert new Type Of Work - DONE');
        }
    } catch (err) {
        console.error('ERROR:', err);
    } finally {
        database.close();
        res.status(200).json({
            data: 'Records Inserted: ' + insertedCount
        });
    }


    // database.runTransaction(function (err, transaction) {
    //     if (err) {
    //       console.error(err);
    //       return;
    //     }
    //     try {
    //       const [rowCount] = transaction.run({
    //         sql: `SELECT mc.CustomerNbr
    //                 , cra.CustomerRelationshipNbr
    //                 ,cra.ContentValue
    //                 FROM  MRDRCustomerDump mc
    //                 INNER JOIN MRDRCustomerRelationshipDump cr
    //                     ON  mc.CustomerNbr = cr.CustomerNbr
    //                 INNER JOIN MRDRCustomerRelationshipAttributeDump cra
    //                     ON cr.CustomerRelationshipNbr = cra.CustomerRelationshipNbr
    //                 WHERE  mc.CustomerNbr NOT IN (SELECT CustomerNbr FROM Customer) AND mc.CustomerNbr LIKE '001%'
    //                     AND LTRIM(RTRIM(cra.AttributeCd)) = 'CRSTDE'`
    //       });
    //       transaction.insert(towTable, rowCount)
    //       console.log(
    //         `Successfully inserted ${rowCount} record into the Singers table.`
    //       );
      
    //       await transaction.commit();
    //     } catch (err) {
    //       console.error('ERROR:', err);
    //     } finally {
    //       // Close the database when finished.
    //       database.close();
    //     }
    //   });
};