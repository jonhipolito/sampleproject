
deletetempcontract_CF3 = async function(database){
    try{
        const [del_rows] = await database.runPartitionedUpdate({sql: `DELETE FROM TempContract
        WHERE 
        (ContractStatus = 'E0010' AND WBSStatus = 'I0046')
        or 
        (ContractStatus = 'E0010' AND WBSStatus = 'E0007')`});
        console.log(`TempContract: ${del_rows}  row(s) deleted.`);
    }
    catch(err){
        console.log(err);
    }
}
deleterestrictedcomp_CF4 = async function(database){
    try{
        const [restricted] = await database.run({sql:`SELECT CompanyDesc FROM RestrictedCompany`});

        if(restricted.length > 0)
            {
                let resultX = [];
                restricted.forEach(row =>{
                    let temp = row.toJSON();
                    let dml = {sql: `DELETE  FROM TempContract WHERE CompanyDesc LIKE '%${temp.CompanyDesc}%'`}
                    resultX.push(dml);                   
      
                });
                await database.runTransactionAsync(async transaction => {
                    const cf4 = await transaction.batchUpdate(resultX);
                    await transaction.commit();
                    console.log(`TempContract:  ${cf4}  row(s) deleted.`);
                });
            }
    }
    catch(err){
        console.log(err);
    }
}

deletetempcontract_CF5 = async function(database){
    const query = {sql : `DELETE FROM TempContract
    WHERE 
    CAST(ProjectType AS INT64) IN (10, 11,20)
    AND ResultsAnalysisKey = ''
    AND CAST(ProjectHierarchyLevel AS INT64) > 1
    AND Contractnbr NOT IN
    (SELECT ContractNbr
    FROM TempContract
    WHERE 
    (CAST(ProjectType AS INT64) IN (10, 11,20) AND ResultsAnalysisKey <> '' AND CAST(ProjectHierarchyLevel AS INT64) > 1)
    OR
    (CAST(ProjectType AS INT64) IN (10, 11,20) AND ResultsAnalysisKey = '' AND CAST(ProjectHierarchyLevel AS INT64) = 1)
    OR 
    CAST(ProjectType AS INT64) NOT IN (10, 11,20))`};
    const dml = [query];
    try{
        await database.runTransactionAsync(async transaction => {
            const [cf5_rows] = await transaction.batchUpdate(dml)
            await transaction.commit();
            console.log(`TempContract:  ${cf5_rows}  row(s) deleted.`);
        });
    }
    catch(err){
        console.log(err);
    }     
}
module.exports = {
    deletetempcontract_CF3,
    deleterestrictedcomp_CF4,
    deletetempcontract_CF5
}