
const   flattencondelete = require('./flattencondelete'),
        { Spanner } = require('@google-cloud/spanner'),
        projectId = process.env.X_GOOGLE_GCLOUD_PROJECT,
        instanceId = 'si-27354-mmc',
        databaseId = 'db-27354-mmc-db',
        // projectId = 'sbx-27354-nmmcsbxdev-a9ab6909', //For Local Testing
        // instanceId = 'nextgenmmc', //For Local Testing
        // databaseId = 'mmcdb', //For Local Testing
        spanner = new Spanner({ projectId: projectId, }),
        instance = spanner.instance(instanceId),
        database = instance.database(databaseId);
 

 exports.flattencondelete = async() => {
    try {
     console.log("Start: TempContract Process - Delete Processes Only");
     console.log(`CONTROL FLOW 3 - DELETE FROM TempContract ('E0010' AND = 'I0046') or ('E0010' AND 'E0007') - IN PROGRESS`);
     await flattencondelete.deletetempcontract_CF3(database); //control flow 3

     console.log(`CONTROL FLOW 4 - DELETE RESTRICTED COMPANY IN TEMPCONTRACT - IN PROGRESS`);
     await flattencondelete.deleterestrictedcomp_CF4(database); //control flow 4

     console.log(`CONTROL FLOW 5 - DELETE FROM TEMPCONTRACT - IN PROGRESS`);
     await flattencondelete.deletetempcontract_CF5(database); //control flow 5
     console.log("End: TempContract Process - Delete Processes Only");
    }
    catch (err) {
        console.error("Error: ", err);
    }
    finally{
        await database.close();
    }
    
}

//Run - Local
//  (async function() {
//  console.log(`CONTROL FLOW 3 - DELETE FROM TempContract ('E0010' AND = 'I0046') or ('E0010' AND 'E0007') - IN PROGRESS`);
    // await tempcontract.deletetempcontract_CF3(database); //control flow 3

    // console.log(`CONTROL FLOW 4 - DELETE RESTRICTED COMPANY IN TEMPCONTRACT -      IN PROGRESS`);
    // await tempcontract.deleterestrictedcomp_CF4(database); //control flow 4

    // console.log(`CONTROL FLOW 5 - DELETE FROM TEMPCONTRACT - IN PROGRESS`);
    // await tempcontract.deletetempcontract_CF5(database); //control flow 5
//  }())