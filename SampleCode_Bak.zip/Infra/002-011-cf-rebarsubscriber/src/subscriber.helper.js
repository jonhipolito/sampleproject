const uuid = require('uuidv4');
const moment = require('moment');
const repository = require('./subscriber.repository');
const app_constants = require('./app.constants');
const _CONST = app_constants.appConstants();
const NodeCache = require("node-cache");
const Cache = new NodeCache({
    stdTTL: 1800,
    checkperiod: 100
});
const request = require('request');

var MMC_COMMENTS_PAYLOAD = {
    "AirId": 27354,
    "RequestId": uuid(),
    "Messages": [{
        "MessageTypes": [
            "Accenture.Events.Legal.Comments.UpdatedEvent"
        ],
        "MessageId": uuid(),
        "Body": {},
        "Headers": {}
    }]
}

/**
 * Helper Module
 */
// [START getRebarMessage]
/**
 * getRebarMessage
 *
 * @param {json} rebarMessage Array of events received from the request.
 */
getRebarMessage = (rebarMessage) => {
    console.log(`helper: getRebarMessage(): stringified rebarMessage: ` + JSON.stringify(rebarMessage));
    try {
        let rows_rebarMessage = [];
        let messages = rebarMessage.Messages;
        if (rebarMessage && rebarMessage.Messages && rebarMessage.Messages.length > 0) {
            for (var i of messages) {
                rows_rebarMessage.push({
                    CIPMMCRiskAuditKey: uuid(),
                    RebarMessage: JSON.stringify(rebarMessage),
                    Status: _CONST.STATUS_UNPROCESSED,
                    CreateDttm: new Date(),
                    CreateUserId: _CONST.REBAR_CREATE_USER,
                    UpdateDttm: new Date(),
                    UpdateUserId: _CONST.REBAR_CREATE_USER

                });
                console.log(`helper: getRebarMessage(): stringified rows_rebarMessage: ` + JSON.stringify(rows_rebarMessage));
            }
            return rows_rebarMessage;
        }
    } catch (error) {
        console.log(`helper: getRebarMessage(): error: ` + error);
        throw error
    }
}
// [END getRebarMessage]

// [START getRisksAndMitigations]
/**
 * getRisksAndMitigations
 *
 * @param {json} rebarResponse Array of events received from the request.
 */
getRisksAndMitigations = async (rebarResponse) => {
    console.log(`helper: getRisksAndMitigations(): stringified rebarResponse: ` + JSON.stringify(rebarResponse));
    return new Promise(async (resolve, reject) => {
        try {
            let rows = {
                risksInsert: [],
                mitigations: [],
                risksUpdate: [],
                mitigationsUpdate: [],
                origdetailsInsert: [],
                origdetailsUpdate: []
            };

            let rows_risks_insert = [];
            let rows_mitigations = [];
            let rows_mitigations_update = [];
            let rows_risks_update = [];
            let rows_orig_risksandmiti_insert = [];
            let rows_orig_risksandmiti_update = [];
            let promises = [];
            let messages = JSON.parse(rebarResponse.RebarMessage);
            messages.Messages.forEach((message) => {
                promises.push(new Promise(async (resolve, reject) => {
                    var risk = message.MessageBody;
                    var riskDetailsKey = uuid();
                    var riskMitigationKey = uuid();
                    var contractNbr = "";
                    var contractNm = "";
                    var customerNm = "";
                    var masterclientNm = "";
                    var customer = "";
                    var masterclient = "";

                    let codeheaders = ['1006','1007', '1008', '1012']
                    let parseCodes = await repository.getCodes(codeheaders);

                    //ESG - Change Mapping Approach
                    let cipLevel = [risk.Category, risk.Subcategory];
                    let riskMapping = await repository.getMMCRiskMapping(cipLevel);
                    //let riskCategory = await repository.getMMCRiskMapping(risk.Level1RiskId);
                    //let riskSubcategory = await repository.getMMCRiskMapping(risk.Level2RiskId);
                    //ESG - Change Mapping Approach
                    if (risk.CIPType == 'OPP') {
                        let getWBS = await repository.getMRDRWBSElementDumpByOpp(risk.Opportunity);
                        console.log("getWBS", getWBS);
                        if (getWBS) {
                            contractNbr = await repository.getMRDRContractLineItemDumpByWBS(getWBS.WBSExternalNbr);
                            console.log("contractNbr", contractNbr);
                            if (contractNbr) {
                                console.log('WITH CONTRACT');
                                contractNm = await repository.getContractByNbr(contractNbr);
                                console.log("contractNm", contractNm);
                                customer = await repository.getCustomerNbrByCon(contractNbr);
                                console.log("customer", customer);
                                masterclient = await repository.getMasterClientByCus(customer.CustomerNbr);
                                console.log("masterclient", masterclient);
                            } else {
                                console.log('WITHOUT CONTRACT');
                                customerNm = await repository.getCustomerNmByNbr(risk.FinancialClient);
                                masterclientNm = await repository.getMasterClientNmByNbr(risk.MasterClient);
                            }
                        }

                    } else {
                        customerNm = await repository.getCustomerNmByNbr(risk.FinancialClient);
                        masterclientNm = await repository.getMasterClientNmByNbr(risk.MasterClient);
                    }

                    console.log("helper: getRisksAndMitigations(): parseCodes: " + JSON.stringify(parseCodes));

                    let riskRating = parseCodes.find(c => (((c.PrimaryDecodeTxt).toLowerCase() === (risk.RAGStatus).toLowerCase()) && (c.CodeHeaderId == 1008)));
                    let riskStatus = parseCodes.find(c => (c.PrimaryDecodeTxt).toLowerCase() === (risk.Status).toLowerCase());
                    //let riskMitigationStatus = parseCodes.find(c => (c.PrimaryDecodeTxt).toLowerCase() === (_CONST.APPROVED_ON_CIP).toLowerCase());
                    let riskType = parseCodes.find(c => (c.PrimaryDecodeTxt).toLowerCase() === (risk.Type).toLowerCase());
                    let riskSource = parseCodes.find(c => (c.PrimaryDecodeTxt).toLowerCase() === (risk.Source).toLowerCase());
                    let riskCategory = riskMapping.find(c => (c.CIPRiskLevel).toLowerCase() === (risk.Category).toLowerCase());
                    let riskSubcategory = riskMapping.find(c => (c.CIPRiskLevel).toLowerCase() === (risk.Subcategory).toLowerCase());
                    let MSAArray = [], todo = _CONST.TODO_DONOTHING; reapproval = [], reapproval_todo = [], duplicates = [];
                    let isRatingUpdatedInMMC = false;
                    let riskNbr = await repository.generateRiskNbr();
                    let samerecord = await repository.getSameRecord(risk, contractNbr, customer);
                    if (samerecord.length > 0) {
                        //this is for reapproval
                        //update risk description, risk mitigation, risk rating
                        //if risk description, APPEND
                        //if risk mitigation, APPEND
                        //if rist rating, UPDATE
                        // reapproval = samerecord.filter(function (el) {
                        //     return el.MitigationStatusCd == _CONST.APPROVED_ON_CIP; // this will return one row of record
                        // })

                        if (samerecord[0].OrigRiskDesc != risk.Description) {
                            // update new table to reflect the new value
                            // append riskdesc to riskdetails table
                            reapproval_todo.push(_CONST.APPEND_RISK_DESC);
                        }
                        if (samerecord[0].OrigMitigationDesc != risk.OriginalMitigation) {
                            reapproval_todo.push(_CONST.APPEND_RISK_MITI);
                        }
                        if (samerecord[0].CIPRatingNm != risk.RAGStatus) {
                            reapproval_todo.push(_CONST.UPDATE_RISK_RATING);
                        }
                        let riskRatingInCIP = parseCodes.find(c => (((c.PrimaryDecodeTxt).toLowerCase() === (samerecord[0].CIPRatingNm).toLowerCase()) && (c.CodeHeaderId == 1008)));
                        if (samerecord[0].RiskRatingCd != riskRatingInCIP.CodeTxt) {
                            isRatingUpdatedInMMC = true;
                        }

                    } else { // not for reapproval
                        duplicates = await repository.getDuplicateRecords(risk, risk.RAGStatus);
                        MSAArray = duplicates.filter(function (el) {
                            return el.CIPType == 'MSA';
                        });

                        if (duplicates.length == 0) {
                            todo = _CONST.TODO_INSERT;
                        } else {
                            if (MSAArray.length > 0 && risk.CIPType == "OPP") {
                                todo = _CONST.TODO_UPDATE;
                            }
                            else {
                                todo = _CONST.TODO_DONOTHING;
                            }
                        }

                        if (MSAArray.length > 0 && risk.CIPType == "OPP") {
                            let publishpayload = CreateMMCCommentsPayload(risk.CIPId, MSAArray[0].CIPId, risk.Level3RiskId);
                            await publishMessage(publishpayload);
                        }
                    }

                    if (reapproval_todo.indexOf(_CONST.APPEND_RISK_DESC) != -1) {
                        // do append in RiskDesc Here
                        let riskdesc = samerecord[0].OrigRiskDesc + ' <br><p><b>New Update from CIP - ' + moment().format("DD-MMM-YYYY") + '</b></p>' + risk.Description;
                        rows_risks_update.push({
                            RiskDetailsKey: samerecord[0].RiskDetailsKey,
                            CIPCategoryNm: riskCategory.MMCRiskCategory, //from CIP
                            CIPId: risk.CIPId, //from CIP
                            CIPOpportunityId: risk.Opportunity, //from CIP
                            CIPRatingNm: risk.RAGStatus, //from CIP
                            CIPReasonforChangeTxt: samerecord[0].CIPReasonforChangeTxt,
                            CIPRiskAsessment: risk.OverallRating,
                            CIPRiskId: risk.Level3RiskId, //from CIP
                            CIPRiskStatementNm: samerecord[0].CIPRiskStatementNm,
                            CIPRiskTitleNm: risk.Title,
                            CIPRiskURI: process.env.CIP_URL + `/${risk.CIPId}/${risk.CIPType}/${risk.Level1RiskId}/${risk.Level2RiskId}/${risk.Level3RiskId}`,
                            CIPSubCategoryNm: (riskSubcategory ? riskSubcategory.MMCRiskCategory : ''), //from CIP
                            CIPType: risk.CIPType, //from CIP
                            ContractNbr: (contractNbr ? contractNbr : ''), //null from CIP
                            ContractNm: (contractNm ? contractNm : ''),
                            CreateDttm: moment(risk.RiskCreatedOn).utc().format(), //from CIP
                            CreateUserId: risk.RiskCreatedBy, //from CIP
                            CustomerNbr: customer ? customer.CustomerNbr : risk.FinancialClient, //from CIP
                            //CustomerNbr: risk.FinancialClient, //from CIP
                            CustomerNm: customer ? customer.CustomerNm : customerNm,
                            //CustomerNm: customerNm,
                            MasterClientNbr: masterclient ? masterclient.MasterClientNbr : risk.MasterClient, //from CIP
                            //MasterClientNbr: risk.MasterClient, //from CIP
                            MasterClientNm: masterclient ? masterclient.MasterClientNm : masterclientNm,
                            //MasterClientNm: masterclientNm,
                            RiskAssessmentQuestionKey: samerecord[0].RiskAssessmentQuestionKey,
                            RiskDesc: riskdesc,
                            RiskLeadReviewDttm: samerecord[0].RiskLeadReviewDttm,
                            RiskLeadReviewStatusCd: samerecord[0].RiskLeadReviewStatusCd,
                            RiskNbr: samerecord[0].RiskNbr,
                            RiskQMDReviewDttm: samerecord[0].RiskQMDReviewDttm,
                            RiskQMDReviewInd: samerecord[0].RiskQMDReviewInd,
                            RiskRatingCd: isRatingUpdatedInMMC ? samerecord[0].RiskRatingCd : riskRating.CodeTxt,
                            RiskScore: samerecord[0].RiskScore,
                            RiskScoreNoCM: samerecord[0].RiskScoreNoCM,
                            RiskSourceCd: riskSource.CodeTxt, //from CIP "CIP"
                            RiskStatusCd: samerecord[0].RiskStatusCd,
                            RiskTypeCd: riskType.CodeTxt, //from CIP "Risk"
                            StatementArr: samerecord[0].StatementArr,
                            UpdateDttm: moment(risk.RiskUpdateOn).utc().format(), //from CIP
                            UpdateUserId: risk.RiskUpdateBy //from CIP
                        });

                        rows_orig_risksandmiti_update.push({
                            RawRiskDetailsKey: samerecord[0].RawRiskDetailsKey,
                            OrigCIPId: risk.CIPId,
                            OrigCIPRiskId: risk.Level3RiskId,
                            OrigCIPType: risk.CIPType,
                            OrigRiskDesc: risk.Description,
                            OrigMitigationDesc: risk.OriginalMitigation,
                            OrigRiskRatingCd: riskStatus.CodeTxt,
                            UpdateDate: moment().format("YYYY-MM-DD")
                        });
                    }

                    if (reapproval_todo.indexOf(_CONST.APPEND_RISK_MITI) != -1) {
                        let mitidesc = samerecord[0].OrigMitigationDesc + ' <br><p><b>New Update from CIP - ' + moment().format("DD-MMM-YYYY") + '</b></p>' + risk.OriginalMitigation;
                        rows_mitigations_update.push({
                            RiskDetailsKey: samerecord[0].RiskDetailsKey,
                            RiskMitigationKey: samerecord[0].RiskMitigationKey,
                            MitigationDesc: mitidesc,
                            AssigneeUserId: _CONST.NO_CM_ASSIGNED,
                            MitigationStatusCd: _CONST.APPROVED_ON_CIP, //riskMitigationStatus.CodeTxt, // 'Approved on CIP'
                            DueDttm: null, //_CONST.NO_DUE_DATE,
                            CreateDttm: samerecord[0].CreateDttm,
                            CreateUserId: samerecord[0].CreateUserId, //from CIP
                            UpdateDttm: moment(risk.RiskUpdateOn).utc().format(), //Date.parse(risk.RiskUpdateOn), //from CIP
                            UpdateUserId: risk.RiskUpdateBy //from CIP
                        });

                        if (reapproval_todo.indexOf(_CONST.APPEND_RISK_DESC) == -1) {
                            rows_orig_risksandmiti_update.push({
                                RawRiskDetailsKey: samerecord[0].RawRiskDetailsKey,
                                OrigCIPId: risk.CIPId,
                                OrigCIPRiskId: risk.Level3RiskId,
                                OrigCIPType: risk.CIPType,
                                OrigRiskDesc: risk.Description,
                                OrigMitigationDesc: risk.OriginalMitigation,
                                OrigRiskRatingCd: riskStatus.CodeTxt,
                                UpdateDate: moment().format("YYYY-MM-DD")
                            });
                        }
                    }

                    if (reapproval_todo.indexOf(_CONST.UPDATE_RISK_RATING) != -1 && reapproval_todo.indexOf(_CONST.APPEND_RISK_DESC) == -1) {
                        if(isRatingUpdatedInMMC) {
                            await UpdateRiskRating(samerecord[0].RiskDetailsKey,risk.RAGStatus, samerecord[0].RiskRatingCd);
                        }
                        else {
                            await UpdateRiskRating(samerecord[0].RiskDetailsKey, risk.RAGStatus, riskRating.CodeTxt);
                        }
                        
                    }

                    if (todo == _CONST.TODO_INSERT) {
                        rows_risks_insert.push({
                            RiskDetailsKey: riskDetailsKey,
                            CIPCategoryNm: riskCategory.MMCRiskCategory, //from CIP
                            CIPId: risk.CIPId, //from CIP
                            CIPOpportunityId: risk.Opportunity, //from CIP
                            CIPRatingNm: risk.RAGStatus, //from CIP
                            CIPReasonforChangeTxt: "",
                            CIPRiskAsessment: risk.OverallRating,
                            CIPRiskId: risk.Level3RiskId, //from CIP
                            CIPRiskStatementNm: _CONST.CIP_RISK,
                            CIPRiskTitleNm: risk.Title,
                            CIPRiskURI: process.env.CIP_URL + `/${risk.CIPId}/${risk.CIPType}/${risk.Level1RiskId}/${risk.Level2RiskId}/${risk.Level3RiskId}`,
                            CIPSubCategoryNm: (riskSubcategory ? riskSubcategory.MMCRiskCategory : ''), //from CIP
                            CIPType: risk.CIPType, //from CIP
                            ContractNbr: (contractNbr ? contractNbr : ''), //null from CIP
                            ContractNm: (contractNm ? contractNm : ''),
                            CreateDttm: moment(risk.RiskCreatedOn).utc().format(), //from CIP
                            CreateUserId: risk.RiskCreatedBy, //from CIP
                            CustomerNbr: customer ? customer.CustomerNbr : risk.FinancialClient, //from CIP
                            //CustomerNbr: risk.FinancialClient, //from CIP
                            CustomerNm: customer ? customer.CustomerNm : customerNm,
                            //CustomerNm: customerNm,
                            MasterClientNbr: masterclient ? masterclient.MasterClientNbr : risk.MasterClient, //from CIP
                            //MasterClientNbr: risk.MasterClient, //from CIP
                            MasterClientNm: masterclient ? masterclient.MasterClientNm : masterclientNm,
                            //MasterClientNm: masterclientNm,
                            RiskAssessmentQuestionKey: "",
                            RiskDesc: risk.Description, //from CIP
                            RiskLeadReviewDttm: null,
                            RiskLeadReviewStatusCd: "",
                            RiskNbr: riskNbr,
                            RiskQMDReviewDttm: null,
                            RiskQMDReviewInd: "",
                            RiskRatingCd: riskRating.CodeTxt,
                            RiskScore: null,
                            RiskScoreNoCM: null,
                            RiskSourceCd: riskSource.CodeTxt, //from CIP 'CIP'
                            RiskStatusCd: riskStatus.CodeTxt, // 'CIP Final'
                            RiskTypeCd: riskType.CodeTxt, //from CIP "Risk"
                            StatementArr: null,
                            UpdateDttm: moment(risk.RiskUpdateOn).utc().format(), //from CIP
                            UpdateUserId: risk.RiskUpdateBy //from CIP
                        });

                        if (risk.OriginalMitigation != null || risk.OriginalMitigation != "") {
                            rows_mitigations.push({
                                RiskDetailsKey: riskDetailsKey,
                                RiskMitigationKey: riskMitigationKey,
                                MitigationDesc: risk.OriginalMitigation, //from CIP
                                AssigneeUserId: _CONST.NO_CM_ASSIGNED,
                                MitigationStatusCd: _CONST.APPROVED_ON_CIP, //riskMitigationStatus.CodeTxt, // 'Approved on CIP'
                                DueDttm: null, //_CONST.NO_DUE_DATE,
                                CreateDttm: moment(risk.RiskCreatedOn).utc().format(), //risk.RiskCreatedOn, //from CIP
                                CreateUserId: risk.RiskCreatedBy, //from CIP
                                UpdateDttm: moment(risk.RiskUpdateOn).utc().format(), //Date.parse(risk.RiskUpdateOn), //from CIP
                                UpdateUserId: risk.RiskUpdateBy //from CIP
                            });
                        }

                        rows_orig_risksandmiti_insert.push({
                            RawRiskDetailsKey: riskDetailsKey,
                            OrigCIPId: risk.CIPId,
                            OrigCIPRiskId: risk.Level3RiskId,
                            OrigCIPType: risk.CIPType,
                            OrigRiskDesc: risk.Description,
                            OrigMitigationDesc: risk.OriginalMitigation,
                            OrigRiskRatingCd: riskStatus.CodeTxt
                        });
                    } else if (todo == _CONST.TODO_UPDATE) {
                        rows_risks_update.push({
                            RiskDetailsKey: duplicates[0].RiskDetailsKey,
                            CIPCategoryNm: riskCategory.MMCRiskCategory, //from CIP
                            CIPId: risk.CIPId, //from CIP
                            CIPOpportunityId: risk.Opportunity, //from CIP
                            CIPRatingNm: risk.RAGStatus, //from CIP
                            CIPReasonforChangeTxt: duplicates[0].CIPReasonforChangeTxt,
                            CIPRiskAsessment: risk.OverallRating,
                            CIPRiskId: risk.Level3RiskId, //from CIP
                            CIPRiskStatementNm: duplicates[0].CIPRiskStatementNm,
                            CIPRiskTitleNm: risk.Title,
                            CIPRiskURI: process.env.CIP_URL + `/${risk.CIPId}/${risk.CIPType}/${risk.Level1RiskId}/${risk.Level2RiskId}/${risk.Level3RiskId}`,
                            CIPSubCategoryNm: (riskSubcategory ? riskSubcategory.MMCRiskCategory : ''), //from CIP
                            CIPType: risk.CIPType, //from CIP
                            ContractNbr: (contractNbr ? contractNbr : ''), //null from CIP
                            ContractNm: (contractNm ? contractNm : ''),
                            CreateDttm: moment(risk.RiskCreatedOn).utc().format(), //from CIP
                            CreateUserId: risk.RiskCreatedBy, //from CIP
                            CustomerNbr: customer ? customer.CustomerNbr : risk.FinancialClient, //from CIP
                            //CustomerNbr: risk.FinancialClient, //from CIP
                            CustomerNm: customer ? customer.CustomerNm : customerNm,
                            //CustomerNm: customerNm,
                            MasterClientNbr: masterclient ? masterclient.MasterClientNbr : risk.MasterClient, //from CIP
                            //MasterClientNbr: risk.MasterClient, //from CIP
                            MasterClientNm: masterclient ? masterclient.MasterClientNm : masterclientNm,
                            //MasterClientNm: masterclientNm,
                            RiskAssessmentQuestionKey: duplicates[0].RiskAssessmentQuestionKey,
                            RiskDesc: risk.Description, //from CIP
                            RiskLeadReviewDttm: duplicates[0].RiskLeadReviewDttm,
                            RiskLeadReviewStatusCd: duplicates[0].RiskLeadReviewStatusCd,
                            RiskNbr: duplicates[0].RiskNbr,
                            RiskQMDReviewDttm: duplicates[0].RiskQMDReviewDttm,
                            RiskQMDReviewInd: duplicates[0].RiskQMDReviewInd,
                            RiskRatingCd: isRatingUpdatedInMMC ? duplicates[0].RiskRatingCd : riskRating.CodeTxt,
                            RiskScore: duplicates[0].RiskScore,
                            RiskScoreNoCM: duplicates[0].RiskScoreNoCM,
                            RiskSourceCd: riskSource.CodeTxt, //from CIP "CIP"
                            RiskStatusCd: duplicates[0].RiskStatusCd,
                            RiskTypeCd: riskType.CodeTxt, //from CIP "Risk"
                            StatementArr: duplicates[0].StatementArr,
                            UpdateDttm: moment(risk.RiskUpdateOn).utc().format(), //from CIP
                            UpdateUserId: risk.RiskUpdateBy //from CIP
                        });

                        rows_orig_risksandmiti_update.push({
                            RawRiskDetailsKey: duplicates[0].RiskDetailsKey,
                            OrigCIPId: risk.CIPId,
                            OrigCIPRiskId: risk.Level3RiskId,
                            OrigCIPType: risk.CIPType,
                            OrigRiskDesc: risk.Description,
                            OrigMitigationDesc: risk.OriginalMitigation,
                            OrigRiskRatingCd: riskStatus.CodeTxt
                        });
                    }

                    console.log(`helper: getRisksAndMitigations(): stringified rows_risks_insert: ` + JSON.stringify(rows_risks_insert));
                    console.log(`helper: getRisksAndMitigations(): stringified rows_mitigations: ` + JSON.stringify(rows_mitigations));
                    console.log(`helper: getRisksAndMitigations(): stringified rows_risks_update: ` + JSON.stringify(rows_risks_update));
                    console.log(`helper: getRisksAndMitigations(): stringified rows_mitigations_update: ` + JSON.stringify(rows_mitigations_update));
                    console.log(`helper: getRisksAndMitigations(): stringified rows_orig_risksandmiti_insert: ` + JSON.stringify(rows_orig_risksandmiti_insert));
                    console.log(`helper: getRisksAndMitigations(): stringified rows_orig_risksandmiti_update: ` + JSON.stringify(rows_orig_risksandmiti_update));

                    rows.risksInsert = rows_risks_insert;
                    rows.mitigations = rows_mitigations;
                    rows.risksUpdate = rows_risks_update;
                    rows.mitigationsUpdate = rows_mitigations_update;
                    rows.origdetailsInsert = rows_orig_risksandmiti_insert;
                    rows.origdetailsUpdate = rows_orig_risksandmiti_update;
                    resolve(rows);
                }));
            });

            Promise.all(promises).then(res => {
                let data = {
                    risksInsert: [],
                    mitigations: [],
                    risksUpdate: [],
                    mitigationsUpdate: [],
                    origdetailsInsert: [],
                    origdetailsUpdate: []
                };
                res.forEach(r => {
                    data.risksInsert = data.risksInsert.concat(r.risksInsert)
                    data.mitigations = data.mitigations.concat(r.mitigations)
                    data.risksUpdate = data.risksUpdate.concat(r.risksUpdate)
                    data.mitigationsUpdate = data.mitigationsUpdate.concat(r.mitigationsUpdate)
                    data.origdetailsInsert = data.origdetailsInsert.concat(r.origdetailsInsert)
                    data.origdetailsUpdate = data.origdetailsUpdate.concat(r.origdetailsUpdate)
                });
                resolve(data);
            });
        } catch (error) {
            console.log(`ERROR: helper: getRisksAndMitigations(): error: ` + error);
            resolve();
            throw error
        }
    });
}
// [END getRisksAndMitigations]

// [START getCIPRisks]
/**
 * getCIPRisks
 *
 * @param {json} rebarResponse Array of events received from the request.
 */
getCIPRisks = (rebarResponse) => {
    console.log(`helper: getCIPRisks(): stringified rebarResponse: ` + JSON.stringify(rebarResponse));
    try {
        let rows_risks = [];
        let messages = rebarResponse.Messages;
        if (messages.length > 0) {
            for (var i of messages) {
                let risk = i.MessageBody;
                rows_risks.push({
                    RiskAuditKey: uuid(),
                    AuditDate: moment(risk.AuditDate).format("YYYY-MM-DD"),
                    Category: risk.Category,
                    CIPId: risk.CIPId,
                    CIPType: risk.CIPType,
                    Contract: risk.Contract,
                    ContractManager: risk.ContractManager ? risk.ContractManager : null,
                    Description: risk.Description,
                    FinancialClient: risk.FinancialClient,
                    Level1Risk: risk.Level1Risk,
                    Level1RiskId: risk.Level1RiskId,
                    Level2Risk: risk.Level2Risk,
                    Level2RiskId: risk.Level2RiskId,
                    Level3Risk: risk.Level3Risk,
                    Level3RiskId: risk.Level3RiskId,
                    MasterClient: risk.MasterClient,
                    Opportunity: risk.Opportunity,
                    OriginalMitigation: risk.OriginalMitigation,
                    RAGStatus: risk.RAGStatus,
                    RiskCreatedBy: risk.RiskCreatedBy,
                    RiskCreatedOn: moment(risk.RiskCreatedOn).format("YYYY-MM-DD"),
                    RiskUpdateBy: risk.RiskUpdateBy,
                    RiskUpdateOn: moment(risk.RiskUpdateOn).format("YYYY-MM-DD"),
                    Sent: risk.Sent ? moment(risk.Sent).format("YYYY-MM-DD") : null,
                    Source: risk.Source,
                    Status: risk.Status,
                    Subcategory: risk.Subcategory,
                    Title: risk.Title,
                    Type: risk.Type,
                    CreateDttm: new Date(),
                    CreateUserId: 'rebar.subscriber',
                    UpdateDttm: new Date(),
                    UpdateUserId: 'rebar.subscriber'
                });
                console.log(`helper: getCIPRisks(): stringified rows_risks: ` + JSON.stringify(rows_risks));
            }
            return rows_risks;
        }
    } catch (error) {
        console.log(`helper: getCIPRisks(): error: ` + error);
        throw error
    }
}
// [END getCIPRisks]


// [START Methods for formatting payload for REBAR response]

formatRebarPayload = (message, action, reason) => {
    var payload = new Object();
    var messageResponsesArray = [];
    var messageResponse = formatMessageResponses(message, action, reason);

    messageResponsesArray.push(messageResponse);
    payload.messageResponses = messageResponsesArray;
    return payload;
}

formatMessageResponses = (message, action, reason) => {    
    var messageRes = new Object();
    messageRes.Action = action;
    messageRes.MessageId = message && message.Messages && message.Messages[0] ? message.Messages[0].MessageId : uuid();
    messageRes.Reason = (action == 0 ? "" : reason);
    messageRes.PublishMessages = formatPublishMessages(message);    
    return messageRes;
}

formatPublishMessages = (message) => {
    var publishMessages = new Object();
    publishMessages.Messages = null;
    publishMessages.RequestId = message && message.Messages && message.Messages[0] ? message.Messages[0].Headers.RequestId: uuid();    
    return publishMessages;
};

CreateMMCCommentsPayload = (CIPOppID, CIPMSAID, RiskId) => {
    let pl = {
        "EventName": "realign_cip",
        "CIPOppID": CIPOppID,
        "CIPMSAID": CIPMSAID,
        "Level3RiskId": RiskId
    }
    MMC_COMMENTS_PAYLOAD.Messages[0].Body = pl;
    return MMC_COMMENTS_PAYLOAD;
}

UpdateRiskRating = async (RiskDetailsKey, rating, RiskRatingCd) => {
    let res = await repository.updateRiskRating(RiskDetailsKey, rating, RiskRatingCd);
    console.log("helper: updateRiskRating result:", res);
}

// [END Methods for formatting payload for REBAR]

// [START GetAADToken]
function GetAADToken() {
    return new Promise(function (resolve, reject) {
        const options = {
            url: `https://login.microsoftonline.com/${process.env.TENANT}/oauth2/token`,
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            form: {
                'client_id': process.env.AAD_CLIENT_ID,
                'client_secret': process.env.AAD_SECRET,
                'grant_type': 'client_credentials',
                'resource': process.env.AAD_RESOURCE
            },
            time: true
        };
        let AppToken = Cache.get("AAD_access_token");
        if (AppToken) {
            resolve(AppToken)
            return;
        }
        request(options, function (error, response, body) {
            if (response.statusCode != 201) {
                const token = JSON.parse(body).access_token;
                Cache.set("AAD_access_token", token);
                resolve(token);
            }
        });
    });
}
// [END GetAADToken]

// [START publishMessage]
async function publishMessage(message) {
    console.log("publishMessage starts");
    try {
        let token = await GetAADToken();
        console.log("token: ", token);
        console.log("message: ", JSON.stringify(message));

        return new Promise(function (resolve, reject) {
            console.log("process.env.publisherURL: ", process.env.publisherURL);
            const options = {
                url: process.env.publisherURL,
                method: 'POST',
                headers: {
                    'Authorization': "Bearer " + token
                },
                json: message
            };
            console.log("options: " + JSON.stringify(options));
            request(options, function (error, response, body) {
                console.log("Publisher Response: " + response);
                console.log("Publisher Body: " + JSON.stringify(body));

                if (error) {
                    console.log('error: ' + error);
                    reject(error);
                } else {
                    let res = body;
                    console.log('res: ' + res);
                    resolve(res);
                }
                console.log("publishMessage ends");
            });
        })
    } catch (error) {
        console.log(error);
    }
}
// [END publishMessage]
module.exports = {
    getRebarMessage,
    getRisksAndMitigations,
    getCIPRisks,
    formatRebarPayload
}