const helper = require('./subscriber.helper');
const repository = require('./subscriber.repository');
const app_constants = require('./app.constants');
const _CONST = app_constants.appConstants();
const _ = require('lodash');
const request = require('request');

const uuid = require('uuidv4');
const TRANSACTIONID = uuid();

saveRebarMessage = async (rebarMessage) => {
    let row_message = helper.getRebarMessage(rebarMessage);
    await repository.saveRebarMessage(row_message);
}

processRebarMessage = async () => {
    let unprocessedMessage = await repository.getUnprocessedMessage();
    for (let x = 0; x < unprocessedMessage.length; x++) {
        await repository.MarkInProgress(unprocessedMessage[x], TRANSACTIONID);
        let innerResult = await helper.getRisksAndMitigations(unprocessedMessage[x]);
        let isValid = await repository.isTransactionValid(unprocessedMessage[x], TRANSACTIONID);
        if (isValid) {
            await repository.createRisks(innerResult);
            await repository.updateStatus(unprocessedMessage[x], TRANSACTIONID);
            console.log("updateStatus", unprocessedMessage[x], TRANSACTIONID)
        }
        
    }
    await repository.updateOldFailedStatus();
}

module.exports = {
    saveRebarMessage,
    processRebarMessage
}