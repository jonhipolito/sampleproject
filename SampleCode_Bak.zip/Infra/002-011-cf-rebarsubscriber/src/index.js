/**
 * Responds to any HTTP request.
 *
 * @param {!express:Request} req HTTP request context.
 * @param {!express:Response} res HTTP response context.
 */

'use strict'

const service = require('./subscriber.service');
const helper = require('./subscriber.helper');
const app_constants = require('./app.constants');
const _CONST = app_constants.appConstants();

function Authenticate(token) {
        return new Promise(resolve => {
                var jwt = require('jsonwebtoken');
                var jwksClient = require('jwks-rsa');
                var client = jwksClient({
                        jwksUri: 'https://login.microsoftonline.com/common/discovery/v2.0/keys'
                });

                function getKey(header, callback) {
                        client.getSigningKey(header.kid, function (err, key) {
                                var signingKey = key.publicKey || key.rsaPublicKey;
                                callback(null, signingKey);
                        });
                }
                token = token.replace("Bearer ", "");
                jwt.verify(token, getKey, {
                        issuer: [
                                "https://sts.windows.net/f3211d0e-125b-42c3-86db-322b19a65a22/",
                                "https://sts.windows.net/e0793d39-0939-496d-b129-198edd916feb/"
                        ]
                }, function (err, decoded) {
                        resolve(decoded);
                });
        })

}

exports.processMessageData = async (req, res) => {
        var response;
        try {
                if (req.method !== 'POST') {
                        const error = new Error('Only POST requests are accepted');
                        error.code = 405;
                        throw error;
                }                
                console.log("Stringified req.body: " + JSON.stringify(req.body.Messages));
                if(req.body.Messages) {
                        await service.saveRebarMessage(req.body);
                }
                else {
                        console.log("NO BODY");
                }
                
                await service.processRebarMessage();

        } catch (error) {
                console.log("Index - Catch", error);
        } finally {
                response = helper.formatRebarPayload(req.body, _CONST.NORMAL_ACTION);
                console.log("finally", response);
                res.set('Access-Control-Allow-Origin', '*');
                res.send(response);
        }
}
