appConstants = () => {
    return {
        CIP_RISK: `CIP Risk`,
        NO_CM_ASSIGNED: `No CM Assigned`,
        APPROVED_ON_CIP: `Approved on CIP`,
        NO_DUE_DATE: `No Due date`,
        DEAD_LETTER_REASON: ``,
        DEAD_LETTER_ACTION: 2,
        NORMAL_ACTION: 0,
        REBAR_CREATE_USER: `rebar`,
        STATUS_UNPROCESSED: `unprocessed`,
        STATUS_PROCESSED: `processed`,
        STATUS_INPROGRESS: `in-progress`,
        TODO_INSERT: `insert`,
        TODO_UPDATE: `update`,
        TODO_DONOTHING: 'donothing',
        APPEND_RISK_DESC: 'append_risk_desc',
        APPEND_RISK_MITI: 'append_risk_miti',
        UPDATE_RISK_RATING: 'update_risk_rating'
    };
}

module.exports = {
    appConstants
}