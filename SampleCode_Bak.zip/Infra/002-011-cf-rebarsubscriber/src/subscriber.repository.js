//const helper = require('./subscriber.helper');
const app_constants = require('./app.constants');
const _CONST = app_constants.appConstants();
const {
    Spanner
} = require('@google-cloud/spanner');
const projectId = process.env.X_GOOGLE_GCLOUD_PROJECT,
    instanceId = 'si-27354-mmc',
    databaseId = 'db-27354-mmc-db';

const spanner = new Spanner({
    projectId: projectId,
});
const NodeCache = require("node-cache");
const Cache = new NodeCache({
    stdTTL: 1800,
    checkperiod: 100
});

// Gets a reference to a Cloud Spanner instance and database
const instance = spanner.instance(instanceId);
const database = instance.database(databaseId);

// [START saveRebarMessage]
/**
 * Insert message in CIPMMCRiskAudit table
 *
 * @param {Array} message
 */
saveRebarMessage = async function (row_message) {
    const CIPMMCRiskAuditTable = database.table(`CIPMMCRiskAudit`);
    try {
        if (row_message.length > 0) {
            let rows = await CIPMMCRiskAuditTable.insert(row_message);
            console.log(`CIPMMCRiskAudit: ${rows.length} row(s) inserted.`);
            console.log(`repository: saveRebarMessage: rows inserted: ` + JSON.stringify(rows));
            return rows;
        } else {
            console.log(`CIPMMCRiskAudit: No rows inserted`)
        }
    } catch (error) {
        console.log(`repository: saveRebarMessage: ` + error);
        throw error;
    } finally {
        console.log(`saveRebarMessage ends`);
    }
}
// [END saveRebarMessage]

// [START getUnprocessedMessage]
/**
 * Get unprocessed messages
 *
 */
getUnprocessedMessage = async function () {
    console.log(`getUnprocessedMessage starts`);
    const query = {
        sql: `SELECT * FROM CIPMMCRiskAudit WHERE Status = @eventStatus`,
        params: {
            eventStatus: _CONST.STATUS_UNPROCESSED,
        },
    };
    // Queries rows from the CIPMMCRiskAudit table
    try {
        let rows_unprocessed = [];
        const [rows] = await database.run(query);
        console.log("rows:", rows.length);
        rows.forEach(row => {
            const unprocessed = row.toJSON();
            rows_unprocessed.push(unprocessed);
        });
        console.log(`repository: getUnprocessedMessage: stringified rows_unprocessed: ` + JSON.stringify(rows_unprocessed));
        return rows_unprocessed;
    } catch (error) {
        console.log("ERROR repository: getUnprocessedMessage: " + error);
        throw error;
    } finally {
        console.log(`getUnprocessedMessage ends`);
    }
}
// [END getUnprocessedMessage]



// [START createRisks]
/**
 * Insert events in createRisks table
 *
 * @param {Array} rows
 */
createRisks = async function (rows) {
    console.log(`createRisks() started`);

    // Instantiate Spanner table objects
    const MMCRiskDetailsTable = database.table(`RiskDetails`);
    const MMCRiskMitigationTable = database.table(`RiskMitigation`);
    const MMCRawRiskDetailsTable = database.table(`RawRiskDetails`);

    // Inserts rows into RiskDetails & RiskMitigation tables 
    try {
        let risksInsert = rows.risksInsert;
        let mitigations = rows.mitigations;
        let risksUpdate = rows.risksUpdate;
        let mitigationsUpdate = rows.mitigationsUpdate;
        let origdetailsInsert = rows.origdetailsInsert;
        let origdetailsUpdate = rows.origdetailsUpdate;

        console.log(`repository: createRisks: risksInsert: ` + JSON.stringify(risksInsert));
        console.log(`repository: createRisks: mitigations: ` + JSON.stringify(mitigations));
        console.log(`repository: createRisks: risksUpdate: ` + JSON.stringify(risksUpdate));
        console.log(`repository: createRisks: mitigationsUpdate: ` + JSON.stringify(mitigationsUpdate));
        console.log(`repository: createRisks: origdetailsInsert: ` + JSON.stringify(origdetailsInsert));
        console.log(`repository: createRisks: origdetailsUpdate: ` + JSON.stringify(origdetailsUpdate));

        if (rows != null) {
            if (rows.risksInsert && rows.risksInsert.length > 0) {
                let inserted_risksDetails = await MMCRiskDetailsTable.insert(rows.risksInsert);
                console.log(`RiskDetails: ${inserted_risksDetails.length} row(s) inserted.`);
            }
            if (rows.mitigations && rows.mitigations.length > 0) {
                let inserted_mitigations = await MMCRiskMitigationTable.insert(rows.mitigations);
                console.log(`RiskMitigation: ${inserted_mitigations.length} row(s) inserted.`);
            }
            if (rows.risksUpdate && rows.risksUpdate.length > 0) {
                let updated_risksDetails = await MMCRiskDetailsTable.update(rows.risksUpdate);
                console.log(`RiskDetails: ${updated_risksDetails.length} row(s) updated.`);
            }
            if (rows.mitigationsUpdate && rows.mitigationsUpdate.length > 0) {
                let updated_mitigation = await MMCRiskMitigationTable.update(rows.mitigationsUpdate);
                console.log(`RiskMitigation: ${updated_mitigation.length} row(s) updated.`);
            }
            if (rows.origdetailsInsert && rows.origdetailsInsert.length > 0) {
                let inserted_rawrisksDetails = await MMCRawRiskDetailsTable.insert(rows.origdetailsInsert);
                console.log(`RawRiskDetails: ${inserted_rawrisksDetails.length} row(s) inserted.`);
            }
            if (rows.origdetailsUpdate && rows.origdetailsUpdate.length > 0) {
                let updated_rawrisksDetails = await MMCRawRiskDetailsTable.update(rows.origdetailsUpdate);
                console.log(`RawRiskDetails: ${updated_rawrisksDetails.length} row(s) updated.`);
            }

            return rows;
        } else {
            console.log(`No rows inserted`);
        }
    } catch (error) {
        console.log(`repository: createRisks: ` + error);
        throw new Error(`repository: createRisks: ` + error);
    } finally {
        console.log(`createRisks ends`);
    }
}
// [END createRisks]

// [START getMMCRiskMapping]
/**
 * Query CIPMMCRiskMapping table
 *
 * @param {Array} cipLevelArr
 */
getMMCRiskMapping = async (cipLevelArr) => {
    console.log(`repository: getMMCRiskMapping() starts`);
    try {
        let cipLevel = ``;
        for (var i of cipLevelArr) {
            if (i != null) {
                cipLevel += `rm.CIPRiskLevel = '` + EscapeSpannerString(i) + `' OR `;
            }
        }
        cipLevel = (cipLevel.trim()).slice(0, -2);
        const query = {
            sql: `SELECT rm.OrderTree, rm.CIPRiskLevel, rm.MMCRiskCategory 
              FROM CIPMMCRiskMapping rm
              WHERE ` + cipLevel
        };

        let mapping = await runQuery(query);

        console.log(`mapping: ` + JSON.stringify(mapping));
        console.log(`repository: getMMCRiskMapping() ends`);

        return mapping;
    } catch (error) {
        console.log(`ERROR: repository: getMMCRiskMapping(): error: ` + error);
        throw error
    }
}
// [END getMMCRiskMapping]

// [START getCodes]
/**
 * Query CodeDetail table
 *
 * @param {Array} codeTxtArr
 */
getCodes = async (codeTxtArr) => {
    console.log(`repository: getCodes() starts`);
    try {
        let codeTxts = ``;
        for (var i of codeTxtArr) {
            if (i != null) {
                codeTxts += `cd.CodeHeaderId = ` + EscapeSpannerString(i) + ` OR `;
            }
        }
        codeTxts = (codeTxts.trim()).slice(0, -2);
        const query = {
            sql: `SELECT cd.CodeDetailId, cd.CodeHeaderId, cd.CodeTxt, cd.PrimaryDecodeTxt, cd.SecondaryDecodeTxt, cd.ParentId 
              FROM CodeDetail cd
              WHERE ` + codeTxts + `AND CodeDetailStatusInd = 'Y'`
        };
        let codeDetail = await runQuery(query);
        console.log(`codeDetail: ` + JSON.stringify(codeDetail));
        return codeDetail;
    } catch (error) {
        console.log(`ERROR: repository: getCodes(): error: ` + error);
        throw error;
    }
}
// [END getCodes]

getSameRecord = async (risk, contractNbr, customer) => {
    console.log(`repository: getSameRecord() starts`, risk);
    try {
        let customerNbr = "";
        if (risk.CIPType == "OPP") {
            if (!contractNbr) {
                contractNbr = "";
                if (risk.FinancialClient) {
                    customerNbr = risk.FinancialClient;
                }
            } else {
                customerNbr = customer.CustomerNbr;
            }
        } else {
            contractNbr = "";
            if (risk.FinancialClient) {
                customerNbr = risk.FinancialClient;
            }
        }

        const query = {
            sql: `Select *
                    FROM RiskDetails rd 
                    INNER JOIN RiskMitigation rm 
                        ON rd.RiskDetailsKey = rm.RiskDetailsKey
                    INNER JOIN RawRiskDetails rrd
                        ON rd.RiskDetailsKey = rrd.RawRiskDetailsKey                
                    WHERE rd.CIPId = ${risk.CIPId} 
                    AND rd.CIPType = '${risk.CIPType}'
                    AND rd.ContractNbr = '${contractNbr}' 
                    AND rd.CustomerNbr = '${customerNbr}' 
                    AND rd.CIPRiskId = ${risk.Level3RiskId}
                    AND rm.MitigationStatusCd = '${_CONST.APPROVED_ON_CIP}'`
        };

        let record = await runQuery(query);
        console.log(`repository: getSameRecord(): record: ` + JSON.stringify(record));
        return record;
    } catch (error) {
        console.log(`ERROR: repository: getSameRecord(): error: ` + error);
        throw new Error(error);
    }
}

getDuplicateRecords = async (risk, CIPRatingNm) => {
    console.log(`repository: getDuplicateRecords() starts`, risk);
    try {
        const query = {
            sql: `Select rd.* from RiskDetails rd
                INNER JOIN RiskMitigation rm ON rm.RiskDetailsKey = rd.RiskDetailsKey
                INNER JOIN RawRiskDetails rrd ON rd.RiskDetailsKey = rrd.RawRiskDetailsKey      
                WHERE rrd.OrigMitigationDesc = @OriginalMitigation AND rrd.OrigRiskDesc = @Description AND rd.CIPRatingNm = @CIPRatingNm`,
                params: {
                    OriginalMitigation: risk.OriginalMitigation,
                    Description: risk.Description,
                    CIPRatingNm: CIPRatingNm
                }
        };

        let record = await runQuery(query);
        console.log(`repository: getDuplicateRecords(): record: ` + JSON.stringify(record));
        return record;
    } catch (error) {
        console.log(`ERROR: repository: getDuplicateRecords(): error: ` + error);
        throw error;
    }
}

updateRiskRating = async (key, CIPRatingNm, RiskRatingCd) => {
    console.log(`repository: updateRiskRating() starts`, RiskRatingCd);
    try {
        let record = await database.runPartitionedUpdate({
            sql: `Update RiskDetails
                    SET CIPRatingNm = @CIPRatingNm,
                    RiskRatingCd = @RiskRatingCd
                    WHERE RiskDetailsKey = '${key}'`,

            params: {
                CIPRatingNm: CIPRatingNm,
                RiskRatingCd: RiskRatingCd
            },
        });
        console.log(`repository: updateRiskRating(): record: ` + JSON.stringify(record));
        return record;
    
    } catch (error) {
        console.log(`ERROR: repository: updateRiskRating(): error: ` + error);
        throw new Error(error);
    }
}
// getRecordToUpdate = async (risk) => {
//     console.log(`repository: getRecordToUpdate() starts`, risk);
//     try {
//         const query = {
//             sql: `Select * from RiskDetails                
//                     WHERE CIPId = '${risk.CIPId}' AND CIPRiskId = ${risk.Level3RiskId}`
//         };

//         let record = await runQuery(query);
//         console.log(`repository: getSameRecord(): record: ` + JSON.stringify(record));
//         return record;
//     } catch (error) {
//         console.log(`ERROR: repository: getSameRecord(): error: ` + error);
//         throw new Error(error);
//     }
// }

// [START runQuery]
/**
 * @param {ExecuteSqlRequest} query
 *
 */
runQuery = async (query) => {
    try {
        const [rows] = await database.run(query);
        return rows.map(o => o.toJSON());
    } catch (err) {
        console.log("runQuery - catch", err);
        console.log("runQuery - catch", query);
        throw err;
    } finally {

    }
}
// [END runQuery]

MarkInProgress = async (message, transactionId) => {
    try {
        await database.runPartitionedUpdate({
            sql: `UPDATE CIPMMCRiskAudit 
            SET Status = @msgStatus 
            WHERE CIPMMCRiskAuditKey = '${message.CIPMMCRiskAuditKey}' 
            AND Status = '${_CONST.STATUS_UNPROCESSED}'`,
            params: {
                msgStatus: transactionId,
            },
        });
        console.log("MarkInProgress END", transactionId)
    } catch (error) {
        console.log(`ERROR: repository: MarkInProgress(): error: ` + error);
        throw error
    }
}
// [START updateStatus]
/**
 * Insert events in CIPMMCRiskAudit table
 *
 * @param {Array} unprocessedMesages Array of unpublished events
 */
updateStatus = async (message, transactionId) => {

    try {
        console.log("updateStatus", {
            sql: `UPDATE CIPMMCRiskAudit 
            SET Status = @msgStatus 
            WHERE CIPMMCRiskAuditKey = '${message.CIPMMCRiskAuditKey}' 
            AND Status = '${transactionId}'`,
            params: {
                msgStatus: _CONST.STATUS_PROCESSED,
            },
        })
        await database.runPartitionedUpdate({
            sql: `UPDATE CIPMMCRiskAudit 
            SET Status = @msgStatus 
            WHERE CIPMMCRiskAuditKey = '${message.CIPMMCRiskAuditKey}' 
            AND Status = '${transactionId}'`,
            params: {
                msgStatus: _CONST.STATUS_PROCESSED,
            },
        });
        console.log("updateStatus END", transactionId)
    } catch (error) {
        console.log(`ERROR: repository: updateStatus(): error: ` + error);
        throw error
    }
}

updateOldFailedStatus = async () => {
    try {
        await database.runPartitionedUpdate({
            sql: `UPDATE CIPMMCRiskAudit 
            SET Status = @Status 
            WHERE Status != @processed
            AND TIMESTAMP_DIFF(CreateDttm,CURRENT_TIMESTAMP, DAY)  < -1`,
            params: {
                Status: _CONST.STATUS_UNPROCESSED,
                processed: _CONST.STATUS_PROCESSED
            },
        });
    } catch (error) {
        console.log(`ERROR: repository: updateStatus(): error: ` + error);        
    }
}
// [END updateStatus]
isTransactionValid = async (message, transactionId) => {
    try {
        const query = {
            sql: `SELECT Status FROM CIPMMCRiskAudit             
            WHERE CIPMMCRiskAuditKey = '${message.CIPMMCRiskAuditKey}'
            AND Status = '${transactionId}'`
        };
        let record = await runQuery(query);
        console.log("isTransactionValid - ", record && record.length > 0, ` - ${transactionId}`)
        return record && record.length > 0;
    } catch (error) {
        console.log(`ERROR: repository: isTransactionValid(): error: ` + error);
        throw error
    }
}
getMRDRWBSElementDumpByOpp = async (oppId) => {
    try {
        const query = {
            sql: `SELECT RTRIM(WBSExternalNbr) as WBSExternalNbr FROM MRDRWBSElementDump 
            WHERE REGEXP_EXTRACT(RTRIM(GBDDOpportunityId), r"^[0-9]*$")   <> '' 
            AND CAST(RTRIM(GBDDOpportunityId) AS INT64) = ${Number.parseInt(oppId)} LIMIT 2`
        };
        let record = await runQuery(query);
        if (record.length == 1) {
            return record[0];
        }
        else {
            return null;
        }
    } catch (error) {
        console.log(`ERROR: repository: getMRDRWBSElementDumpByOpp(): error: ` + error);
        throw error
    }
}

getMRDRContractLineItemDumpByWBS = async (wbs) => {
    try {
        const query = {
            sql: `SELECT ContractCd FROM MRDRContractLineItemDump WHERE RTRIM(WBSElementNbr) = '${wbs}' LIMIT 2`
        };
        var record = await runQuery(query);
        if (record.length == 1) {
            return record[0].ContractCd;
        }
        else {
            return null;
        }
        return record;
    } catch (error) {
        console.log(`ERROR: repository: getMRDRContractLineItemDumpByWBS(): error: ` + error);
        throw error
    }
}

getContractByNbr = async (contractNbr) => {
    try {
        const query = {
            sql: `SELECT ContractNm FROM Contract WHERE RTRIM(ContractNbr) = '${contractNbr}' LIMIT 1`
        };
        let record = await runQuery(query);
        if (record.length > 0) {
            return record[0].ContractNm;
        }
        else {
            return "";
        }
        return record;
    } catch (error) {
        console.log(`ERROR: repository: getContractByNbr(): error: ` + error);
        throw error
    }
}

getCustomerNmByNbr = async (customerNbr) => {
    try {
        const query = {
            sql: `SELECT CustomerNm FROM Customer WHERE RTRIM(CustomerNbr) = '${customerNbr}' LIMIT 1`
        };
        let record = await runQuery(query);
        if (record.length > 0) {
            return record[0].CustomerNm;
        }
        else {
            return "";
        }
        return record;
    } catch (error) {
        console.log(`ERROR: repository: getCustomerNmByNbr(): error: ` + error);
        throw error
    }
}

getMasterClientNmByNbr = async (masterclientNbr) => {
    try {
        const query = {
            sql: `SELECT MasterClientNm FROM MasterClient WHERE RTRIM(MasterClientNbr) = '${masterclientNbr}' LIMIT 1`
        };
        let record = await runQuery(query);
        if (record.length > 0) {
            return record[0].MasterClientNm;
        }
        else {
            return "";
        }
        return record;
    } catch (error) {
        console.log(`ERROR: repository: getMasterClientNmByNbr(): error: ` + error);
        throw error
    }
}

getCustomerNbrByCon = async (contractNbr) => {
    try {
        const query = {
            sql: `SELECT CustomerNbr FROM Contract WHERE RTRIM(ContractNbr) = '${contractNbr}' LIMIT 1`
        };
		
        let record = await runQuery(query);
        if (record.length > 0) {
			const query2 = {
				sql: `SELECT CustomerNbr, CustomerNm FROM Customer WHERE RTRIM(CustomerNbr) = '${record[0].CustomerNbr}' LIMIT 1`
			};
			let record2 = await runQuery(query2);
			if (record2.length > 0) { 
				return record2[0];
			} else {
                return null;
            }
        }
        else {
            return null;
        }
    } catch (error) {
        console.log(`ERROR: repository: getCustomerNbrByCon(): error: ` + error);
        throw error
    }
}

getMasterClientByCus = async (customerNbr) => {
    try {
		const query = {
            sql: `SELECT MasterClientNbr FROM Customer WHERE RTRIM(CustomerNbr) = '${customerNbr}' LIMIT 1`
        };
       
        let record = await runQuery(query);
        if (record.length > 0) {
			const query2 = {
				sql: `SELECT MasterClientNbr, MasterClientNm FROM MasterClient WHERE RTRIM(MasterClientNbr) = '${record[0].MasterClientNbr}' LIMIT 1`
			};
			let record2 = await runQuery(query2);
            if (record2.length > 0) { 
				return record2[0];
			} else {
                return null;
            }
        }
        else {
            return null;
        }
    } catch (error) {
        console.log(`ERROR: repository: getMasterClientByCus(): error: ` + error);
        throw error
    }
}

generateRiskNbr = async () => {
    try {
        const query = {
            sql: `SELECT UNIX_MICROS(CURRENT_TIMESTAMP()) AS RiskNbr`
        };
        let record = await runQuery(query);
        if (record.length > 0) {
            return record[0].RiskNbr;
        }
        else {
            return "0";
        }
    } catch (error) {
        console.log(`ERROR: repository: generateRiskNbr(): error: ` + error);
        throw error
    }
}

EscapeSpannerString = (query) => {
    var s = query;
    if (query.indexOf("'") > -1) {
        s = query.replace(/'/g, "\\'");
        console.log("ssss", s);
    }
    return s
}
module.exports = {
    saveRebarMessage,
    getUnprocessedMessage,
    updateStatus,
    createRisks,
    getMMCRiskMapping,
    getCodes,
    getSameRecord,
    getDuplicateRecords,
    updateRiskRating,
    MarkInProgress,
    isTransactionValid,
    getMRDRWBSElementDumpByOpp,
    getMRDRContractLineItemDumpByWBS,
    getContractByNbr,
    EscapeSpannerString,
    getCustomerNmByNbr,
    getMasterClientNmByNbr,
    getCustomerNbrByCon,
    getMasterClientByCus,
    generateRiskNbr,
    updateOldFailedStatus
}