exports.processOGOUCSG = async (req, res) => {
    // Imports the Google Cloud client library
    const { Spanner } = require('@google-cloud/spanner');
    const uuid = require('uuidv4');

    const projectId = process.env.X_GOOGLE_GCLOUD_PROJECT;
    const instanceId = 'si-27354-mmc';
    const databaseId = 'db-27354-mmc-db';

    // Creates a client
    const spanner = new Spanner({
        projectId: projectId,
    });

    // Gets a reference to a Cloud Spanner instance and database
    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);

    const ogTable = database.table('OperatingGroup');
    const ouTable = database.table('OperatingUnit');
    const csgTable = database.table('ClientServiceGroup');

    var errFlag = false;

    //async function queryData() {

    try {
        console.log("start: OGOUCSG");
        // // NORMALIZING OPERATING GROUP: START

        [ogInsertRowsInit] = await database.run({
            sql:
                `SELECT RTRIM(OperatingGroupCd) AS OperatingGroupCd , RTRIM(OperatingGroupNm) AS OperatingGroupNm FROM OperatingGroup`
        });


        [ogUpdateRows] = await database.run({
            sql:
                `SELECT OperatingGroupKey, RTRIM(A.OperatingGroupCd) AS OperatingGroupCd , RTRIM(A.OperatingGroupNm) AS OperatingGroupNm 
                FROM OperatingGroupDump A 
                INNER JOIN OperatingGroup 
                USING (OperatingGroupCd) WHERE A.UpdatedInd = 'Y' 
                EXCEPT ALL SELECT B.OperatingGroupKey, RTRIM(B.OperatingGroupCd) , RTRIM(B.OperatingGroupNm) FROM OperatingGroup B`
        });

        if (ogInsertRowsInit.length == 0 || ogInsertRowsInit.length == undefined) {
            [ogDumpInsertRows] = await database.run({
                sql:
                    `SELECT RTRIM(OperatingGroupCd) AS OperatingGroupCd , RTRIM(OperatingGroupNm) AS OperatingGroupNm FROM OperatingGroupDump`
            });

            let rows = [];
            if (ogDumpInsertRows.length > 0) {
                ogDumpInsertRows.forEach(row => {
                    let tempRow = row.toJSON();
                    tempRow.OperatingGroupKey = uuid();
                    tempRow.DummyInd = 'N';
                    rows.push(addUserDateandTime(tempRow));
                });

                //transaction.insert('OperatingGroup', rows);

                await ogTable.insert(rows);

                console.log(`OperatingGroup: ${ogDumpInsertRows.length} row/s inserted`);
            }

        }

        if (ogUpdateRows.length > 0) {
            let rows = [];

            ogUpdateRows.forEach(row => {
                let tempRow = row.toJSON();
                //tempRow.DummyInd = 'N';
                rows.push(addUserDateandTime(tempRow));
            });

            //transaction.update('OperatingGroup', rows);

            await ogTable.update(rows);

            console.log(`OperatingGroup: ${ogUpdateRows.length} row/s updated`);
        }

        [ogInsertRows] = await database.run({
            sql:
                `SELECT RTRIM(A.OperatingGroupCd) AS OperatingGroupCd , RTRIM(A.OperatingGroupNm) AS OperatingGroupNm FROM OperatingGroupDump A LEFT JOIN OperatingGroup B USING (OperatingGroupCd) WHERE B.OperatingGroupCd IS NULL AND A.UpdatedInd = 'Y'`
        });

        if (ogInsertRows.length > 0) {
            let rows = [];

            ogInsertRows.forEach(row => {
                let tempRow = row.toJSON();
                tempRow.OperatingGroupKey = uuid();
                tempRow.DummyInd = 'N';
                rows.push(addUserDateandTime(tempRow));
            })

            //transaction.insert('OperatingGroup', rows);

            await ogTable.insert(rows);

            console.log(`OperatingGroup: ${ogInsertRows.length} row/s inserted`);
        }

        //NORMALIZING OPERATING GROUP: END

        //NORMALIZING OPERATING UNIT: START


        [ouInsertRowsInit] = await database.run({
            sql:
                `SELECT RTRIM(OperatingUnitCd) AS OperatingUnitCd , RTRIM(OperatingGroupCd) AS OperatingGroupCd FROM OperatingUnit`
        });

        [ouUpdateRows] = await database.run({
            sql:
                `SELECT OperatingUnitKey, RTRIM(A.OperatingUnitCd) AS OperatingUnitCd , RTRIM(B.OperatingGroupCd) AS OperatingGroupCd , RTRIM(A.OperatingUnitDesc) AS OperatingUnitNm FROM OperatingUnitDump AS A 
                INNER JOIN OperatingGroup AS B ON RTRIM(A.OperatingGroupCd) = RTRIM(B.OperatingGroupCd)
                INNER JOIN OperatingUnit AS C ON RTRIM(A.OperatingUnitCd) = RTRIM(C.OperatingUnitCd)
                WHERE (A.UpdatedInd = 'Y') EXCEPT ALL SELECT D.OperatingUnitKey, TRIM(D.OperatingUnitCd) AS OperatingUnitCd , RTRIM(D.OperatingGroupCd) AS OperatingGroupCd , RTRIM(D.OperatingUnitNm) AS OperatingUnitNm  FROM OperatingUnit D`
        });

        if (ouInsertRowsInit.length == 0 || ouInsertRowsInit.length == undefined) {

            [ouDumpInsertRows] = await database.run({
                sql:
                    `SELECT RTRIM(A.OperatingUnitCd) AS OperatingUnitCd , RTRIM(B.OperatingGroupCd) AS OperatingGroupCd 
                        , RTRIM(A.OperatingUnitDesc) AS OperatingUnitNm FROM OperatingUnitDump AS A 
                        INNER JOIN OperatingGroup AS B ON RTRIM(A.OperatingGroupCd) = RTRIM(B.OperatingGroupCd)`
            });

            let rows = [];
            if (ouDumpInsertRows.length > 0) {
                ouDumpInsertRows.forEach(row => {
                    let tempRow = row.toJSON();
                    tempRow.OperatingUnitKey = uuid();
                    tempRow.DummyInd = 'N';
                    rows.push(addUserDateandTime(tempRow));
                });

                //transaction.insert('OperatingUnit', rows);

                await ouTable.insert(rows);

                console.log(`OperatingUnit: ${ouDumpInsertRows.length} row/s inserted`);
            }

        }

        if (ouUpdateRows.length > 0) {
            let rows = [];

            ouUpdateRows.forEach(row => {
                let tempRow = row.toJSON();
                //tempRow.DummyInd = 'N';
                rows.push(addUserDateandTime(tempRow));
            });

            //transaction.update('OperatingUnit', rows);

            await ouTable.update(rows);

            console.log(`OperatingUnit: ${ouUpdateRows.length} row/s updated`);
        }

        [ouInsertRows] = await database.run({
            sql:
                `SELECT RTRIM(A.OperatingUnitCd) AS OperatingUnitCd , RTRIM(B.OperatingGroupCd) AS OperatingGroupCd , RTRIM(A.OperatingUnitDesc) AS OperatingUnitNm FROM OperatingUnitDump AS A 
                     INNER JOIN OperatingGroup AS B ON RTRIM(A.OperatingGroupCd) = RTRIM(B.OperatingGroupCd)
                    LEFT JOIN OperatingUnit AS C ON RTRIM(A.OperatingUnitCd) = RTRIM(C.OperatingUnitCd)
                    WHERE (A.UpdatedInd = 'Y') AND RTRIM(C.OperatingUnitCd) IS NULL`
        });

        if (ouInsertRows.length > 0) {
            let rows = [];

            ouInsertRows.forEach(row => {
                let tempRow = row.toJSON();
                tempRow.OperatingUnitKey = uuid();
                tempRow.DummyInd = 'N';
                rows.push(addUserDateandTime(tempRow));
            })

            //transaction.insert('OperatingUnit', rows);

            await ouTable.insert(rows);

            console.log(`OperatingUnit: ${ouInsertRows.length} row/s inserted`);
        }

        // NORMALIZING OPERATING UNIT: END

        // NORMALIZING CLIENT SERVICE GROUP: START

        [csgInsertRowsInit] = await database.run({
            sql:
                `SELECT RTRIM(ClientServiceGroupCd) AS ClientServiceGroupCd  FROM ClientServiceGroup`
        });

        [csgUpdateRows] = await database.run({
            sql:
                `SELECT ClientServiceGroupKey, RTRIM(A.ClientServiceGroupCd) AS ClientServiceGroupCd , B.OperatingUnitCd , A.ClientServiceGroupDesc
                FROM ClientServiceGroupDump AS A
                INNER JOIN OperatingUnit AS B USING (OperatingUnitCd)
                INNER JOIN ClientServiceGroup AS C USING (ClientServiceGroupCd)
                WHERE A.UpdatedInd='Y' EXCEPT ALL SELECT D.ClientServiceGroupKey, RTRIM(D.ClientServiceGroupCd) AS ClientServiceGroupCd , D.OperatingUnitCd , D.ClientServiceGroupDesc FROM ClientServiceGroup D`
        });

        if (csgInsertRowsInit.length == 0 || csgInsertRowsInit.length == undefined) {

            [csgDumpRows] = await database.run({
                sql: `SELECT RTRIM(A.ClientServiceGroupCd) AS ClientServiceGroupCd , B.OperatingUnitCd , A.ClientServiceGroupDesc
                        FROM ClientServiceGroupDump AS A
                        INNER JOIN OperatingUnit AS B 
                    	ON RTRIM(A.OperatingUnitCd) = RTRIM(B.OperatingUnitCd)`
            });

            let rows = [];
            if (csgDumpRows.length > 0) {
                csgDumpRows.forEach(row => {
                    let tempRow = row.toJSON();
                    tempRow.ClientServiceGroupKey = uuid();
                    tempRow.DummyInd = 'N';
                    rows.push(addUserDateandTime(tempRow));
                })

                await csgTable.insert(rows);
            }


            //transaction.insert('ClientServiceGroup', rows);

            console.log(`ClientServiceGroup: ${csgDumpRows.length} row/s inserted`);
        }

        if (csgUpdateRows.length > 0) {
            let rows = [];


            csgUpdateRows.forEach(row => {
                let tempRow = row.toJSON();
                //tempRow.DummyInd = 'N';
                rows.push(addUserDateandTime(tempRow));
            });

            //transaction.update('ClientServiceGroup', rows);

            await csgTable.update(rows);

            console.log(`ClientServiceGroup: ${csgUpdateRows.length} row/s updated`);
        }

        [csgInsertRows] = await database.run({
            sql:
                `SELECT RTRIM(A.ClientServiceGroupCd) AS ClientServiceGroupCd , B.OperatingUnitCd , A.ClientServiceGroupDesc FROM ClientServiceGroupDump AS A
                        INNER JOIN OperatingUnit AS B USING (OperatingUnitCd)
                        LEFT JOIN ClientServiceGroup AS C USING (ClientServiceGroupCd)
                        WHERE C.ClientServiceGroupCd IS NULL AND A.UpdatedInd='Y'`
        });

        if (csgInsertRows.length > 0) {
            let rows = [];

            csgInsertRows.forEach(row => {
                let tempRow = row.toJSON();
                tempRow.ClientServiceGroupKey = uuid();
                tempRow.DummyInd = 'N';
                rows.push(addUserDateandTime(tempRow));
            })

            await csgTable.insert(rows);

            //transaction.insert('ClientServiceGroup', rows);

            console.log(`ClientServiceGroup: ${csgInsertRows.length} row/s inserted`);
        }

        // NORMALIZING CLIENT SERVICE GROUP: END

    } catch (err) {
        console.error('ERROR:', err);
    } finally {
        // Close the database when finished.
        database.close();
        const { PubSub } = require('@google-cloud/pubsub');
        const pubsub = new PubSub({ projectId });
        const dataBuffer = Buffer.from("ogoucsg");
        await pubsub.topic("JobEvents").publish(dataBuffer);
        res.status(200).json({
            data: 'Successful: OGOUCSG'
        });
        //return;
    }
    //}

    //queryData();

    function addUserDateandTime(obj) {
        obj.CreateUserId = 'MMC_JOB_USER';
        obj.CreateDttm = new Date();
        obj.UpdateUserId = 'MMC_JOB_USER';
        obj.UpdateDttm = new Date();
        return obj;
    }
}