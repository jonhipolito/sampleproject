exports.processUCD = async (req, res) => {
    //(async function() { 
    //const uuid = require('uuidv4');
    const { Spanner } = require('@google-cloud/spanner');    
    //process.env.GOOGLE_APPLICATION_CREDENTIALS = './sa-npd-27354-oriondev-95184682-42b68c284938.json';  //comment  
    const projectId = process.env.X_GOOGLE_GCLOUD_PROJECT;

    const spanner = new Spanner({
        projectId: projectId,
    });
    
    const instanceId = 'si-27354-mmc';
    const databaseId = 'db-27354-mmc-db';

    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);
    const towTable = database.table('Customer');

    var updatedCount;
    try {
        const [rowsDump_update] = await database.run({
            sql: `SELECT a.CustomerNbr, b.ContentValue as GlobalClientDirector, c.ContentValue as ClientDirector
            FROM Customer a
            LEFT JOIN
            (SELECT CustomerNbr, ContentValue
            FROM MRDRCustomerAttributeDump
            WHERE AttributeCd = 'GCLDEI'
            AND CustomerNbr IN (SELECT CustomerNbr FROM Customer)) b
            ON a.CustomerNbr = b.CustomerNbr
            LEFT JOIN
            (SELECT CustomerNbr, ContentValue
            FROM MRDRCustomerAttributeDump
            WHERE AttributeCd = 'CLDREP'
            AND CustomerNbr IN (SELECT CustomerNbr FROM Customer)) c
            ON a.CustomerNbr = c.CustomerNbr`
        });

        if (rowsDump_update.length > 0) {
            let rowRef = [];

            for(let x=0; x < rowsDump_update.length; x++) {
                let tempRow = rowsDump_update[x].toJSON();
                tempRow.UpdateUserId = 'MMC_JOB_USER';
                tempRow.UpdateDttm = (new Date());
                tempRow.CreateUserId = 'MMC_JOB_USER';
                rowRef.push(tempRow);
                if(rowRef.length == 1000) {
                    await towTable.update(rowRef);
                    rowRef = [];
                }
            }
            console.log('Updating additional Customer Details - IN PROGRESS');
            if(rowRef.length > 0) {
                await towTable.update(rowRef);    
            }            
            updatedCount = rowsDump_update.length;
            console.log('Additional updates for Customer Details - DONE');
        }
    } catch (err) {
        console.error('ERROR:', err);
    } finally {
        database.close();
        const { PubSub } = require('@google-cloud/pubsub'); 
        const pubsub = new PubSub({ projectId });
        const dataBuffer = Buffer.from("additionalstomerdetails");
        await pubsub.topic("JobEvents").publish(dataBuffer); 
        res.status(200).json({ 
        data: ' Records Updated: ' + updatedCount 
        }); 

    }
}
//())
;