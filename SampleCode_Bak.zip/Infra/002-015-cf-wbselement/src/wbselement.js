
insertTempContract_CF2_WBS = async function (database){
    const wbsTable = database.table('WBSElementDumpTemp');
    try{
        const [wbsElement] = await database.run({sql:`SELECT DISTINCT wbs.CompanyCd
                        , wbs.ProfitCenterNbr
                        ,wbs.WBSExternalNbr as WBSInternalNbr
                        ,wbs.WBSStatus 
                        , wbs.ProfitCenterNbr
                        , wbs.ProjectType
                        , wbs.ResultsAnalysisKey
                        , wbs.ProjectHierarchyLevel
                        , wbs.TypeofWorkCd
                FROM MRDRWBSElementDump wbs
                    WHERE RTRIM(WBSExternalNbr) IN (SELECT RTRIM(WBSElementNbr) FROM MRDRContractLineItemDump) 
                    AND CompanyCd IN (SELECT CompanyCd FROM MRDRCompanyCodeDump)
                    AND TypeOfWorkCd IN (SELECT TypeOfWorkCd FROM TypeOfWork)
                    LIMIT 10`
        });


        if(wbsElement.length > 0){
            console.log(`WBSElementDumpTemp: Started.`);
            
            wbsElement.forEach(row =>{
                let rowsToInsert = [];
                let temp = row.toJSON();
                temp.CreateUserId = 'MMC.JOB';
                temp.CreateDttm = (new Date());
                temp.UpdateUserId = 'MMC.JOB';
                temp.UpdateDttm = (new Date());
                rowsToInsert.push(temp);

                wbsTable.insert(rowsToInsert);
            })
            
           console.log(`Successfully inserted ${wbsElement.length} row(s). -WBSElementDumpTemp`);
        }
        else{
            console.log(`WBSElementDumpTemp: No row(s) inserted.`);
        }

    }
    catch(error){
        console.log(error);
        return error;
    }
}

module.exports = {
    insertTempContract_CF2_WBS
}