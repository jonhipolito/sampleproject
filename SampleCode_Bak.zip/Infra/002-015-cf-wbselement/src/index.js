
const  // wbselement = require('./wbselement'),
        { Spanner } = require('@google-cloud/spanner'),
        projectId = process.env.X_GOOGLE_GCLOUD_PROJECT,
        instanceId = 'si-27354-mmc',
        databaseId = 'db-27354-mmc-db',
        // projectId = 'sbx-27354-nmmcsbxdev-a9ab6909', //For Local Testing
        // instanceId = 'nextgenmmc', //For Local Testing
        // databaseId = 'mmcdb', //For Local Testing
        spanner = new Spanner({ projectId: projectId, }),
        instance = spanner.instance(instanceId),
        database = instance.database(databaseId);
 

 exports.wbselement = async(req, res) => {
    try {
     console.log("Start: TempContract Process - Insert WBS Element Only");
     console.log(`CONTROL FLOW 2 - INSERTING DATA TO TEMPCONTRACT - IN PROGRESS`);
        //await wbselement.insertTempContract_CF2_WBS(database);//control flow 2
        const wbsTable = database.table('WBSElementDumpTemp');
        const [wbsElement] = await database.run({sql:`SELECT wbs.CompanyCd
                    , wbs.ProfitCenterNbr
                    ,wbs.WBSExternalNbr as WBSInternalNbr
                    ,wbs.WBSStatus 
                    , wbs.ProfitCenterNbr
                    , wbs.ProjectType
                    , wbs.ResultsAnalysisKey
                    , wbs.ProjectHierarchyLevel
                    , wbs.TypeofWorkCd
            FROM MRDRWBSElementDump@{FORCE_INDEX=MRDRWBSElementDump_WBSExternalNbr_IDX} wbs
                WHERE RTRIM(WBSExternalNbr) IN (SELECT RTRIM(WBSElementNbr) FROM MRDRContractLineItemDump) 
                AND CompanyCd IN (SELECT CompanyCd FROM MRDRCompanyCodeDump)
                AND TypeOfWorkCd IN (SELECT TypeOfWorkCd FROM TypeOfWork)`
            });


            if(wbsElement.length > 0){
                console.log(`WBSElementDumpTemp: Started.`);
                let rowsToInsert = [];
                wbsElement.forEach(row =>{                 
                    let temp = row.toJSON();
                    rowsToInsert.push(temp);                                   
                })
                await wbsTable.insert(rowsToInsert);
                console.log(`Successfully inserted ${wbsElement.length} row(s). -WBSElementDumpTemp`);
                
            }
            else{
                console.log(`WBSElementDumpTemp: No row(s) inserted.`);
            }
     console.log("End: TempContract Process - Insert WBS Element Only");
    }
    catch (err) {
        console.error("Error: ", err);
    }
    finally{
        //database.close();
        res.status(200).json({
            data: 'Records Inserted'
        });
    }
    
}

//Run - Local
//  (async function() {
//   console.log(`CONTROL FLOW 2 - INSERTING DATA TO TEMPCONTRACT - IN PROGRESS`);
//   await wbselement.insertTempContract_CF2_WBS(database);//control flow 2
//  }())