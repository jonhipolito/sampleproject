exports.exportusagemetrics = async (req, res) => {
        let today = new Date().toISOString();
        let Filename = `MMCDailyUsageMetrics-${today}.xlsx`;
        let details = null;

        details = await GetMetricsDetails();

        try {
                let data = await GenerateTemplate(details, Filename);
                res.status(200).json({
                        data: ' Generate Usage Metrics Daily ' + data
                });
                console.log(' Generate Usage Metrics Daily ' + data);
        } catch (error) {
                console.log("Index - Catch", error);
        }
        finally {
        }
};

async function QueryMetrics() {
        const { Spanner } = require('@google-cloud/spanner');
        const projectId = process.env.X_GOOGLE_GCLOUD_PROJECT,
                instanceId = 'si-27354-mmc',
                databaseId = 'db-27354-mmc-db';
        const spanner = new Spanner({
                projectId: projectId,
        });
        const instance = spanner.instance(instanceId);
        const database = instance.database(databaseId);

        const [rows] = await database.run({
                sql: `SELECT "Unique User Logins" AS Metric, COUNT(DISTINCT EnterpriseId) AS Count
                FROM AuditLog
                WHERE ObjectNm = 'Health Scorecard' AND EventTypeNm = 'Visit'
                AND DATE_DIFF(CURRENT_DATE() , CAST (EventDt as DATE), DAY) = 1
                UNION ALL
                SELECT "Total Logins" AS Metric, COUNT(EnterpriseId) AS Count
                FROM AuditLog
                WHERE ObjectNm = 'Health Scorecard' AND EventTypeNm = 'Visit'
                AND DATE_DIFF(CURRENT_DATE() , CAST (EventDt as DATE), DAY) = 1
                UNION ALL
                SELECT "Lead Review Create" AS Metric, COUNT(EnterpriseId) AS Count
                FROM AuditLog
                WHERE ObjectNm  = 'Lead Review Create'
                AND DATE_DIFF(CURRENT_DATE() , CAST (EventDt as DATE), DAY) = 1
                UNION ALL
                SELECT "Lead Review Delete" AS Metric, COUNT(EnterpriseId) AS Count
                FROM AuditLog
                WHERE ObjectNm  = 'Lead Review Delete'
                AND DATE_DIFF(CURRENT_DATE() , CAST (EventDt as DATE), DAY) = 1
                UNION ALL
                SELECT "Mitigation Create" AS Metric, COUNT(EnterpriseId) AS Count
                FROM AuditLog
                WHERE ObjectNm  = 'Mitigation Create'
                AND DATE_DIFF(CURRENT_DATE() , CAST (EventDt as DATE), DAY) = 1
                UNION ALL
                SELECT "Mitigation Delete" AS Metric, COUNT(EnterpriseId) AS Count
                FROM AuditLog
                WHERE ObjectNm  = 'Mitigation Delete'
                AND DATE_DIFF(CURRENT_DATE() , CAST (EventDt as DATE), DAY) = 1
                UNION ALL
                SELECT "Risks and Issues Create" AS Metric, COUNT(EnterpriseId) AS Count
                FROM AuditLog
                WHERE ObjectNm  = 'Risks and Issues Create'
                AND DATE_DIFF(CURRENT_DATE() , CAST (EventDt as DATE), DAY) = 1
                UNION ALL
                SELECT "Risks and Issues Modify" AS Metric, COUNT(EnterpriseId) AS Count
                FROM AuditLog
                WHERE ObjectNm  = 'Risks and Issues Modify'
                AND DATE_DIFF(CURRENT_DATE() , CAST (EventDt as DATE), DAY) = 1
                UNION ALL
                SELECT "Total Master Clients" AS Metric, 34 AS Count
                UNION ALL
                SELECT "Risk Assessments - Master Clients" AS Metric, COUNT (DISTINCT MasterClientNbr) AS Count
                FROM RiskDetails WHERE RiskSourceCd = '101201'
                UNION ALL
                SELECT "Total Financial Clients" AS Metric, COUNT(b.CustomerNbr) AS Count
                FROM MasterClient a
                INNER JOIN Customer b
                ON a.MasterClientNbr = b.MasterClientNbr
                WHERE a.MasterClientNbr IN
                ('0070000355','0070000363','0070000384','0070000386','0070000422','0070000878','0070000954',
                '0070000972','0070001043','0070001137','0070001273','0070001489','0070001589','0070001732',
                '0070001933','0070002168','0070002294','0070002436','0070002616','0070002671','0070002755',
                '0070002773','0070002797','0070002810','0070002865','0070002892','0070002919','0070004514',
                '0070008050','0070009203','0070012702','0070016178','0070016600','0070020865')
                UNION ALL
                SELECT "Risk Assessments - Financial Clients" AS Metric, COUNT (DISTINCT CustomerNbr) AS Count
                FROM RiskDetails WHERE RiskSourceCd = '101201'
                UNION ALL
                SELECT "Total Contracts" AS Metric, COUNT(c.ContractNbr) AS Count
                FROM Customer b
                INNER JOIN Contract c
                ON b.CustomerNbr = c.CustomerNbr
                WHERE b.MasterClientNbr IN
                ('0070000355','0070000363','0070000384','0070000386','0070000422','0070000878','0070000954',
                '0070000972','0070001043','0070001137','0070001273','0070001489','0070001589','0070001732',
                '0070001933','0070002168','0070002294','0070002436','0070002616','0070002671','0070002755',
                '0070002773','0070002797','0070002810','0070002865','0070002892','0070002919','0070004514',
                '0070008050','0070009203','0070012702','0070016178','0070016600','0070020865')
                UNION ALL
                SELECT "Risk Assessments - Contracts" AS Metric, COUNT (DISTINCT ContractNbr) AS Count
                FROM RiskDetails WHERE RiskSourceCd = '101201'
                `
        });
        return rows;
}

async function GetMetricsDetails() {
        let report = await QueryMetrics();
        let details = [];
        report.forEach(row => {
                let item = row.toJSON();
                details.push(item);
        });
        return details;
}

function GenerateTemplate(details, Filename) {
        var Excel = require('exceljs');
        const { Storage } = require('@google-cloud/storage');
        const storage = new Storage();

        return new Promise(async (resolve) => {
                let file = storage.bucket("npd-27354-oriondev-mrdr").file(`Usage-Metrics/${Filename}`)
                if (details) {
                        let readstream = storage.bucket("npd-27354-oriondev-mrdr").file("excel-templates/Daily-Usage-Metrics-Template.xlsx").createReadStream();
                        var workbook = new Excel.Workbook();
                        let writeStream = workbook.xlsx.createInputStream();
                        readstream.pipe(writeStream);
                        writeStream.on('done', () => {
                                let ws = workbook.getWorksheet("Daily Usage Metrics");
                                let ctr = 2;
                                details.forEach(d => {
                                        ws.getCell(ctr, 1).value = d.Metric
                                        ws.getCell(ctr, 2).value = d.Count
                                        ctr++;
                                });
                                workbook.xlsx.writeBuffer()
                                        .then(function (buffer) {
                                                file.save(buffer).then(() => {
                                                        resolve("Success");
                                                });
                                        });
                        });
                }
                else {
                        resolve("Failed")
                }

        });

}