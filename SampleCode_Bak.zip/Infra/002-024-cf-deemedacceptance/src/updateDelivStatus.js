

 setDeemedAccepted = async function(database){
    const [rows_update] = await database.run( `SELECT * FROM DeliverablesObligations 
    WHERE SubmissionReviewPeriod > 0
    AND SubmittedDttm IS NOT NULL
    AND SubmissionLevelCd = '102704'
    AND SubmissionDelivStatusCd = '102505'
    AND FORMAT_TIMESTAMP('%D', CURRENT_TIMESTAMP(), "UTC") >= FORMAT_TIMESTAMP('%D', TIMESTAMP_ADD(SubmittedDttm, INTERVAL SubmissionReviewPeriod DAY), "UTC")
    ` );
    
    //TIMESTAMP_ADD(SubmittedDttm, INTERVAL 1 DAY) = CURRENT_TIMESTAMP()

    //SELECT FORMAT_TIMESTAMP('%D %H:%M', TIMESTAMP_ADD(SubmittedDttm, INTERVAL 1 DAY), "Hongkong") AS tomdate, FORMAT_TIMESTAMP('%D %H:%M',CURRENT_TIMESTAMP(), "Hongkong") as nowdate FROM DeliverablesObligations 

    //WHERE DelivsObligationsKey = '3ab028c8-1d80-4a18-a82a-70cc056d11d1'
        if(rows_update.length > 0){
            let rows =[];
            rows_update.forEach(row =>{
                let temp = row.toJSON();
                rows.push(temp);
            });

            let keys = rows.map(element =>`'${element.DelivsObligationsKey}'`).join(',');      

            const [updatedRows] = await database.runPartitionedUpdate({sql:
                `UPDATE DeliverablesObligations 
                SET SubmissionDelivStatusCd = '102507',
                RAGStatusCd = '102401'
                WHERE DelivsObligationsKey IN (${keys})`
                });

            console.log(`DeliverablesObligations: ${updatedRows} row(s) updated.`);
        }
        else{
            console.log(`DeliverablesObligations: No row(s) updated.`);
        }
        
}


module.exports = {
    setDeemedAccepted
}

