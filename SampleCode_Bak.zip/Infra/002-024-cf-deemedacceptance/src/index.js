const   updateDelivStatus = require('./updateDelivStatus'),
        updateRagStatusAmber = require('./updateRagStatusAmber'),
        updateRagStatusGreen = require('./updateRagStatusGreen'),
        updateRagStatusRed = require('./updateRagStatusRed'),
        projectId = process.env.X_GOOGLE_GCLOUD_PROJECT,
        instanceId = 'si-27354-mmc',
        databaseId = 'db-27354-mmc-db',
        { Spanner } = require('@google-cloud/spanner'),
        spanner = new Spanner({ projectId: projectId, }),
        instance = spanner.instance(instanceId),
        database = instance.database(databaseId)
        //process.env.GOOGLE_APPLICATION_CREDENTIALS='./sa-npd-27354-oriondev-95184682-42b68c284938.json';



 exports.deemedacceptance = async() => {
    try {
         console.log("Start: Update Deemed Accepted");
         await updateDelivStatus.setDeemedAccepted(database);
         await updateRagStatusAmber.setRagStatusAmber(database);
         await updateRagStatusGreen.setRagStatusGreen(database);
         await updateRagStatusRed.setRagStatusRed(database);
    }
    catch (err) {
        console.error("Error: ", err);
    }
    finally {
        // Close the database when finished
        console.log("End: Update Deemed Accepted");
        res.status(200).json({
            data: 'Deemed Accepted Data Updated'
        });
        database.close();
        res.send();
    }
}


//Run - Local
// (async function() {
//     try{
//     await updateDelivStatus.setDeemedAccepted(database);
//     }catch(err){
//         console.log(err);
//     }
//  }())