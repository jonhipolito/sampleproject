

setRagStatusGreen = async function (database) {
    const [rows_update] = await database.run(`SELECT * FROM DeliverablesObligations 
    WHERE SubmissionDelivStatusCd IN ('102502', '102504', '102506', '102507')
    AND RAGStatusCd != '102401'
    ` );

    if (rows_update.length > 0) {
        let rows = [];
        rows_update.forEach(row => {
            let temp = row.toJSON();
            rows.push(temp);
        });

        let keys = rows.map(element => `'${element.DelivsObligationsKey}'`).join(',');

        const [updatedRows] = await database.runPartitionedUpdate({
            sql:
                `UPDATE DeliverablesObligations 
                SET RAGStatusCd = '102401'
                WHERE DelivsObligationsKey IN (${keys})`
        });

        console.log(`DeliverablesObligations: ${updatedRows} row(s) updated to green rag status.`);
    }
    else {
        console.log(`DeliverablesObligations: No row(s) updated.`);
    }

}


module.exports = {
    setRagStatusGreen
}

