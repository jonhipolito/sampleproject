const { Spanner } = require('@google-cloud/spanner');
const uuid = require('uuidv4');

truncateContractStage = async function(projectId, instanceId, databaseId){
    const spanner = new Spanner({
        projectId: projectId,
    });
    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);    

    try{
        const [truncContractStage] = await database.runPartitionedUpdate(`DELETE FROM ContractStage WHERE true`
        );
        console.log(`ContractStage: ${truncContractStage}  row(s) deleted.`);
    }
    catch(error){
        return error;
    }
    finally{
        await database.close();
    }    
}

insertcontractstage_cf12 = async function(projectId, instanceId, databaseId){
    const spanner = new Spanner({
        projectId: projectId,
    });
    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);
    const cTable = database.table('ContractStage');
    try{
        const [rows_cf12] = await database.run({sql:
            `SELECT '' as ContractStageKey
            ,LTRIM(RTRIM(ContractNbr)) AS ContractNbr
            ,LTRIM(RTRIM(ContractNm)) AS ContractNm
            ,LTRIM(RTRIM(CustomerNbr)) AS CustomerNbr
            ,ContractStartDt
            ,ContractEndDt
            ,LTRIM(RTRIM(ContractDirectorPersonnelNbr)) AS ContractDirectorPersonnelNbr
            ,LTRIM(RTRIM(ContractDirectorNm)) AS ContractDirectorNm
            ,LTRIM(RTRIM(ClientServiceGroupCd)) AS ClientServiceGroupCd
            ,LTRIM(RTRIM(CountryCd)) AS CountryCd
            ,LTRIM(RTRIM(TypeOfWorkCd)) AS TypeOfWorkCd
        FROM TempContractStage`
        });

        if(rows_cf12.length > 0){
            let rows = [];
            rows_cf12.forEach(row =>{
                    let temp = row.toJSON();
                    temp.ContractStageKey = uuid();
                    temp.CreateUserId = 'MMC_JOB_USER';
                    temp.CreateDttm = (new Date());
                    temp.UpdateUserId = 'MMC_JOB_USER';
                    temp.UpdateDttm = (new Date());
                    rows.push(temp);

                    cTable.insert(rows);
                })
               
                console.log(`ContractStage: ${rows_cf12.length} row(s) inserted. -Control flow 12`);
        }
        else{
            console.log(`ContractStage: No rows inserted`)
        }
    }
    catch(err){
        console.log(err);
        return err;
    }
    finally{
        await database.close();
    }
}

deletecontractstage_cf13 = async function(projectId, instanceId, databaseId){
    const spanner = new Spanner({
        projectId: projectId,
    });
    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);
    try{
        const [rows_delete] = await database.run(
            `SELECT cs.ContractStageKey
            FROM (
                    SELECT con.ContractNbr
                        ,c.CountryCd
                        ,max(cl.ContractItem) AS ContractItem
                    FROM (
                              SELECT ContractNbr
                                ,Count(CountryCd) as CountryCount
                            FROM (
                                      SELECT DISTINCT ContractNbr
                                        ,CountryCd
                                    FROM ContractStage
                                 )
                            GROUP BY ContractNbr
                            HAVING Count(CountryCd) > 1
                         ) con
                    INNER JOIN ContractsDumpTemp  cl
                        ON con.ContractNbr = cl.ContractCd
                    INNER JOIN WBSElementDumpTemp  wbs
                        ON cl.WBSElementNbr = wbs.WBSExternalNbr
                    INNER JOIN MRDRCompanyCodeDump cc
                        ON wbs.CompanyCd = cc.CompanyCd
                    INNER JOIN Country c
                        ON cc.CountryKey = c.CountryCd
                    GROUP BY con.ContractNbr,c.CountryCd
                 ) a
            INNER JOIN ContractStage cs
                ON a.ContractNbr = cs.ContractNbr
                AND a.CountryCd = cs.CountryCd
            LEFT JOIN (
                          SELECT ContractNbr
                            ,max(ContractItem) AS ContractItem
                        FROM (
                                  SELECT con.ContractNbr
                                    ,c.CountryCd
                                    ,max(cl.ContractItem) AS ContractItem
                                FROM (
                                        SELECT ContractNbr
                                            ,Count(CountryCd) as CountryCount
                                        FROM (
                                                SELECT DISTINCT ContractNbr
                                                    ,CountryCd
                                                FROM ContractStage
                                             )
                                        GROUP BY ContractNbr
                                        HAVING Count(CountryCd) > 1
                                     ) con
                                INNER JOIN ContractsDumpTemp  cl
                                    ON con.ContractNbr = cl.ContractCd
                                INNER JOIN WBSElementDumpTemp  wbs
                                    ON cl.WBSElementNbr = wbs.WBSExternalNbr
                                INNER JOIN MRDRCompanyCodeDump cc
                                    ON wbs.CompanyCd = cc.CompanyCd
                                INNER JOIN Country c
                                    ON cc.CountryKey = c.CountryCd
                                GROUP BY con.ContractNbr,c.CountryCd
                             )
                        GROUP BY ContractNbr
                      ) b
                ON a.ContractItem = b.ContractItem
            WHERE b.ContractItem IS NULL`
            );
            if(rows_delete.length > 0){
                let rows =[];
                rows_delete.forEach(row =>{
                    let temp = row.toJSON();
                    rows.push(temp);
                });
                let contractKeys = rows.map(element =>`'${element}'`).join(',');
                const [deletedRows] = await database.runPartitionedUpdate({sql:
                    `DELETE FROM ContractStage WHERE ContractStageKey IN(${contractKeys})`
                });
                console.log(`ContractStage: ${deletedRows} row(s) deleted`);
            }
            else{
                console.log(`ContractStage: No row(s) deleted.`);
            }
    }
    catch(err){
        console.log(err);
        return err;
    }
}

module.exports = {
    truncateContractStage,
    insertcontractstage_cf12,
    deletecontractstage_cf13
}