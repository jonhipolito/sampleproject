
const { Spanner } = require('@google-cloud/spanner');
const uuid = require('uuidv4');


truncateTempContract = async(projectId, instanceId, databaseId) => {    
    const spanner = new Spanner({
        projectId: projectId,
    });
    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);
    try{
        const [truncTempContract] = await database.runPartitionedUpdate({sql:`DELETE FROM TempContract WHERE true`}); 
        console.log(`TempContract: ${truncTempContract} row/s deleted`);                
    }
    catch(error){
        console.log(error);
        return error;
    }
    finally {
        await database.close();
    }    
}

insertTempContract_CF2 = async function (projectId, instanceId, databaseId){
    const spanner = new Spanner({
        projectId: projectId,
    });
    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);
    const tTable = database.table('TempContract');
    const wbsTable = database.table('WBSElementDumpTemp');
    const conTable = database.table('ContractsDumpTemp');
    try{
        const [wbsElement] = await database.run({sql:`SELECT DISTINCT wbs.CompanyCd
                        , wbs.ProfitCenterNbr
                        ,wbs.WBSExternalNbr as WBSInternalNbr
                        ,wbs.WBSStatus 
                        , wbs.ProfitCenterNbr
                        , wbs.ProjectType
                        , wbs.ResultsAnalysisKey
                        , wbs.ProjectHierarchyLevel
                        , wbs.TypeofWorkCd
                FROM MRDRWBSElementDump wbs
                    WHERE RTRIM(WBSExternalNbr) IN (SELECT RTRIM(WBSElementNbr) FROM MRDRContractLineItemDump) 
                    AND CompanyCd IN (SELECT CompanyCd FROM MRDRCompanyCodeDump)
                    AND TypeOfWorkCd IN (SELECT TypeOfWorkCd FROM TypeOfWork)`
        });


        if(wbsElement.length > 0){
            console.log(`WBSElementDumpTemp: Started.`);
            let rowsToInsert = [];
            wbsElement.forEach(row =>{
                let temp = row.toJSON();
                temp.CreateUserId = 'MMC.JOB';
                temp.CreateDttm = (new Date());
                rowsToInsert.push(temp);

                wbsTable.insert(rowsToInsert);
            })
            
           console.log(`Successfully inserted ${wbsElement.length} row(s). -WBSElementDumpTemp`);
        }
        else{
            console.log(`WBSElementDumpTemp: No row(s) inserted.`);
        }



        const [conData] = await database.run({sql:`SELECT DISTINCT
                            con.ContractCd as ContractNbr
                            , con.ContractDescr as ContractNm
                            , con.CustomerNbr  
                            , con.ContractUserStatCd as ContractStatus  
                            , con.ContractStartDt
                            , con.ContractEndDt
                            , con.RespSrExecPrimaryPersNbr as ContractDirectorPersonnelNbr
                            , con.RespSrExecPrimaryEntID as ContractDirectorNm    
                            ,cl.WBSElementNbr
                        FROM MRDRContractsDump@{FORCE_INDEX=IX_ContractCd} con
                            INNER JOIN MRDRContractLineItemDump  cl
                                ON con.ContractCd = cl.ContractCd
                        WHERE             
                            RTRIM(con.ContractUserStatCd) NOT IN ('E0011', 'E0006') `
                    });

       if(conData.length > 0){
           console.log(`ContractsDumpTemp: Started.`);
            let rowsToInsert = [];
            conData.forEach(row =>{
                let temp = row.toJSON();
                temp.CreateUserId = 'MMC.JOB';
                temp.CreateDttm = (new Date());
                rowsToInsert.push(temp);

                 conTable.insert(rowsToInsert);
            })
           
            console.log(`Successfully inserted ${conData.length} row(s). -ContractsDumpTemp`);
        }
        else{
            console.log(`ContractsDumpTemp: No row(s) inserted.`);
        }


        const [rows] = await database.run({sql:`SELECT DISTINCT
                    con.ContractCd as ContractNbr
                , con.ContractDescr as ContractNm
                , con.CustomerNbr  
                , con.ContractUserStatCd as ContractStatus  
                , wbs.WBSStatus 
                , wbs.ProfitCenterNbr
                , wbs.ProjectType
                , wbs.ResultsAnalysisKey
                , wbs.ProjectHierarchyLevel
                ,case
                        when wbs.TypeofWorkCd Is Null then '003005'
                        when wbs.TypeofWorkCd = ' ' then  '003005'
                        else wbs.TypeOfWorkCd
                end AS TypeofWorkCd
                , cc.CompanyDesc
                , c.CountryCd
                , con.ContractStartDt
                , con.ContractEndDt
                , con.RespSrExecPrimaryPersNbr as ContractDirectorPersonnelNbr
                , con.RespSrExecPrimaryEntID as ContractDirectorNm     
            FROM ContractsDumpTemp con
                INNER JOIN WBSElementDumpTemp wbs
                    ON con.WBSElementNbr = wbs.WBSExternalNbr
                INNER JOIN MRDRCompanyCodeDump cc
                    ON wbs.CompanyCd = cc.CompanyCd
                INNER JOIN Country c
                    ON cc.CountryKey = c.CountryCd`
    });

        if(rows.length > 0){
            console.log(`TempContract: Started.`);
            let rowsToInsert = [];
            // let rowsToInsert = rows.map(row => {
            //     let temp = row.toJSON();
            //     temp.TempContractKey = uuid();
            //     return temp;
            // });
            rows.forEach(row =>{
                let temp = row.toJSON();
                temp.TempContractKey = uuid();
                temp.CreateUserId = 'MMC.JOB';
                temp.CreateDttm = (new Date());
                rowsToInsert.push(temp);

                tTable.insert(rowsToInsert);
            })
            
            console.log(`Successfully inserted ${rows.length} row(s). -TempContract`);
        }
        else{
            console.log(`TempContract: No row(s) inserted.`);
        }

    }
    catch(error){
        console.log(error);
        return error;
    }
    finally{
        await database.close();
    }
}
deletetempcontract_CF3 = async function(projectId, instanceId, databaseId){
    const spanner = new Spanner({
        projectId: projectId,
    });
    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);
    try{
        const [del_rows] = await database.runPartitionedUpdate({sql: `DELETE FROM TempContract
        WHERE 
        (ContractStatus = 'E0010' AND WBSStatus = 'I0046')
        or 
        (ContractStatus = 'E0010' AND WBSStatus = 'E0007')`});
        console.log(`TempContract: ${del_rows}  row(s) deleted.`);
    }
    catch(err){
        console.log(err);
    }
    finally{
        await database.close();
    }
}
deleterestrictedcomp_CF4 = async function(projectId, instanceId, databaseId){
    const spanner = new Spanner({
        projectId: projectId,
    });
    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);
    try{
        const [restricted] = await database.run({sql:`SELECT CompanyDesc FROM RestrictedCompany`});

        if(restricted.length > 0)
            {
                let resultX = [];
                restricted.forEach(row =>{
                    let temp = row.toJSON();
                    let dml = {sql: `DELETE  FROM TempContract WHERE CompanyDesc LIKE '%${temp.CompanyDesc}%'`}
                    resultX.push(dml);                   
                    // await transaction.run(`DELETE  FROM TempContract WHERE CompanyDesc LIKE '%${temp.CompanyDesc}%'`);
                    // resultX.push(new Promise(async(resolve) =>{
                    //     let temp = row.toJSON();
                    //     // await deletetempcont(projectId, instanceId, databaseId,temp.CompanyDesc);
                    //     await deletetempcont(database,temp.CompanyDesc);
                    //     resolve();
                    // }));
                });
                await database.runTransactionAsync(async transaction => {
                    const cf4 = await transaction.batchUpdate(resultX);
                    await transaction.commit();
                    console.log(`TempContract:  ${cf4}  row(s) deleted.`);
                });
            }
    }
    catch(err){
        console.log(err);
    }
    finally{
        await database.close();
    }
}
deletetempcontract_CF5 = async function(projectId, instanceId, databaseId){
    const spanner = new Spanner({
        projectId: projectId,
    });
    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);
    const query = {sql : `DELETE FROM TempContract
    WHERE 
    CAST(ProjectType AS INT64) IN (10, 11,20)
    AND ResultsAnalysisKey = ''
    AND CAST(ProjectHierarchyLevel AS INT64) > 1
    AND Contractnbr NOT IN
    (SELECT ContractNbr
    FROM TempContract
    WHERE 
    (CAST(ProjectType AS INT64) IN (10, 11,20) AND ResultsAnalysisKey <> '' AND CAST(ProjectHierarchyLevel AS INT64) > 1)
    OR
    (CAST(ProjectType AS INT64) IN (10, 11,20) AND ResultsAnalysisKey = '' AND CAST(ProjectHierarchyLevel AS INT64) = 1)
    OR 
    CAST(ProjectType AS INT64) NOT IN (10, 11,20))`};
    const dml = [query];
    try{
        await database.runTransactionAsync(async transaction => {
            const [cf5_rows] = await transaction.batchUpdate(dml)
            await transaction.commit();
            console.log(`TempContract:  ${cf5_rows}  row(s) deleted.`);
        });
    }
    catch(err){
        console.log(err);
    }
    finally{
        await database.close();
    }       
}
// deletetempcont = function(database,CompanyDesc){    
//     return new Promise(async(resolve,reject) =>{   
//         // const spanner = new Spanner({
//         //     projectId: projectId,
//         // });
//         // const instance = spanner.instance(instanceId);
//         // const database = instance.database(databaseId);     
//             [result] = await database.runPartitionedUpdate({sql: `DELETE  FROM TempContract WHERE CompanyDesc LIKE '%${CompanyDesc}%'`});
//             resolve();        
//     });
// }
module.exports = {
    truncateTempContract,
    insertTempContract_CF2,
    deletetempcontract_CF3,
    deleterestrictedcomp_CF4,
    deletetempcontract_CF5
}