
const { Spanner } = require('@google-cloud/spanner');
const uuid = require('uuidv4');

truncateTempContractStage = async(projectId, instanceId, databaseId) =>{
    const spanner = new Spanner({
        projectId: projectId,
    });
    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);

    // const tempcontstage = database.table('TempContractStage');
    // const keys = [];
    // const query = {columns: ['ContractStageKey']};
    try{ 
        const [truncTempContractStage] = await database.runPartitionedUpdate({sql:`DELETE FROM TempContractStage WHERE true`}); 
        console.log(`TempContractStage: ${truncTempContractStage} row/s deleted`);      
        // const [rows] = await tempcontstage.read(query);       
        // if(rows.length > 0){
        //     rows.forEach(row =>{
        //         let temp = JSON.stringify(row);
        //         keys.push(temp);
        //     });
        //     await tempcontstage.deleteRows(keys);            
        //     console.log(`DELETE ALL ROWS IN TEMPCONTRACTSTAGE - DONE`);
        // }
        // else{
        //     console.log(`No rows to be deleted. - TEMPCONTRACTSTAGE`);
        // }        
    }
    catch(error){
        console.log(error);
        return error;
    }
    finally{
        await database.close();
    }   
}
insert_tempcontractstage_CF7 = async function(projectId, instanceId, databaseId){
    const spanner = new Spanner({
        projectId: projectId,
    });
    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);
    const tcsTable = database.table('TempContractStage');
    try{
        [rows_cf7] = await database.run({ sql :
            `SELECT  DISTINCT
            '' as ContractStageKey
            ,c.ContractNbr
            ,c.ContractNm
            ,c.CustomerNbr
            ,c.ContractStartDt
            ,c.ContractEndDt
            ,c.ContractDirectorPersonnelNbr
            ,c.ContractDirectorNm
            ,pch.ClientServiceGroupCd
            ,c.CountryCd
            ,c.TypeOfWorkCd
        FROM TempContract c
            INNER JOIN TempProfitCenterHierarchy pch
                ON c.ProfitCenterNbr = pch.ProfitCenterNbr`
        });
        if(rows_cf7.length > 0){
            let rows = [];
            rows_cf7.forEach(row =>{
                    let temp = row.toJSON();
                    temp.ContractStageKey = uuid();
                    temp.CreateUserId = 'MMC.JOB';
                    temp.CreateDttm = (new Date());
                    temp.DummyInd = 'N';
                    temp.UpdateUserId = 'MMC.JOB';
                    temp.UpdateDttm = (new Date());
                    rows.push(temp);

                    tcsTable.insert(rows);
                })
                
                console.log(`TempContractStage:  ${rows_cf7.length} row(s) inserted. -Control flow 7`);
        }
        else{
            console.log(`TempContractStage: No row(s) inserted. -Control flow 7`);
        }
    }
    catch(err){
        console.log(err);
    }
    finally{
       await database.close();
    }
}

module.exports = {
    truncateTempContractStage,
    insert_tempcontractstage_CF7
}