// 'use strict';
const { Spanner } = require('@google-cloud/spanner');
const uuid = require('uuidv4');

truncateTempContractStagePrevious = async function(projectId, instanceId, databaseId){
    const spanner = new Spanner({
        projectId: projectId,
    });
    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);

    try{
        const [truncTempContractStagePrevious] = await database.runPartitionedUpdate(`DELETE FROM TempContractStagePrevious WHERE true`
        );
        console.log(`TempContractStagePrevious: ${truncTempContractStagePrevious} row/s deleted`);
    }
    catch(error){
        return error;
    }
    finally{
        await database.close();
    }
}
insert_tempconstageprev = async function(projectId, instanceId, databaseId){
    const spanner = new Spanner({
        projectId: projectId,
    });
    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);
    const tcspTable = database.table('TempContractStagePrevious');
    try{
        [resultrows] = await database.run(
            `SELECT '' as ContractStagePreviousKey
            ,ContractNbr
            ,ContractNm
            ,CustomerNbr
            ,ContractStartDt
            ,ContractEndDt
            ,ContractDirectorPersonnelNbr
            ,ContractDirectorNm
            ,ClientServiceGroupCd
            ,CountryCd
            ,CreateUserId
            ,CreateDttm
           ,TypeOfWorkCd
        FROM ContractStagePrevious`
            );
        if(resultrows.length > 0) {
            let rowsToInsert = [];
            resultrows.forEach(row =>{
                let temp = row.toJSON();
                temp.ContractStagePreviousKey = uuid();
                temp.UpdateUserId = 'MMC.JOB';
                temp.UpdateDttm = (new Date());  
                rowsToInsert.push(temp);

                tcspTable.insert(rowsToInsert);
            })
            
            console.log(`TempContractStagePrevious:   ${resultrows.length} row(s) inserted. -TempContractStagePrevious`);
        }
        else{
            console.log(`TempContractStagePrevious: No row(s) inserted.`);
        }
    }
    catch(err){
        console.log(err);
    }
    finally{
        await database.close();
    }
}

module.exports = {
    truncateTempContractStagePrevious,
    insert_tempconstageprev
}