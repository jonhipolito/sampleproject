'use strict'
// const uuid = require('uuidv4');
const projectId = process.env.X_GOOGLE_GCLOUD_PROJECT,
        instanceId = 'si-27354-mmc',
        databaseId = 'db-27354-mmc-db',
        flatcondata = require('./flattencondata')(projectId, instanceId, databaseId);
 

exports.flattenContracts = async() => {
    console.log(`FLATTENING CONTRACT DATA STARTED`);
    await flatcondata.flatConDataProcess();
    console.log(`FLATTENING CONTRACT DATA ENDED`);
}
// (async function() {
//     console.log(`FLATTENING CONTRACT DATA STARTED`);
//     await flatcondata.flatConDataProcess();
//     console.log(`FLATTENING CONTRACT DATA ENDED`);
// }())
