const { Spanner } = require('@google-cloud/spanner');
const uuid = require('uuidv4');

insertdeletedcontract_cf14 = async function(projectId, instanceId, databaseId){
    const spanner = new Spanner({
        projectId: projectId,
    });
    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);
    const dcTable = database.table('DeletedContract');
    try{
        const [rows_cf14] = await database.run({sql:
            `SELECT DISTINCT '' as DeletedContractKey
            ,csp.ContractNbr
            ,csp.ContractNm
            ,csp.CustomerNbr
            ,csp.ContractStartDt
            ,csp.ContractEndDt
            ,csp.ContractDirectorPersonnelNbr
            ,csp.ContractDirectorNm
            ,csp.ClientServiceGroupCd
            ,csp.CountryCd
            ,csp.TypeOfWorkCd
            FROM ContractStagePrevious csp
            LEFT JOIN ContractStage cs
                ON csp.ContractNbr = cs.ContractNbr
            WHERE cs.ContractNbr IS NULL`
        });
        if(rows_cf14.length > 0){
            let rows = [];
            rows_cf14.forEach(row => {
                let temp = row.toJSON();
                temp.DeletedContractKey = uuid();
                temp.CreateUserId = 'MMC.JOB';
                temp.CreateDttm = (new Date());
                rows.push(temp);

                dcTable.insert(rows);
            }); 
            console.log(`DeletedContract: ${rows_cf14.length} rows(s) inserted.`);
        }
        else{
            console.log(`DeletedContract: No row(s) inserted.`);
        }
    }
    catch(err){
        console.log(err);
        return err;
    }
}

module.exports = {
    insertdeletedcontract_cf14
}