'use strict';

const tempcontractstage = require('./tempcontractstage');
const tempcontract = require('./tempcontract');
const tempprofitcenterhierarchy = require('./tempprofitcenterhierarchy');
const tempcontractstageprevious = require('./tempcontractstgeprevious');
const contractstageprevious = require('./contractstageprevious');
const contractstage = require('./contractstage');
const deletedcontract = require('./deletedcontract');

module.exports = function(projectId, instanceId, databaseId){
    let flatConDataProcess;

    flatConDataProcess = async function(){        
    
        try{            
                // console.log(`CONTROL FLOW 1 - DELETE ALL ROWS IN TEMPCONTRACTSTAGE - IN PROGRESS`);
                // await tempcontractstage.truncateTempContractStage(projectId, instanceId, databaseId);       //control flow 1         

                // console.log(`CONTROL FLOW 1 - DELETE ALL ROWS IN TEMPCONTRACT - IN PROGRESS`);
                // await tempcontract.truncateTempContract(projectId, instanceId, databaseId);       //control flow 1         

                // console.log(`CONTROL FLOW 1 - DELETE ALL ROWS IN TEMPPROFITCENTERHIERARCHY - IN PROGRESS`);
                // await tempprofitcenterhierarchy.truncateTempProfitCenterHierarchy(projectId, instanceId, databaseId); //control flow 1
                
                // console.log(`CONTROL FLOW 1 - DELETE ALL ROWS IN TEMPCONTRACTSTAGEPREVIOUS - IN PROGRESS`);
                // await tempcontractstageprevious.truncateTempContractStagePrevious(projectId, instanceId, databaseId);//control flow 1

                // console.log(`CONTROL FLOW 2 - INSERTING DATA TO TEMPCONTRACT - IN PROGRESS`);
                // await tempcontract.insertTempContract_CF2(projectId, instanceId, databaseId);//control flow 2

                // console.log(`CONTROL FLOW 3 - DELETE FROM TempContract ('E0010' AND = 'I0046') or ('E0010' AND 'E0007') - IN PROGRESS`);
                // await tempcontract.deletetempcontract_CF3(projectId, instanceId, databaseId); //control flow 3

                // console.log(`CONTROL FLOW 4 - DELETE RESTRICTED COMPANY IN TEMPCONTRACT - IN PROGRESS`);
                // await tempcontract.deleterestrictedcomp_CF4(projectId, instanceId, databaseId); //control flow 4

                // console.log(`CONTROL FLOW 5 - DELETE FROM TEMPCONTRACT - IN PROGRESS`);
                // await tempcontract.deletetempcontract_CF5(projectId, instanceId, databaseId); //control flow 5

                console.log(`CONTROL FLOW 6 - INSERTING DATA TO TempProfitCenterHierarchy - IN PROGRESS`);
                await tempprofitcenterhierarchy.inserttempprofit_CF6(projectId, instanceId, databaseId); //control flow 6                

                console.log(`CONTROL FLOW 7 - INSERTING DATA TO TempContractStage - IN PROGRESS`);
                await tempcontractstage.insert_tempcontractstage_CF7(projectId, instanceId, databaseId); //control flow 7

                console.log(`CONTROL FLOW 8 - INSERTING DATA TO TEMPCONTRACTSTAGEPREVIOUS - IN PROGRESS`)
                await tempcontractstageprevious.insert_tempconstageprev(projectId, instanceId, databaseId);

                console.log(`CONTROL FLOW 9 - DELETE ALL ROWS ContractStagePrevious - IN PROGRESS`);
                await contractstageprevious.truncateContractStagePrev(projectId, instanceId, databaseId);

                console.log(`CONTROL FLOW 10 - INSERTING DATA TO ContractStagePrevious - IN PROGRESS`);
                await contractstageprevious.insertContractStagePrev_CF10(projectId, instanceId, databaseId);

                console.log(`CONTROL FLOW 11 - DELETE ALL ROWS IN CONTRACTSTAGE - IN PROGRESS`);
                await contractstage.truncateContractStage(projectId, instanceId, databaseId);

                console.log(`CONTROL FLOW 12 - INSERTING DATA TO CONTRACTSTAGE - IN PROGRESS`);
                await contractstage.insertcontractstage_cf12(projectId, instanceId, databaseId);

                console.log(`CONTROL FLOW 13 - DELETING DATA FROM CONTRACTSTAGE - IN PROGRESS`);
                await contractstage.deletecontractstage_cf13(projectId, instanceId, databaseId);

                console.log(`CONTROL FLOW 14 - INSERTING DATA TO DELETEDCONTRACTS - IN PROGRESS`);
                await deletedcontract.insertdeletedcontract_cf14(projectId, instanceId, databaseId);

                console.log(`CONTROL FLOW 15 - DELETE ALL ROWS IN TEMPCONTRACTSTAGE - IN PROGRESS`);
                await tempcontractstage.truncateTempContractStage(projectId, instanceId, databaseId);       //control flow 15         

                console.log(`CONTROL FLOW 15 - DELETE ALL ROWS IN TEMPCONTRACT - IN PROGRESS`);
                await tempcontract.truncateTempContract(projectId, instanceId, databaseId);       //control flow 15         

                console.log(`CONTROL FLOW 15 - DELETE ALL ROWS IN TEMPPROFITCENTERHIERARCHY - IN PROGRESS`);
                await tempprofitcenterhierarchy.truncateTempProfitCenterHierarchy(projectId, instanceId, databaseId); //control flow 15
                
                console.log(`CONTROL FLOW 15 - DELETE ALL ROWS IN TEMPCONTRACTSTAGEPREVIOUS - IN PROGRESS`);
                await tempcontractstageprevious.truncateTempContractStagePrevious(projectId, instanceId, databaseId);//control flow 15
        }
        catch(error){
            console.log(error)
        }        
    }
    return {flatConDataProcess : flatConDataProcess}
}