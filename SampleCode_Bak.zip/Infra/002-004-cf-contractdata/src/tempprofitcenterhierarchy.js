// 'use strict';
const { Spanner } = require('@google-cloud/spanner');
const uuid = require('uuidv4');

truncateTempProfitCenterHierarchy = async function(projectId, instanceId, databaseId){       
    const spanner = new Spanner({
        projectId: projectId,
    });
    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);   

    // const temprof = database.table('TempProfitCenterHierarchy');
    // const keys = [];
    // const query = {columns: ['ProfitCenterNbr']};
    try{
        const [truncTempProfitCenterHierarchy] = await database.runPartitionedUpdate({sql:`DELETE FROM TempProfitCenterHierarchy WHERE true`});
        console.log(`TempProfitCenterHierarchy: ${truncTempProfitCenterHierarchy} row/s deleted`);
        // const [truncTempProfitCenterHierarchy] = await temprof.read(query);
        // if(truncTempProfitCenterHierarchy.length > 0){
        //     truncTempProfitCenterHierarchy.forEach(row =>{
        //         let temp = JSON.stringify(row);
        //         keys.push(temp);
        //     });
        //     await temprof.deleteRows(keys);        
        //     console.log(`DELETE ALL ROWS IN TempProfitCenterHierarchy - DONE`);            
        // }
        // else{
        //     console.log(`No rows to be deleted. - TempProfitCenterHierarchy`);
        // }  
    }
    catch(error){
        console.log(error);
        return error;
    }
    finally{
        await database.close();
    }
}
inserttempprofit_CF6 = async function(projectId, instanceId, databaseId){
    const spanner = new Spanner({
        projectId: projectId,
    });
    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);
    const tempprofit = database.table('TempProfitCenterHierarchy');
    try{
        [insert_to_TempProfit_6_4] = await database.run(
            `SELECT DISTINCT 
            lev4.EntityCd ProfitCenterNbr 
            ,lev3.EntityCd ClientServiceGroupCd
            , '' CreateDttm
            , '' CreateUserId
            FROM MRDRHierarchyDump lev1
            INNER JOIN MRDRHierarchyDump lev2
            ON lev1.ChildEntityCd = lev2.EntityCd
            AND LTRIM(RTRIM(lev2.entitylev)) = '2'
            INNER JOIN MRDRHierarchyDump lev3
            ON lev2.ChildEntityCd = lev3.EntityCd
            AND LTRIM(RTRIM(lev3.entitylev)) = '3'
            INNER JOIN MRDRHierarchyDump lev4
            ON lev3.ChildEntityCd = lev4.EntityCd
            AND LTRIM(RTRIM(lev4.entitylev)) = '4'
            WHERE LTRIM(RTRIM(lev1.entitylev)) = '1'
            AND LTRIM(RTRIM(lev1.hierarchycd)) = 'ACN'
            AND lev4.EntityCd  BETWEEN '0000000000' AND '9999999999'
            AND (lev4.ChildEntityFl is NULL OR  RTRIM(lev4.ChildEntityFl)='')
            AND LTRIM(RTRIM(lev1.ENTITYCD)) <> 'OTHER'
            AND LTRIM(RTRIM(lev3.EntityCd)) <> 'GVDBZ0XXX'`
            );

        if(insert_to_TempProfit_6_4.length > 0)
            {
                let rows = [];
                insert_to_TempProfit_6_4.forEach(row =>{
                    let temp = row.toJSON();
                    temp.CreateUserId = 'MMC.JOB';
                    temp.CreateDttm = (new Date());
                    rows.push(temp);

                     tempprofit.insert(rows);
                })
               
                console.log(`TempProfitCenterHierarchy: ${insert_to_TempProfit_6_4.length}  row(s) inserted. Level 4`);
            }
            else{
                console.log(`TempProfitCenterHierarchy:  No row(s) inserted. Level 4`);
            }
        [insert_to_TempProfit_6_5] = await database.run(
            `SELECT DISTINCT 
            lev5.EntityCd ProfitCenterNbr
            ,lev3.EntityCd ClientServiceGroupCd
            FROM MRDRHierarchyDump lev1
            INNER JOIN MRDRHierarchyDump lev2
            ON lev1.ChildEntityCd = lev2.EntityCd
            AND LTRIM(RTRIM(lev2.entitylev)) = '2'
            INNER JOIN MRDRHierarchyDump lev3
            ON lev2.ChildEntityCd = lev3.EntityCd
            AND LTRIM(RTRIM(lev3.entitylev)) = '3'
            INNER JOIN MRDRHierarchyDump lev4
            ON lev3.ChildEntityCd = lev4.EntityCd
            AND LTRIM(RTRIM(lev4.entitylev)) = '4'
            INNER JOIN MRDRHierarchyDump lev5
            ON lev4.ChildEntityCd = lev5.EntityCd
            AND LTRIM(RTRIM(lev5.entitylev)) = '5'
            WHERE LTRIM(RTRIM(lev1.entitylev)) = '1'
            AND LTRIM(RTRIM(lev1.hierarchycd)) = 'ACN'
            AND lev5.EntityCd  BETWEEN '0000000000' AND '9999999999'
            AND (lev5.ChildEntityFl is NULL OR  RTRIM(lev5.ChildEntityFl)='')
            AND LTRIM(RTRIM(lev1.ENTITYCD)) <> 'OTHER'
            AND LTRIM(RTRIM(lev3.EntityCd)) <> 'GVDBZ0XXX'`
            );
        if(insert_to_TempProfit_6_5.length >0){
            let rows = [];
            insert_to_TempProfit_6_5.forEach(row => {
                    let temp = row.toJSON();
                    temp.CreateUserId = 'MMC.JOB';
                    temp.CreateDttm = (new Date());
                    rows.push(temp);

                    tempprofit.insert(rows);
                });
               
               console.log(`TempProfitCenterHierarchy: ${insert_to_TempProfit_6_5.length} row(s) inserted. Level 5`);
        }
        else{
            console.log(`TempProfitCenterHierarchy:  No row(s) inserted. Level 5`);
        }

        [insert_to_TempProfit_6_6] = await database.run(
            `SELECT DISTINCT 
            lev6.EntityCd ProfitCenterNbr
            ,lev3.EntityCd ClientServiceGroupCd
            FROM MRDRHierarchyDump lev1
            INNER JOIN MRDRHierarchyDump lev2
            ON lev1.ChildEntityCd = lev2.EntityCd
            AND LTRIM(RTRIM(lev2.entitylev)) = '2'
            INNER JOIN MRDRHierarchyDump lev3
                                                                                                                                                                                                                            
                ON lev2.ChildEntityCd = lev3.EntityCd
                                                                                                                                                                                                                        
                AND LTRIM(RTRIM(lev3.entitylev)) = '3'
                                                                                                                                                                                                                                        
            INNER JOIN MRDRHierarchyDump lev4
                                                                                                                                                                                                                            
                ON lev3.ChildEntityCd = lev4.EntityCd
                                                                                                                                                                                                                        
                AND LTRIM(RTRIM(lev4.entitylev)) = '4'
                                                                                                                                                                                                                                        
            INNER JOIN MRDRHierarchyDump lev5
                                                                                                                                                                                                                            
                ON lev4.ChildEntityCd = lev5.EntityCd
                                                                                                                                                                                                                        
                AND LTRIM(RTRIM(lev5.entitylev)) = '5'
                                                                                                                                                                                                                                        
            INNER JOIN MRDRHierarchyDump lev6
                                                                                                                                                                                                                            
                ON lev5.ChildEntityCd = lev6.EntityCd
                                                                                                                                                                                                                        
                AND LTRIM(RTRIM(lev6.entitylev)) = '6'
                                                                                                                                                                                                                                        
            WHERE lev1.entitylev = '1'
                                                                                                                                                                                                                                        
            AND LTRIM(RTRIM(lev1.hierarchycd)) = 'ACN'
                                                                                                                                                                                                                                    
            AND lev6.EntityCd  BETWEEN '0000000000' AND '9999999999'
                                                                                                                                                                                                        
            AND (lev6.ChildEntityFl is NULL OR  RTRIM(lev6.ChildEntityFl)='')
                                                                                                                                                                                                
            AND LTRIM(RTRIM(lev1.ENTITYCD)) <> 'OTHER'
                                                                                                                                                                                                                                    
            AND LTRIM(RTRIM(lev3.EntityCd)) <> 'GVDBZ0XXX'`
            );

        if(insert_to_TempProfit_6_6.length >0){
            let rows = [];
            insert_to_TempProfit_6_6.forEach(row => {
                    let temp = row.toJSON();
                    temp.CreateUserId = 'MMC.JOB';
                    temp.CreateDttm = (new Date());
                    rows.push(temp);

                    tempprofit.insert(rows);
                });
               
               console.log(`TempProfitCenterHierarchy: ${insert_to_TempProfit_6_6.length} row(s) inserted. Level 6`);
        }
        else{
            console.log(`TempProfitCenterHierarchy:  No row(s) inserted. Level 6`);
        }

        [insert_to_TempProfit_6_7] = await database.run(
            `SELECT DISTINCT                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
            lev7.EntityCd ProfitCenterNbr
            ,lev3.EntityCd ClientServiceGroupCd
            FROM MRDRHierarchyDump lev1
                                                                                                                                                                                                 
                INNER JOIN MRDRHierarchyDump lev2
                                                                                                                                                                                                                              
                    ON lev1.ChildEntityCd = lev2.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev2.entitylev)) = '2'
                                                                                                                                                                                                                                            
                INNER JOIN MRDRHierarchyDump lev3
                                                                                                                                                                                                                              
                    ON lev2.ChildEntityCd = lev3.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev3.entitylev)) = '3'
                                                                                                                                                                                                                                            
                INNER JOIN MRDRHierarchyDump lev4
                                                                                                                                                                                                                              
                    ON lev3.ChildEntityCd = lev4.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev4.entitylev)) = '4'
                                                                                                                                                                                                                                            
                INNER JOIN MRDRHierarchyDump lev5
                                                                                                                                                                                                                              
                    ON lev4.ChildEntityCd = lev5.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev5.entitylev)) = '5'
                                                                                                                                                                                                                                            
                INNER JOIN MRDRHierarchyDump lev6
                                                                                                                                                                                                                              
                    ON lev5.ChildEntityCd = lev6.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev6.entitylev)) = '6'
                                                                                                                                                                                                                                           
                INNER JOIN MRDRHierarchyDump lev7
                                                                                                                                                                                                                              
                    ON lev6.ChildEntityCd = lev7.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev7.entitylev)) = '7'	
                                                                                                                                                                                                                                           
            WHERE lev1.entitylev = '1'
                                                                                                                                                                                                                                            
                AND LTRIM(RTRIM(lev1.hierarchycd)) = 'ACN'
                                                                                                                                                                                                                                       
                AND lev7.EntityCd  BETWEEN '0000000000' AND '9999999999'
                                                                                                                                                                                                           
                AND (lev7.ChildEntityFl is NULL OR  RTRIM(lev7.ChildEntityFl)='')
                                                                                                                                                                                                  
                AND LTRIM(RTRIM(lev1.ENTITYCD)) <> 'OTHER'
                                                                                                                                                                                                                                       
                AND LTRIM(RTRIM(lev3.EntityCd)) <> 'GVDBZ0XXX'`
            );
        if(insert_to_TempProfit_6_7.length > 0){
            let rows = [];
            insert_to_TempProfit_6_7.forEach(row => {
                    let temp = row.toJSON();
                    temp.CreateUserId = 'MMC.JOB';
                    temp.CreateDttm = (new Date());
                    rows.push(temp);

                     tempprofit.insert(rows);
                });
              
               console.log(`TempProfitCenterHierarchy:  ${insert_to_TempProfit_6_7.length} row(s) inserted. Level 7`);
        }
        else{
            console.log(`TempProfitCenterHierarchy:  No row(s) inserted. Level 7`);
        }

        [insert_to_TempProfit_6_8] = await database.run(
            `SELECT DISTINCT
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
            lev8.EntityCd ProfitCenterNbr
            ,lev3.EntityCd ClientServiceGroupCd
                                                                                                                                                                                                                                   
            FROM MRDRHierarchyDump lev1
                                                                                                                                                                                                                                     
                INNER JOIN MRDRHierarchyDump lev2
                                                                                                                                                                                                                              
                    ON lev1.ChildEntityCd = lev2.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev2.entitylev)) = '2'
                                                                                                                                                                                                                                            
                INNER JOIN MRDRHierarchyDump lev3
                                                                                                                                                                                                                              
                    ON lev2.ChildEntityCd = lev3.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev3.entitylev)) = '3'
                                                                                                                                                                                                                                            
                INNER JOIN MRDRHierarchyDump lev4
                                                                                                                                                                                                                              
                    ON lev3.ChildEntityCd = lev4.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev4.entitylev)) = '4'
                                                                                                                                                                                                                                            
                INNER JOIN MRDRHierarchyDump lev5
                                                                                                                                                                                                                              
                    ON lev4.ChildEntityCd = lev5.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev5.entitylev)) = '5'
                                                                                                                                                                                                                                            
                INNER JOIN MRDRHierarchyDump lev6
                                                                                                                                                                                                                              
                    ON lev5.ChildEntityCd = lev6.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev6.entitylev)) = '6'	
                                                                                                                                                                                                                                           
                INNER JOIN MRDRHierarchyDump lev7
                                                                                                                                                                                                                              
                    ON lev6.ChildEntityCd = lev7.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev7.entitylev)) = '7'	
                                                                                                                                                                                                                                           
                INNER JOIN MRDRHierarchyDump lev8
                                                                                                                                                                                                                              
                    ON lev7.ChildEntityCd = lev8.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev8.entitylev)) = '8'	
                                                                                                                                                                                                                                           
            WHERE lev1.entitylev = '1'
                                                                                                                                                                                                                                            
                AND LTRIM(RTRIM(lev1.hierarchycd)) = 'ACN'
                                                                                                                                                                                                                                       
                AND lev8.EntityCd  BETWEEN '0000000000' AND '9999999999'
                                                                                                                                                                                                           
                AND (lev8.ChildEntityFl is NULL OR  RTRIM(lev8.ChildEntityFl)='')
                                                                                                                                                                                                  
                AND LTRIM(RTRIM(lev1.ENTITYCD)) <> 'OTHER'
                                                                                                                                                                                                                                       
                AND LTRIM(RTRIM(lev3.EntityCd)) <> 'GVDBZ0XXX'`
            );
        if(insert_to_TempProfit_6_8.length > 0){
            let rows = [];
            insert_to_TempProfit_6_8.forEach(row => {
                    let temp = row.toJSON();
                    temp.CreateUserId = 'MMC.JOB';
                    temp.CreateDttm = (new Date());
                    rows.push(temp);

                    tempprofit.insert(rows);
                });
               
               console.log(`TempProfitCenterHierarchy:  ${insert_to_TempProfit_6_8.length} row(s) inserted. Level 8`);
        }
        else{
            console.log(`TempProfitCenterHierarchy:  No row(s) inserted. Level 8`);
        }

        [insert_to_TempProfit_6_9] = await database.run(
            `SELECT DISTINCT                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                 
             lev9.EntityCd ProfitCenterNbr
            ,lev3.EntityCd ClientServiceGroupCd                                                                                                                                                                                                                      
            FROM MRDRHierarchyDump lev1
                                                                                                                                                                                                                                     
                INNER JOIN MRDRHierarchyDump lev2
                                                                                                                                                                                                                              
                    ON lev1.ChildEntityCd = lev2.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev2.entitylev)) = '2'
                                                                                                                                                                                                                                            
                INNER JOIN MRDRHierarchyDump lev3
                                                                                                                                                                                                                              
                    ON lev2.ChildEntityCd = lev3.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev3.entitylev)) = '3'
                                                                                                                                                                                                                                            
                INNER JOIN MRDRHierarchyDump lev4
                                                                                                                                                                                                                              
                    ON lev3.ChildEntityCd = lev4.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev4.entitylev)) = '4'
                                                                                                                                                                                                                                            
                INNER JOIN MRDRHierarchyDump lev5
                                                                                                                                                                                                                              
                    ON lev4.ChildEntityCd = lev5.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev5.entitylev)) = '5'
                                                                                                                                                                                                                                            
                INNER JOIN MRDRHierarchyDump lev6
                                                                                                                                                                                                                              
                    ON lev5.ChildEntityCd = lev6.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev6.entitylev)) = '6'	
                                                                                                                                                                                                                                           
                INNER JOIN MRDRHierarchyDump lev7
                                                                                                                                                                                                                              
                    ON lev6.ChildEntityCd = lev7.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev7.entitylev)) = '7'	
                                                                                                                                                                                                                                           
                INNER JOIN MRDRHierarchyDump lev8
                                                                                                                                                                                                                              
                    ON lev7.ChildEntityCd = lev8.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev8.entitylev)) = '8'	
                                                                                                                                                                                                                                           
                INNER JOIN MRDRHierarchyDump lev9
                                                                                                                                                                                                                              
                    ON lev8.ChildEntityCd = lev9.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev9.entitylev)) = '9'	
                                                                                                                                                                                                                                           
            WHERE lev1.entitylev = '1'
                                                                                                                                                                                                                                            
                AND LTRIM(RTRIM(lev1.hierarchycd)) = 'ACN'
                                                                                                                                                                                                                                       
                AND lev9.EntityCd  BETWEEN '0000000000' AND '9999999999'
                                                                                                                                                                                                           
                AND (lev9.ChildEntityFl is NULL OR  RTRIM(lev9.ChildEntityFl)='')
                                                                                                                                                                                                  
                AND LTRIM(RTRIM(lev1.ENTITYCD)) <> 'OTHER'
                                                                                                                                                                                                                                       
                AND LTRIM(RTRIM(lev3.EntityCd)) <> 'GVDBZ0XXX'`
            );
        if(insert_to_TempProfit_6_9.length > 0){
            let rows = [];
            insert_to_TempProfit_6_9.forEach(row => {
                    let temp = row.toJSON();
                    temp.CreateUserId = 'MMC.JOB';
                    temp.CreateDttm = (new Date());
                    rows.push(temp);

                     tempprofit.insert(rows);
                });
               
               console.log(`TempProfitCenterHierarchy: ${insert_to_TempProfit_6_9.length}  row(s) inserted. Level 9`);
        }
        else{
            console.log(`TempProfitCenterHierarchy:  No row(s) inserted. Level 9`);
        }

        [insert_to_TempProfit_6_10] = await database.run(
            `SELECT DISTINCT                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                 
            lev10.EntityCd ProfitCenterNbr
            ,lev3.EntityCd ClientServiceGroupCd                                                                                                                                                                                                                      
            FROM MRDRHierarchyDump lev1
                                                                                                                                                                                                                                     
                INNER JOIN MRDRHierarchyDump lev2
                                                                                                                                                                                                                              
                    ON lev1.ChildEntityCd = lev2.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev2.entitylev)) = '2'
                                                                                                                                                                                                                                            
                INNER JOIN MRDRHierarchyDump lev3
                                                                                                                                                                                                                              
                    ON lev2.ChildEntityCd = lev3.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev3.entitylev)) = '3'
                                                                                                                                                                                                                                            
                INNER JOIN MRDRHierarchyDump lev4
                                                                                                                                                                                                                              
                    ON lev3.ChildEntityCd = lev4.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev4.entitylev)) = '4'
                                                                                                                                                                                                                                            
                INNER JOIN MRDRHierarchyDump lev5
                                                                                                                                                                                                                              
                    ON lev4.ChildEntityCd = lev5.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev5.entitylev)) = '5'
                                                                                                                                                                                                                                            
                INNER JOIN MRDRHierarchyDump lev6
                                                                                                                                                                                                                              
                    ON lev5.ChildEntityCd = lev6.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev6.entitylev)) = '6'	
                                                                                                                                                                                                                                           
                INNER JOIN MRDRHierarchyDump lev7
                                                                                                                                                                                                                              
                    ON lev6.ChildEntityCd = lev7.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev7.entitylev)) = '7'	
                                                                                                                                                                                                                                           
                INNER JOIN MRDRHierarchyDump lev8
                                                                                                                                                                                                                              
                    ON lev7.ChildEntityCd = lev8.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev8.entitylev)) = '8'	
                                                                                                                                                                                                                                           
                INNER JOIN MRDRHierarchyDump lev9
                                                                                                                                                                                                                              
                    ON lev8.ChildEntityCd = lev9.EntityCd
                                                                                                                                                                                                                             
                    AND LTRIM(RTRIM(lev9.entitylev)) = '9'	
                                                                                                                                                                                                                                           
                INNER JOIN MRDRHierarchyDump lev10
                                                                                                                                                                                                                             
                    ON lev9.ChildEntityCd = lev10.EntityCd
                                                                                                                                                                                                                            
                    AND LTRIM(RTRIM(lev10.entitylev)) = '10'
                                                                                                                                                                                                                                          
            WHERE lev1.entitylev = '1'
                                                                                                                                                                                                                                            
                AND LTRIM(RTRIM(lev1.hierarchycd)) = 'ACN'
                                                                                                                                                                                                                                       
                AND lev10.EntityCd  BETWEEN '0000000000' AND '9999999999'
                                                                                                                                                                                                          
                AND (lev10.ChildEntityFl is NULL OR  RTRIM(lev10.ChildEntityFl)='')
                                                                                                                                                                                                
                AND LTRIM(RTRIM(lev1.ENTITYCD)) <> 'OTHER'
                                                                                                                                                                                                                                       
                AND LTRIM(RTRIM(lev3.EntityCd)) <> 'GVDBZ0XXX'`
            );
        if(insert_to_TempProfit_6_10.length > 0){
            let rows = [];
            insert_to_TempProfit_6_10.forEach(row => {
                    let temp = row.toJSON();
                    temp.CreateUserId = 'MMC.JOB';
                    temp.CreateDttm = (new Date());
                    rows.push(temp);

                     tempprofit.insert(rows);
                });
              
               console.log(`TempProfitCenterHierarchy: ${insert_to_TempProfit_6_10.length} row(s) inserted. Level 10`);
        }
        else{
            console.log(`TempProfitCenterHierarchy:  No row(s) inserted. Level 10`);
        }
    }
    catch(err){
        console.log(err);
    }
    finally{
        await database.close()
    }
}


module.exports = {
    truncateTempProfitCenterHierarchy,
    inserttempprofit_CF6
}