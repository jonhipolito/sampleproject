const { Spanner } = require('@google-cloud/spanner');
const uuid = require('uuidv4');

truncateContractStagePrev = async function(projectId, instanceId, databaseId){
    const spanner = new Spanner({
        projectId: projectId,
    });
    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);    

    try{
        const [truncContractStagePrev] = await database.runPartitionedUpdate({sql:`DELETE FROM ContractStagePrevious WHERE true`});
        console.log(`ContractStagePrevious: ${truncContractStagePrev} row(s) deleted`);
    }
    catch(error){
        console.log(error);
        return error;
    }
    finally{
        await database.close();
    }    
}

insertContractStagePrev_CF10 = async function(projectId, instanceId, databaseId){
    const spanner = new Spanner({
        projectId: projectId,
    });
    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId); 
    const cspTable = database.table('ContractStagePrevious');
    try{

        const [rows_cf10] = await database.run({sql:
            `SELECT '' as ContractStagePreviousKey
            ,ContractNbr
            ,ContractNm
            ,CustomerNbr
            ,ContractStartDt
            ,ContractEndDt
            ,ContractDirectorPersonnelNbr
            ,ContractDirectorNm
            ,ClientServiceGroupCd
            ,CountryCd
            ,CreateUserId
            ,CreateDttm
            ,TypeOfWorkCd
        FROM ContractStage`
        });
        if(rows_cf10.length > 0){
            let rows = [];
            rows_cf10.forEach(row =>{
                    let temp = row.toJSON();
                    temp.ContractStagePreviousKey = uuid();
                    temp.UpdateUserId = 'MMC.JOB';
                    temp.UpdateDttm = (new Date());  
                    rows.push(temp);

                    cspTable.insert(rows);
                });
                
                console.log(`ContractStagePrevious:  ${rows_cf10.length} row(s) inserted.`);
        }
        else{
            console.log(`ContractStagePrevious: No rows inserted.`);
        }
    }
    catch(err){
        console.log(err)
    }
    finally{
        await database.close();
    }
}

module.exports = {
    truncateContractStagePrev,
    insertContractStagePrev_CF10
}