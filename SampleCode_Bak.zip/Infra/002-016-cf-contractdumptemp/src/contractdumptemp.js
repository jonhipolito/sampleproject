
insertTempContract_CF2_Con = async function (database){
    const conTable = database.table('ContractsDumpTemp');
    try{

        const [conData] = await database.run({sql:`SELECT DISTINCT
                            con.ContractCd as ContractNbr
                            , con.ContractDescr as ContractNm
                            , con.CustomerNbr  
                            , con.ContractUserStatCd as ContractStatus  
                            , con.ContractStartDt
                            , con.ContractEndDt
                            , con.RespSrExecPrimaryPersNbr as ContractDirectorPersonnelNbr
                            , con.RespSrExecPrimaryEntID as ContractDirectorNm    
                            ,cl.WBSElementNbr
                        FROM MRDRContractsDump@{FORCE_INDEX=IX_ContractCd} con
                            INNER JOIN MRDRContractLineItemDump  cl
                                ON con.ContractCd = cl.ContractCd
                        WHERE             
                            RTRIM(con.ContractUserStatCd) NOT IN ('E0011', 'E0006') 
                        LIMIT 10`
                    });

       if(conData.length > 0){
           console.log(`ContractsDumpTemp: Started.`);
            let rowsToInsert = [];
            conData.forEach(row =>{
                let temp = row.toJSON();
                temp.CreateUserId = 'MMC.JOB';
                temp.CreateDttm = (new Date());
                rowsToInsert.push(temp);

                 conTable.insert(rowsToInsert);
            })
           
            console.log(`Successfully inserted ${conData.length} row(s). -ContractsDumpTemp`);
        }
        else{
            console.log(`ContractsDumpTemp: No row(s) inserted.`);
        }
    }
    catch(error){
        console.log(error);
        return error;
    }
}
module.exports = {
    insertTempContract_CF2_Con
}