
const   contractdumptemp = require('./contractdumptemp'),
        { Spanner } = require('@google-cloud/spanner'),
        projectId = process.env.X_GOOGLE_GCLOUD_PROJECT,
        instanceId = 'si-27354-mmc',
        databaseId = 'db-27354-mmc-db',
        // projectId = 'sbx-27354-nmmcsbxdev-a9ab6909', //For Local Testing
        // instanceId = 'nextgenmmc', //For Local Testing
        // databaseId = 'mmcdb', //For Local Testing
        spanner = new Spanner({ projectId: projectId, }),
        instance = spanner.instance(instanceId),
        database = instance.database(databaseId);
 

 exports.contractdumptemp = async() => {
    try {
     console.log("Start: TempContract Process - Insert ContractDumpTemp Only");
     console.log(`CONTROL FLOW 2 - INSERTING DATA TO TEMPCONTRACT - IN PROGRESS`);
        await contractdumptemp.insertTempContract_CF2_Con(database);//control flow 2
     console.log("End: TempContract Process - Insert ContractDumpTemp Only");
    }
    catch (err) {
        console.error("Error: ", err);
    }
    finally{
       // await database.close();
        return true;
    }
    
}

//Run - Local
//  (async function() {
//   console.log(`CONTROL FLOW 2 - INSERTING DATA TO TEMPCONTRACT - IN PROGRESS`);
//   await tempcontract.insertTempContract_CF2_Con(database);//control flow 2
//  }())