
const { Spanner } = require('@google-cloud/spanner');
const uuid = require('uuidv4');

contractInsert = async (projectId, instanceId, databaseId) => {
    const spanner = new Spanner({
        projectId: projectId,
    });
    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);
    const contractTable = database.table('Contract');

    try {
        //insert contract details - regular
        [insertRows] = await database.run({
            sql:
                `SELECT DISTINCT cs.ContractNbr
            , cs.ContractNm
            , cs.CustomerNbr
            , cs.ContractStartDt
            , cs.ContractEndDt
            , cs.CountryCd
            , cs.ContractDirectorPersonnelNbr  as ContractDirectorPeopleKeyNbr
            , cs.ContractDirectorNm
            , cd.RBEDescr
            FROM ContractStage AS cs
 INNER JOIN MRDRContractsDump cd
ON cs.ContractNbr = cd.ContractCd`
        });
        console.log(`ContractStage: ${insertRows.length} rows`);
        let contw = await getContractTypeOfWorkCd(database);
        let contwArr = []
        contw.forEach(row => {
            let tempRow = row.toJSON();
            contwArr.push(tempRow);
        })
        let tw = await getTypeOfWork(database);
        let twArr = [];
        tw.forEach(row => {
            let tempRow = row.toJSON();
            twArr.push(tempRow);
        })
        if (insertRows.length > 0) {
            let rows = [];
            let promises = [];
            insertRows.forEach(async (row) => {
                let tempRow = row.toJSON();
                tempRow.CreateDttm = (new Date());
                tempRow.UpdateDttm = (new Date());
                if (!tempRow.ContractDirectorPeopleKeyNbr) {
                    tempRow.ContractDirectorNm = "No Contract Director Defined";
                }

                let contws = contwArr.filter(x => x.ContractNbr == tempRow.ContractNbr);
                let tws = twArr.filter(y => contws.map(x => x.TypeOfWorkCd.trim()).includes(y.TypeOfWorkCd.trim()));
                tempRow.TypeOfWork = tws.map(x => x.TypeOfWorkDesc).join(" || ");
                tempRow.CreateUserId = 'MMC_JOB_USER';
                tempRow.UpdateUserId = 'MMC_JOB_USER';
                promises.push(contractTable.upsert(tempRow));
            })
            await Promise.all(promises);
            console.log(`Contract Regular: ${insertRows.length} row/s inserted`);
        } else {
            console.log('Contract Regular: No Rows inserted');
        }

    } catch (err) {
        console.log('Error', err);
    } finally {
        console.log('Close DB');
        await database.close();
    }

}

function getContractTypeOfWorkCd(database) {
    return new Promise(async (resolve, reject) => {
        const [ContractTypeOfWorkCd] = await database.run({
            sql: `SELECT ContractNbr, TypeOfWorkCd
                FROM ContractStage
                `
        });
        resolve(ContractTypeOfWorkCd);
    });
};

function getTypeOfWork(database) {
    return new Promise(async (resolve, reject) => {
        const [typeOfWorkRows] = await database.run({
            sql: `SELECT *
                FROM TypeOfWork
            `
        });
        resolve(typeOfWorkRows);
    });
};

module.exports = {
    contractInsert
}