// Imports the Google Cloud client library
const Contract = require('./contract');
const projectId = process.env.X_GOOGLE_GCLOUD_PROJECT;
const instanceId = 'si-27354-mmc';
const databaseId = 'db-27354-mmc-db';

 exports.populateContractTable = async(req, res) => {    
    console.log("start: populateContractTable");
    try{
        await Contract.contractInsert(projectId, instanceId, databaseId);
        console.log("end: populateContractTable");
    } catch (err) {
        console.error('ERROR:', err);
    } 
    finally{
        const { PubSub } = require('@google-cloud/pubsub');
        const pubsub = new PubSub({ projectId });
        const dataBuffer = Buffer.from("popcontract");
        await pubsub.topic("JobEvents").publish(dataBuffer);
        res.status(200).json({
            data: 'SUCCESSFUL: popcontract'
        });
    }
    //res.send();
}

// queryData();


