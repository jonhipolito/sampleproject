exports.processUCD = async (req, res) => {
    //(async function() { 
    //const uuid = require('uuidv4');
    const { Spanner } = require('@google-cloud/spanner');    
    //process.env.GOOGLE_APPLICATION_CREDENTIALS = './sa-npd-27354-oriondev-95184682-42b68c284938.json';  //comment  
    const projectId = process.env.X_GOOGLE_GCLOUD_PROJECT;

    const spanner = new Spanner({
        projectId: projectId,
    });
    
    const instanceId = 'si-27354-mmc';
    const databaseId = 'db-27354-mmc-db';

    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);
    const towTable = database.table('Customer');
    var insertedCount;
    var updatedCount;
    try {
        //const [rowsDump_insert] = await database.run({
            //sql: `SELECT dump.TypeOfWorkCd, dump.TypeOfWorkDesc 
           // FROM MRDRTypeOfWorkDump AS dump 
           // LEFT JOIN TypeOfWork tow on dump.TypeOfWorkCd = tow.TypeOfWorkCd 
           // WHERE tow.TypeOfWorkCd IS NULL`
        //});

        //if (rowsDump_insert.length > 0) {
         //   let rowBase = [];

           // rowsDump_insert.forEach(row => {
            //    let tempRow = row.toJSON();
            //    tempRow.TypeOfWorkKey = uuid();
            //    tempRow.CreateUserId = 'MMC_JOB_USER';
            //    tempRow.UpdateUserId = 'MMC_JOB_USER';
            //    tempRow.CreateDttm = new Date();
            //    tempRow.UpdateDttm = new Date();
            //    rowBase.push(tempRow);
            //});
           // console.log('Insert new Type Of Work - IN PROGRESS');
           // await towTable.insert(rowBase);
           // insertedCount = rowsDump_insert.length;
           // console.log('Insert new Type Of Work - DONE');
        //}

        const [rowsDump_update] = await database.run({
            sql: `SELECT a.CustomerNbr, b.CountryKey, b.City, 
            c.ContentValue as IndustrySegment
            FROM Customer a
            INNER JOIN MRDRCustomerMasterDump b
            ON a.CustomerNbr = b.CustomerNbr
            LEFT JOIN
            (SELECT CustomerNbr, ContentValue
            FROM MRDRCustomerAttributeDump
            WHERE AttributeCd = 'INDSEG'
            AND CustomerNbr IN (SELECT CustomerNbr FROM Customer)) c
            ON a.CustomerNbr = c.CustomerNbr`
        });

        if (rowsDump_update.length > 0) {
            let rowRef = [];

            for(let x=0; x < rowsDump_update.length; x++) {
                let tempRow = rowsDump_update[x].toJSON();
                tempRow.UpdateUserId = 'MMC_JOB_USER';
                tempRow.UpdateDttm = (new Date());
                tempRow.CreateUserId = 'MMC_JOB_USER';
                rowRef.push(tempRow);
                if(rowRef.length == 1000) {
                    await towTable.update(rowRef);
                    rowRef = [];
                }
            }
            console.log('Update Customer Details - IN PROGRESS');
            if(rowRef.length > 0) {
                await towTable.update(rowRef);    
            }            
            updatedCount = rowsDump_update.length;
            console.log('Update Customer Details - DONE');
        }
    } catch (err) {
        console.error('ERROR:', err);
    } finally {
        database.close();
        const { PubSub } = require('@google-cloud/pubsub'); 
        const pubsub = new PubSub({ projectId });
        const dataBuffer = Buffer.from("updatecustomerdetails");
        await pubsub.topic("JobEvents").publish(dataBuffer); 
        res.status(200).json({ 
        data: ' Records Updated: ' + updatedCount 
        }); 

    }
}
//())
;