'use strict';

const projectId = process.env.X_GOOGLE_GCLOUD_PROJECT,
    instanceId = 'si-27354-mmc',
    databaseId = 'db-27354-mmc-db',
    gr = require('./geographicregion')(projectId, instanceId, databaseId),
    gu = require('./geographicunit')(projectId, instanceId, databaseId),
    country = require('./country')(projectId, instanceId, databaseId);


exports.processGRGUCountry = async (req, res) => {
    try{
        console.log('Populate GRGUCOUNTRY - STARTED');
        await gr.processGR();
        await gu.processGU();
        await country.processCountry();
        
    }
    catch(err){
        console.error("Error: ", err);
    }
    finally{
        console.log('Populate GRGUCOUNTRY - FINISHED');
        const { PubSub } = require('@google-cloud/pubsub');
        const pubsub = new PubSub({ projectId });
        const dataBuffer = Buffer.from("grgucountry");
        await pubsub.topic("JobEvents").publish(dataBuffer);
        res.status(200).json({
            data: 'SUCCESSFUL: GRGUCOUNTRY'
        });
    }
}