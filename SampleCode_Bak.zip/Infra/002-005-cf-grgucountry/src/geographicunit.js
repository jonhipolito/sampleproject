'use strict';

// const uuid = require('uuidv4');
const { Spanner } = require('@google-cloud/spanner');
const uuid = require('uuidv4');

module.exports = function (projectId, instanceId, databaseId) {
    let processGU;

    processGU = async function () {

        const spanner = new Spanner({
            projectId: projectId,
        });


        const instance = spanner.instance(instanceId);
        const database = instance.database(databaseId);
        const guTable = database.table('GeographicUnit');
        try {
            const [rowsDump_insert] = await database.run({
                sql: `SELECT DISTINCT a.GeographicUnitCd
                            ,a.GeographicUnitDesc
                            ,b.GeographicRegionCd
                        FROM (
                            SELECT DISTINCT RTRIM(grcd.LocationAttributeValue, " ") AS GeographicRegionCd
                            ,RTRIM(reg.RegionNm, " ") AS GeographicRegionDesc
                            ,RTRIM(gucd.LocationAttributeValue, " ") AS GeographicUnitCd
                            ,RTRIM(geou.GeoUnitNm, " ") AS GeographicUnitDesc
                            ,RTRIM(COALESCE(ctcd4.LocationAttributeValue, ctcd3.LocationAttributeValue), " ") AS CountryCd
                            ,RTRIM(COALESCE(cnt4.CountryNm, cnt3.CountryNm), " ") AS CountryNm
                        FROM  (
                                SELECT gr.LocationId AS RegionID
                                    ,gr.LocationNm AS RegionNm
                                FROM MRDRLocationHierarchyNodeDump gr
                                WHERE gr.LocationId IN (
                                    SELECT LocationId
                                    FROM MRDRLocationHierarchyAttributeDump
                                    WHERE RTRIM(LocationAttributeValue) = 'Geographic Region'
                                    AND RTRIM(LocationAttributeCd) = 'USGTYP')
                                ) reg
                            INNER JOIN MRDRLocationHierarchyRelationshipDump reggu ON reg.RegionID = reggu.ParentLocationId
                                AND RTRIM(reggu.LocationHierarchyTypeCd) = 'ACN'
                            INNER JOIN (
                                SELECT gu.LocationId AS GeoUnitID
                                    ,gu.LocationNm AS GeoUnitNm
                                FROM MRDRLocationHierarchyNodeDump gu
                                WHERE gu.LocationId IN (
                                    SELECT LocationId
                                    FROM MRDRLocationHierarchyAttributeDump
                                    WHERE RTRIM(LocationAttributeValue) = 'Geographic Unit'
                                    AND RTRIM(LocationAttributeCd) = 'USGTYP')
                                ) geou ON reggu.LocationId = geou.GeoUnitID
                            LEFT JOIN MRDRLocationHierarchyRelationshipDump gugtm ON geou.GeoUnitID = gugtm.ParentLocationId
                                AND RTRIM(gugtm.LocationHierarchyTypeCd) = 'ACN'
                            LEFT JOIN (
                                SELECT gtm.LocationId AS GTMID
                                    ,gtm.LocationNm AS GTMNm
                                FROM MRDRLocationHierarchyNodeDump gtm
                                WHERE gtm.LocationId IN (
                                    SELECT LocationId
                                    FROM MRDRLocationHierarchyAttributeDump
                                    WHERE RTRIM(LocationAttributeValue) = 'Go To Market'
                                    AND RTRIM(LocationAttributeCd) = 'USGTYP')
                                ) gtmk ON gugtm.LocationId = gtmk.GTMID
                            LEFT JOIN MRDRLocationHierarchyRelationshipDump gtmcnt ON gtmk.GTMID = gtmcnt.ParentLocationId
                                AND RTRIM(gtmcnt.LocationHierarchyTypeCd) = 'AAA'
                            LEFT JOIN (
                                SELECT cnt.LocationId AS CountryID
                                    ,cnt.LocationNm AS CountryNm
                                FROM MRDRLocationHierarchyNodeDump cnt
                                WHERE cnt.LocationId IN (
                                    SELECT LocationId
                                    FROM MRDRLocationHierarchyAttributeDump
                                    WHERE RTRIM(LocationAttributeValue) = 'Country'
                                    AND RTRIM(LocationAttributeCd) = 'USGTYP')
                                ) cnt4 ON gtmcnt.LocationId = cnt4.CountryID
                            LEFT JOIN (
                                SELECT cnt.LocationId AS CountryID
                                    ,cnt.LocationNm AS CountryNm
                                FROM MRDRLocationHierarchyNodeDump cnt
                                WHERE cnt.LocationId IN (
                                    SELECT LocationId
                                    FROM MRDRLocationHierarchyAttributeDump
                                    WHERE RTRIM(LocationAttributeValue) = 'Country'
                                    AND RTRIM(LocationAttributeCd) = 'USGTYP')
                                ) cnt3 ON gugtm.LocationId = cnt3.CountryID
                            INNER JOIN MRDRLocationHierarchyAttributeDump grcd ON reg.RegionID = grcd.LocationId
                                AND RTRIM(grcd.LocationAttributeCd) = 'MRDRCD'
                            INNER JOIN MRDRLocationHierarchyAttributeDump gucd ON geou.GeoUnitID = gucd.LocationId
                                AND RTRIM(gucd.LocationAttributeCd) = 'MRDRCD'
                            LEFT JOIN MRDRLocationHierarchyAttributeDump ctcd4 ON cnt4.CountryID = ctcd4.LocationId
                                AND RTRIM(ctcd4.LocationAttributeCd) = 'MRDRCD'
                            LEFT JOIN MRDRLocationHierarchyAttributeDump ctcd3 ON cnt3.CountryID = ctcd3.LocationId
                                AND RTRIM(ctcd3.LocationAttributeCd) = 'MRDRCD'
                            ) a
                        INNER JOIN GeographicRegion b ON a.GeographicRegionCd = b.GeographicRegionCd
                        LEFT JOIN GeographicUnit c ON a.GeographicUnitCd = c.GeographicUnitCd
                        WHERE c.GeographicUnitCd IS NULL`
            });

            if (rowsDump_insert.length > 0) {
                let rowBase = [];

                rowsDump_insert.forEach(row => {
                    let tempRow = row.toJSON();
                    tempRow.GeographicUnitKey = uuid();
                    tempRow.CreateUserId = 'sample.user';
                    tempRow.UpdateUserId = 'sample.user';
                    tempRow.CreateDttm = (new Date());
                    tempRow.UpdateDttm = (new Date());
                    tempRow.DummyInd = 'N'
                    rowBase.push(tempRow);
                });
                console.log('Insert new Geographic Unit - IN PROGRESS');
                await guTable.insert(rowBase);
                console.log(`Insert new Geographic Unit - DONE - ${rowsDump_insert.length} row(s) inserted`);
            }

            const [rowsDump_update] = await database.run({
                sql: `SELECT DISTINCT a.GeographicUnitCd
                            ,a.GeographicUnitDesc
                            ,a.GeographicRegionCd
                            ,c.GeographicUnitKey
                        FROM (
                            SELECT DISTINCT RTRIM(grcd.LocationAttributeValue, " ") AS GeographicRegionCd
                            ,RTRIM(reg.RegionNm, " ") AS GeographicRegionDesc
                            ,RTRIM(gucd.LocationAttributeValue, " ") AS GeographicUnitCd
                            ,RTRIM(geou.GeoUnitNm, " ") AS GeographicUnitDesc
                            ,RTRIM(COALESCE(ctcd4.LocationAttributeValue, ctcd3.LocationAttributeValue), " ") AS CountryCd
                            ,RTRIM(COALESCE(cnt4.CountryNm, cnt3.CountryNm), " ") AS CountryNm
                        FROM  (
                                SELECT gr.LocationId AS RegionID
                                    ,gr.LocationNm AS RegionNm
                                FROM MRDRLocationHierarchyNodeDump gr
                                WHERE gr.LocationId IN (
                                    SELECT LocationId
                                    FROM MRDRLocationHierarchyAttributeDump
                                    WHERE RTRIM(LocationAttributeValue) = 'Geographic Region'
                                    AND RTRIM(LocationAttributeCd) = 'USGTYP')
                                ) reg
                            INNER JOIN MRDRLocationHierarchyRelationshipDump reggu ON reg.RegionID = reggu.ParentLocationId
                                AND RTRIM(reggu.LocationHierarchyTypeCd) = 'ACN'
                            INNER JOIN (
                                SELECT gu.LocationId AS GeoUnitID
                                    ,gu.LocationNm AS GeoUnitNm
                                FROM MRDRLocationHierarchyNodeDump gu
                                WHERE gu.LocationId IN (
                                    SELECT LocationId
                                    FROM MRDRLocationHierarchyAttributeDump
                                    WHERE RTRIM(LocationAttributeValue) = 'Geographic Unit'
                                    AND RTRIM(LocationAttributeCd) = 'USGTYP')
                                ) geou ON reggu.LocationId = geou.GeoUnitID
                            LEFT JOIN MRDRLocationHierarchyRelationshipDump gugtm ON geou.GeoUnitID = gugtm.ParentLocationId
                                AND RTRIM(gugtm.LocationHierarchyTypeCd) = 'ACN'
                            LEFT JOIN (
                                SELECT gtm.LocationId AS GTMID
                                    ,gtm.LocationNm AS GTMNm
                                FROM MRDRLocationHierarchyNodeDump gtm
                                WHERE gtm.LocationId IN (
                                    SELECT LocationId
                                    FROM MRDRLocationHierarchyAttributeDump
                                    WHERE RTRIM(LocationAttributeValue) = 'Go To Market'
                                    AND RTRIM(LocationAttributeCd) = 'USGTYP')
                                ) gtmk ON gugtm.LocationId = gtmk.GTMID
                            LEFT JOIN MRDRLocationHierarchyRelationshipDump gtmcnt ON gtmk.GTMID = gtmcnt.ParentLocationId
                                AND RTRIM(gtmcnt.LocationHierarchyTypeCd) = 'ACN'
                            LEFT JOIN (
                                SELECT cnt.LocationId AS CountryID
                                    ,cnt.LocationNm AS CountryNm
                                FROM MRDRLocationHierarchyNodeDump cnt
                                WHERE cnt.LocationId IN (
                                    SELECT LocationId
                                    FROM MRDRLocationHierarchyAttributeDump
                                    WHERE RTRIM(LocationAttributeValue) = 'Country'
                                    AND RTRIM(LocationAttributeCd) = 'USGTYP')
                                ) cnt4 ON gtmcnt.LocationId = cnt4.CountryID
                            LEFT JOIN (
                                SELECT cnt.LocationId AS CountryID
                                    ,cnt.LocationNm AS CountryNm
                                FROM MRDRLocationHierarchyNodeDump cnt
                                WHERE cnt.LocationId IN (
                                    SELECT LocationId
                                    FROM MRDRLocationHierarchyAttributeDump
                                    WHERE RTRIM(LocationAttributeValue) = 'Country'
                                    AND RTRIM(LocationAttributeCd) = 'USGTYP')
                                ) cnt3 ON gugtm.LocationId = cnt3.CountryID
                            INNER JOIN MRDRLocationHierarchyAttributeDump grcd ON reg.RegionID = grcd.LocationId
                                AND RTRIM(grcd.LocationAttributeCd) = 'MRDRCD'
                            INNER JOIN MRDRLocationHierarchyAttributeDump gucd ON geou.GeoUnitID = gucd.LocationId
                                AND RTRIM(gucd.LocationAttributeCd) = 'MRDRCD'
                            LEFT JOIN MRDRLocationHierarchyAttributeDump ctcd4 ON cnt4.CountryID = ctcd4.LocationId
                                AND RTRIM(ctcd4.LocationAttributeCd) = 'MRDRCD'
                            LEFT JOIN MRDRLocationHierarchyAttributeDump ctcd3 ON cnt3.CountryID = ctcd3.LocationId
                                AND RTRIM(ctcd3.LocationAttributeCd) = 'MRDRCD'
                            ) a
                        INNER JOIN GeographicUnit c ON a.GeographicUnitCd = c.GeographicUnitCd
                        WHERE a.GeographicUnitDesc <> c.GeographicUnitDesc
                        OR a.GeographicRegionCd <> c.GeographicRegionCd`
            });

            if (rowsDump_update.length > 0) {
                let rowRef = [];

                rowsDump_update.forEach(row => {
                    let tempRow = row.toJSON();
                    tempRow.UpdateUserId = 'sample.user';
                    tempRow.UpdateDttm = (new Date());
                    rowRef.push(tempRow);
                });
                console.log('Update Geographic Unit - IN PROGRESS');
                await guTable.update(rowRef);
                console.log(`Update Geographic Unit - DONE - ${rowsDump_update.length} row(s) updated`);
            }
        } catch (error) {
            console.error('ERROR:', error);
        } finally {
            database.close();
        }
    }

    return {
        processGU: processGU
    }
}


