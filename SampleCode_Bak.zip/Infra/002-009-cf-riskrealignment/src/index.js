exports.maprisks = async () => {
    const { Spanner } = require('@google-cloud/spanner');
    const uuid = require('uuidv4');

    const projectId = process.env.X_GOOGLE_GCLOUD_PROJECT;
    const instanceId = 'si-27354-mmc';
    const databaseId = 'db-27354-mmc-db';
	//const instanceId = 'nextgenmmc';
    //const databaseId = 'mmcdb';
  
    const spanner = new Spanner({
        projectId: projectId,
    });

    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);
    const rdTable = database.table('RiskDetails');

    try {
        const [rowstoupdate] = await database.run({
            sql: `SELECT rd.RiskDetailsKey
                    ,rd.ContractNbr, con.ContractNbr AS SourceContractNbr
                    ,rd.ContractNm, con.ContractNm AS SourceContractNm
                    ,rd.CustomerNbr, cus.CustomerNbr AS SourceCustomerNbr
                    ,rd.CustomerNm, cus.CustomerNm AS SourceCustomerNm
                    ,rd.MasterClientNbr, mc.MasterClientNbr AS SourceMasterClientNbr
                    ,rd.MasterClientNm, mc.MasterClientNm AS SourceMasterClientNm
                FROM RiskDetails rd
                INNER JOIN MRDRWBSElementDump wbs
                ON rd.CIPOpportunityId = CAST(wbs.GBDDOpportunityId AS INT64)
                AND REGEXP_EXTRACT(wbs.GBDDOpportunityId, r"^[0-9]") <> ''
                AND rd.CIPType = 'OPP'
                INNER JOIN MRDRContractLineItemDump cli
                ON wbs.WBSExternalNbr = cli.WBSElementNbr
                INNER JOIN Contract con
                ON cli.ContractCd = con.ContractNbr
                INNER JOIN Customer cus
                ON con.CustomerNbr = cus.CustomerNbr
                INNER JOIN MasterClient mc
                ON cus.MasterClientNbr = mc.MasterClientNbr
                WHERE rd.ContractNbr <> con.ContractNbr`
        });

        if (rowstoupdate.length > 0) {
            let rowRef = [];

            rowstoupdate.forEach(row => {
                let tempRow = row.toJSON();
                tempRow.ContractNbr = tempRow.SourceContractNbr;
                tempRow.ContractNm = tempRow.SourceContractNm;
                tempRow.CustomerNbr = tempRow.SourceCustomerNbr;
                tempRow.CustomerNm = tempRow.SourceCustomerNm;
                tempRow.MasterClientNbr = tempRow.SourceMasterClientNbr;
                tempRow.MasterClientNm = tempRow.SourceMasterClientNm;
                delete tempRow.SourceContractNbr;
                delete tempRow.SourceContractNm;
                delete tempRow.SourceCustomerNbr;   
                delete tempRow.SourceCustomerNm;
                delete tempRow.SourceMasterClientNbr;
                delete tempRow.SourceMasterClientNm;

                rowRef.push(tempRow);
            });
            console.log('Update RiskDetails - IN PROGRESS');
            await rdTable.update(rowRef);
            console.log('Update RiskDetails - DONE');
        }
    } catch (err) {
        console.error('ERROR:', err);
    } finally {
        //database.close();
        res.status(200).json({
            data: 'SUCCESSFUL: riskrealignment'
        });
    }
}