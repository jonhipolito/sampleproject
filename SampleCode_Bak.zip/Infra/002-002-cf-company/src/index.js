exports.processCompany = async (req, res) => {
    // Imports the Google Cloud client library
    const { Spanner } = require('@google-cloud/spanner');
    const uuid = require('uuidv4');
    
    const projectId = process.env.X_GOOGLE_GCLOUD_PROJECT;
    const instanceId = 'si-27354-mmc';
    const databaseId = 'db-27354-mmc-db';

    // Creates a client
    const spanner = new Spanner({
        projectId: projectId,
    });

    // Gets a reference to a Cloud Spanner instance and database
    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);
    const comTable = database.table('Company');

    try {
        const [rowsDump_insert] = await database.run({
            sql: `SELECT M.CompanyCd , M.CompanyDesc 
            , M.City , M.CountryKey AS CountryCd , M.CurrencyKey AS CurrencyCd, M.PostingPeriodVariantCd 
            FROM MRDRCompanyCodeDump M 
            LEFT JOIN Company C USING (CompanyCd) WHERE C.CompanyCd IS NULL `
        });

        if (rowsDump_insert.length > 0) {
            let rowBase = [];

            rowsDump_insert.forEach(row => {
                let tempRow = row.toJSON();
                tempRow.CompanyKey = uuid();
                tempRow.CreateUserId = 'sample.user';
                tempRow.UpdateUserId = 'sample.user';
                tempRow.CreateDttm = new Date();
                tempRow.UpdateDttm = new Date();
                rowBase.push(tempRow);
            });
            console.log('Insert new Company - IN PROGRESS');
            await comTable.insert(rowBase);
            console.log('Insert new Company - DONE');
        }

        const [rowsDump_update] = await database.run({
            sql: `SELECT A.CompanyKey, B.CompanyCd , B.CompanyDesc , B.City , B.CountryCd , B.CurrencyCd , B.PostingPeriodVariantCd FROM Company A
            INNER JOIN (
                SELECT M.CompanyCd , M.CompanyDesc , M.City , M.CountryKey AS CountryCd, M.CurrencyKey  AS CurrencyCd , M.PostingPeriodVariantCd 
                  FROM MRDRCompanyCodeDump M             
                EXCEPT ALL SELECT C.CompanyCd , C.CompanyDesc , C.City , C.CountryCd , C.CurrencyCd, C.PostingPeriodVariantCd FROM Company C) B 
                USING (CompanyCd)`
        });

        if (rowsDump_update.length > 0) {
            let rowRef = [];

            rowsDump_update.forEach(row => {
                let tempRow = row.toJSON();
                tempRow.UpdateUserId = 'sample.user';
                tempRow.UpdateDttm = (new Date());
                rowRef.push(tempRow);
            });
            console.log('Update Company - IN PROGRESS');
            await comTable.update(rowRef);
            console.log('Update Company - DONE');
            return;
        }
    } catch (err) {
        console.error('ERROR:', err);
    } finally {
        database.close();
        const { PubSub } = require('@google-cloud/pubsub');
        const pubsub = new PubSub({ projectId });
        const dataBuffer = Buffer.from("company");
        await pubsub.topic("JobEvents").publish(dataBuffer);
        res.status(200).json({
            data: 'SUCCESSFUL: Company'
        });
        return;
    }
}