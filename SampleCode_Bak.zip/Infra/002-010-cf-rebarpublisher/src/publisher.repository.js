const { Spanner } = require('@google-cloud/spanner');
const helper = require('./publisher.helper');

// [START createMMCCIPCommentAudit]
/**
 * Insert events in MMCCIPCommentAudit table
 *
 * @param {Array} eventsArray Array of events received from the request.
 * @param {String} tableName Table name.
 * @param projectId Project ID
 * @param instanceId Instance ID
 * @param databaseId Database ID
 */
createMMCCIPCommentAudit = async function (eventsArray, tableName, projectId, instanceId, databaseId) {

    const spanner = new Spanner({
        projectId: projectId,
    });

    // Gets a reference to a Cloud Spanner instance and database
    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);

    // Instantiate Spanner table objects
    const MMCCIPCommentAuditTable = database.table(tableName);

    // Inserts rows into the MMCCIPCommentAudit table
    try {
        let eventsCreated = helper.getEvents(eventsArray);
        console.log("createMMCCIPCommentAudit eventsCreated: " + JSON.stringify(eventsCreated));
        if (eventsCreated.length > 0) {
            await MMCCIPCommentAuditTable.insert(eventsCreated);
            console.log(`MMCCIPCommentAudit: ${eventsCreated.length} row(s) inserted.`);
            return eventsCreated;
        }
        else {
            console.log(`MMCCIPCommentAudit: No rows inserted`)
        }
    } catch (error) {
        console.log("ERROR repository: createMMCCIPCommentAudit: " + error);
    }
    finally {
        await database.close();
        console.log(`createMMCCIPCommentAudit end`);
    }
}
// [END createMMCCIPCommentAudit]


// [START updateStatus]
/**
 * Insert events in MMCCIPCommentAudit table
 *
 * @param {Array} unpublishedMesagesArray Array of unpublished events
 * @param projectId Project ID
 * @param instanceId Instance ID
 * @param databaseId Database ID
 */
updateStatus = async function (unpublishedMesagesArray, projectId, instanceId, databaseId) {
    console.log(`updateStatus is called...`);
    const spanner = new Spanner({
        projectId: projectId,
    });

    // Gets a reference to a Cloud Spanner instance and database
    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);

    try {
        let condition = "";
        const publishedStatus = "published";
        for (var i of unpublishedMesagesArray) {
            if (i.MMCCIPCommentAuditKey != null) {
                condition += `MMCCIPCommentAuditKey = '` + i.MMCCIPCommentAuditKey + `' OR `;
            }
        }
        condition = (condition.trim()).slice(0, -3);
        const [rowCount] = await database.runPartitionedUpdate({
            sql: `UPDATE MMCCIPCommentAudit 
                SET Status = @eventStatus
                WHERE ` + condition,
            params: {
                eventStatus: publishedStatus,
            },
        });
        console.log(`Successfully updated ${rowCount} records.`);
        return rowCount;
    } catch (err) {
        console.error('ERROR:', err);
    } finally {
        // Close the database when finished.
        database.close();
        console.log(`updateStatus end`);
    }
}
// [END updateStatus]


// [START getUnpublishedMessage]
/**
 * Get events from tableName with unpublished status
 *
 * @param {Array} unpublishedMesagesArray Array of unpublished events
 * @param {String} tableName Table name
 * @param projectId Project ID
 * @param instanceId Instance ID
 * @param databaseId Database ID
 */
getUnpublishedMessage = async function (tableName, projectId, instanceId, databaseId) {
    let status = 'unpublished';
    const spanner = new Spanner({
        projectId: projectId,
    });

    // Gets a reference to a Cloud Spanner instance and database
    const instance = spanner.instance(instanceId);
    const database = instance.database(databaseId);

    const query = {
        sql: `SELECT * FROM MMCCIPCommentAudit WHERE Status = @eventStatus`,
        params: {
            MMCCIPCommentAuditTableName: tableName,
            eventStatus: status,
        },
    };

    // Queries rows from the MMCCIPCommentAudit table
    try {
        let rows_unpublished = [];
        const [rows] = await database.run(query);
        rows.forEach(row => {
            const unpublished = row.toJSON();
            //console.log("Unpublished eventsArray: " + JSON.stringify(unpublished));
            rows_unpublished.push(unpublished);
        });
        console.log("getUnpublishedMessage: rows_unpublished: " + rows_unpublished);
        return rows_unpublished;
    }
    catch (error) {
        console.log(error);
    }
    finally {
        await database.close();
        console.log(`getUnpublishedMessage end`);
    }
}
// [END getUnpublishedMessage]

module.exports = {
    createMMCCIPCommentAudit,
    getUnpublishedMessage,
    updateStatus
}