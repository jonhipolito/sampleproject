/**
 * Responds to any HTTP request.
 *
 * @param {!express:Request} req HTTP request context.
 * @param {!express:Response} res HTTP response context.
 */

'use strict'

const projectId = process.env.X_GOOGLE_GCLOUD_PROJECT,
        instanceId = 'si-27354-mmc',
        databaseId = 'db-27354-mmc-db',
        MMCCIPCommentAuditTableName = 'MMCCIPCommentAudit',
        service = require('./publisher.service');


function Authenticate(token) {
        return new Promise(resolve => {
                var jwt = require('jsonwebtoken');
                var jwksClient = require('jwks-rsa');
                var client = jwksClient({
                        jwksUri: 'https://login.microsoftonline.com/common/discovery/v2.0/keys'
                });

                function getKey(header, callback) {
                        client.getSigningKey(header.kid, function (err, key) {
                                var signingKey = key.publicKey || key.rsaPublicKey;
                                callback(null, signingKey);
                        });
                }
                token = token.replace("Bearer ", "");
                jwt.verify(token, getKey, {
                        issuer: [
                                "https://sts.windows.net/f3211d0e-125b-42c3-86db-322b19a65a22/",
                                "https://sts.windows.net/e0793d39-0939-496d-b129-198edd916feb/"
                        ]
                }, function (err, decoded) {
                        resolve(decoded);
                });
        })

}

exports.processMessageData = async (req, res) => {
        try {
                if (req.method !== 'POST') {
                        const error = new Error('Only POST requests are accepted');
                        error.code = 405;
                        throw error;
                }

                res.set('Access-Control-Allow-Origin', '*');

                console.log("req.body.events: " + JSON.stringify(req.body.events));
                if (req.body.events.length > 0) {
                        await service.processMessage(req.body.events, MMCCIPCommentAuditTableName, projectId, instanceId, databaseId)
                                .then(result => {
                                        if (result > 0) {
                                                res.status(200).send('OK');
                                        }
                                });
                } else {
                        res.status(400).send('400 Bad request: Invalid body');
                }


        } catch (error) {
                console.log(error);
        }

}

// Comment out when debugging local
// const mockRequestPayload = {
//         "events": [{
//                 "EventName": "new_mitigation",
//                 "RiskRatingCd": "100801",
//                 "RiskDetailsKey": "7fb6fa6b-26c8-4cfe-a6cd-7334e214ed70",
//                 "RiskMitigationKey": "6562a2f4-df7d-4a3e-9e74-7c8fe824a258",
//                 "RiskMitigationKey": "6562a2f4-df7d-4a3e-9e74-7c8fe824a258",
//                 "MMCLinkToRiskDetails": "MMC URL that points to Risk Details page",
//                 "CIPId": 12345,
//                 "CIPType": "OPP",
//                 "Level3RiskId": 123,
//                 "MitigationCreateUserId": "test.id.001",
//                 "MitigationCreateDttm": "2019-07-04T05:16:28.476559Z",
//                 "MitigationUpdateUserId": "test.id.001",
//                 "MitigationUpdateDttm": "2019-07-04T05:16:28.476559Z",
//                 "MitigationStatus": "In Progress (Due)",
//                 "MitigationDueDate": "2019-10-04T07:00:00.000000000Z",
//                 "MitigationOwner": "test.id.002",
//                 "MitigationDescription": "description"
//         }, {
//                 "EventName": "update_mitigation",
//                 "RiskRatingCd": "100801",
//                 "RiskDetailsKey": "7fb6fa6b-26c8-4cfe-a6cd-7334e214ed70",
//                 "RiskMitigationKey": "6562a2f4-df7d-4a3e-9e74-7c8fe824a258",
//                 "MMCLinkToRiskDetails": "MMC URL that points to Risk Details page",
//                 "CIPId": 12345,
//                 "CIPType": "OPP",
//                 "Level3RiskId": 123,
//                 "MitigationCreateUserId": "test.id.001",
//                 "MitigationCreateDttm": "2019-07-04T05:16:28.476559Z",
//                 "MitigationUpdateUserId": "test.id.004",
//                 "MitigationUpdateDttm": "2019-07-04T05:24:28.476559Z",
//                 "MitigationStatus": "In Progress (Due)",
//                 "MitigationDueDate": "2019-10-04T07:00:00.000000000Z",
//                 "MitigationOwner": "test.id.002",
//                 "MitigationDescription": "description"
//         }, {
//                 "EventName": "update_risk_rating",
//                 "CreateUserId": "test.id.001",
//                 "CreateDttm": "2019-05-30T07:00:00.000000000Z",
//                 "UpdateUserId": "test.id.001",
//                 "UpdateDttm": "2019-06-28T00:17:51.579000000Z",
//                 "RiskRatingCd": "100801",
//                 "RiskDetailsKey": "7fb6fa6b-26c8-4cfe-a6cd-7334e214ed70",
//                 "MMCLinkToRiskDetails": "MMC URL that points to Risk Details page",
//                 "CIPId": 12345,
//                 "CIPType": "OPP",
//                 "Level3RiskId": 123
//         }
//         ]
// };
// async function local() {
//         await service.processMessage(mockRequestPayload.events, MMCCIPCommentAuditTableName, projectId, instanceId, databaseId)
//                 .then(result => {
//                         if (result) {
//                                 //res.status(200).send('OK');
//                                 console.log("DONE!!!!!!");
//                                 return true;
//                         }
//                 });
// };
// local();