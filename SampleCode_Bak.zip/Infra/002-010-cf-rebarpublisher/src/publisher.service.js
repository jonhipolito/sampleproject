const repository = require('./publisher.repository');
const helper = require('./publisher.helper');
const _ = require('lodash');
const request = require('request');
const NodeCache = require("node-cache");
const Cache = new NodeCache({
    stdTTL: 1800,
    checkperiod: 100
});

// [START processMessage]
/**
 * processMessage
 *
 * @param {Array} eventsArray Array of events received from the request.
 * @param {String} tableName Table name.
 * @param projectId Project ID
 * @param instanceId Instance ID
 * @param databaseId Database ID
 */
processMessage = async (eventsArray, tableName, projectId, instanceId, databaseId) => {
    console.log("processMessage eventsArray: " + JSON.stringify(eventsArray));
    return new Promise(async (resolve, reject) => {
        let created = [];
        await repository.createMMCCIPCommentAudit(eventsArray, tableName, projectId, instanceId, databaseId)
            .then(result => {
                created = result;
            });
        resolve(created);
    }).then(async (result) => {
        if (result.length > 0) { }

        let unpublishedMessages = await repository.getUnpublishedMessage(tableName, projectId, instanceId, databaseId);

        return unpublishedMessages;
    }).then(async (outerResult) => {
        let unpublishedMessagesDeep = _.cloneDeep(outerResult);
        console.log("unpublishedMessagesDeep" + JSON.stringify(unpublishedMessagesDeep));
        let resultsArray = [];

        if (outerResult.length > 0) {
            for (var i of unpublishedMessagesDeep) {
                const messageObject = helper.formatRebarPayload(i);

                console.log("messageObject: " + JSON.stringify(messageObject));
                // Run publish to rebar once
                let publish = await publishMessage(messageObject).then(innerResult => {
                    console.log("innerResult: " + JSON.stringify(innerResult));
                    if (innerResult.TransactionId) {
                        // Update message status to 'published'
                        for (var j of unpublishedMessagesDeep) {
                            console.log("unpublishedMessagesDeep(j): " + JSON.stringify(j));
                            console.log("innerResult: " + JSON.stringify(innerResult));
                            if (j.MMCCIPCommentAuditKey === i.MMCCIPCommentAuditKey) {
                                j.Status = "published";
                                break;
                            }
                        }
                        return innerResult;
                    }
                });
                resultsArray.push(publish);
            }

            if (resultsArray.length == unpublishedMessagesDeep.length) {
                return unpublishedMessagesDeep;
            }
        }
    }).then(result => {
        if (result.length > 0) {

            let updated = repository.updateStatus(result, projectId, instanceId, databaseId);

            return updated;
        }
    });
}
// [END processMessage]


// [START publishMessage]
publishMessage = async function (message) {
    console.log("publishMessage starts");
    try {
        let token = await GetAADToken();
        console.log("token: ", token);
        console.log("message: ", JSON.stringify(message));

        return new Promise(function (resolve, reject) {
            console.log("process.env.publisherURL: ", process.env.publisherURL);
            const options = {
                url: process.env.publisherURL,
                method: 'POST',
                headers: {
                    'Authorization': "Bearer " + token
                },
                json: message
            };
            console.log("options: " + JSON.stringify(options));
            request(options, function (error, response, body) {

                console.log("error: " + JSON.stringify(error));
                console.log("response: " + JSON.stringify(response));
                console.log("body: " + JSON.stringify(body));

                if (error) {
                    console.log('error: ' + error);
                    reject(error);
                } else {
                    let res = body;
                    //console.log('res: ' + res);
                    resolve(res);
                }
                console.log("publishMessage ends");
            });
        }).then(result => {
            return result;
        });
    } catch (error) {
        console.log(error);
    }
}
// [END publishMessage]


// [START GetAADToken]
GetAADToken = () => {
    return new Promise(function (resolve, reject) {
        const options = {
            url: `https://login.microsoftonline.com/${process.env.TENANT}/oauth2/token`,
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            form: {
                'client_id': process.env.AAD_CLIENT_ID,
                'client_secret': process.env.AAD_SECRET,
                'grant_type': 'client_credentials',
                'resource': process.env.AAD_RESOURCE
            },
            time: true
        };
        let AppToken = Cache.get("AAD_access_token");
        if (AppToken) {
            resolve(AppToken)
            return;
        }
        request(options, function (error, response, body) {
            if (response.statusCode != 201) {
                const token = JSON.parse(body).access_token;
                Cache.set("AAD_access_token", token);
                resolve(token);
            }
        });
    });
}
// [END GetAADToken]

module.exports = {
    processMessage,
    GetAADToken
}