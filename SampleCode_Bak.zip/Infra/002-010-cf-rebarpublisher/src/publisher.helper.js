/**
 * Helper Module
 */

const uuid = require('uuidv4');
const moment = require('moment');
const timezone = require('moment-timezone');

getEvents = (eventsArray) => {
    console.log("getEvents(): stringified eventsArray: " + JSON.stringify(eventsArray));
    try {
        if (eventsArray.length > 0) {
            const status = 'unpublished';
            const createUserId = 'mmc.rebar.messaging';
            let rows = [];
            for (var i = 0; i < eventsArray.length; i++) {
                if (eventsArray[i].EventName.trim() === "new_mitigation" || eventsArray[i].EventName.trim() === "update_mitigation") {

                    rows.push({
                        MMCCIPCommentAuditKey: uuid(),
                        EventName: (eventsArray[i].EventName.trim() === "new_mitigation" ? "new_mitigation" : "update_mitigation"), //todo create a CodeDetail
                        EventComment: formatCommentToHTML(eventsArray[i]),
                        CreateUserId: eventsArray[i].MitigationCreateUserId,
                        CreateDttm: eventsArray[i].MitigationCreateDttm,
                        UpdateUserId: eventsArray[i].MitigationUpdateUserId,
                        UpdateDttm: eventsArray[i].MitigationUpdateDttm,
                        Status: status,
                        RiskRatingCd: eventsArray[i].RiskRatingCd,
                        RiskDetailsKey: eventsArray[i].RiskDetailsKey,
                        RiskMitigationKey: eventsArray[i].RiskMitigationKey,
                        MMCLinkToRiskDetails: eventsArray[i].MMCLinkToRiskDetails,
                        CIPId: eventsArray[i].CIPId,
                        CIPType: eventsArray[i].CIPType,
                        Level3RiskId: eventsArray[i].Level3RiskId,
                        MitigationCreateUserId: eventsArray[i].MitigationCreateUserId,
                        MitigationCreateDttm: eventsArray[i].MitigationCreateDttm,
                        MitigationUpdateUserId: eventsArray[i].MitigationUpdateUserId,
                        MitigationUpdateDttm: eventsArray[i].MitigationUpdateDttm,
                        MitigationStatus: eventsArray[i].MitigationStatus,
                        MitigationDueDate: eventsArray[i].MitigationDueDate,
                        MitigationOwner: eventsArray[i].MitigationOwner,
                        MitigationDescription: eventsArray[i].MitigationDescription
                    });
                } else if (eventsArray[i].EventName.trim() === "update_risk_rating") {
                    rows.push({
                        MMCCIPCommentAuditKey: uuid(),
                        EventName: eventsArray[i].EventName.trim(),
                        EventComment: formatCloseCommentToHTML(eventsArray[i]),
                        CreateUserId: eventsArray[i].CreateUserId,
                        CreateDttm: eventsArray[i].CreateDttm,
                        UpdateUserId: eventsArray[i].UpdateUserId,
                        UpdateDttm: eventsArray[i].UpdateDttm,
                        Status: status,
                        RiskRatingCd: eventsArray[i].RiskRatingCd,
                        RiskDetailsKey: eventsArray[i].RiskDetailsKey,
                        RiskMitigationKey: null,
                        MMCLinkToRiskDetails: eventsArray[i].MMCLinkToRiskDetails,
                        CIPId: eventsArray[i].CIPId,
                        CIPType: eventsArray[i].CIPType,
                        Level3RiskId: eventsArray[i].Level3RiskId,
                        MitigationCreateUserId: null,
                        MitigationCreateDttm: null,
                        MitigationUpdateUserId: null,
                        MitigationUpdateDttm: null,
                        MitigationStatus: null,
                        MitigationDueDate: null,
                        MitigationOwner: null,
                        MitigationDescription: null
                    });
                } else if (eventsArray[i].EventName.trim() === "realign_cip") {
                    rows.push({
                        MMCCIPCommentAuditKey: uuid(),
                        CIPOppID: eventsArray[i].CIPOppID,
                        CIPMSAID: eventsArray[i].CIPMSAID,
                        Level3RiskId: eventsArray[i].Level3RiskId
                    });
                } else {
                    console.log(eventsArray[i].EventName + " is undefined.");
                }
            }
            console.log("helper getEvents(): stringified rows: " + JSON.stringify(rows));
            return rows;
        }
    } catch (error) {
        console.log(error);
    }

}

// [START Methods for formatting payload for REBAR]


formatRebarPayload = (row) => {
    var payload = new Object();

    var messagesArray = [];
    var messages = formatMessages(row);

    messagesArray.push(messages);

    payload.AirId = 27354;
    payload.RequestId = uuid();
    payload.Messages = messagesArray;

    //return JSON.stringify(payload);
    console.log("helper formatRebarPayload(): stringified payload: " + JSON.stringify(payload));
    return payload;
}

formatMessages = (row) => {
    var message = new Object();
    var messageTypesArray = [];
    var messageType = "Accenture.Events.Legal.Comments.UpdatedEvent";

    messageTypesArray.push(messageType);

    message.MessageTypes = messageTypesArray;
    message.MessageId = uuid();
    message.Body = formatBody(row);
    message.Headers = formatHeaders(row);

    //return JSON.stringify(message);
    return message;
}

formatBody = (row) => {
    var body = new Object();
    body.MMCCIPCommentAuditKey = row.MMCCIPCommentAuditKey;
    body.EventName = row.EventName;
    body.RiskRatingCd = row.RiskRatingCd;
    body.RiskDetailsKey = row.RiskDetailsKey;
    body.RiskMitigationKey = row.RiskMitigationKey;
    body.MMCLinkToRiskDetails = row.MMCLinkToRiskDetails;
    body.EventComment = row.EventComment;
    body.CIPId = row.CIPId;
    body.CIPType = row.CIPType;
    body.Level3RiskId = row.Level3RiskId;
    if (row.EventName === "new_mitigation" || row.EventName === "update_mitigation") {
        body.MitigationCreateUserId = row.MitigationCreateUserId;
        body.MitigationCreateDttm = row.MitigationCreateDttm;
        body.MitigationUpdateUserId = row.MitigationUpdateUserId;
        body.MitigationUpdateDttm = row.MitigationUpdateDttm;
        body.MitigationStatus = row.MitigationStatus;
        body.MitigationDueDate = row.MitigationDueDate;
        body.MitigationOwner = row.MitigationOwner;
        body.MitigationDescription = row.MitigationDescription;
    } else if (row.EventName === "update_risk_rating") {
        body.CreateUserId = row.CreateUserId;
        body.CreateDttm = row.CreateDttm;
        body.UpdateUserId = row.UpdateUserId;
        body.UpdateDttm = row.UpdateDttm;
    }

    //return JSON.stringify(body);
    return body;
}

formatHeaders = (row) => {
    var headers = new Object();
    headers.CIPMMCRiskAuditId = row.MMCCIPCommentAuditKey;
    headers.CIPId = row.CIPId;
    headers.Level3RiskId = row.Level3RiskId;
    headers.AuditDate = (new Date());

    //return JSON.stringify(headers);
    return headers;
}

formatCommentToHTML = (row) => {
    console.log("helper formatCommentToHTML(): stringified row: " + JSON.stringify(row));
    /* <p style="text-align:left;">Related MMC Risk has an Mitigation UPDATE. Further details can be found in MMC.<br>
    <b>Status:</b> [Status of the mitigation]<br>
    <b>Due Date:</b> [Due Date included on the mitigation on MMC]<br>
    <b>Mitigation Owner:</b> [person Assigned as Mitigation responsible]<br>
    <b>Description:</b> [Description of the mitigation]<br>
    </p> */

    var commentHtmlString = "";
    var commentStr = "";
    if (row.EventName === "new_mitigation") {
        commentStr = "Related MMC Risk has a NEW Mitigation.";
    } else if (row.EventName === "update_mitigation") {
        commentStr = "Related MMC Risk has a Mitigation UPDATE.";
    } else if (row.EventName === "update_risk_rating") {
        commentStr = "The related MMC Risk has been Closed because it was Mitigated.";
    }

    commentHtmlString += "<p style=\"text-align:left;\">" + commentStr + " Further details can be found in <a href=\"" + row.MMCLinkToRiskDetails + "\" target=\"_blank\">MMC</a>.<br>";
    commentHtmlString += "<b>Status:</b> " + row.MitigationStatus + "<br>";
    commentHtmlString += "<b>Due Date:</b> " + moment(row.MitigationDueDate).format("DD-MMM-YYYY").toUpperCase() + "<br>";
    commentHtmlString += "<b>Mitigation Owner:</b> " + row.MitigationOwner + "<br>";
    commentHtmlString += "<b>Description:</b> " + row.MitigationDescription + "<br></p>";

    console.log("commentHtmlString: " + commentHtmlString);
    return commentHtmlString;
}

formatCloseCommentToHTML = (row) => {
    console.log("helper formatCloseCommentToHTML(): stringified row: " + JSON.stringify(row));
    /* <p style="text-align:left;">Related MMC Risk has an Mitigation UPDATE. Further details can be found in MMC.<br>
    <b>Status:</b> [Status of the mitigation]<br>
    <b>Due Date:</b> [Due Date included on the mitigation on MMC]<br>
    <b>Mitigation Owner:</b> [person Assigned as Mitigation responsible]<br>
    <b>Description:</b> [Description of the mitigation]<br>
    </p> */

    var closeCommentString = "";
    var commentStr = "";
    if (row.EventName === "update_risk_rating") {
        commentStr = "The related MMC Risk has been Closed because it was Mitigated.";
    }

    closeCommentString += "<p style=\"text-align:left;\">" + commentStr + " Further details can be found in <a href=\"" + row.MMCLinkToRiskDetails + "\" target=\"_blank\">MMC</a>.<br>";
    closeCommentString += "</p>";

    console.log("closeCommentString: " + closeCommentString);
    return closeCommentString;
}

// [END Methods for formatting payload for REBAR]

module.exports = {
    getEvents,
    formatRebarPayload
}