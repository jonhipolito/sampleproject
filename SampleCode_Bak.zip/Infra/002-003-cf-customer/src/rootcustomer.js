const uuid = require('uuidv4');

populateRootCustomer = function(database, rootCustomerTable) {
    return new Promise(async (resolve) => {
        //Truncate RootCustomer table
        await truncateRootCustomer(database);

        //Populate RootCustomer table
        [rootCustomerInsertRows] = await database.run({
            sql:
                `SELECT LTRIM(RTRIM(CustomerNbr)) AS CustomerNbr
                    FROM MRDRCustomerDump`
        });

        if (rootCustomerInsertRows.length > 0) {
            let finalRows = [];
            let promises = [];

            rootCustomerInsertRows.forEach(row => {
                promises.push(new Promise(async (resolve) => {
                    let tempRow = row.toJSON();
                    tempRow.RootCustomerKey = uuid();
                    tempRow.RootCustomerNbr = await getRootCustomer(database, tempRow.CustomerNbr);
                    tempRow.CreateDttm = (new Date());
                    tempRow.CreateUserId = 'MMC_JOB_USER';
                    finalRows.push(tempRow);
                    resolve();
                }));
            });

            Promise.all(promises).then(async () => {
                await rootCustomerTable.insert(finalRows);
                console.log(`RootCustomer: ${rootCustomerInsertRows.length} row/s inserted`);

                resolve();
            });
        }
    });
}

truncateRootCustomer = async function(database) {
    const [rootCustomerAllRows] = await database.runPartitionedUpdate({
        sql: 
            `DELETE FROM RootCustomer WHERE true`
    });

    console.log(`RootCustomer: ${rootCustomerAllRows} row/s deleted`);
}

getRootCustomer = function(database, customerNbrPar) {
    return new Promise(async (resolve, reject) => {
        let rootCustomerNbr = '',
            parentCustomerNbr = customerNbrPar,
            customerNbr = customerNbrPar;

        if (customerNbrPar == '') {
            rootCustomerNbr = '';
        }
        else {
            while (parentCustomerNbr != '' && parentCustomerNbr != '0000000000') {
                parentCustomerNbr = '0000000000';

                [parentCustomerNbrRows] = await database.run({
                    sql:
                        `SELECT ParentCustomerNbr
                        FROM MRDRCustomerDump
                        WHERE CustomerNbr = '${customerNbr}'`
                });

                if (parentCustomerNbrRows.length > 0) {
                    parentCustomerNbr = parentCustomerNbrRows[0][0].value;
                    if (parentCustomerNbr != '' && parentCustomerNbr != '0000000000') {
                        customerNbr = parentCustomerNbr;
                    }
                }
            }

            rootCustomerNbr = customerNbr;
        }
        
        resolve(rootCustomerNbr);
    });
}

module.exports = {
    populateRootCustomer,
    truncateRootCustomer
}