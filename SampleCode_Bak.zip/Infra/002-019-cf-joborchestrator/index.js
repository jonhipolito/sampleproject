/**
 * Triggered from a message on a Cloud Pub/Sub topic.
 *
 * @param {!Object} event Event payload.
 * @param {!Object} context Metadata for the event.
 */

const {
  Spanner
} = require('@google-cloud/spanner');
const { google } = require('googleapis');
const dataflow = google.dataflow('v1b3');
const cloudfunctions = google.cloudfunctions('v1');

const instanceId = 'si-27354-mmc',
  databaseId = 'db-27354-mmc-db';


exports.joborchestrator = async (event, context) => {

  const projectId = await google.auth.getProjectId();
  const spanner = new Spanner({
    projectId: projectId,
  });

  const instance = spanner.instance(instanceId);
  const database = instance.database(databaseId);
  const authClient = await google.auth.getClient({
    scopes: [
      'https://www.googleapis.com/auth/cloud-platform',
      'https://www.googleapis.com/auth/compute',
      'https://www.googleapis.com/auth/compute.readonly',
      'https://www.googleapis.com/auth/userinfo.email'
    ],
  });
  const pubsubMessage = event.data;
  const jobname = Buffer.from(pubsubMessage, 'base64').toString();
  console.log("message", jobname);

  const query = {
    sql: `SELECT * FROM JobDependency WHERE Source = '${jobname}'`
  };
  const [rows] = await database.run(query);
  for (let x = 0; x < rows.length; x++) {
    let item = rows[x].toJSON();
    console.log("item.DataFlowTemplatePath", item.DataFlowTemplatePath)
    console.log("item.Target", item.Target)
    console.log("item.FunctionName", item.FunctionName)

    if (item.DataFlowTemplatePath) {
      let val = await dataflow.projects.templates.launch({
        auth: authClient,
        projectId: projectId,
        gcsPath: item.DataFlowTemplatePath
      });      
    }
    else if (item.FunctionName) {
      let val = await cloudfunctions.projects.locations.functions.call({
        auth: authClient,
        name: `projects/${projectId}/locations/us-east1/functions/${item.FunctionName}`
      });      
    }
    const table = database.table('JobExecutionLogs');
    table.insert({
      JobName: jobname,
      CreateDttm: 'spanner.commit_timestamp()'
    })

  }
};
