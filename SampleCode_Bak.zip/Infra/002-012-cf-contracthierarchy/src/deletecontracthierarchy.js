

 deleteContractHierarchyMapping = async function(database){
    const [rows_delete] = await database.run( `SELECT ContractNbr, ClientServiceGroupCd
    FROM ContractHierarchyMapping 
 
 EXCEPT DISTINCT
 
(SELECT DISTINCT cs.ContractNbr, cs.ClientServiceGroupCd
        FROM ContractStage cs
        INNER JOIN	Contract AS c
            ON cs.ContractNbr = c.ContractNbr 
        INNER JOIN	ClientServiceGroup AS csg 
            ON cs.ClientServiceGroupCd = csg.ClientServiceGroupCd
            
            UNION DISTINCT

SELECT DISTINCT chm.ContractNbr, chm.ClientServiceGroupCd
        FROM ContractHierarchyMapping chm
        INNER JOIN	Contract AS c
            ON chm.ContractNbr = c.ContractNbr )` );

        if(rows_delete.length > 0){
            let rows =[];
            rows_delete.forEach(row =>{
                let temp = row.toJSON();
                rows.push(temp);
            });

            let conNbr = rows.map(element =>`'${element.ContractNbr}'`).join(',');              

            let csgCd = rows.map(element =>`'${element.ClientServiceGroupCd}'`).join(',');

            const [deletedRows] = await database.runPartitionedUpdate({sql:
                `DELETE FROM ContractHierarchyMapping 
                WHERE ContractNbr IN (${conNbr}) AND ClientServiceGroupCd IN (${csgCd})`
                });

            console.log(`ContractHierarchyMapping: ${deletedRows} row(s) deleted.`);
        }
        else{
            console.log(`ContractHierarchyMapping: No row(s) deleted.`);
        }
        
}

module.exports = {
deleteContractHierarchyMapping
}

