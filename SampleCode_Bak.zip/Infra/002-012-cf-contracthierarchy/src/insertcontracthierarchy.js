 insertContractHierarchyMapping = async function(database, chmTable) {
        
        [selectedRows] = await database.run(
            `SELECT DISTINCT 
             RTRIM(cs.ClientServiceGroupCd) AS ClientServiceGroupCd
            , cs.ContractNbr AS ContractNbr
        FROM ContractStage cs
        WHERE cs.ContractNbr NOT IN (SELECT ContractNbr FROM ContractHierarchyMapping)
        AND cs.ContractNbr IN (SELECT ContractNbr FROM Contract)
        `
        );
        console.log("selectedRows", selectedRows.length);
        if(selectedRows.length > 0){
            let rows = [];
            let promises = [];
            selectedRows.forEach(async(row) => {
                    let temp = row.toJSON();
                    temp.CreateUserId = 'MMC.JOB';
                    temp.CreateDttm = (new Date());
                    temp.UpdateUserId = 'MMC.JOB';
                    temp.UpdateDttm = (new Date());
                    //rows.push(temp);
                    promises.push(chmTable.insert(temp));
                });
               //await chmTable.insert(rows);
               await Promise.all(promises);
               console.log(`ContractHierarchyMapping: ${selectedRows.length} row(s) inserted.`);
        }
        else{
            console.log(`ContractHierarchyMapping:  No row(s) inserted.`);
        }

}

module.exports = {
    insertContractHierarchyMapping
}