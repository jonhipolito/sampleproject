
const deletedata = require('./deletecontracthierarchy'),
    insertdata = require('./insertcontracthierarchy'),
    { Spanner } = require('@google-cloud/spanner'),
    projectId = process.env.X_GOOGLE_GCLOUD_PROJECT,
    instanceId = 'si-27354-mmc',
    databaseId = 'db-27354-mmc-db',
    // projectId = 'sbx-27354-nmmcsbxdev-a9ab6909', //For Local Testing
    // instanceId = 'nextgenmmc', //For Local Testing
    // databaseId = 'mmcdb', //For Local Testing
    spanner = new Spanner({ projectId: projectId, }),
    instance = spanner.instance(instanceId),
    database = instance.database(databaseId),
    chmTable = database.table('ContractHierarchyMapping');


exports.populateContractHierarchy = async (req, res) => {
    try {
        console.log("Start: Populate Contract Hierarchy");
        await insertdata.insertContractHierarchyMapping(database, chmTable);
        await deletedata.deleteContractHierarchyMapping(database);
    }
    catch (err) {
        console.error("Error: ", err);
    }
    finally {
        // Close the database when finished
        console.log("End: Populate Contract Hierarchy");
        const { PubSub } = require('@google-cloud/pubsub');
        const pubsub = new PubSub({ projectId });
        const dataBuffer = Buffer.from("populateContractHierarchy");
        await pubsub.topic("JobEvents").publish(dataBuffer);
        res.status(200).json({
            data: 'Records Inserted'
        });
        database.close();
        res.send();
    }
    return true;
}

//Run - Local
//  (async function() {
//     await insertdata.insertContractHierarchyMapping();
//     await deletedata.deleteContractHierarchyMapping();   
//  }())