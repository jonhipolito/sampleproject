/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.accenture.nextgenmmc;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.AvroCoder;
import org.apache.beam.sdk.coders.DefaultCoder;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO;
import org.apache.beam.sdk.io.gcp.spanner.SpannerWriteResult;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO.Write;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.Wait;
import org.apache.beam.sdk.values.PCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

import com.google.api.services.pubsub.model.PubsubMessage;
import com.google.cloud.Timestamp;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.Struct;

public class PopulateCustomer_DF {

	private static final String INSTANCE_ID = "si-27354-mmc";
	private static final String DATABASE_ID = "db-27354-mmc-db";

	private static final String TARGET_TABLE = "Customer";

	private static final Timestamp TimeStamp = Timestamp.now();
	private static final Logger LOG = LoggerFactory.getLogger(PopulateCustomer_DF.class);

	private static final String QUERY = "SELECT one.CustomerNbr\r\n" + 
			",two.customerNm\r\n" + 
			",two.MasterClientNbr\r\n" + 
			",'Customer_DF' AS CreateUserId\r\n" + 
			",'N'AS DummyInd\r\n" + 
			",'Customer_DF' AS UpdateUserId\r\n" + 
			",'N' AS WithCMInd\r\n" + 
			"FROM customernbrNotInCustomerQueryOneDF one\r\n" + 
			"INNER JOIN customernbrNotInCustomerQueryTwoDF two on one.CustomerNbr = two.CustomerNbr\r\n" + 
			"GROUP BY 1,2,3,4,5,6,7";

	public interface DFOptions extends PipelineOptions {
		String getProjectId();

		void setProjectId(String value);
	}

	public static void main(String[] args) {
		DFOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(DFOptions.class);
		Pipeline p = Pipeline.create(options);

		PCollection<Struct> customerTbl = p.apply("Read MRDRCustomerDump Table", ReadSpannerWithQuery(QUERY));
		SpannerWriteResult finish = customerTbl.apply(ParDo.of(new WriteMutation())).apply("Write to " + TARGET_TABLE,
				WriteToSpanner());

		p.apply("Start PubSub Process", ReadSpannerWithQuery("SELECT 1 AS Placeholder"))
				.apply(Wait.on(finish.getOutput())).apply(ParDo.of(new ReturnClassName())).apply("Publish message",
						PubsubIO.writeStrings().to("projects/" + options.getProjectId() + "/topics/JobEvents"));

		p.run();
	}

	@DefaultCoder(AvroCoder.class)
	static class CustomerTable {
		String CustomerNbr;
		String CustomerNm;
		String MasterClientNbr;
		String CreateUserId;
		String DummyInd;
		String UpdateUserId;
		String WithCMInd;


		CustomerTable(String CustomerNbr, String CustomerNm, String MasterClientNbr, String ParentCustomerNbr,
				String CreateUserId, String DummyInd, String UpdateUserId, String WithCMInd) {
			this.CustomerNbr = CustomerNbr;
			this.CustomerNm = CustomerNm;
			this.MasterClientNbr = MasterClientNbr;
			this.CreateUserId = CreateUserId;
			this.DummyInd = DummyInd;
			this.UpdateUserId = UpdateUserId;
			this.WithCMInd = WithCMInd;

		}
	}

	static class WriteMutation extends DoFn<Struct, Mutation> {
		private static final long serialVersionUID = 1L;

		@ProcessElement
		public void processElement(ProcessContext c) {
			Struct input = c.element();
			c.output(Mutation.newInsertOrUpdateBuilder(TARGET_TABLE).set("CustomerNbr")
					.to(input.isNull(0) ? null : input.getString(0)).set("CustomerNm")
					.to(input.isNull(1) ? null : input.getString(1)).set("MasterClientNbr")
					.to(input.isNull(2) ? null : input.getString(2)).set("CreateUserId")
					.to(input.isNull(3) ? null : input.getString(3)).set("DummyInd")
					.to(input.isNull(4) ? null : input.getString(4)).set("UpdateUserId")
					.to(input.isNull(5) ? null : input.getString(5)).set("WithCMInd")
					.to(input.isNull(6) ? null : input.getString(6)).set("CreateDttm").to(TimeStamp).set("UpdateDttm")
					.to(TimeStamp).build());
		}
	}

	public static Write WriteToSpanner() {
		return SpannerIO.write().withMaxNumMutations(5000).withInstanceId(INSTANCE_ID).withDatabaseId(DATABASE_ID);
	}

	public static SpannerIO.Read ReadSpannerWithQuery(String query) {
		return SpannerIO.read().withInstanceId(INSTANCE_ID).withDatabaseId(DATABASE_ID).withBatching(false)
				.withQuery(query);
	}

	static class ReturnClassName extends DoFn<Struct, String> {
		@ProcessElement
		public void processElement(ProcessContext c) throws IOException {
			PubsubMessage message = new PubsubMessage();
			message.encodeData("PopulateCustomer_DF".getBytes("UTF-8"));
			c.output("PopulateCustomer_DF");
		}
	}
}
