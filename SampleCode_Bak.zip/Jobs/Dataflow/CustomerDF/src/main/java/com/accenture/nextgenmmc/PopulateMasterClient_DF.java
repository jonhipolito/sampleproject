/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.accenture.nextgenmmc;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.AvroCoder;
import org.apache.beam.sdk.coders.DefaultCoder;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO;
import org.apache.beam.sdk.io.gcp.spanner.SpannerWriteResult;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO.Write;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.Wait;
import org.apache.beam.sdk.values.PCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

import com.google.api.services.pubsub.model.PubsubMessage;
import com.google.cloud.Timestamp;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.Struct;

public class PopulateMasterClient_DF {

	private static final String INSTANCE_ID = "si-27354-mmc";
	private static final String DATABASE_ID = "db-27354-mmc-db";
	private static final Timestamp TimeStamp = Timestamp.now();
	private static final Logger LOG = LoggerFactory.getLogger(PopulateMasterClient_DF.class);

	private static final String TARGET_TABLE = "MasterClient";

	private static final String QUERY = "SELECT DISTINCT rc.RootCustomerNbr AS MasterClientNbr\r\n"
			+ "                    ,IFNULL(cad.ContentValue,'') AS MasterClientNm\r\n"
			+ "                    ,'PopulateMasterClient_DF' as CreateUserId\r\n"
			+ "                    ,'PopulateMasterClient_DF' as UpdateUserId\r\n"
			+ "                FROM RootCustomer rc\r\n" + "                INNER JOIN MRDRCustomerDump mcd\r\n"
			+ "                    ON rc.RootCustomerNbr = mcd.CustomerNbr\r\n"
			+ "                LEFT JOIN MRDRCustomerAttributeDump cad\r\n"
			+ "                    ON cad.CustomerNbr = rc.RootCustomerNbr\r\n"
			+ "                    AND cad.AttributeCd = 'CNAME'\r\n"
			+ "                    AND rc.RootCustomerNbr <> ''";

	public interface DFOptions extends PipelineOptions {
		String getProjectId();

		void setProjectId(String value);
	}

	public static void main(String[] args) {
		DFOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(DFOptions.class);
		Pipeline p = Pipeline.create(options);

		PCollection<Struct> MasterClientTbl = p.apply("Read MRDRCustomerAttributeDump Table",
				ReadSpannerWithQuery(QUERY));
		SpannerWriteResult finish = MasterClientTbl.apply(ParDo.of(new WriteMutation())).apply("Write to MasterClient",
				WriteToSpanner());

		p.apply("Start PubSub Process", ReadSpannerWithQuery("SELECT 1 AS Placeholder"))
				.apply(Wait.on(finish.getOutput())).apply(ParDo.of(new ReturnClassName())).apply("Publish message",
						PubsubIO.writeStrings().to("projects/" + options.getProjectId() + "/topics/JobEvents"));

		p.run();
	}

	@DefaultCoder(AvroCoder.class)
	static class MasterClient {
		String MasterClientNbr;
		String MasterClientNm;
		String CreateUserId;
		String UpdateUserId;

		MasterClient(String MasterClientNbr, String MasterClientNm, String CreateUserId, String UpdateUserId) {
			this.MasterClientNbr = MasterClientNbr;
			this.MasterClientNm = MasterClientNm;
			this.CreateUserId = CreateUserId;
			this.UpdateUserId = UpdateUserId;
		}
	}

	static class WriteMutation extends DoFn<Struct, Mutation> {
		private static final long serialVersionUID = 1L;

		@ProcessElement
		public void processElement(ProcessContext c) {
			Struct input = c.element();
			c.output(Mutation.newInsertOrUpdateBuilder(TARGET_TABLE).set("MasterClientNbr")
					.to(input.isNull(0) ? null : input.getString(0)).set("MasterClientNm")
					.to(input.isNull(1) ? null : input.getString(1)).set("CreateUserId")
					.to(input.isNull(2) ? null : input.getString(2)).set("UpdateUserId")
					.to(input.isNull(3) ? null : input.getString(3)).set("CreateDttm").to(TimeStamp).set("UpdateDttm")
					.to(TimeStamp).build());
		}
	}

	public static Write WriteToSpanner() {
		return SpannerIO.write().withInstanceId(INSTANCE_ID).withDatabaseId(DATABASE_ID);
	}

	public static SpannerIO.Read ReadSpannerWithQuery(String query) {
		return SpannerIO.read().withInstanceId(INSTANCE_ID).withDatabaseId(DATABASE_ID).withBatching(false)
				.withQuery(query);
	}

	static class ReturnClassName extends DoFn<Struct, String> {
		@ProcessElement
		public void processElement(ProcessContext c) throws IOException {
			PubsubMessage message = new PubsubMessage();
			message.encodeData("PopulateMasterClient_DF".getBytes("UTF-8"));
			c.output("PopulateMasterClient_DF");
		}
	}
}
