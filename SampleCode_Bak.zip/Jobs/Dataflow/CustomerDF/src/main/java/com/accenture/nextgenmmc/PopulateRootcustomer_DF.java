/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.accenture.nextgenmmc;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.AvroCoder;
import org.apache.beam.sdk.coders.DefaultCoder;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO;
import org.apache.beam.sdk.io.gcp.spanner.SpannerWriteResult;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO.Write;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.Wait;
import org.apache.beam.sdk.values.PCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

import com.google.api.services.pubsub.model.PubsubMessage;
import com.google.cloud.Timestamp;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.Struct;

public class PopulateRootcustomer_DF {

	private static final String INSTANCE_ID = "si-27354-mmc";
	private static final String DATABASE_ID = "db-27354-mmc-db";
	private static final Timestamp TimeStamp = Timestamp.now();
	private static final Logger LOG = LoggerFactory.getLogger(PopulateRootcustomer_DF.class);

	private static final String TARGET_TABLE = "RootCustomer";

	private static final String QUERY = "SELECT\r\n" + "Y.CustomerNbr\r\n" + ",Y.RootCustomerNbr\r\n"
			+ ",'Rootcustomer_DF' as CreateUserId\r\n" + "from (\r\n"
			+ "SELECT coalesce(x.LEVEL5_CHILD,x.LEVEL4_CHILD,x.LEVEL3_CHILD,x.LEVEL2_CHILD,x.LEVEL1_CHILD,x.rootcustomernbr) as CustomerNbr\r\n"
			+ ",x.rootcustomernbr as RootCustomerNbr\r\n" + "\r\n" + "from\r\n"
			+ "(SELECT  Parent.CustomerNbr as rootcustomernbr\r\n" + ",child_a.CustomerNbr as LEVEL1_CHILD\r\n"
			+ ",child_b.CustomerNbr as LEVEL2_CHILD\r\n" + ",child_c.CustomerNbr as LEVEL3_CHILD\r\n"
			+ ",child_d.CustomerNbr as LEVEL4_CHILD\r\n" + ",child_e.CustomerNbr as LEVEL5_CHILD\r\n" + "FROM \r\n"
			+ "(select CustomerNbr,	ParentCustomerNbr	 \r\n" + "from mrdrcustomerdump\r\n"
			+ "where ParentCustomerNbr = '') Parent\r\n" + "LEFT JOIN\r\n"
			+ "(select CustomerNbr,	ParentCustomerNbr	 \r\n" + "from mrdrcustomerdump\r\n"
			+ "where ParentCustomerNbr <> '') child_a\r\n" + "ON Parent.CustomerNbr = child_a.ParentCustomerNbr\r\n"
			+ "LEFT JOIN\r\n" + "(select CustomerNbr,	ParentCustomerNbr	 \r\n" + "from mrdrcustomerdump\r\n"
			+ "where ParentCustomerNbr <> '') child_b\r\n" + "ON child_a.CustomerNbr = child_b.ParentCustomerNbr\r\n"
			+ "LEFT JOIN\r\n" + "(select CustomerNbr,	ParentCustomerNbr	 \r\n" + "from mrdrcustomerdump\r\n"
			+ "where ParentCustomerNbr <> '') child_c\r\n" + "ON child_b.CustomerNbr = child_c.ParentCustomerNbr\r\n"
			+ "LEFT JOIN\r\n" + "(select CustomerNbr,	ParentCustomerNbr	 \r\n" + "from mrdrcustomerdump\r\n"
			+ "where ParentCustomerNbr <> '') child_d\r\n" + "ON child_c.CustomerNbr = child_d.ParentCustomerNbr\r\n"
			+ "LEFT JOIN\r\n" + "(select CustomerNbr,	ParentCustomerNbr	 \r\n" + "from mrdrcustomerdump\r\n"
			+ "where ParentCustomerNbr <> '') child_e\r\n" + "ON child_d.CustomerNbr = child_e.ParentCustomerNbr\r\n"
			+ "\r\n" + ") X\r\n" + "  ) Y\r\n" + "where Y.CustomerNbr <> ''\r\n" + "--and Y.CustomerNbr = '0010000005'";

	public interface DFOptions extends PipelineOptions {
		String getProjectId();

		void setProjectId(String value);
	}

	public static void main(String[] args) {
		DFOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(DFOptions.class);
		Pipeline p = Pipeline.create(options);

		PCollection<Struct> RootCustomerTbl = p.apply("Read MRDRCustomerDump Table", ReadSpannerWithQuery(QUERY));
		SpannerWriteResult finish = RootCustomerTbl.apply(ParDo.of(new WriteMutation()))
				.apply("Write to " + TARGET_TABLE, WriteToSpanner());

		p.apply("Start PubSub Process", ReadSpannerWithQuery("SELECT 1 AS Placeholder"))
				.apply(Wait.on(finish.getOutput())).apply(ParDo.of(new ReturnClassName())).apply("Publish message",
						PubsubIO.writeStrings().to("projects/" + options.getProjectId() + "/topics/JobEvents"));

		p.run();
	}

	@DefaultCoder(AvroCoder.class)
	static class RootCustomer {
		String CustomerNbr;
		String RootCustomerNbr;
		String CreateUserId;

		RootCustomer(String CustomerNbr, String RootCustomerNbr, String CreateUserId) {
			this.CustomerNbr = CustomerNbr;
			this.RootCustomerNbr = RootCustomerNbr;
			this.CreateUserId = CreateUserId;
		}
	}

	static class WriteMutation extends DoFn<Struct, Mutation> {
		private static final long serialVersionUID = 1L;

		@ProcessElement
		public void processElement(ProcessContext c) {
			Struct input = c.element();
			c.output(Mutation.newInsertOrUpdateBuilder(TARGET_TABLE).set("CustomerNbr")
					.to(input.isNull(0) ? null : input.getString(0)).set("RootCustomerNbr")
					.to(input.isNull(1) ? null : input.getString(1)).set("CreateUserId")
					.to(input.isNull(2) ? null : input.getString(2)).set("CreateDttm").to(TimeStamp).build());
		}
	}

	public static Write WriteToSpanner() {
		return SpannerIO.write().withInstanceId(INSTANCE_ID).withDatabaseId(DATABASE_ID);
	}

	public static SpannerIO.Read ReadSpannerWithQuery(String query) {
		return SpannerIO.read().withInstanceId(INSTANCE_ID).withDatabaseId(DATABASE_ID).withBatching(false)
				.withQuery(query);
	}

	static class ReturnClassName extends DoFn<Struct, String> {
		@ProcessElement
		public void processElement(ProcessContext c) throws IOException {
			PubsubMessage message = new PubsubMessage();
			message.encodeData("PopulateRootcustomer_DF".getBytes("UTF-8"));
			c.output("PopulateRootcustomer_DF");
		}
	}
}
