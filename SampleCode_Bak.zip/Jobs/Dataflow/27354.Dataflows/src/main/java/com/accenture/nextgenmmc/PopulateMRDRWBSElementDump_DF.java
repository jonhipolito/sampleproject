/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.accenture.nextgenmmc;

import java.io.IOException;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.AvroCoder;
import org.apache.beam.sdk.coders.DefaultCoder;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.io.TextIO.Read;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO;
import org.apache.beam.sdk.io.gcp.spanner.SpannerWriteResult;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO.Write;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.Wait;
import org.apache.beam.sdk.values.PCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.api.services.pubsub.model.PubsubMessage;
import com.google.cloud.Timestamp;
import com.google.cloud.spanner.KeySet;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.Struct;
import com.opencsv.CSVParser;

public class PopulateMRDRWBSElementDump_DF {
	
	private static final String INSTANCE_ID = "si-27354-mmc";
	private static final String DATABASE_ID = "db-27354-mmc-db";
//	private static final String FilePath = "gs://27354-nextgenmmc/EBIDump/MRDRWBSElementDump.csv";
	private static final String FileName = "MRDRWBSElementDump.csv";
	private static final Timestamp TimeStamp = Timestamp.now();

	private static final Logger LOG = LoggerFactory.getLogger(PopulateMRDRWBSElementDump_DF.class);

	private static final CSVParser CSVParser = new CSVParser();
	private static int Counter = 0;
	public interface DFOptions extends PipelineOptions {		
		String getInputFile();	
		String getProjectId();
		void setInputFile(String value);
		void setProjectId(String value);
	  }
	public static void main(String[] args) {
		DFOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(DFOptions.class);
		Pipeline p = Pipeline.create(options);
		
		SpannerWriteResult delete = p.apply("Start MRDRWBSElementDump Deletion", ReadSpannerDump("SELECT * FROM MRDRWBSElementDump LIMIT 1"))
		.apply("Delete Mutation for MRDRWBSElementDump", ParDo.of(new DeleteMutations()))
		.apply("Delete rows in MRDRWBSElementDump Table", WriteToSpanner());

		PCollection<String> dump = p.apply("Read MRDRWBSElementDump CSV", ReadCSVDump(options.getInputFile() + FileName));
		
		PCollection<Mutation> mutations = dump
				.apply(Wait.on(delete.getOutput()))
				.apply("Parse CSV Rows", ParDo.of(new ParseRows()))
				.apply("Create Mutation", ParDo.of(new WriteMutation()));
		
				SpannerWriteResult finish = mutations.apply("Write to MRDRWBSElementDump Table", WriteToSpanner());

		p.apply("Start PubSub Process", ReadSpannerDump("SELECT 1 AS Placeholder"))
		.apply(Wait.on(finish.getOutput()))
		.apply(ParDo.of(new ReturnClassName()))
		.apply("Publish message", PubsubIO.writeStrings().to("projects/" + options.getProjectId() + "/topics/JobEvents"));

		p.run();
		LOG.info("Count: " + Counter);

	}
	
	static class ParseRows extends DoFn<String, MRDRWBSElementDump> {
		@ProcessElement
		public void processElement(ProcessContext c) throws IOException {
			String line = c.element();
			String[] columns = CSVParser.parseLine(line);
			if (line.compareTo("WBSInternalNbr,WBSExternalNbr,WBSDescr,CompanyCd,ProfitCenterNbr,ResponsibleCostCenter,PersonnelNbr,EmployeeNm,GBDDOpportunityID,WBSStatus,TypeOfWorkCd,DetailTypeOfWork1,DetailTypeOfWork2,DetailTypeOfWork3,DeliveryCenterCd,ResultsAnalysisKey,ProjectHierarchyLevel,DetailTypeOfWorkPercentage1,DetailTypeOfWorkPercentage2,DetailTypeOfWorkPercentage3,ProjectType,BusinessActivities1,BusinessActivities2,BusinessActivities3,BasicStartDt,BasicFinishDt,CreateDt,BillingInd") != 0) {
				try {
					//LOG.info("column1",columns[1]);
					c.output(new MRDRWBSElementDump(columns[0], columns[1], columns[2],columns[3],
							columns[4], columns[5], columns[6],columns[7], columns[8], columns[9], 
							columns[10],columns[11],columns[12], columns[13], columns[14],columns[15],
							columns[16], columns[17], columns[18],columns[19],columns[20], columns[21],
							columns[22],columns[23],columns[24], columns[25], columns[26],columns[27]
							));
				} catch (Exception e) {
					LOG.info(line);
					LOG.info(e.getMessage());
				}

			}
		}
	}
	static class CreateDeleteMutation extends DoFn<Struct, MRDRWBSElementDump> {
		@ProcessElement
		public void processElement(ProcessContext c) throws IOException {
			Struct row = c.element();
			Counter++;
		}
	}
	@DefaultCoder(AvroCoder.class)
	static class MRDRWBSElementDump {
		String WBSInternalNbr; 
		String WBSExternalNbr;
		String WBSDescr;
		String CompanyCd;
		String ProfitCenterNbr;
		String ResponsibleCostCenter;
		String PersonnelNbr;
		String EmployeeNm;
		String GBDDOpportunityID;
		String WBSStatus;
		String TypeOfWorkCd;
		String DetailTypeOfWork1;
		String DetailTypeOfWork2;
		String DetailTypeOfWork3;
		String DeliveryCenterCd; 
		String ResultsAnalysisKey;
		String ProjectHierarchyLevel; 
		String DetailTypeOfWorkPercentage1;
		String DetailTypeOfWorkPercentage2;
		String DetailTypeOfWorkPercentage3;
		String ProjectType; 
		String BusinessActivities1;
		String BusinessActivities2; 
		String BusinessActivities3; 
		String BasicStartDt;
		String BasicFinishDt;
		String CreateDt;
		String BillingInd;
		String UpdatedInd;
		String CreateUserId;
		String UpdateUserId;

		MRDRWBSElementDump() {
		}
		
		MRDRWBSElementDump(String WBSInternalNbr, String WBSExternalNbr, String WBSDescr, String CompanyCd,
				String ProfitCenterNbr,String ResponsibleCostCenter, String PersonnelNbr,String EmployeeNm,
				String GBDDOpportunityID, String WBSStatus,String TypeOfWorkCd, String DetailTypeOfWork1,
				String DetailTypeOfWork2, String DetailTypeOfWork3, String DeliveryCenterCd, String ResultsAnalysisKey,
				String ProjectHierarchyLevel, String DetailTypeOfWorkPercentage1, String DetailTypeOfWorkPercentage2,
				String DetailTypeOfWorkPercentage3, String ProjectType, String BusinessActivities1, 
				String BusinessActivities2, String BusinessActivities3, String BasicStartDt, String BasicFinishDt,
				String CreateDt, String BillingInd) {
			this.WBSInternalNbr = WBSInternalNbr.trim();
			this.WBSExternalNbr = WBSExternalNbr.trim();
			this.WBSDescr = WBSDescr.trim();
			this.CompanyCd = CompanyCd.trim();
			this.ProfitCenterNbr = ProfitCenterNbr.trim();
			this.ResponsibleCostCenter = ResponsibleCostCenter.trim();
			this.PersonnelNbr = PersonnelNbr.trim();
			this.EmployeeNm = EmployeeNm.trim();
			this.GBDDOpportunityID = GBDDOpportunityID.trim();
			this.WBSStatus = WBSStatus.trim();
			this.TypeOfWorkCd = TypeOfWorkCd.trim();
			this.DetailTypeOfWork1 = DetailTypeOfWork1.trim();
			this.DetailTypeOfWork2 = DetailTypeOfWork2.trim();
			this.DetailTypeOfWork3 = DetailTypeOfWork3.trim();
			this.DeliveryCenterCd = DeliveryCenterCd.trim();
			this.ResultsAnalysisKey = ResultsAnalysisKey.trim();
			this.ProjectHierarchyLevel = ProjectHierarchyLevel.trim();
			this.DetailTypeOfWorkPercentage1 = DetailTypeOfWorkPercentage1.trim();
			this.DetailTypeOfWorkPercentage2 = DetailTypeOfWorkPercentage2.trim();
			this.DetailTypeOfWorkPercentage3 = DetailTypeOfWorkPercentage3.trim();
			this.ProjectType = ProjectType.trim();
			this.BusinessActivities1 = BusinessActivities1.trim();
			this.BusinessActivities2 = BusinessActivities2.trim();
			this.BusinessActivities3 = BusinessActivities3.trim();
			this.BasicStartDt = BasicStartDt.trim();
			this.BasicFinishDt = BasicFinishDt.trim();
			this.ProfitCenterNbr = ProfitCenterNbr.trim();
			this.CreateDt = CreateDt.trim();
			this.BillingInd = BillingInd.trim();
			this.UpdatedInd = "N";
			this.CreateUserId = "MRDRWBSElementDump";
			this.UpdateUserId = "MRDRWBSElementDump";
		}
	}
	static class WriteMutation extends DoFn<MRDRWBSElementDump, Mutation> {
		private static final long serialVersionUID = 1L;

		@ProcessElement
		public void processElement(ProcessContext c) {
			MRDRWBSElementDump model = c.element();
			c.output(Mutation.newInsertOrUpdateBuilder("MRDRWBSElementDump")
					.set("WBSInternalNbr").to(model.WBSInternalNbr)
					.set("WBSExternalNbr").to(model.WBSExternalNbr)
					.set("WBSDescr").to(model.WBSDescr)
					.set("CompanyCd").to(model.CompanyCd)
					.set("ProfitCenterNbr").to(model.ProfitCenterNbr)
					.set("ResponsibleCostCenter").to(model.ResponsibleCostCenter)
					.set("PersonnelNbr").to(model.PersonnelNbr)
					.set("EmployeeNm").to(model.EmployeeNm)
					.set("GBDDOpportunityID").to(model.GBDDOpportunityID)
					.set("WBSStatus").to(model.WBSStatus)
					.set("TypeOfWorkCd").to(model.TypeOfWorkCd)
					.set("DetailTypeOfWork1").to(model.DetailTypeOfWork1)
					.set("DetailTypeOfWork2").to(model.DetailTypeOfWork2)
					.set("DetailTypeOfWork3").to(model.DetailTypeOfWork3)
					.set("DeliveryCenterCd").to(model.DeliveryCenterCd)
					.set("ResultsAnalysisKey").to(model.ResultsAnalysisKey)
					.set("ProjectHierarchyLevel").to(model.ProjectHierarchyLevel)
					.set("DetailTypeOfWorkPercentage1").to(model.DetailTypeOfWorkPercentage1)
					.set("DetailTypeOfWorkPercentage2").to(model.DetailTypeOfWorkPercentage2)
					.set("DetailTypeOfWorkPercentage3").to(model.DetailTypeOfWorkPercentage3)
					.set("ProjectType").to(model.ProjectType)
					.set("BusinessActivities1").to(model.BusinessActivities1)
					.set("BusinessActivities2").to(model.BusinessActivities2)
					.set("BusinessActivities3").to(model.BusinessActivities3)
					.set("BasicStartDt").to(model.BasicStartDt)
					.set("BasicFinishDt").to(model.BasicFinishDt)
					.set("CreateDt").to(model.CreateDt)
					.set("BillingInd").to(model.BillingInd)
					.set("UpdatedInd").to(model.UpdatedInd)
					.set("CreateDttm").to(TimeStamp)
					.set("CreateUserId").to(model.CreateUserId)
					.set("UpdateDttm").to(TimeStamp)
					.set("UpdateUserId").to(model.UpdateUserId)
					.build());
		}
	}
	
	public static Read ReadCSVDump(String Path) {
		return TextIO.read().from(Path);
	}

	public static Write WriteToSpanner() {
		return SpannerIO.write().withInstanceId(INSTANCE_ID).withDatabaseId(DATABASE_ID);
	}
	
	public static SpannerIO.Read ReadSpannerDump(String query) {
		return SpannerIO.read().withInstanceId(INSTANCE_ID).withDatabaseId(DATABASE_ID).withBatching(false).withQuery(query);
	}
	
	static class DeleteMutations extends DoFn<Struct, Mutation> {
        @ProcessElement
        public void processElement(ProcessContext c) {
			Mutation tcs = Mutation.delete("MRDRWBSElementDump", KeySet.all());
			c.output(tcs);
        }
	}

	static class ReturnClassName extends DoFn<Struct, String> {
		@ProcessElement
		public void processElement(ProcessContext c) throws IOException {
			PubsubMessage message = new PubsubMessage();
			message.encodeData("PopulateMRDRWBSElementDump_DF".getBytes("UTF-8"));
			c.output("PopulateMRDRWBSElementDump_DF");			
		}
	}
}
