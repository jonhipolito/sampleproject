/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.accenture.nextgenmmc;

import java.io.IOException;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.AvroCoder;
import org.apache.beam.sdk.coders.DefaultCoder;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.io.TextIO.Read;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO;
import org.apache.beam.sdk.io.gcp.spanner.SpannerWriteResult;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO.Write;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.Wait;
import org.apache.beam.sdk.values.PCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.api.services.pubsub.model.PubsubMessage;
import com.google.cloud.Timestamp;
import com.google.cloud.spanner.KeySet;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.Struct;
import com.opencsv.CSVParser;

public class PopulateOperatingUnitDump_DF {
	
	private static final String INSTANCE_ID = "si-27354-mmc";
	private static final String DATABASE_ID = "db-27354-mmc-db";
//	private static final String FilePath = "gs://27354-nextgenmmc/EBIDump/OperatingUnitDump.csv";
	private static final String FileName = "OperatingUnitDump.csv";
	private static final Timestamp TimeStamp = Timestamp.now();

	private static final Logger LOG = LoggerFactory.getLogger(PopulateOperatingUnitDump_DF.class);

	private static final CSVParser CSVParser = new CSVParser();
	private static int Counter = 0;
	public interface DFOptions extends PipelineOptions {		
		String getInputFile();	
		String getProjectId();
		void setInputFile(String value);
		void setProjectId(String value);
	  }
	public static void main(String[] args) {
		DFOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(DFOptions.class);
		Pipeline p = Pipeline.create(options);
		
		SpannerWriteResult delete = p.apply("Start OperatingUnitDump Deletion", ReadSpannerDump("SELECT * FROM OperatingUnitDump LIMIT 1"))
		.apply("Delete Mutation for OperatingUnitDump", ParDo.of(new DeleteMutations()))
		.apply("Delete rows in OperatingUnitDump Table", WriteToSpanner());
		
		PCollection<String> dump = p.apply("Read OperatingUnitDump CSV", ReadCSVDump(options.getInputFile() + FileName));
		
		PCollection<Mutation> mutations = dump
				.apply(Wait.on(delete.getOutput()))
				.apply("Parse CSV Rows", ParDo.of(new ParseRows()))
				.apply("Create Mutation", ParDo.of(new WriteMutation()));
		
				SpannerWriteResult finish = mutations.apply("Write to OperatingUnitDump Table", WriteToSpanner());	

		p.apply("Start PubSub Process", ReadSpannerDump("SELECT 1 AS Placeholder"))
		.apply(Wait.on(finish.getOutput()))
		.apply(ParDo.of(new ReturnClassName()))
		.apply("Publish message", PubsubIO.writeStrings().to("projects/" + options.getProjectId() + "/topics/JobEvents"));

		p.run();
		LOG.info("Count: " + Counter);

	}
	
	static class ParseRows extends DoFn<String, OperatingUnitDump> {
		@ProcessElement
		public void processElement(ProcessContext c) throws IOException {
			String line = c.element();
			String[] columns = CSVParser.parseLine(line);
			if (line.compareTo("OperatingUnitCd,OperatingUnitDesc,OperatingGroupCd") != 0) {
				try {
					//LOG.info("column1",columns[1]);
					c.output(new OperatingUnitDump(columns[0], columns[1], columns[2]
							));
				} catch (Exception e) {
					LOG.info(line);
					LOG.info(e.getMessage());
				}

			}
		}
	}
	static class CreateDeleteMutation extends DoFn<Struct, OperatingUnitDump> {
		@ProcessElement
		public void processElement(ProcessContext c) throws IOException {
			Struct row = c.element();
			Counter++;
		}
	}
	@DefaultCoder(AvroCoder.class)
	static class OperatingUnitDump {
		String OperatingUnitCd;
		String OperatingUnitDesc;
		String OperatingGroupCd;
		String UpdatedInd;
		String CreateUserId;
		String UpdateUserId;

		OperatingUnitDump() {
		}
		
		OperatingUnitDump(String OperatingUnitCd, String OperatingUnitDesc, String OperatingGroupCd

				) {
			this.OperatingUnitCd = OperatingUnitCd.trim();
			this.OperatingUnitDesc = OperatingUnitDesc.trim();
			this.OperatingGroupCd = OperatingGroupCd.trim();
			this.UpdatedInd = "N";
			this.CreateUserId = "OperatingUnitDump";
			this.UpdateUserId = "OperatingUnitDump";
		}
	}
	static class WriteMutation extends DoFn<OperatingUnitDump, Mutation> {
		private static final long serialVersionUID = 1L;

		@ProcessElement
		public void processElement(ProcessContext c) {
			OperatingUnitDump model = c.element();
			c.output(Mutation.newInsertOrUpdateBuilder("OperatingUnitDump")
					.set("OperatingUnitCd").to(model.OperatingUnitCd)
					.set("OperatingUnitDesc").to(model.OperatingUnitDesc)
					.set("OperatingGroupCd").to(model.OperatingGroupCd)
					.set("UpdatedInd").to(model.UpdatedInd)
					.set("CreateDttm").to(TimeStamp)
					.set("CreateUserId").to(model.CreateUserId)
					.set("UpdateDttm").to(TimeStamp)
					.set("UpdateUserId").to(model.UpdateUserId)
					.build());
		}
	}
	
	public static Read ReadCSVDump(String Path) {
		return TextIO.read().from(Path);
	}

	public static Write WriteToSpanner() {
		return SpannerIO.write().withInstanceId(INSTANCE_ID).withDatabaseId(DATABASE_ID);
	}
	
	public static SpannerIO.Read ReadSpannerDump(String query) {
		return SpannerIO.read().withInstanceId(INSTANCE_ID).withDatabaseId(DATABASE_ID).withBatching(false).withQuery(query);
	}

	static class DeleteMutations extends DoFn<Struct, Mutation> {
        @ProcessElement
        public void processElement(ProcessContext c) {
			Mutation tcs = Mutation.delete("OperatingUnitDump", KeySet.all());
			c.output(tcs);
        }
	}

	static class ReturnClassName extends DoFn<Struct, String> {
		@ProcessElement
		public void processElement(ProcessContext c) throws IOException {
			PubsubMessage message = new PubsubMessage();
			message.encodeData("PopulateOperatingUnitDump_DF".getBytes("UTF-8"));
			c.output("PopulateOperatingUnitDump_DF");			
		}
	}
}
