/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.accenture.nextgenmmc;

import java.io.IOException;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.AvroCoder;
import org.apache.beam.sdk.coders.DefaultCoder;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.io.TextIO.Read;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO;
import org.apache.beam.sdk.io.gcp.spanner.SpannerWriteResult;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO.Write;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.Wait;
import org.apache.beam.sdk.values.PCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.api.services.pubsub.model.PubsubMessage;
import com.google.cloud.Timestamp;
import com.google.cloud.spanner.Key;
import com.google.cloud.spanner.KeySet;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.Struct;
import com.opencsv.CSVParser;

public class PopulateMRDRContractsDump_DF {
	
	private static final String INSTANCE_ID = "si-27354-mmc";
	private static final String DATABASE_ID = "db-27354-mmc-db";
//	private static final String FilePath = "gs://27354-nextgenmmc/EBIDump/MRDRContractsDump.csv";
	private static final String FileName = "MRDRContractsDump.csv";
	private static final Timestamp TimeStamp = Timestamp.now();

	private static final Logger LOG = LoggerFactory.getLogger(PopulateMRDRContractsDump_DF.class);

	private static final CSVParser CSVParser = new CSVParser();
	private static int Counter = 0;
	public interface DFOptions extends PipelineOptions {		
		String getInputFile();	
		String getProjectId();
		void setInputFile(String value);
		void setProjectId(String value);
	  }
	public static void main(String[] args) {
		DFOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(DFOptions.class);
		Pipeline p = Pipeline.create(options);
		
		SpannerWriteResult delete = p.apply("Start MRDRContractsDump Deletion", ReadSpannerDump("SELECT ContractCd FROM MRDRContractsDump"))
		.apply("Delete Mutation for MRDRContractsDump", ParDo.of(new DeleteMutations()))
		.apply("Delete rows in MRDRContractsDump Table", WriteToSpanner());

		PCollection<String> dump = p.apply("Read MRDRContractsDump CSV", ReadCSVDump(options.getInputFile() + FileName));
		
		PCollection<Mutation> mutations = dump
				.apply(Wait.on(delete.getOutput()))		
				.apply("Parse CSV Rows", ParDo.of(new ParseRows()))
				.apply("Create Mutation", ParDo.of(new WriteMutation()));
		
				SpannerWriteResult finish = mutations.apply("Write to MRDRContractsDump Table", WriteToSpanner());

		p.apply("Start PubSub Process", ReadSpannerDump("SELECT 1 AS Placeholder"))
		.apply(Wait.on(finish.getOutput()))
		.apply(ParDo.of(new ReturnClassName()))
		.apply("Publish message", PubsubIO.writeStrings().to("projects/" + options.getProjectId() + "/topics/JobEvents"));

		p.run();
		LOG.info("Count: " + Counter);

	}
	
	static class ParseRows extends DoFn<String, MRDRContractsDump> {
		@ProcessElement
		public void processElement(ProcessContext c) throws IOException {
			String line = c.element();
			String[] columns = CSVParser.parseLine(line);
			if (line.compareTo("ContractCd,ContractDescr,ContractStartDt,ContractEndDt,CustomerNbr,CustomerAccountNbr,ContractLineItemNbr,CreateDt,ValidFromDt,ValidToDt,CostCenterNbr,RespSrExecPrimaryPersNbr,RespSrExecPrimaryEntID,ContractUserStatCd,ContractUserStatDescr,ContractType,RBECd,RBEDescr") != 0) {
				try {
					//LOG.info("column1",columns[1]);
					c.output(new MRDRContractsDump(columns[0], columns[1], columns[2],columns[3],
							columns[4], columns[5], columns[6],columns[7],columns[8], columns[9], 
							columns[10],columns[11],columns[12], columns[13], columns[14],columns[15],
							columns[16],columns[17]));
				} catch (Exception e) {
					LOG.info(line);
					LOG.info(e.getMessage());					
				}

			}
		}
	}
	static class CreateDeleteMutation extends DoFn<Struct, MRDRContractsDump> {
		@ProcessElement
		public void processElement(ProcessContext c) throws IOException {
			Struct row = c.element();
			Counter++;
		}
	}
	@DefaultCoder(AvroCoder.class)
	static class MRDRContractsDump {
		String ContractCd;
		String ContractDescr;
		String ContractStartDt;
		String ContractEndDt;
		String CustomerNbr;
		String CustomerAccountNbr;
		String ContractLineItemNbr;
		String CreateDt;
		String ValidFromDt;
		String ValidToDt;
		String CostCenterNbr;
		String RespSrExecPrimaryPersNbr;
		String RespSrExecPrimaryEntID;
		String ContractUserStatCd;
		String ContractUserStatDescr;
		String ContractType;
		String RBECd;
		String RBEDescr;
		String UpdatedInd;
		String CreateUserId;
		String UpdateUserId;

		MRDRContractsDump() {
		}
		
		MRDRContractsDump(String ContractCd,String ContractDescr,String ContractStartDt,String ContractEndDt,
				String CustomerNbr,String CustomerAccountNbr,String ContractLineItemNbr,String CreateDt,String ValidFromDt,
				String ValidToDt,String CostCenterNbr,String RespSrExecPrimaryPersNbr,String RespSrExecPrimaryEntID,
				String ContractUserStatCd,String ContractUserStatDescr,String ContractType,String RBECd, String RBEDescr) {
			this.ContractCd = ContractCd.trim();
			this.ContractDescr = ContractDescr.trim();
			this.ContractStartDt = ContractStartDt.trim();
			this.ContractEndDt = ContractEndDt.trim();
			this.CustomerNbr = CustomerNbr.trim();
			this.CustomerAccountNbr = CustomerAccountNbr.trim();
			this.ContractLineItemNbr = ContractLineItemNbr.trim();
			this.CreateDt = CreateDt.trim();
			this.ValidFromDt = ValidFromDt.trim();
			this.ValidToDt = ValidToDt.trim();
			this.CostCenterNbr = CostCenterNbr.trim();
			this.RespSrExecPrimaryPersNbr = RespSrExecPrimaryPersNbr.trim();
			this.RespSrExecPrimaryEntID = RespSrExecPrimaryEntID.trim();
			this.ContractUserStatCd = ContractUserStatCd.trim();
			this.ContractUserStatDescr = ContractUserStatDescr.trim();
			this.ContractType = ContractType.trim();
			this.RBECd = RBECd.trim();
			this.RBEDescr = RBEDescr.trim();
			this.UpdatedInd = "N";
			this.CreateUserId = "MRDRContractsDump";
			this.UpdateUserId = "MRDRContractsDump";
		}
	}
	static class WriteMutation extends DoFn<MRDRContractsDump, Mutation> {
		private static final long serialVersionUID = 1L;

		@ProcessElement
		public void processElement(ProcessContext c) {
			MRDRContractsDump model = c.element();
			c.output(Mutation.newInsertOrUpdateBuilder("MRDRContractsDump")
					.set("ContractCd").to(model.ContractCd)
					.set("ContractDescr").to(model.ContractDescr)
					.set("ContractStartDt").to(model.ContractStartDt)
					.set("ContractEndDt").to(model.ContractEndDt)
					.set("CustomerNbr").to(model.CustomerNbr)
					.set("CustomerAccountNbr").to(model.CustomerAccountNbr)
					.set("ContractLineItemNbr").to(model.ContractLineItemNbr)
					.set("CreateDt").to(model.CreateDt)
					.set("ValidFromDt").to(model.ValidFromDt)
					.set("ValidToDt").to(model.ValidToDt)
					.set("CostCenterNbr").to(model.CostCenterNbr)
					.set("RespSrExecPrimaryPersNbr").to(model.RespSrExecPrimaryPersNbr)
					.set("RespSrExecPrimaryEntID").to(model.RespSrExecPrimaryEntID)
					.set("ContractUserStatCd").to(model.ContractUserStatCd)
					.set("ContractUserStatDescr").to(model.ContractUserStatDescr)
					.set("ContractType").to(model.ContractType)
					.set("RBECd").to(model.RBECd)
					.set("RBEDescr").to(model.RBEDescr)
					.set("UpdatedInd").to(model.UpdatedInd)
					.set("CreateDttm").to(TimeStamp)
					.set("CreateUserId").to(model.CreateUserId)
					.set("UpdateDttm").to(TimeStamp)
					.set("UpdateUserId").to(model.UpdateUserId)
					.build());
		}
	}
	
	public static Read ReadCSVDump(String Path) {
		return TextIO.read().from(Path);
	}

	public static Write WriteToSpanner() {
		return SpannerIO.write().withInstanceId(INSTANCE_ID).withDatabaseId(DATABASE_ID);
	}
	
	public static SpannerIO.Read ReadSpannerDump(String query) {
		return SpannerIO.read().withInstanceId(INSTANCE_ID).withDatabaseId(DATABASE_ID).withBatching(false).withQuery(query);
	}

	static class DeleteMutations extends DoFn<Struct, Mutation> {
        @ProcessElement
        public void processElement(ProcessContext c) {
			Struct input = c.element();
			Mutation tcs = Mutation.delete("MRDRContractsDump", KeySet.singleKey(Key.newBuilder().append(input.getString(0)).build()));
			c.output(tcs);
        }
	}

	static class ReturnClassName extends DoFn<Struct, String> {
		@ProcessElement
		public void processElement(ProcessContext c) throws IOException {
			PubsubMessage message = new PubsubMessage();
			message.encodeData("PopulateMRDRContractsDump_DF".getBytes("UTF-8"));
			c.output("PopulateMRDRContractsDump_DF");			
		}
	}
}
