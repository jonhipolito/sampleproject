/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.accenture.nextgenmmc;

import java.io.IOException;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.AvroCoder;
import org.apache.beam.sdk.coders.DefaultCoder;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.io.TextIO.Read;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO;
import org.apache.beam.sdk.io.gcp.spanner.SpannerWriteResult;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO.Write;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.Wait;
import org.apache.beam.sdk.values.PCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.api.services.pubsub.model.PubsubMessage;
import com.google.cloud.Timestamp;
import com.google.cloud.spanner.KeySet;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.Struct;
import com.opencsv.CSVParser;

public class PopulateMRDRCompanyCodeDump_DF {
	
	private static final String INSTANCE_ID = "si-27354-mmc";
	private static final String DATABASE_ID = "db-27354-mmc-db";
//	private static final String FilePath = "gs://27354-nextgenmmc/EBIDump/MRDRCompanyCodeDump.csv";
	private static final String FileName = "MRDRCompanyCodeDump.csv";
	private static final Timestamp TimeStamp = Timestamp.now();

	private static final Logger LOG = LoggerFactory.getLogger(PopulateMRDRCompanyCodeDump_DF.class);

	private static final CSVParser CSVParser = new CSVParser();
	private static int Counter = 0;
	public interface DFOptions extends PipelineOptions {		
		String getInputFile();	
		String getProjectId();
		void setInputFile(String value);
		void setProjectId(String value);
	  }
	public static void main(String[] args) {
		DFOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(DFOptions.class);
		Pipeline p = Pipeline.create(options);
		
		SpannerWriteResult delete = p.apply("Start MRDRCompanyCodeDump Deletion", ReadSpannerDump("SELECT * FROM MRDRCompanyCodeDump LIMIT 1"))
		.apply("Delete Mutation for MRDRCompanyCodeDump", ParDo.of(new DeleteMutations()))
		.apply("Delete rows in MRDRCompanyCodeDump Table", WriteToSpanner());

		PCollection<String> dump = p.apply("Read MRDRCompanyCodeDump CSV", ReadCSVDump(options.getInputFile() + FileName));
		
		PCollection<Mutation> mutations = dump
				.apply(Wait.on(delete.getOutput()))		
				.apply("Parse CSV Rows", ParDo.of(new ParseRows()))
				.apply("Create Mutation", ParDo.of(new WriteMutation()));
		
				SpannerWriteResult finish = mutations.apply("Write to MRDRCompanyCodeDump Table", WriteToSpanner());

		p.apply("Start PubSub Process", ReadSpannerDump("SELECT 1 AS Placeholder"))
		.apply(Wait.on(finish.getOutput()))
		.apply(ParDo.of(new ReturnClassName()))
		.apply("Publish message", PubsubIO.writeStrings().to("projects/" + options.getProjectId() + "/topics/JobEvents"));

		p.run();
		LOG.info("Count: " + Counter);
	}
	
	static class ParseRows extends DoFn<String, MRDRCompanyCodeDump> {
		@ProcessElement
		public void processElement(ProcessContext c) throws IOException {
			String line = c.element();
			String[] columns = CSVParser.parseLine(line);
			if (line.compareTo("CompanyCd,CompanyDesc,City,CountryKey,CurrencyKey,PostingPeriodVariantCd") != 0) {
				try {
					//LOG.info(columns[0] + ": " + columns[1]);
					if(columns[0] == "1506") {
						LOG.info(line);
					}
					c.output(new MRDRCompanyCodeDump(columns[0], columns[1], columns[2],columns[3], columns[4],
							columns[5]));
				} catch (Exception e) {
					LOG.warn(line);
					LOG.warn(e.getMessage());
				}

			}
		}
	}
	static class CreateDeleteMutation extends DoFn<Struct, MRDRCompanyCodeDump> {
		@ProcessElement
		public void processElement(ProcessContext c) throws IOException {
			Struct row = c.element();
			Counter++;
		}
	}
	@DefaultCoder(AvroCoder.class)
	static class MRDRCompanyCodeDump {
		String CompanyCd; 
		String CompanyDesc; 
		String City; 
		String CountryKey; 
		String CurrencyKey;
		String PostingPeriodVariantCd;
		String UpdatedInd;
		String CreateUserId;
		String UpdateUserId;

		MRDRCompanyCodeDump() {
		}
		
		MRDRCompanyCodeDump(String CompanyCd, String CompanyDesc, String City, String CountryKey, String CurrencyKey, String PostingPeriodVariantCd) {
			this.CompanyCd = CompanyCd.trim();
			this.CompanyDesc = CompanyDesc.trim();
			this.City = City.trim();
			this.CountryKey = CountryKey.trim();
			this.CurrencyKey = CurrencyKey.trim();
			this.PostingPeriodVariantCd = PostingPeriodVariantCd.trim();
			this.UpdatedInd = "N";
			this.CreateUserId = "MRDRCompanyCodeDump";
			this.UpdateUserId = "MRDRCompanyCodeDump";
		}
	}
	static class WriteMutation extends DoFn<MRDRCompanyCodeDump, Mutation> {
		private static final long serialVersionUID = 1L;

		@ProcessElement
		public void processElement(ProcessContext c) {
			MRDRCompanyCodeDump model = c.element();	
			LOG.info(model.CompanyCd + " : " + model.CompanyDesc);
			c.output(Mutation.newInsertOrUpdateBuilder("MRDRCompanyCodeDump")
					.set("CompanyCd").to(model.CompanyCd)
					.set("CompanyDesc").to(model.CompanyDesc)
					.set("City").to(model.City)
					.set("CountryKey").to(model.CountryKey)
					.set("CurrencyKey").to(model.CurrencyKey)
					.set("PostingPeriodVariantCd").to(model.PostingPeriodVariantCd)
					.set("UpdatedInd").to(model.UpdatedInd)					
					.set("CreateUserId").to(model.CreateUserId)					
					.set("UpdateUserId").to(model.UpdateUserId)
					.build());
		}
	}
	
	public static Read ReadCSVDump(String Path) {
		return TextIO.read().from(Path);
	}

	public static Write WriteToSpanner() {
		return SpannerIO.write().withInstanceId(INSTANCE_ID).withDatabaseId(DATABASE_ID);
	}
	
	public static SpannerIO.Read ReadSpannerDump(String query) {
		return SpannerIO.read().withInstanceId(INSTANCE_ID).withDatabaseId(DATABASE_ID).withBatching(false).withQuery(query);
	}

	static class DeleteMutations extends DoFn<Struct, Mutation> {
        @ProcessElement
        public void processElement(ProcessContext c) {
			Mutation tcs = Mutation.delete("MRDRCompanyCodeDump", KeySet.all());
			c.output(tcs);
        }
	}

	static class ReturnClassName extends DoFn<Struct, String> {
		@ProcessElement
		public void processElement(ProcessContext c) throws IOException {
			PubsubMessage message = new PubsubMessage();
			message.encodeData("PopulateMRDRCompanyCodeDump_DF".getBytes("UTF-8"));
			c.output("PopulateMRDRCompanyCodeDump_DF");			
		}
	}
}
