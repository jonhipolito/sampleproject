const uuid = require('uuidv4');

populateMasterClient = async function(database, masterClientTable) {
    //Update Master Client Name
    [masterClientUpdateRows] = await database.run({
        sql:
            `SELECT mc.MasterClientKey
                    ,RTRIM(cad.ContentValue) AS MasterClientNm
                FROM MasterClient mc
                INNER JOIN MRDRCustomerAttributeDump cad
                    ON cad.CustomerNbr = mc.MasterClientNbr
                    AND cad.AttributeCd = 'CNAME'`
    });

    if (masterClientUpdateRows.length > 0) {
        let finalRows = [];

        masterClientUpdateRows.forEach(row => {
            let tempRow = row.toJSON();
            tempRow.UpdateDttm = (new Date());
            tempRow.UpdateUserId = 'sample.user';
            finalRows.push(tempRow);
        });

        await masterClientTable.update(finalRows);

        console.log(`MasterClient: ${masterClientUpdateRows.length} row/s updated`);
    }

    //Insert new Master Clients
    [masterClientInsertRows] = await database.run({
        sql:
            `SELECT DISTINCT rc.RootCustomerNbr AS MasterClientNbr
                    ,IFNULL(cad.ContentValue,'') AS MasterClientNm
                FROM RootCustomer rc
                INNER JOIN MRDRCustomerDump mcd
                    ON rc.RootCustomerNbr = mcd.CustomerNbr
                LEFT JOIN MasterClient mc
                    ON mc.MasterClientNbr = rc.RootCustomerNbr
                LEFT JOIN MRDRCustomerAttributeDump cad
                    ON cad.CustomerNbr = rc.RootCustomerNbr
                    AND cad.AttributeCd = 'CNAME'
                WHERE mc.MasterClientNbr IS NULL
                    AND rc.RootCustomerNbr <> ''`
    });

    if (masterClientInsertRows.length > 0) {
        let finalRows = [];

        masterClientInsertRows.forEach(row => {
            let tempRow = row.toJSON();
            tempRow.MasterClientKey = uuid();
            tempRow.CreateDttm = (new Date());
            tempRow.CreateUserId = 'sample.user';
            tempRow.UpdateDttm = (new Date());
            tempRow.UpdateUserId = 'sample.user';
            finalRows.push(tempRow);
        });

        await masterClientTable.insert(finalRows);

        console.log(`MasterClient: ${masterClientInsertRows.length} row/s inserted`);
    }
}

module.exports = {
    populateMasterClient
}