const { Spanner } = require('@google-cloud/spanner'),
    rootCustomer = require('./rootcustomer'),
    masterClient = require('./masterclient'),
    customer = require('./customer'),
    projectId = process.env.X_GOOGLE_GCLOUD_PROJECT,
    instanceId = '27354-mmc-npd-si',
    databaseId = 'db-27354-mmc-db',
    spanner = new Spanner({ projectId: projectId, }),
    instance = spanner.instance(instanceId),
    database = instance.database(databaseId),
    rootCustomerTable = database.table('RootCustomer'),
    masterClientTable = database.table('MasterClient'),
    customerTable = database.table('Customer');


exports.populateCustomer = async () => {
    try {
        console.log("Start: Populate Customer");
        await rootCustomer.populateRootCustomer(database, rootCustomerTable);
        await masterClient.populateMasterClient(database, masterClientTable);
        await customer.populateCustomer(database, customerTable);
        await rootCustomer.truncateRootCustomer(database);
    }
    catch (err) {
        console.error("Error: ", err);
    }
    finally {
        // Close the database when finished
        console.log("End: Populate Customer");
        database.close();
    }
}