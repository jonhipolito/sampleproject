const uuid = require('uuidv4');

populateCustomer = async function(database, customerTable) {
    //Insert Customers
    [customerInsertRows] = await database.run({
        sql:
            `SELECT DISTINCT LTRIM(RTRIM(cm.CustomerNbr)) AS CustomerNbr
                    ,RTRIM(cm.CustomerNm1) AS CustomerNm
                    ,mc.MasterClientNbr AS MasterClientNbr
                    ,mrcu.ParentCustomerNbr AS ParentCustomerNbr
                FROM MRDRCustomerMasterDump cm
                INNER JOIN RootCustomer rc
                    ON cm.CustomerNbr = rc.CustomerNbr
                INNER JOIN MasterClient mc
                    ON mc.MasterClientNbr = rc.RootCustomerNbr
                INNER JOIN MRDRCustomerDump mrcu
                    ON cm.CustomerNbr = mrcu.CustomerNbr
                INNER JOIN ContractStage cs
                    ON cm.CustomerNbr = cs.CustomerNbr
                LEFT JOIN Customer cus
                    ON cm.CustomerNbr = cus.CustomerNbr
                WHERE cus.CustomerNbr IS NULL`
    });

    if (customerInsertRows.length > 0) {
        let finalRows = [];

        customerInsertRows.forEach(row => {
            let tempRow = row.toJSON();
            tempRow.CustomerKey = uuid();
            tempRow.CreateDttm = (new Date());
            tempRow.CreateUserId = 'sample.user';
            tempRow.DummyInd = 'N';
            tempRow.UpdateDttm = (new Date());
            tempRow.UpdateUserId = 'sample.user';
            tempRow.WithCMInd = 'N';
            finalRows.push(tempRow);
        });

        await customerTable.insert(finalRows);

        console.log(`Customer: ${customerInsertRows.length} row/s inserted`);
    }

    //Load NonCM Customer
    //Insert non-cm customers with approved status
    [approvedCMCustomerInsertRows] = await database.run({
        sql:
            `SELECT DISTINCT tcl.CustomerNbr
                    ,RTRIM(ca.ContentValue) AS CustomerNm
                    ,mc.ParentCustomerNbr                                                                                                                                                                                                  
                    ,'N' AS WithCMInd
                    ,mas.MasterClientNbr
                FROM (
                        SELECT DISTINCT mc.CustomerNbr
                            , cra.CustomerRelationshipNbr
                        FROM  MRDRCustomerDump mc
                        INNER JOIN MRDRCustomerRelationshipDump cr
                            ON  mc.CustomerNbr = cr.CustomerNbr
                        INNER JOIN MRDRCustomerRelationshipAttributeDump cra
                            ON cr.CustomerRelationshipNbr = cra.CustomerRelationshipNbr
                        WHERE mc.CustomerNbr NOT IN (SELECT CustomerNbr FROM Customer)
                            AND mc.CustomerNbr <> '' 
                            AND mc.CustomerNbr NOT LIKE '00700%'
                            AND mc.CustomerNbr NOT LIKE '%FED%'
                            AND cra.AttributeCd = 'CRSTDE' 
                            AND cra.ContentValue = 'Approved'
                     ) tcl
                INNER JOIN MRDRCustomerAttributeDump ca
                    ON tcl.CustomerNbr = ca.CustomerNbr
                    AND ca.Attributecd = 'CNAME'
                INNER JOIN MRDRCustomerDump mc
                    ON tcl.CustomerNbr = mc.CustomerNbr
                LEFT JOIN RootCustomer rc
                    ON tcl.CustomerNbr = rc.CustomerNbr
                LEFT JOIN MasterClient mas
                    ON rc.RootCustomerNbr = mas.MasterClientNbr
                LEFT JOIN MRDRCustomerAttributeDump ca2
                    ON rc.RootCustomerNbr = ca2.CustomerNbr
                    AND ca2.attributecd ='DSATID'`
    });

    if (approvedCMCustomerInsertRows.length > 0) {
        let finalRows = [];

        approvedCMCustomerInsertRows.forEach(row => {
            let tempRow = row.toJSON();
            tempRow.CustomerKey = uuid();
            tempRow.CreateDttm = (new Date());
            tempRow.CreateUserId = 'sample.user';
            tempRow.DummyInd = 'N';
            tempRow.UpdateDttm = (new Date());
            tempRow.UpdateUserId = 'sample.user';
            finalRows.push(tempRow);
        });

        await customerTable.insert(finalRows);

        console.log(`Customer: ${approvedCMCustomerInsertRows.length} row/s inserted`);
    }

    //Insert non-cm customers without approved status
    [notApprovedCMCustomerInsertRows] = await database.run({
        sql:
            `SELECT DISTINCT btcl.CustomerNbr
                    ,RTRIM(bca.ContentValue) AS CustomerNm
                    ,bmc.ParentCustomerNbr
                    ,'N' AS WithCMInd
                    ,mas.MasterClientNbr
                FROM (
                        SELECT DISTINCT mc.CustomerNbr
                            ,cr.CustomerRelationshipNbr
                        FROM  MRDRCustomerDump mc
                        INNER JOIN MRDRCustomerRelationshipDump cr
                            ON  mc.CustomerNbr = cr.CustomerNbr
                        WHERE mc.CustomerNbr NOT IN (SELECT CustomerNbr FROM Customer)
                            AND mc.CustomerNbr <> '' 
                            AND mc.CustomerNbr not like '00700%'
                            AND mc.CustomerNbr not like '%FED%'
                            AND mc.CustomerNbr not in (SELECT mc.CustomerNbr 
                                                        FROM MRDRCustomerDump mc
                                                        INNER JOIN MRDRCustomerRelationshipDump cr
                                                            ON  mc.CustomerNbr = cr.CustomerNbr
                                                        INNER JOIN MRDRCustomerRelationshipAttributeDump cra
                                                            ON cr.CustomerRelationshipNbr = cra.CustomerRelationshipNbr
                                                        WHERE mc.CustomerNbr NOT IN (SELECT CustomerNbr FROM Customer)
                                                            AND mc.CustomerNbr <> '' 
                                                            AND mc.CustomerNbr NOT LIKE '00700%'
                                                            AND mc.CustomerNbr NOT LIKE '%FED%'
                                                            AND cra.AttributeCd = 'CRSTDE' 
                                                            AND cra.ContentValue = 'Approved')
                     ) btcl
                INNER JOIN MRDRCustomerAttributeDump bca
                    ON btcl.CustomerNbr = bca.CustomerNbr
                    AND bca.Attributecd = 'CNAME'
                INNER JOIN MRDRCustomerDump bmc
                    ON btcl.CustomerNbr = bmc.CustomerNbr
                INNER JOIN RootCustomer brc
                    ON btcl.CustomerNbr = brc.CustomerNbr
                LEFT JOIN MasterClient mas
                    ON brc.RootCustomerNbr = mas.MasterClientNbr
                LEFT JOIN MRDRCustomerAttributeDump bca2
                    ON brc.RootCustomerNbr = bca2.CustomerNbr
                    AND bca2.attributecd ='DSATID'`
    });

    if (notApprovedCMCustomerInsertRows.length > 0) {
        let finalRows = [];

        notApprovedCMCustomerInsertRows.forEach(row => {
            let tempRow = row.toJSON();
            tempRow.CustomerKey = uuid();
            tempRow.CreateDttm = (new Date());
            tempRow.CreateUserId = 'sample.user';
            tempRow.DummyInd = 'N';
            tempRow.UpdateDttm = (new Date());
            tempRow.UpdateUserId = 'sample.user';
            finalRows.push(tempRow);
        });

        await customerTable.insert(finalRows);

        console.log(`Customer: ${notApprovedCMCustomerInsertRows.length} row/s inserted`);
    }

    //Update CustomerDetails
    [customerUpdateRows] = await database.run({
        sql:
            `SELECT DISTINCT CustomerKey
                    ,mca.ContentValue AS CustomerNm
                    ,mc.MasterClientNbr AS MasterClientNbr
                FROM MRDRCustomerAttributeDump mca
                INNER JOIN Customer c
                    ON mca.CustomerNbr = c.CustomerNbr
                INNER JOIN RootCustomer rc
                    ON c.CustomerNbr = rc.CustomerNbr
                INNER JOIN MasterClient mc
                    ON mc.MasterClientNbr = rc.RootCustomerNbr
                WHERE mca.AttributeCd = 'CNAME'
                    AND LTRIM(RTRIM(c.CustomerNm)) <> LTRIM(RTRIM(mca.ContentValue))
                    OR (c.MasterClientNbr <> mc.MasterClientNbr)
                    AND (rc.RootCustomerNbr IS NOT NULL OR rc.RootCustomerNbr <> '')`
    });

    if (customerUpdateRows.length > 0) {
        let finalRows = [];

        customerUpdateRows.forEach(row => {
            let tempRow = row.toJSON();
            tempRow.UpdateDttm = (new Date());
            tempRow.UpdateUserId = 'sample.user';
            finalRows.push(tempRow);
        });

        await customerTable.update(finalRows);

        console.log(`Customer: ${customerUpdateRows.length} row/s updated`);
    }
}

module.exports = {
    populateCustomer
}