'use strict';

const SpannerDB = require('../configs/db.connection');

const getJobSchedule = async (enterpriseId) => {
    const database = new SpannerDB();

    const query = `SELECT *  FROM JobSchedule WHERE Active = true`;

    try {
        let [jobschedule] = await database.run(query);
        return jobschedule;
    } catch (err) {
        return new Error(err);
    } finally {
        // Close the database when finished.
        await database.close();
    }
}

module.exports = {
    getJobSchedule
}