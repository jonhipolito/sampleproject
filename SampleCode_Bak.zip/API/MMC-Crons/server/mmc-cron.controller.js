'use strict';

const mmcCronService = require('./mmc-cron.service');

const runScheduleJobs = (req, res, next) => {
    mmcCronService._processSchedule()
        .then(data => {
            res.send();
        });
}

module.exports = {
    runScheduleJobs
}