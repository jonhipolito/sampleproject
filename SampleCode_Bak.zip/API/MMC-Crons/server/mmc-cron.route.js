'use strict';

const express = require('express');
const router = express.Router();
const mmcCronController = require('./mmc-cron.controller');

router.get('/runScheduleJobs', mmcCronController.runScheduleJobs);
module.exports = router;