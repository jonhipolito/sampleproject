'use strict';

const {
    authorization
} = require('./authorization'), {
    logError,
    handleError,
    apinotfound,
    ignoreFavicon
} = require('./errorhandler')


const init = function (server) {

    server.use(authorization);

    server.use(ignoreFavicon);

    // missing route error handling
    //server.use(apinotfound);

    // log error
    server.use(logError);

    // handle error
    server.use(handleError);
}
module.exports = {
    init
}