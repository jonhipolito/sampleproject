'use strict';

const authorization = (req, res, next) => {
    if(req.headers['x-appengine-cron']){
        next();
    }
    else {
        console.log("Unathorized");
        res.send('Unathorized');
    }
    
};

module.exports = { authorization }