'use strict';
const mmcCronRepository = require('./mmc-cron.repository');
const { PubSub } = require('@google-cloud/pubsub');


const _getJobSchedule = async() => {
  return await mmcCronRepository.getJobSchedule();
}

const _processSchedule = async() => {
  let days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  let scheds = await _getJobSchedule();  
  scheds.forEach(s => {
    let sched = s.toJSON();
    if(sched.Daily) {
      let hour = new Date().getUTCHours();      
      if(sched.Hourly || hour == sched.Hour_24H_UTC) {
        _runJob(sched.JobName);
      }      
    }
    else if(sched.Day && sched.Day.length > 0) {      
      let day = new Date().getUTCDay();
      let hour = new Date().getUTCHours();
      sched.Day.forEach(d => {
        if(day == days.indexOf(d)) {
          if(sched.Hourly || hour == sched.Hour_24H_UTC) {
            _runJob(sched.JobName);
          }          
        }
      });      
    }
  });
}

const _runJob = async(jobname) => {
  console.log("jobname", jobname);
  const topicName = 'JobEvents';  
  const pubsub = new PubSub();
  const dataBuffer = Buffer.from(jobname);
  const messageId = await pubsub.topic(topicName).publish(dataBuffer);
  console.log(`${jobname} - Message published.`);
}

module.exports = {
  _processSchedule
}
