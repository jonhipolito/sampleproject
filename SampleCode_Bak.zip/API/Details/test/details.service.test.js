process.env.NODE_ENV = 'test';
const detailsRepository = require('../server/details.repository');
const detailsService = require('../server/details.service');
const sinon = require('sinon');
const chai = require('chai');
const should = chai.should();
const expect = require('chai').expect;

describe('Testing Details Service', () => {
 
    describe('_getDetails Test Success', () => {
        before(() => {
            sinon.stub(detailsRepository, 'getDetails').resolves('test details');
        })

        after(() => {
            detailsRepository.getDetails.restore();
        })

        it("should successfully get details", function (done) {
            detailsService._getDetails(1, 1, 1)
                .then(message => {
                    message.should.eql('test details');
                })
                .finally(done())
        });
    });

});