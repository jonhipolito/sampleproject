process.env.NODE_ENV = 'test';
const uuid = require('uuidv4');
const detailsRepository = require('../server/details.repository');
const sinon = require('sinon');
const chai = require('chai');
const should = chai.should();
const expect = require('chai').expect;
const assert = chai.assert;  
const mockery = require('mockery');
require('dotenv').config(); // Loads .env (for local)    

describe('Testing Details Repository', () => {
  describe('getDetails Test', () => {
    
    beforeEach((done) => {

        mockery.enable({
            warnOnReplace: false,
            warnOnUnregistered: false,
            useCleanCache: true
        });
        done();
    });

    afterEach((done) => {
        mockery.disable();
        done();
    })

    it('should return contract data', (done) => {
        
        const conDBResult = [{'ContractNm': 'Rapid Test',
                        'ContractNbr': '1',
                        'CustomerNm': 'Rapid Test',
                        'CustomerNbr': '1',
                        'ContractStartDt': '18-Nov-2019g',
                        'ContractEndDt': '18-Nov-2019',
                        'RBEDescr': 'RBE Test'}];                      
        class SpannerDB {
            constructor(args) {}
            async close() {}
            async run(query) {
                return new Promise((resolve, reject) => {
                    resolve([conDBResult]);
                });
            }
        };
        mockery.registerMock('../configs/db.connection', SpannerDB);
        
        let detailsRepository = require('../server/details.repository');

        detailsRepository.getDetails('1','1','1')
        .then(result => {
            assert.equal(result, conDBResult); 
        }).then(done, done);

        mockery.deregisterMock('../configs/db.connection');
    });

    it('should return financial client', (done) => {
      
      const fcDBResult = [{'CustomerNm': 'Rapid Test',
                      'MasterClientNbr': '1',
                      'CustomerNbr': '1',
                      'IndustrySegment': ' Test',
                      'Country': 'Country Test',
                      'Region': 'Region Test',
                      'City': 'City Test',
                      'ClientServiceGroup': 'ClientServiceGroup Test',
                      'OperatingUnit': 'OperatingUnit Test',
                      'OperatingGroup': 'OperatingGroup Test',
                      'GlobalClientDirector': 'GlobalClientDirector Test',
                      'ClientDirector': 'ClientDirector Test'}];                      
      class SpannerDB {
          constructor(args) {}
          async close() {}
          async run(query) {
              return new Promise((resolve, reject) => {
                  resolve([fcDBResult]);
              });
          }
      };
      mockery.registerMock('../configs/db.connection', SpannerDB);
      
      let detailsRepository = require('../server/details.repository');

      detailsRepository.getDetails('1','1',0)
      .then(result => {
          assert.equal(result, fcDBResult); 
      }).then(done, done);

      mockery.deregisterMock('../configs/db.connection');
    });

   it('should return master client data', (done) => {

        const mcDBResult = [{'MasterClientNm': 'Rapid Test',
                        'ClientNbr': '1',
                        'IndustrySegment': ' Test',
                        'Country': 'Country Test',
                        'Region': 'Region Test',
                        'City': 'City Test',
                        'ClientServiceGroup': 'ClientServiceGroup Test',
                        'OperatingUnit': 'OperatingUnit Test',
                        'OperatingGroup': 'OperatingGroup Test',
                        'GlobalClientDirector': 'GlobalClientDirector Test'}];                        
        class SpannerDB {
            constructor(args) {}
            async close() {}
            async run(query) {
                return new Promise((resolve, reject) => {
                    resolve([mcDBResult]);
                });
            }
        };
        mockery.registerMock('../configs/db.connection', SpannerDB);
        
        let detailsRepository = require('../server/details.repository');

        detailsRepository.getDetails('1',0,0)
        .then(result => {
            assert.equal(result, mcDBResult); 
        }).then(done, done);

        mockery.deregisterMock('../configs/db.connection');
    });

    it('should return null when no mc/fc/contract', (done) => {

      const dbResult = [];                        
      class SpannerDB {
          constructor(args) {}
          async close() {}
          async run(query) {
              return new Promise((resolve, reject) => {
                  resolve([dbResult]);
              });
          }
      };
      mockery.registerMock('../configs/db.connection', SpannerDB);
      
      let detailsRepository = require('../server/details.repository');

      detailsRepository.getDetails(0,0,0)
      .then(result => {
          assert.equal('', dbResult); 
      }).then(done, done);

      mockery.deregisterMock('../configs/db.connection');
    });

    it('should catch error', (done) => {
      class SpannerDB {
          constructor(args) {}
          async close() {}
          async run(query) {
              return new Promise((resolve, reject) => {
                  reject('error')
              });
          }
      };
      mockery.registerMock('../configs/db.connection', SpannerDB);
    
      let  detailsRepository = require('../server/details.repository');

      detailsRepository.getDetails('1', 0)
      .catch(error => {
          assert.equal(error, 'error');   
      }).then(done, done)

      mockery.deregisterMock('../configs/db.connection');
    });

  });

});


