process.env.NODE_ENV = 'test';
const detailsController = require('../server/details.controller');
const detailsService = require('../server/details.service');
const sinon = require('sinon');
const chai = require('chai');
const expect = require('chai').expect;
var sinonChai = require('sinon-chai');
chai.use(sinonChai);
const nextSpy = sinon.spy();
const sendSpy = sinon.spy();

describe('Testing Details Controller', () => {
  describe('getDetails Test', () => {
    const detailsServiceMethodStub = sinon.stub(detailsService, '_getDetails');
    
    beforeEach(function(done) {
        done();
    });

    afterEach(function(done) {
      sendSpy.resetHistory();
      nextSpy.resetHistory();
      detailsServiceMethodStub.reset();
      done();
    });

    after(() => {
        detailsServiceMethodStub.restore();
    })
    
    it('should call service and return master client data', async () => {
        detailsServiceMethodStub.resolves([])
        const req = ({params :{clientNbr : "1",customerNbr:"1",contractNbr: "1"}});
        const res = { send: sendSpy };
        await detailsController.getDetails(req, res, nextSpy);
        expect(sendSpy).to.have.been.calledWith({ data: [] });
    });

    it('should call service and return financial client data', async () => {
      detailsServiceMethodStub.resolves([])
      const req = ({params :{clientNbr : "1",customerNbr:"1",contractNbr: 0}});
      const res = { send: sendSpy };
      await detailsController.getDetails(req, res, nextSpy);
      expect(sendSpy).to.have.been.calledWith({ data: [] });
    });

    it('should call service and return contract data', async () => {
      detailsServiceMethodStub.resolves([])
      const req = ({params :{clientNbr : "1",customerNbr: 0,contractNbr: 0}});
      const res = { send: sendSpy };
      await detailsController.getDetails(req, res, nextSpy);
      expect(sendSpy).to.have.been.calledWith({ data: [] });
    });


    it('should handle error returned by service', async () => {
        const statusSpy = sinon.spy();
        detailsServiceMethodStub.rejects('error');
        const req = ({params :{clientNbr : "1",customerNbr:"1",contractNbr: "1"}});
        const res = { send: sendSpy, status: statusSpy };
        await detailsController.getDetails(req, res, nextSpy);
        return detailsServiceMethodStub().catch((error) => {
          expect(error.name).eql('error');
        });
    });

  });

});