'use strict';
// const axios = require('axios');

const SpannerDB = require('../configs/db.connection');



const getDetails = async (clientNbr, customerNbr, contractNbr) => {
    const database = new SpannerDB();

    var detailsquery = await getQuery(clientNbr, customerNbr, contractNbr);

    try {
        let [detailsRows] = await database.run(detailsquery);
        if (detailsRows.length > 0) {
            return detailsRows;
        } else {
            return null;
        }
    } catch (err) {
    } finally {
        await database.close();
    }

}


const getQuery = async (clientNbr, customerNbr, contractNbr) => {
    var query = ``;

    if (contractNbr != 0) {
        // Query for Contract Details
        query = `SELECT co.ContractNm as ContractNm
                        ,co.ContractNbr as ContractNbr
                        ,cu.CustomerNm as CustomerNm
                        ,co.CustomerNbr as CustomerNbr
                        ,FORMAT_DATE("%d-%b-%Y", DATE(co.ContractStartDt,'+00:00')) as ContractStartDt
                        ,FORMAT_DATE("%d-%b-%Y", DATE(co.ContractEndDt,'+00:00')) as ContractEndDt
                        ,co.RBEDescr as RBEDescr
                FROM Customer cu
                LEFT JOIN Contract co ON cu.CustomerNbr = co.CustomerNbr
                WHERE co.ContractNbr = '${contractNbr}'
                `
    } else if (customerNbr != 0){
        // Query for Financial Client Details
        query = `SELECT cu.CustomerNm as CustomerNm
                        ,cu.MasterClientNbr as MasterClientNbr
                        ,cu.CustomerNbr as CustomerNbr
                        ,string_agg(distinct cu.IndustrySegment,'| |') as IndustrySegment
                        ,string_agg(distinct ct.CountryNm,'| |') as Country
                        ,string_agg(distinct gr.GeographicRegionDesc,'| |') as Region
                        ,string_agg(distinct cu.City,'| |') as City
                        ,string_agg(distinct csg.ClientServiceGroupDesc,'| |') as ClientServiceGroup
                        ,string_agg(distinct ou.OperatingUnitNm,'| |') as OperatingUnit
                        ,string_agg(distinct og.OperatingGroupNm,'| |') as OperatingGroup
                        ,string_agg(distinct cu.GlobalClientDirector,'| |') as GlobalClientDirector
                        ,string_agg(distinct cu.ClientDirector,'| |') as ClientDirector
                FROM Customer cu
                LEFT JOIN Contract co ON co.CustomerNbr = cu.CustomerNbr
                LEFT JOIN Country ct ON ct.CountryCd = cu.CountryKey 
                LEFT JOIN GeographicUnit gu ON gu.GeographicUnitCd = ct.GeographicUnitCd
                LEFT JOIN GeographicRegion gr ON gu.GeographicRegionCd = gr.GeographicRegionCd
                LEFT JOIN ContractHierarchyMapping chm ON chm.ContractNbr = co.ContractNbr
                LEFT JOIN ClientServiceGroup csg ON csg.ClientServiceGroupCd = chm.ClientServiceGroupCd
                LEFT JOIN OperatingUnit ou ON ou.OperatingUnitCd = csg.OperatingUnitCd
                LEFT JOIN OperatingGroup og ON og.OperatingGroupCd = ou.OperatingGroupCd
                WHERE cu.CustomerNbr = '${customerNbr}'
                group by cu.CustomerNm, cu.MasterClientNbr, cu.CUstomerNbr
                `
    } else if (clientNbr != 0){
        // Query for Master Client Details
        query = `SELECT mc.MasterClientNm as MasterClientNm
                        ,mc.MasterClientNbr as ClientNbr
                        ,string_agg(distinct cu.IndustrySegment,'| |') as IndustrySegment
                        ,string_agg(distinct ct.CountryNm,'| |')  as Country
                        ,string_agg(distinct gr.GeographicRegionDesc,'| |') as Region
                        ,string_agg(distinct cu.City,'| |') as City
                        ,string_agg(distinct csg.ClientServiceGroupDesc,'| |') as ClientServiceGroup
                        ,string_agg(distinct ou.OperatingUnitNm,'| |') as OperatingUnit
                        ,string_agg(distinct og.OperatingGroupNm,'| |') as OperatingGroup
                        ,string_agg(distinct cu.GlobalClientDirector,'| |') as GlobalClientDirector
                FROM MasterClient mc
                LEFT JOIN Customer cu ON cu.MasterClientNbr = mc.MasterClientNbr
                LEFT JOIN Contract co ON co.CustomerNbr = cu.CustomerNbr
                LEFT JOIN Country ct ON ct.CountryCd = cu.CountryKey 
                LEFT JOIN GeographicUnit gu ON gu.GeographicUnitCd = ct.GeographicUnitCd
                LEFT JOIN GeographicRegion gr ON gu.GeographicRegionCd = gr.GeographicRegionCd
                LEFT JOIN ContractHierarchyMapping chm ON chm.ContractNbr = co.ContractNbr
                LEFT JOIN ClientServiceGroup csg ON csg.ClientServiceGroupCd = chm.ClientServiceGroupCd
                LEFT JOIN OperatingUnit ou ON ou.OperatingUnitCd = csg.OperatingUnitCd
                LEFT JOIN OperatingGroup og ON og.OperatingGroupCd = ou.OperatingGroupCd
                WHERE cu.MasterClientNbr = '${clientNbr}' 
                group by mc.MasterClientNm, mc.MasterClientNbr    
                `             
    }

    return query;
}


module.exports = {
    getDetails
}