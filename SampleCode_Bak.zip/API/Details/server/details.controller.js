'use strict';

const detailsService = require('./details.service');

//Consume the data and transform the api
const getDetails = (req, res, next) => {
    detailsService._getDetails(req.params.clientNbr, req.params.customerNbr, req.params.contractNbr)
        .then(message => {
            res.send({
                data: message
            });       
        })
        .catch(error => {
            const err = new Error(error);
            next(err);
        })
}

module.exports = {
    getDetails
}
