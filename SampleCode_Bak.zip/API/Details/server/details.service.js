'use strict';

const uuid = require('uuidv4');
const _ = require('lodash');
const detailsRepository = require('./details.repository');
const axios = require('axios');
const NodeCache = require("node-cache");
const ttl = 60 * 60 * 1; // cache for 1 Hour
const cache = new NodeCache({ stdTTL: ttl, checkperiod: ttl * 0.2 });

//Apply logic here using the repository
const _getDetails = (clientNbr, customerNbr, contractNbr) => {
  return new Promise((resolve, reject) => {
    var res = detailsRepository.getDetails(clientNbr, customerNbr, contractNbr);
    try {
      resolve(res);
      res.catch(err);
    } catch (err) {
      return reject(err);
    }
  });
}

module.exports = {
  _getDetails
}
