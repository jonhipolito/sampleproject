'use strict';

const express = require('express');

const detailsController = require('./details.controller');

const router = express.Router();

const { hasAccess } = require('./middlewares/accesscontrol');

router.get('/getDetails/:clientNbr/:customerNbr/:contractNbr', hasAccess, detailsController.getDetails);

module.exports = router;