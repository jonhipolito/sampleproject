'use strict';

const express = require('express');

const functionController = require('./functions.controller');

const router = express.Router();

router.get('/:function', functionController.callFunction);
router.post('/:function', functionController.callFunction);


module.exports = router;