'use strict';

const functionsService = require('./functions.service');

const callFunction = (req, res, next) => {
    functionsService.callFunction(req)
        .then(message => {
            res.send(message);
        })
        .catch(error => {
            res.status(500).send({ errors: error });
        })
}


module.exports = {
    callFunction
}
