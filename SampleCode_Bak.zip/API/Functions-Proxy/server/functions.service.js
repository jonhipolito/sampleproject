'use strict';

const { google } = require('googleapis');
const cloudfunctions = google.cloudfunctions('v1');
const callFunction = (req) => {
  return new Promise(async function (resolve, reject) {
    const authClient = await google.auth.getClient({
      scopes: [
        'https://www.googleapis.com/auth/cloud-platform',
        'https://www.googleapis.com/auth/compute',
        'https://www.googleapis.com/auth/compute.readonly',
        'https://www.googleapis.com/auth/userinfo.email'
      ],
    });
    let val = await cloudfunctions.projects.locations.functions.call({
      auth: authClient,
      name: `projects/${process.env.PROJECT_ID}/locations/us-east1/functions/${req.params.function}`,
      requestBody: {data: JSON.stringify(req.body)}
    }, {}, (err, response) => {
      console.log("response", response.data.result);
        resolve(response.data.result);
    });    
  });
}

module.exports = {
  callFunction
}