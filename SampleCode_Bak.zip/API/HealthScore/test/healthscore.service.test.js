process.env.NODE_ENV = 'test';
const healthscoreRepository = require('../server/healthscore.repository');
const healthscoreService = require('../server/healthscore.service');
const request = require('request');
const sinon = require('sinon');
const axios = require('axios');
const chai = require('chai');
const should = chai.should();
const expect = require('chai').expect;
const mockery = require('mockery');
const moment = require('moment');

describe('Testing HealthScore Service', function() {
    this.timeout(30000);

    describe('_getClientCIPInfo Test Success', () => {
        before(() => {
            sinon.stub(healthscoreRepository, 'getClientCIPInfo').returns('test get client cip info');
        })

        after(() => {
            healthscoreRepository.getClientCIPInfo.restore();
        })

        it("should successfully get client cip info", function (done) {
            healthscoreService._getClientCIPInfo(1, 1)
            .then(message => {
                message.should.eql('test get client cip info');
            })
            .finally(done())

        });

    });

    describe('_getContractCIPInfo Test Success', () => {
        before(() => {
            sinon.stub(healthscoreRepository, 'getContractCIPInfo').returns('test get contract cip info');
        })

        after(() => {
            healthscoreRepository.getContractCIPInfo.restore();
        })

        it("should successfully get contract cip info", function (done) {
            healthscoreService._getContractCIPInfo(1)
            .then(message => {
                message.should.eql('test get contract cip info');
            })
            .finally(done())

        });

    });


    describe('_getClientCMRiskInfo Test Success', () => {
        var req;
        before(() => {
            req = ({
                body: {mcId:"0123456789", fcId: "0013445766"},
                headers: { authorization: "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IkhCeGw5bUFlNmd4YXZDa2NvT1UyVEhzRE5hMCIsImtpZCI6IkhCeGw5bUFlNmd4YXZDa2NvT1UyVEhzRE5hMCJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTU2MTY5MzQ4LCJuYmYiOjE1NTYxNjkzNDgsImV4cCI6MTU1NjE3MzI0OCwiYWlvIjoiQVZRQXEvOExBQUFBcUdEa0Q5U3Jzb3B0cmFjWGpFZElkamxkMnlvTjlLbXFLZWd1N294UmlacE1JUjJxQVNYOW5SSERlSGhaQVgvZHRxODZ5NDk3K1VVQXhPblBGMi90R2NGajVYR3d5MEt0YkJzaWlKOStiNUk9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkFub3JhIiwiZ2l2ZW5fbmFtZSI6IkNpbmR5IE1hcmllIiwiaXBhZGRyIjoiMTcwLjI1Mi4xNjAuMSIsIm5hbWUiOiJBw7FvcmEsIENpbmR5IE1hcmllIEwuIiwibm9uY2UiOiJhYzBjYWEyYi0zNDI2LTRkNGEtOWU5Zi1lNWI4NTNiMDg0OWUiLCJvaWQiOiI2ZWRiYmUxNi0zYWQxLTRkNDItYjVkMy04ZmQ1OGJhYzQ2NDkiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTMxODI5ODUiLCJzdWIiOiJqcERVRFJoU0MtNzhnRHotUE1PZXF3eGYzRlVyNnlTejByMEV5U25XemhzIiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJjaW5keS5tYXJpZS5sLmFub3JhQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXBuIjoiY2luZHkubWFyaWUubC5hbm9yYUBkcy5kZXYuYWNjZW50dXJlLmNvbSIsInV0aSI6IjlTaE02LUFPeDBPV0xIZlU4ZTZCQUEiLCJ2ZXIiOiIxLjAifQ.a8IZbaAx6FMaWFtisz_D9q4I8Kj77j1DSFMxEpDpG5BSUEPh1fsyxGwoRzBdgWOGtk4Pw4S_AF1QAi5KUvw1ugoRXY6DnLhAfSDsXk0Ics1fqhX0s_7COv5Fg2-I-1arxWILKbFzoFPFb7NjpWdSxYiICq7x2-q6zkAfbhcbSvT9CAk1LTLN5rZ0JPtKSqLA_jco0CacFTzXlXEfVMSPiYdk6J-KP3_heYCZVD_Maj7ip5k0JJeFw0M-3cXJfx1XWrOCSQ1wWcGgCwJd3bXWXLNeHodZM7NDraTQQBngANqlDmQCy3kR9ytYgD02S_jEIKextVb_vdUU-ho-fCNA7Q" }
            });
            
            let arrObj = [];
            let jsonString = [`{"value" :2, "label": "Normal"}`];
            let jsonObject = JSON.parse(jsonString);
            for (var k in jsonObject) {
                if (jsonObject.hasOwnProperty(k)) {
                    arrObj.push({ name: jsonObject[k], value: k });
                }
            }
            sinon.stub(healthscoreRepository, 'getClientCMRiskList').returns(arrObj);
        })

        after(() => {
            healthscoreRepository.getClientCMRiskList.restore();
            req = "";
        })

        it("should successfully get CM client risk list", function (done) {
            healthscoreService._getClientCMRiskInfo(req);            
            done();

        });

    });

    describe('_getClientCDPInfo Test Success', () => {
        var req;
        before(() => {
            req = ({
                body: {strMasterCustomerNbr:"70017616"},
                headers: { authorization: "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IkhCeGw5bUFlNmd4YXZDa2NvT1UyVEhzRE5hMCIsImtpZCI6IkhCeGw5bUFlNmd4YXZDa2NvT1UyVEhzRE5hMCJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTU2MTY5MzQ4LCJuYmYiOjE1NTYxNjkzNDgsImV4cCI6MTU1NjE3MzI0OCwiYWlvIjoiQVZRQXEvOExBQUFBcUdEa0Q5U3Jzb3B0cmFjWGpFZElkamxkMnlvTjlLbXFLZWd1N294UmlacE1JUjJxQVNYOW5SSERlSGhaQVgvZHRxODZ5NDk3K1VVQXhPblBGMi90R2NGajVYR3d5MEt0YkJzaWlKOStiNUk9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkFub3JhIiwiZ2l2ZW5fbmFtZSI6IkNpbmR5IE1hcmllIiwiaXBhZGRyIjoiMTcwLjI1Mi4xNjAuMSIsIm5hbWUiOiJBw7FvcmEsIENpbmR5IE1hcmllIEwuIiwibm9uY2UiOiJhYzBjYWEyYi0zNDI2LTRkNGEtOWU5Zi1lNWI4NTNiMDg0OWUiLCJvaWQiOiI2ZWRiYmUxNi0zYWQxLTRkNDItYjVkMy04ZmQ1OGJhYzQ2NDkiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTMxODI5ODUiLCJzdWIiOiJqcERVRFJoU0MtNzhnRHotUE1PZXF3eGYzRlVyNnlTejByMEV5U25XemhzIiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJjaW5keS5tYXJpZS5sLmFub3JhQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXBuIjoiY2luZHkubWFyaWUubC5hbm9yYUBkcy5kZXYuYWNjZW50dXJlLmNvbSIsInV0aSI6IjlTaE02LUFPeDBPV0xIZlU4ZTZCQUEiLCJ2ZXIiOiIxLjAifQ.a8IZbaAx6FMaWFtisz_D9q4I8Kj77j1DSFMxEpDpG5BSUEPh1fsyxGwoRzBdgWOGtk4Pw4S_AF1QAi5KUvw1ugoRXY6DnLhAfSDsXk0Ics1fqhX0s_7COv5Fg2-I-1arxWILKbFzoFPFb7NjpWdSxYiICq7x2-q6zkAfbhcbSvT9CAk1LTLN5rZ0JPtKSqLA_jco0CacFTzXlXEfVMSPiYdk6J-KP3_heYCZVD_Maj7ip5k0JJeFw0M-3cXJfx1XWrOCSQ1wWcGgCwJd3bXWXLNeHodZM7NDraTQQBngANqlDmQCy3kR9ytYgD02S_jEIKextVb_vdUU-ho-fCNA7Q" }
            });            
            let arrObj = [];
            let jsonString = [`{"MasterCustomerNbr":"70017616", "ClientName": "AXIATA GROUP BERHAD","OperatingGroup":"Communications, Media & Technology",
            "GeographicUnit": "ASEAN","AccountableMD":"damian.kwok","Current_WeightedOperationalRisk":"0.00",
            "Current_WeightedOperationalRiskBubbleColor":"Green","TotalControlCount":"109",
            "BadControlCount": "0","ClientID":"00414020-ADA9-4ED4-9D30-0765C99B0784"}`];
            let jsonObject = JSON.parse(jsonString);
            for (var k in jsonObject) {
                if (jsonObject.hasOwnProperty(k)) {
                    arrObj.push({ name: jsonObject[k], value: k });
                }
            }
            sinon.stub(healthscoreService, '_getClientCDPInfo').returns(arrObj);
        })

        after(() => {
            healthscoreService._getClientCDPInfo.restore();
            req ="";
        })

        it("should successfully get CDP client info", function (done) {
            healthscoreService._getClientCDPInfo(req);
            
            done();

        });

    });

    describe('_getClientHRIInfo Test Success', () => {
        var req;
        before(() => {
            req = ({
                body: {MasterClientNbr:"0010000122",CustomerNbr:""},
                headers: { authorization: "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IkhCeGw5bUFlNmd4YXZDa2NvT1UyVEhzRE5hMCIsImtpZCI6IkhCeGw5bUFlNmd4YXZDa2NvT1UyVEhzRE5hMCJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTU2MTY5MzQ4LCJuYmYiOjE1NTYxNjkzNDgsImV4cCI6MTU1NjE3MzI0OCwiYWlvIjoiQVZRQXEvOExBQUFBcUdEa0Q5U3Jzb3B0cmFjWGpFZElkamxkMnlvTjlLbXFLZWd1N294UmlacE1JUjJxQVNYOW5SSERlSGhaQVgvZHRxODZ5NDk3K1VVQXhPblBGMi90R2NGajVYR3d5MEt0YkJzaWlKOStiNUk9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkFub3JhIiwiZ2l2ZW5fbmFtZSI6IkNpbmR5IE1hcmllIiwiaXBhZGRyIjoiMTcwLjI1Mi4xNjAuMSIsIm5hbWUiOiJBw7FvcmEsIENpbmR5IE1hcmllIEwuIiwibm9uY2UiOiJhYzBjYWEyYi0zNDI2LTRkNGEtOWU5Zi1lNWI4NTNiMDg0OWUiLCJvaWQiOiI2ZWRiYmUxNi0zYWQxLTRkNDItYjVkMy04ZmQ1OGJhYzQ2NDkiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTMxODI5ODUiLCJzdWIiOiJqcERVRFJoU0MtNzhnRHotUE1PZXF3eGYzRlVyNnlTejByMEV5U25XemhzIiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJjaW5keS5tYXJpZS5sLmFub3JhQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXBuIjoiY2luZHkubWFyaWUubC5hbm9yYUBkcy5kZXYuYWNjZW50dXJlLmNvbSIsInV0aSI6IjlTaE02LUFPeDBPV0xIZlU4ZTZCQUEiLCJ2ZXIiOiIxLjAifQ.a8IZbaAx6FMaWFtisz_D9q4I8Kj77j1DSFMxEpDpG5BSUEPh1fsyxGwoRzBdgWOGtk4Pw4S_AF1QAi5KUvw1ugoRXY6DnLhAfSDsXk0Ics1fqhX0s_7COv5Fg2-I-1arxWILKbFzoFPFb7NjpWdSxYiICq7x2-q6zkAfbhcbSvT9CAk1LTLN5rZ0JPtKSqLA_jco0CacFTzXlXEfVMSPiYdk6J-KP3_heYCZVD_Maj7ip5k0JJeFw0M-3cXJfx1XWrOCSQ1wWcGgCwJd3bXWXLNeHodZM7NDraTQQBngANqlDmQCy3kR9ytYgD02S_jEIKextVb_vdUU-ho-fCNA7Q" }
            });            
            let arrObj = [];
            let jsonString = [`{"HRIId": 5214,"HRIListLevel": "DTE Watch","OverallStatusCd": "G","MasterClientNbr": "0070000471"}`];
            let jsonObject = JSON.parse(jsonString);
            for (var k in jsonObject) {
                if (jsonObject.hasOwnProperty(k)) {
                    arrObj.push({ name: jsonObject[k], value: k });
                }
            }
            sinon.stub(healthscoreService, '_getClientHRIInfo').returns(arrObj);
        })

        after(() => {
            healthscoreService._getClientHRIInfo.restore()
            req = "";
        })

        it("should successfully get CDP client info", function (done) {
            healthscoreService._getClientHRIInfo(req);
            done();

        });

    });

    describe('_getClientQAInfo Test Success', () => {
        before(() => {
            sinon.stub(healthscoreRepository, 'getClientQAInfo').returns('test get client qa info');
        })

        after(() => {
            healthscoreRepository.getClientQAInfo.restore();
        })

        it("should successfully get client qa info", function (done) {
            healthscoreService._getClientQAInfo(1, 1)
            .then(message => {
                message.should.eql('test get client qa info');
            })
            .finally(done())

        });

    });

    describe('_getContractCMRiskInfo Test', async () => {
        const hsRepositoryStub = sinon.stub(healthscoreRepository, 'getContractCMRiskInfo');

        const req = ({
            params: { contractNbr: '1' }
        });

        afterEach((done) => {
            hsRepositoryStub.reset();
            done();
        })

        it("should return null when empty data returned from repository", (done) => {
            hsRepositoryStub.resolves([]);
            healthscoreService._getContractCMRiskInfo(req, req.params.contractNbr)
            .then(result => {
                expect(result).to.eq(null);
            }).then(done, done);
        });

        it("should return data when valid data returned from repository", (done) => {
            const expectedResult = {'highRisk':1,'normalRisk':0,'aboveNormalRisk':0,'mitigateSection':[{'section':'Client Expectations/Context','mitigations':{'completed':0,'overdue':0,'dueAndOngoing':1}},{'section':'Alignment','mitigations':{'completed':0,'overdue':1,'dueAndOngoing':0}},{'section':'Contract & Deal Structure','mitigations':{'completed':1,'overdue':0,'dueAndOngoing':0}},{'section':'Solution Plan & Cost','mitigations':{'completed':0,'overdue':0,'dueAndOngoing':0}},{'section':'Underlying Capability','mitigations':{'completed':0,'overdue':0,'dueAndOngoing':1}},{'section':'Delivery Execution','mitigations':{'completed':0,'overdue':1,'dueAndOngoing':0}},{'section':'Other','mitigations':{'completed':1,'overdue':0,'dueAndOngoing':0}}]};
            hsRepositoryStub.resolves([
                {CategoryCd: '100301', MitigationStatusCd: '101401', RiskDetailsKey: '1', RiskRatingCd: '100801'},
                //include duplicate  RiskDetailKey
                {CategoryCd: '100301', MitigationStatusCd: '101401', RiskDetailsKey: '1', RiskRatingCd: '100801'},
                {CategoryCd: '100302', MitigationStatusCd: '101402', RiskDetailsKey: '2', RiskRatingCd: '100801'},
                {CategoryCd: '100301', MitigationStatusCd: 'xxxxxx', RiskDetailsKey: '3', RiskRatingCd: 'xxxxxx'},
                {CategoryCd: '100303', MitigationStatusCd: '101403', RiskDetailsKey: '4', RiskRatingCd: '100802'},
                {CategoryCd: '100305', MitigationStatusCd: '101401', RiskDetailsKey: '5', RiskRatingCd: '100802'},
                {CategoryCd: '100304', MitigationStatusCd: '101402', RiskDetailsKey: '6', RiskRatingCd: '100803'},
                {CategoryCd: '100306', MitigationStatusCd: '101402', RiskDetailsKey: '7', RiskRatingCd: '100803'},
                {CategoryCd: 'xxxxxx', MitigationStatusCd: '101402', RiskDetailsKey: '8', RiskRatingCd: '100803'}
            ]);
            healthscoreService._getContractCMRiskInfo(req, req.params.contractNbr)
            .then(result => {
                expect(result.highRisk).to.eq(2);
                expect(result.normalRisk).to.eq(3);
                expect(result.aboveNormalRisk).to.eq(2);
                expect(result.mitigateSection.length).to.eq(7);
                expect(result.mitigateSection[0].section).to.eq('Client Expectations/Context');
                expect(result.mitigateSection[1].section).to.eq('Alignment');
                expect(result.mitigateSection[2].section).to.eq('Contract & Deal Structure');
                expect(result.mitigateSection[3].section).to.eq('Solution Plan & Cost');
                expect(result.mitigateSection[4].section).to.eq('Underlying Capability');
                expect(result.mitigateSection[5].section).to.eq('Delivery Execution');
                expect(result.mitigateSection[6].section).to.eq('Other');
            }).then(done, done);
        });

        it("should return null when empty data returned from repository", (done) => {
            hsRepositoryStub.rejects('error');
            healthscoreService._getContractCMRiskInfo(req, req.params.contractNbr)
            .catch(error => {
                expect(error.name).to.eq('error');
            }).then(done, done);
        });

    });

    describe('_getContractQARiskInfo Test', async () => {

        process.env.QA_URL = 'http://example.com/';
        const req = ({
            body: { contractNbr: '1' },
            headers: { authorization: 'Bearer 123456' }
        });

        let healthscoreService2;
        let requestStub;

        beforeEach(() => {
            mockery.enable({
                warnOnReplace: false,
                warnOnUnregistered: false,
                useCleanCache: true
            });
            // replace the module `request` with a stub object
            requestStub = sinon.stub();
            mockery.registerMock('request', requestStub);
            healthscoreService2 = require('../server/healthscore.service');
        });

        after(() => {
            
        })

        afterEach(() => {
            requestStub.reset();
            mockery.disable();
        })

        it("should return data for single plan", (done) => {
            const responseObject = {
                statusCode: 200,
                headers: {
                    'content-type': 'application/json'
                }
            };
            const responseBody = [[{'RiskScore':1.48,'RiskTierDesc':'Normal','QADirectorEnterpriseId':'frank.mang','LastFinalizedDt':'2019-04-29T16:57:58.817Z','NextScheduleDt':null,'PlanId':1352929,'PlanNm':'Plan 1'}],[{'StatDesc':'High','StatCount':0},{'StatDesc':'Above Normal','StatCount':4},{'StatDesc':'Normal','StatCount':42},{'StatDesc':'N/A','StatCount':2},{'StatDesc':'','StatCount':0},{'StatDesc':null,'StatCount':9},{'StatDesc':'Not Included','StatCount':1}],[{'NoOfMitigations':7}],[{'CMScore':'1.39'}]];
            requestStub.yields(null, responseObject, JSON.stringify(responseBody));
            healthscoreService2._getContractQARiskInfo(req, req.body.contractNbr)
            .then(result => {
                expect(result.cmScore).to.eq('1.39');
                expect(result.highRisk).to.eq(0);
                expect(result.aboveNormalRisk).to.eq(4);
                expect(result.normalRisk).to.eq(42);
                expect(result.naRisk).to.eq(2);
                expect(result.unavailableRisk).to.eq(9);
                expect(result.director).to.eq('frank.mang');
                expect(result.lastFinalizedQA).to.eq('2019-04-29T16:57:58.817Z');
                expect(result.nextScheduledQA).to.eq(null);
                expect(result.plans.length).to.eq(1);
                expect(result.plans[0].planId).to.eq(1352929);
                expect(result.plans[0].planName).to.eq('Plan 1');
                expect(result.plans[0].riskScore).to.eq(1.48);
                expect(result.plans[0].riskStatus).to.eq('Normal');
            }).then(done, done);
        });

        it("should return data for multiple plans", (done) => {
            const responseObject = {
                statusCode: 200,
                headers: {
                    'content-type': 'application/json'
                }
            };
            const responseBody = [
                [
                    {'RiskScore':1.48,'RiskTierDesc':'Normal','QADirectorEnterpriseId':'frank.mang','LastFinalizedDt':'2019-04-29T16:57:58.817Z','NextScheduleDt':null,'PlanId':1352929,'PlanNm':'Plan 1'},
                    {'RiskScore':1.48,'RiskTierDesc':'Normal','QADirectorEnterpriseId':'frank.mang','LastFinalizedDt':'2019-04-29T16:57:58.817Z','NextScheduleDt':null,'PlanId':1352930,'PlanNm':'Plan 2'}
                ],
                [
                    {'StatDesc':'High','StatCount':0},{'StatDesc':'Above Normal','StatCount':4},
                    {'StatDesc':'Normal','StatCount':42},{'StatDesc':'N/A','StatCount':2},
                    {'StatDesc':'','StatCount':0},{'StatDesc':null,'StatCount':9},
                    {'StatDesc':'Not Included','StatCount':1}
                ],
                [
                    {'NoOfMitigations':7}],[{'CMScore':'1.39'}
                ]
            ];
            requestStub.yields(null, responseObject, JSON.stringify(responseBody));
            healthscoreService2._getContractQARiskInfo(req, req.body.contractNbr)
            .then(result => {
                expect(result.plans.length).to.eq(2);
            }).then(done, done);
        });


        it("should return null if API returns a null planId", (done) => {
            const responseObject = {
                statusCode: 200,
                headers: {
                    'content-type': 'application/json'
                }
            };
            const responseBody = [[{'RiskScore':null,'RiskTierDesc':null,'QADirectorEnterpriseId':null,'LastFinalizedDt':null,'NextScheduleDt':null,'PlanId':null,'PlanNm':null}],[{'StatDesc':'High','StatCount':0}],[{'NoOfMitigations':7}],[{'CMScore':'1.39'}]];
            requestStub.yields(null, responseObject, JSON.stringify(responseBody));
            healthscoreService2._getContractQARiskInfo(req, req.body.contractNbr)
            .then(result => {
                expect(result).to.eq(null);
            }).then(done, done);
        });

        it("should return null if return is empty", (done) => {
            const responseObject = {
                statusCode: 204,
                headers: {
                    'content-type': 'application/json'
                }
            };
            const responseBody = {};
            requestStub.yields(null, responseObject, JSON.stringify(responseBody));
            healthscoreService2._getContractQARiskInfo(req, req.body.contractNbr)
            .then(result => {
                expect(result).to.eq(null);
            }).then(done, done);
        });

        it("should catch error", (done) => {
            const responseObject = {
                statusCode: 500,
                headers: {
                    'content-type': 'application/json'
                }
            };
            const responseBody = {};
            requestStub.yields('error', responseObject, JSON.stringify(responseBody));
            healthscoreService2._getContractQARiskInfo(req, req.body.contractNbr)
            .catch(error => {
                expect(error).to.eq('error');
            }).then(done, done);
        });
    });

    describe('_getContractHRI Test', async () => {

        process.env.HRI_URL = 'http://example.com/';
        const req = ({
            body: { contractNbr: '1' },
            headers: { authorization: 'Bearer 123456' }
        });

        let healthscoreService2;
        let requestStub;

        beforeEach(() => {
            mockery.enable({
                warnOnReplace: false,
                warnOnUnregistered: false,
                useCleanCache: true
            });
            // replace the module `request` with a stub object
            requestStub = sinon.stub();
            mockery.registerMock('request', requestStub);
            healthscoreService2 = require('../server/healthscore.service');
        });

        after(() => {
            
        })

        afterEach(() => {
            requestStub.reset();
            mockery.disable();
        })

        it("should return data", (done) => {
            const responseObject = {
                statusCode: 200,
                headers: {
                    'content-type': 'application/json'
                }
            };
            const responseBody = { name: 'hri' };
            requestStub.yields(null, responseObject, JSON.stringify(responseBody));
            healthscoreService2._getContractHRI(req, req.body.contractNbr)
            .then(result => {
                expect(result.name).to.eq('hri');
            }).then(done, done);
        });

        it("should return null", (done) => {
            const responseObject = {
                statusCode: 204,
                headers: {
                    'content-type': 'application/json'
                }
            };
            const responseBody = { name: 'hri' };
            requestStub.yields(null, responseObject, JSON.stringify(responseBody));
            healthscoreService2._getContractHRI(req, req.body.contractNbr)
            .then(result => {
                expect(result).to.eq(null);
            }).then(done, done);
        });

        it("should catch error", (done) => {
            const responseObject = {
                statusCode: 500,
                headers: {
                    'content-type': 'application/json'
                }
            };
            const responseBody = {};
            requestStub.yields('error', responseObject, JSON.stringify(responseBody));

            healthscoreService2._getContractHRI(req, req.body.contractNbr)
            .catch(error => {
                expect(error).to.eq('error');
            }).then(done, done);
        });
    });

    describe('_getContractPolicy Test', async () => {

        process.env.POLICY_URL = 'http://example.com/';
        const req = ({
            body: { contractNbr: '1' },
            headers: { authorization: 'Bearer 123456' }
        });

        let healthscoreService2;
        let requestStub;

        beforeEach(() => {
            mockery.enable({
                warnOnReplace: false,
                warnOnUnregistered: false,
                useCleanCache: true
            });
            // replace the module `request` with a stub object
            requestStub = sinon.stub();
            mockery.registerMock('request', requestStub);
            healthscoreService2 = require('../server/healthscore.service');
        });

        after(() => {
            
        })

        afterEach(() => {
            requestStub.reset();
            mockery.disable();
        })

        it("should return data", (done) => {
            const responseObject = {
                statusCode: 200,
                headers: {
                    'content-type': 'application/json'
                }
            };
            const responseBody = { name: 'ContractPolicy' };
            requestStub.yields(null, responseObject, JSON.stringify(responseBody));
            healthscoreService2._getContractPolicy(req, req.body.contractNbr)
            .then(result => {
                expect(result.length).to.eq(1);
                expect(result[0].name).to.eq('ContractPolicy');
            }).then(done, done);
        });

        it("should return null", (done) => {
            const responseObject = {
                statusCode: 200,
                headers: {
                    'content-type': 'application/json'
                }
            };
            const responseBody = { name: 'ContractPolicy' };
            requestStub.yields('error', responseObject, JSON.stringify(responseBody));
            healthscoreService2._getContractPolicy(req, req.body.contractNbr)
            .then(result => {
                expect(result).to.eq(null);
            }).then(done, done);
        });

        it("should catch error", (done) => {
            const responseObject = {
                statusCode: 500,
                headers: {
                    'content-type': 'application/json'
                }
            };
            const responseBody = {};
            requestStub.throws('error');

            healthscoreService2._getContractPolicy(req, req.body.contractNbr)
            .catch(error => {
                expect(error.name).to.eq('error');
            }).then(done, done);
        });
    });
    
    describe('_getContractMitigations Test', async () => {
        process.env.QA_URL = 'http://example.com/';
        const req = ({
            body: { contractNbr: '1' },
            headers: { authorization: 'Bearer 123456' }
        });

        let healthscoreService2;
        let healthscoreRepository2;
        let requestStub;

        beforeEach(() => {
            mockery.enable({
                warnOnReplace: false,
                warnOnUnregistered: false,
                useCleanCache: true
            });

            requestStub = sinon.stub();
            healthscoreRepository2 = sinon.stub();
            healthscoreRepository2 = {
                getContractMitigations: sinon.stub()
            };
            mockery.registerMock('request', requestStub);
            mockery.registerMock('./healthscore.repository', healthscoreRepository2);
            healthscoreService2 = require('../server/healthscore.service');
        });

        after(() => {
            
        })

        afterEach(() => {
            healthscoreRepository2.getContractMitigations.reset();
            requestStub.reset();
            mockery.deregisterMock('request');
            mockery.deregisterMock('../server/healthscore.repository');
            mockery.disable();
        })

        it("should return data when QA and CM-CIP return value", (done) => {
            const responseObject = {
                statusCode: 200,
                headers: {
                    'content-type': 'application/json'
                }
            };
            const responseBody = [[{'RiskScore':1.48,'RiskTierDesc':'Normal','QADirectorEnterpriseId':'frank.mang','LastFinalizedDt':'2019-04-29T16:57:58.817Z','NextScheduleDt':null,'PlanId':1352929,'PlanNm':'Plan 1'}],[{'StatDesc':'High','StatCount':0},{'StatDesc':'Above Normal','StatCount':4},{'StatDesc':'Normal','StatCount':42},{'StatDesc':'N/A','StatCount':2},{'StatDesc':'','StatCount':0},{'StatDesc':null,'StatCount':9}, {'StatDesc':'Not Included','StatCount':1}],[{'NoOfMitigations':7}],[{'CMScore':'1.39'}]];
            requestStub.yields(null, responseObject, JSON.stringify(responseBody));
            healthscoreRepository2.getContractMitigations.resolves([
                {RiskSource: 'CM', Status: "OVERDUE", StatusCode: "101402", Count: 1},
                {RiskSource: 'CM', Status: "IN PROGRESS", StatusCode: "101401", Count: 2},
                {RiskSource: 'CM', Status: "COMPLETE", StatusCode: "101403", Count: 3},
                {RiskSource: 'NOT_DEFINED', Status: "COMPLETE", StatusCode: "101403", Count: 1},
                {RiskSource: 'CM', Status: "NOT_DEFINED", StatusCode: "101xx11", Count: 1},
                {RiskSource: 'CIP', Status: "OVERDUE", StatusCode: "101402", Count: 2},
                {RiskSource: 'CIP', Status: "IN PROGRESS", StatusCode: "101401", Count: 3},
                {RiskSource: 'CIP', Status: "COMPLETE", StatusCode: "101403", Count: 1}
            ]);
            healthscoreService2._getContractMitigations(req, req.body.contractNbr)
            .then(result => {
                expect(result.length).to.eq(3);
                expect(result[0].section).to.eq('CM');
                expect(result[0].mitigations.Overdue).to.eq(1);
                expect(result[0].mitigations.Ongoing).to.eq(2);
                expect(result[0].mitigations.Complete).to.eq(3);
                expect(result[1].section).to.eq('CIP');
                expect(result[1].mitigations.Overdue).to.eq(2);
                expect(result[1].mitigations.Ongoing).to.eq(3);
                expect(result[1].mitigations.Complete).to.eq(1);
                expect(result[2].section).to.eq('QA');
                expect(result[2].mitigations.Overdue).to.eq(0);
                expect(result[2].mitigations.Ongoing).to.eq(7);
                expect(result[2].mitigations.Complete).to.eq(0);
            }).then(done, done);

        });

        it("should return null when QA and CM-CIP return value but zero count", (done) => {
            const responseObject = {
                statusCode: 200,
                headers: {
                    'content-type': 'application/json'
                }
            };
            const responseBody = [[{'RiskScore':1.48,'RiskTierDesc':'Normal','QADirectorEnterpriseId':'frank.mang','LastFinalizedDt':'2019-04-29T16:57:58.817Z','NextScheduleDt':null,'PlanId':1352929,'PlanNm':'Plan 1'}],[{'StatDesc':'High','StatCount':0},{'StatDesc':'Above Normal','StatCount':4},{'StatDesc':'Normal','StatCount':42},{'StatDesc':'N/A','StatCount':2},{'StatDesc':'','StatCount':0},{'StatDesc':null,'StatCount':9},{'StatDesc':'Not Included','StatCount':1}],[{'NoOfMitigations':0}],[{'CMScore':'1.39'}]];
            requestStub.yields(null, responseObject, JSON.stringify(responseBody));
            healthscoreRepository2.getContractMitigations.resolves([]);
            healthscoreService2._getContractMitigations(req, req.body.contractNbr)
            .then(result => {
                expect(null).to.eq(null);
            }).then(done, done);

        });

        it("should return data when QA has value and CM-CIP has none", (done) => {
            const responseObject = {
                statusCode: 200,
                headers: {
                    'content-type': 'application/json'
                }
            };
            const responseBody = [[{'RiskScore':1.48,'RiskTierDesc':'Normal','QADirectorEnterpriseId':'frank.mang','LastFinalizedDt':'2019-04-29T16:57:58.817Z','NextScheduleDt':null,'PlanId':1352929,'PlanNm':'Plan 1'}],[{'StatDesc':'High','StatCount':0},{'StatDesc':'Above Normal','StatCount':4},{'StatDesc':'Normal','StatCount':42},{'StatDesc':'N/A','StatCount':2},{'StatDesc':'','StatCount':0},{'StatDesc':null,'StatCount':9},{'StatDesc':'Not Included','StatCount':1}],[{'NoOfMitigations':7}],[{'CMScore':'1.39'}]];
            requestStub.yields(null, responseObject, JSON.stringify(responseBody));
            healthscoreRepository2.getContractMitigations.resolves([]);
            healthscoreService2._getContractMitigations(req, req.body.contractNbr)
            .then(result => {
                expect(result.length).to.eq(3);

                expect(result[0].mitigations.Overdue).to.eq(0);
                expect(result[0].mitigations.Ongoing).to.eq(0);
                expect(result[0].mitigations.Complete).to.eq(0);

                expect(result[1].mitigations.Overdue).to.eq(0);
                expect(result[1].mitigations.Ongoing).to.eq(0);
                expect(result[1].mitigations.Complete).to.eq(0);
                
                expect(result[2].mitigations.Overdue).to.eq(0);
                expect(result[2].mitigations.Ongoing).to.eq(7);
                expect(result[2].mitigations.Complete).to.eq(0);
            }).then(done, done);

        });

        it("should return null when QA has error", (done) => {
            const responseObject = {
                statusCode: 500,
                headers: {
                    'content-type': 'application/json'
                }
            };
            requestStub.yields('error', responseObject, JSON.stringify({}));
            healthscoreRepository2.getContractMitigations.resolves([]);
            healthscoreService2._getContractMitigations(req, req.body.contractNbr)
            .then(result => {
                expect(result).to.eq(null);
            }).then(done, done);
        });

        it("should return null when QA returns empty response", (done) => {
            const responseObject = {
                statusCode: 204,
                headers: {
                    'content-type': 'application/json'
                }
            };
            requestStub.yields(null, responseObject, JSON.stringify({}));
            healthscoreRepository2.getContractMitigations.resolves([]);
            healthscoreService2._getContractMitigations(req, req.body.contractNbr)
            .then(result => {
                expect(result).to.eq(null);
            }).then(done, done);
        });

        it("should return null when CM-CIP has error", (done) => {
            const responseObject = {
                statusCode: 200,
                headers: {
                    'content-type': 'application/json'
                }
            };
            const responseBody = [[{'RiskScore':1.48,'RiskTierDesc':'Normal','QADirectorEnterpriseId':'frank.mang','LastFinalizedDt':'2019-04-29T16:57:58.817Z','NextScheduleDt':null,'PlanId':1352929,'PlanNm':'Plan 1'}],[{'StatDesc':'High','StatCount':0},{'StatDesc':'Above Normal','StatCount':4},{'StatDesc':'Normal','StatCount':42},{'StatDesc':'N/A','StatCount':2},{'StatDesc':'','StatCount':0},{'StatDesc':null,'StatCount':9},{'StatDesc':'Not Included','StatCount':1}],[{'NoOfMitigations':7}],[{'CMScore':'1.39'}]];
            requestStub.yields(null, responseObject, JSON.stringify(responseBody));
            healthscoreRepository2.getContractMitigations.rejects('error');
            healthscoreService2._getContractMitigations(req, req.body.contractNbr)
            .then(result => {
                expect(result).to.eq(null);
            }).then(done, done);
        });


        it("should catch error", (done) => {
            const responseObject = {
                statusCode: 500,
                headers: {
                    'content-type': 'application/json'
                }
            };
            requestStub.rejects('error');
            healthscoreRepository2.getContractMitigations.rejects('error');
            healthscoreService2._getContractMitigations(req, req.body.contractNbr)
            .then(result => {
                expect(result).to.eq(null);
            }).then(done, done);
        });
    });

    describe('_getContractingStatus Test', async () => {
        const hsRepositoryStub = sinon.stub(healthscoreRepository, 'getContractingStatus');
        let dateFormat = 'YYYY-MM-DDT00:00:00.000000000Z';
        afterEach((done) => {
            hsRepositoryStub.reset();
            done();
        })

        it("should return data with count when contract number has value", (done) => {
            const last30dt = moment(new Date()).add('months', -1).startOf('month').add('days', 15).format(dateFormat);
            const next30dt = moment(new Date()).startOf('month').add('days', 15).format(dateFormat);
            const res = [
                {CustomerNbr: '1', Status: 'Awaiting Signature', ExpectedSgnDt: last30dt, DiffMonth: -1},
                {CustomerNbr: '1', Status: 'Not Started', ExpectedSgnDt: last30dt, DiffMonth: -1},
                {CustomerNbr: '1', Status: 'In Legal Review', ExpectedSgnDt: last30dt, DiffMonth: -1},
                {CustomerNbr: '1', Status: 'With Client for Review', ExpectedSgnDt: last30dt, DiffMonth: -1},
                {CustomerNbr: '1', Status: 'Signed', ExpectedSgnDt: last30dt, DiffMonth: -1},
                {CustomerNbr: '1', Status: 'With Delivery Team', ExpectedSgnDt: last30dt, DiffMonth: -1},
                {CustomerNbr: '1', Status: 'Awaiting Signature', ExpectedSgnDt: next30dt, DiffMonth: 0},
                {CustomerNbr: '1', Status: 'Not Started', ExpectedSgnDt: next30dt, DiffMonth: 0},
                {CustomerNbr: '1', Status: 'In Legal Review', ExpectedSgnDt: next30dt, DiffMonth: 0},
                {CustomerNbr: '1', Status: 'With Client for Review', ExpectedSgnDt: next30dt, DiffMonth: 0},
                {CustomerNbr: '1', Status: 'Signed', ExpectedSgnDt: next30dt, DiffMonth: 0},
                {CustomerNbr: '1', Status: 'With Delivery Team', ExpectedSgnDt: next30dt, DiffMonth: 0},
                {CustomerNbr: '1', Status: 'xxx-undefined-xxx', ExpectedSgnDt: next30dt, DiffMonth: 0},
            ]
            
            hsRepositoryStub.resolves(res);
            healthscoreService._getContractingStatus({ ContractNbr: '1', CustomerNbr: '1', MasterClientNbr: '1' })
            .then(result => {
                expect(result.PastDue.NotStarted).to.eq(1);
                expect(result.PastDue.WithDeliveryTeam).to.eq(1);
                expect(result.PastDue.InLegalReview).to.eq(1);
                expect(result.PastDue.ClientForReview).to.eq(1);
                expect(result.PastDue.AwaitingSignature).to.eq(1);
                expect(result.PastDue.Signed).to.eq(1);
                expect(result.DueThisMonth.NotStarted).to.eq(2);
                expect(result.DueThisMonth.WithDeliveryTeam).to.eq(2);
                expect(result.DueThisMonth.InLegalReview).to.eq(2);
                expect(result.DueThisMonth.ClientForReview).to.eq(2);
                expect(result.DueThisMonth.AwaitingSignature).to.eq(2);
                expect(result.DueThisMonth.Signed).to.eq(2);
            }).then(done, done);
        });

        it("should return data with count when contract has no value and only MC and FC have", (done) => {
            const next60dt = moment(new Date()).add('months', 1).startOf('month').add('days', 15).format(dateFormat);
            const res = [
                {CustomerNbr: '1', Status: 'Awaiting Signature', ExpectedSgnDt: next60dt, DiffMonth: 1},
                {CustomerNbr: '1', Status: 'Not Started', ExpectedSgnDt: next60dt, DiffMonth: 1},
                {CustomerNbr: '1', Status: 'In Legal Review', ExpectedSgnDt: next60dt, DiffMonth: 1},
                {CustomerNbr: '1', Status: 'Signed', ExpectedSgnDt: next60dt, DiffMonth: 1},
                {CustomerNbr: '1', Status: 'With Delivery Team', ExpectedSgnDt: next60dt, DiffMonth: 1}
            ]
            
            hsRepositoryStub.resolves(res);
            healthscoreService._getContractingStatus({ ContractNbr: null, CustomerNbr: '1', MasterClientNbr: '1' })
            .then(result => {
                expect(result.DueNextMonth.NotStarted).to.eq(1);
                expect(result.DueNextMonth.WithDeliveryTeam).to.eq(1);
                expect(result.DueNextMonth.InLegalReview).to.eq(1);
                expect(result.DueNextMonth.AwaitingSignature).to.eq(1);
                expect(result.DueNextMonth.Signed).to.eq(1);
            }).then(done, done);
        });

        it("should return data with count when only MC has value", (done) => {

            const next90dt = moment(new Date()).add('months', 2).startOf('month').add('days', 15).format(dateFormat);
            const res = [
                {CustomerNbr: '1', Status: 'Awaiting Signature', ExpectedSgnDt: next90dt, DiffMonth: 2},
                {CustomerNbr: '1', Status: 'Not Started', ExpectedSgnDt: next90dt, DiffMonth: 2},
                {CustomerNbr: '1', Status: 'In Legal Review', ExpectedSgnDt: next90dt, DiffMonth: 2},
                {CustomerNbr: '1', Status: 'Signed', ExpectedSgnDt: next90dt, DiffMonth: 2},
                {CustomerNbr: '1', Status: 'With Delivery Team', ExpectedSgnDt: next90dt, DiffMonth: 2},
            ]
            
            hsRepositoryStub.resolves(res);
            healthscoreService._getContractingStatus({ ContractNbr: null, CustomerNbr: null, MasterClientNbr: '1' })
            .then(result => {
                expect(result.DueTwoMonthsOut.NotStarted).to.eq(1);
                expect(result.DueTwoMonthsOut.WithDeliveryTeam).to.eq(1);
                expect(result.DueTwoMonthsOut.InLegalReview).to.eq(1);
                expect(result.DueTwoMonthsOut.AwaitingSignature).to.eq(1);
                expect(result.DueTwoMonthsOut.Signed).to.eq(1);
            }).then(done, done);
        });

        it("should return zero count on all when empty data returned from repository", (done) => {

            hsRepositoryStub.resolves([]);
            healthscoreService._getContractingStatus({ ContractNbr: '1', CustomerNbr: '1', MasterClientNbr: '1' })
            .then(result => {
                expect(result.PastDue.NotStarted).to.eq(0);
                expect(result.PastDue.WithDeliveryTeam).to.eq(0);
                expect(result.PastDue.InLegalReview).to.eq(0);
                expect(result.PastDue.ClientForReview).to.eq(0);
                expect(result.PastDue.AwaitingSignature).to.eq(0);
                expect(result.PastDue.Signed).to.eq(0);

                expect(result.DueThisMonth.NotStarted).to.eq(0);
                expect(result.DueThisMonth.WithDeliveryTeam).to.eq(0);
                expect(result.DueThisMonth.InLegalReview).to.eq(0);
                expect(result.DueThisMonth.ClientForReview).to.eq(0);
                expect(result.DueThisMonth.AwaitingSignature).to.eq(0);
                expect(result.DueThisMonth.Signed).to.eq(0);

                expect(result.DueNextMonth.NotStarted).to.eq(0);
                expect(result.DueNextMonth.WithDeliveryTeam).to.eq(0);
                expect(result.DueNextMonth.InLegalReview).to.eq(0);
                expect(result.DueNextMonth.ClientForReview).to.eq(0);
                expect(result.DueNextMonth.AwaitingSignature).to.eq(0);
                expect(result.DueNextMonth.Signed).to.eq(0);

                expect(result.DueTwoMonthsOut.NotStarted).to.eq(0);
                expect(result.DueTwoMonthsOut.WithDeliveryTeam).to.eq(0);
                expect(result.DueTwoMonthsOut.InLegalReview).to.eq(0);
                expect(result.DueTwoMonthsOut.ClientForReview).to.eq(0);
                expect(result.DueTwoMonthsOut.AwaitingSignature).to.eq(0);
                expect(result.DueTwoMonthsOut.Signed).to.eq(0);

            }).then(done, done);
        });

        it("should return null when an error in repository", (done) => {
            hsRepositoryStub.rejects('error');
            healthscoreService._getContractingStatus({ ContractNbr: '1', CustomerNbr: '1', MasterClientNbr: '1' })
            .catch(error => {
                expect(error.name).to.eq('error');
            }).then(done, done);
        });

        it("should return zero count on all when null returned from repository", (done) => {
            hsRepositoryStub.resolves(null);
            healthscoreService._getContractingStatus({ ContractNbr: '1', CustomerNbr: '1', MasterClientNbr: '1' })
            .then(result => {
                expect(result.PastDue.NotStarted).to.eq(0);
                expect(result.PastDue.WithDeliveryTeam).to.eq(0);
                expect(result.PastDue.InLegalReview).to.eq(0);
                expect(result.PastDue.AwaitingSignature).to.eq(0);
                expect(result.PastDue.Signed).to.eq(0);

                expect(result.DueThisMonth.NotStarted).to.eq(0);
                expect(result.DueThisMonth.WithDeliveryTeam).to.eq(0);
                expect(result.DueThisMonth.InLegalReview).to.eq(0);
                expect(result.DueThisMonth.AwaitingSignature).to.eq(0);
                expect(result.DueThisMonth.Signed).to.eq(0);

                expect(result.DueNextMonth.NotStarted).to.eq(0);
                expect(result.DueNextMonth.WithDeliveryTeam).to.eq(0);
                expect(result.DueNextMonth.InLegalReview).to.eq(0);
                expect(result.DueNextMonth.AwaitingSignature).to.eq(0);
                expect(result.DueNextMonth.Signed).to.eq(0);

                expect(result.DueTwoMonthsOut.NotStarted).to.eq(0);
                expect(result.DueTwoMonthsOut.WithDeliveryTeam).to.eq(0);
                expect(result.DueTwoMonthsOut.InLegalReview).to.eq(0);
                expect(result.DueTwoMonthsOut.AwaitingSignature).to.eq(0);
                expect(result.DueTwoMonthsOut.Signed).to.eq(0);

            }).then(done, done);
        });

    });
    
});
