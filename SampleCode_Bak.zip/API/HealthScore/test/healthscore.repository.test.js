const uuid = require('uuidv4');
const healthscoreRepository = require('../server/healthscore.repository');
const sinon = require('sinon');
const chai = require('chai');
const should = chai.should();
const expect = require('chai').expect;
const assert = chai.assert;  
const mockery = require('mockery');

describe('Testing HealthScore Repository', async function() {
    this.timeout(30000);

    describe('getClientCIPInfo Test', () => {
        beforeEach((done) => {
            mockery.enable({
                warnOnReplace: false,
                warnOnUnregistered: false,
                useCleanCache: true
            });
            done();
        });

        afterEach((done) => {
            mockery.disable();
            done();
        })

        it('should return data views as json', (done) => {
            const dbResult = [{'value': 1, 'label': 'CIP'}];
            class SpannerDB {
                constructor(args) {}
                async close() {}
                async run(query) {
                    return new Promise((resolve, reject) => {
                        resolve([dbResult]);
                    });
                }
            };
            mockery.registerMock('../configs/db.connection', SpannerDB);
            
            let healthscoreRepository = require('../server/healthscore.repository');

            healthscoreRepository.getClientCIPInfo('1', '0')
            .then(result => {
                assert.equal(result, dbResult); 
            });

            healthscoreRepository.getClientCIPInfo('1', '1')
            .then(result => {
                assert.equal(result, dbResult); 
            }).then(done, done);

            healthscoreRepository.getClientCIPInfo(0, 0)
            .then(result => {
                assert.equal(result, null); 
            });

            mockery.deregisterMock('../configs/db.connection');
        });

        it('should catch error', (done) => {
            class SpannerDB {
                constructor(args) {}
                async close() {}
                async run(query) {
                    return new Promise((resolve, reject) => {
                        reject('error')
                    });
                }
            };
            mockery.registerMock('../configs/db.connection', SpannerDB);

            let  healthscoreRepository = require('../server/healthscore.repository');

            healthscoreRepository.getClientCIPInfo('1', '0')
            .catch(error => {
                assert.to.notEqual(error, null);   
            }).then(done, done);

            mockery.deregisterMock('../configs/db.connection');
        });
    });

    describe('getClientCMRiskList Test', () => {
        beforeEach((done) => {
            mockery.enable({
                warnOnReplace: false,
                warnOnUnregistered: false,
                useCleanCache: true
            });
            done();
        });

        afterEach((done) => {
            mockery.disable();
            done();
        })

        it('should return data views as json', (done) => {
            const dbResult = [{'value': 1, 'label': 'CIP'}];
            class SpannerDB {
                constructor(args) {}
                async close() {}
                async run(query) {
                    return new Promise((resolve, reject) => {
                        resolve([dbResult]);
                    });
                }
            };
            mockery.registerMock('../configs/db.connection', SpannerDB);
            
            let healthscoreRepository = require('../server/healthscore.repository');

            healthscoreRepository.getClientCMRiskList('1', '0')
            .then(result => {
                assert.equal(result, dbResult); 
            });

            healthscoreRepository.getClientCMRiskList('1', '1')
            .then(result => {
                assert.equal(result, dbResult); 
            }).then(done, done);

            healthscoreRepository.getClientCMRiskList(0, 0)
            .then(result => {
                assert.equal(result, null); 
            });

            mockery.deregisterMock('../configs/db.connection');
        });

        it('should catch error', (done) => {
            class SpannerDB {
                constructor(args) {}
                async close() {}
                async run(query) {
                    return new Promise((resolve, reject) => {
                        reject('error')
                    });
                }
            };
            mockery.registerMock('../configs/db.connection', SpannerDB);

            let  healthscoreRepository = require('../server/healthscore.repository');

            healthscoreRepository.getClientCMRiskList('1', '0')
            .catch(error => {
                assert.to.notEqual(error, null);   
            }).then(done, done);

            mockery.deregisterMock('../configs/db.connection');
        });
    });

    describe('getContractCIPInfo Test', () => {
        beforeEach((done) => {
            mockery.enable({
                warnOnReplace: false,
                warnOnUnregistered: false,
                useCleanCache: true
            });
            done();
        });

        afterEach((done) => {
            mockery.disable();
            done();
        })

        it('should return data views as json', (done) => {
            const dbResult = [{'value': 1, 'label': 'CIP'}];
            class SpannerDB {
                constructor(args) {}
                async close() {}
                async run(query) {
                    return new Promise((resolve, reject) => {
                        resolve([dbResult]);
                    });
                }
            };
            mockery.registerMock('../configs/db.connection', SpannerDB);
            
            let healthscoreRepository = require('../server/healthscore.repository');

            healthscoreRepository.getContractCIPInfo('1')
            .then(result => {
                assert.equal(result, dbResult); 
            }).then(done, done);

            mockery.deregisterMock('../configs/db.connection');
        });

        it('should catch error', (done) => {
            class SpannerDB {
                constructor(args) {}
                async close() {}
                async run(query) {
                    return new Promise((resolve, reject) => {
                        reject('error')
                    });
                }
            };
            mockery.registerMock('../configs/db.connection', SpannerDB);

            let  healthscoreRepository = require('../server/healthscore.repository');

            healthscoreRepository.getContractCIPInfo('1')
            .catch(error => {
                assert.to.notEqual(error, null);   
            }).then(done, done);

            mockery.deregisterMock('../configs/db.connection');
        });
    });

	describe('getContractMitigations Test', () => {
        beforeEach((done) => {
            mockery.enable({
                warnOnReplace: false,
                warnOnUnregistered: false,
                useCleanCache: true
            });
            done();
        });

        after((done) => {
            done();
        })

        afterEach((done) => {
            mockery.disable();
            done();
        })

        it('should return data views as json', (done) => {
            const dbResult = [{'RiskScore':1.48,'RiskTierDesc':'Normal'}];
            class SpannerDB {
                constructor(args) {}
                async close() {}
                async run(query) {
                    return new Promise((resolve, reject) => {
                        resolve([dbResult]);
                    });
                }
            };
        	mockery.registerMock('../configs/db.connection', SpannerDB);

            let healthscoreRepository = require('../server/healthscore.repository');
            healthscoreRepository.getContractMitigations('1')
            .then(result => {
                assert.equal(result, dbResult);	
            }).then(done, done);

            mockery.deregisterMock('../configs/db.connection');
        });

        it('should catch error', (done) => {
            class SpannerDB {
                constructor(args) {}
                async close() {}
                async run(query) {
                    return new Promise((resolve, reject) => {
                        reject('error')
                    });
                }
            };
            mockery.registerMock('../configs/db.connection', SpannerDB);

            let  healthscoreRepository = require('../server/healthscore.repository');
            healthscoreRepository.getContractMitigations('1')
            .catch(error => {
                assert.to.notEqual(error, null);   
            }).then(done, done);

            mockery.deregisterMock('../configs/db.connection');
        });

    });

    describe('getContractCMRiskInfo Test', () => {
        beforeEach((done) => {
            mockery.enable({
                warnOnReplace: false,
                warnOnUnregistered: false,
                useCleanCache: true
            });
            done();
        });

        after((done) => {
            done();
        })

        afterEach((done) => {
            mockery.disable();
            done();
        })

        it('should return data views as json', (done) => {
            const dbResult = [{'highRisk':1,'normalRisk':0,'aboveNormalRisk':0}];
            class SpannerDB {
                constructor(args) {}
                async close() {}
                async run(query) {
                    return new Promise((resolve, reject) => {
                        resolve([dbResult]);
                    });
                }
            };
            mockery.registerMock('../configs/db.connection', SpannerDB);

            let healthscoreRepository = require('../server/healthscore.repository');
            healthscoreRepository.getContractCMRiskInfo('1')
            .then(result => {
                assert.equal(result, dbResult); 
            }).then(done, done);

            mockery.deregisterMock('../configs/db.connection');
        });

        it('should catch error', (done) => {
            class SpannerDB {
                constructor(args) {}
                async close() {}
                async run(query) {
                    return new Promise((resolve, reject) => {
                        reject('error')
                    });
                }
            };
            mockery.registerMock('../configs/db.connection', SpannerDB);

            let  healthscoreRepository = require('../server/healthscore.repository');
            healthscoreRepository.getContractCMRiskInfo('1')
            .catch(error => {
                assert.to.notEqual(error, null);   
            }).then(done, done);

            mockery.deregisterMock('../configs/db.connection');
        });

    });

    describe('getDNO Test', () => {
        beforeEach((done) => {
            mockery.enable({
                warnOnReplace: false,
                warnOnUnregistered: false,
                useCleanCache: true
            });
            done();
        });

        after((done) => {
            done();
        })

        afterEach((done) => {
            mockery.disable();
            done();
        })

        it('should return data views as json', (done) => {
            const dbResult = [{'highRisk':1,'normalRisk':0,'aboveNormalRisk':0}];
            class SpannerDB {
                constructor(args) {}
                async close() {}
                async run(query) {
                    return new Promise((resolve, reject) => {
                        resolve([dbResult]);
                    });
                }
            };
            mockery.registerMock('../configs/db.connection', SpannerDB);

            let healthscoreRepository = require('../server/healthscore.repository');
            healthscoreRepository.getDNO('ContractNbr = "1"')
            .then(result => {
                assert.equal(result, dbResult); 
            }).then(done, done);

            mockery.deregisterMock('../configs/db.connection');
        });

        it('should catch error', (done) => {
            class SpannerDB {
                constructor(args) {}
                async close() {}
                async run(query) {
                    return new Promise((resolve, reject) => {
                        reject('error')
                    });
                }
            };
            mockery.registerMock('../configs/db.connection', SpannerDB);

            let  healthscoreRepository = require('../server/healthscore.repository');
            healthscoreRepository.getDNO('ContractNbr = "1"')
            .catch(error => {
                assert.to.notEqual(error, null);   
            }).then(done, done);

            mockery.deregisterMock('../configs/db.connection');
        });

    });

    describe('getContractingStatus Test', () => {
        beforeEach((done) => {
            mockery.enable({
                warnOnReplace: false,
                warnOnUnregistered: false,
                useCleanCache: true
            });
            done();
        });

        after((done) => {
            done();
        })

        afterEach((done) => {
            mockery.disable();
            done();
        })

        it('should return data views as json', (done) => {
            const dbResult = [{'highRisk':1,'normalRisk':0,'aboveNormalRisk':0}];
            class SpannerDB {
                constructor(args) {}
                async close() {}
                async run(query) {
                    return new Promise((resolve, reject) => {
                        resolve([dbResult]);
                    });
                }
            };
            mockery.registerMock('../configs/db.connection', SpannerDB);

            let healthscoreRepository = require('../server/healthscore.repository');
            healthscoreRepository.getContractingStatus('ContractNbr = "1"')
            .then(result => {
                assert.equal(result, dbResult); 
            }).then(done, done);

            mockery.deregisterMock('../configs/db.connection');
        });

        it('should catch error', (done) => {
            class SpannerDB {
                constructor(args) {}
                async close() {}
                async run(query) {
                    return new Promise((resolve, reject) => {
                        reject('error')
                    });
                }
            };
            mockery.registerMock('../configs/db.connection', SpannerDB);

            let  healthscoreRepository = require('../server/healthscore.repository');
            healthscoreRepository.getContractingStatus('ContractNbr = "1"')
            .catch(error => {
                assert.to.notEqual(error, null);   
            }).then(done, done);

            mockery.deregisterMock('../configs/db.connection');
        });

    });

});
