process.env.NODE_ENV = 'test';
const healthscoreController = require('../server/healthscore.controller');
const healthscoreService = require('../server/healthscore.service');
const sinon = require('sinon');
const chai = require('chai');

var sinonChai = require('sinon-chai');
chai.use(sinonChai);

const should = chai.should();
const expect = require('chai').expect;
const nextSpy = sinon.spy();
const sendSpy = sinon.spy();
const serviceMock = sinon.stub();

describe('Testing HealthScore Controller', () => {

    describe('getContractQARiskInfo Test', () => {
        const hsServiceMethodStub = sinon.stub(healthscoreService, '_getContractQARiskInfo');
        beforeEach(function(done) {
            //hsServiceMethodStub.returns(returnMock);
            done();
        });

        afterEach(function(done) {
          sendSpy.resetHistory();
          nextSpy.resetHistory();
          hsServiceMethodStub.reset();
          done();
        });

        after(() => {
            hsServiceMethodStub.restore();
        })
        
        it('should call service and return data', async () => {
            hsServiceMethodStub.resolves([])
            const req = ({params: {contractNbr : '1'}});
            const res = { send: sendSpy };
            await healthscoreController.getContractQARiskInfo(req, res, nextSpy);
            expect(sendSpy).to.have.been.calledWith({ data: [] });
        });
        

        it('should handle error returned by service', async () => {
            hsServiceMethodStub.rejects('error');
            //hsServiceMethodStub.throws();
            const req = ({params: {contractNbr : '1'}});
            const res = {};
            await healthscoreController.getContractQARiskInfo(req, res, nextSpy);
            return hsServiceMethodStub().catch((error) => {
                expect(error.name).eql('error');
            });
        });

    });

    
    describe('getContractCMRiskInfo Test', () => {
        const hsServiceMethodStub = sinon.stub(healthscoreService, '_getContractCMRiskInfo');
        
        beforeEach(function(done) {
            done();
        });

        afterEach(function(done) {
          sendSpy.resetHistory();
          nextSpy.resetHistory();
          hsServiceMethodStub.reset();
          done();
        });

        after(() => {
            hsServiceMethodStub.restore();
        })
        
        it('should call service and return data', async () => {
            hsServiceMethodStub.resolves([])
            const req = ({params: {contractNbr : '1'}});
            const res = { send: sendSpy };
            await healthscoreController.getContractCMRiskInfo(req, res, nextSpy);
            expect(sendSpy).to.have.been.calledWith({ data: [] });
        });

        it('should handle error returned by service', async () => {
            hsServiceMethodStub.rejects('error');
            const req = ({params: {contractNbr : '1'}});
            const res = {};
            await healthscoreController.getContractCMRiskInfo(req, res, nextSpy);
            return hsServiceMethodStub().catch((error) => {
                expect(error.name).eql('error');
            });
        });
    });
    
    describe('getContractMitigations Test', () => {
        const hsServiceMethodStub = sinon.stub(healthscoreService, '_getContractMitigations');
        
        beforeEach(function(done) {
            done();
        });

        afterEach(function(done) {
          sendSpy.resetHistory();
          nextSpy.resetHistory();
          hsServiceMethodStub.reset();
          done();
        });

        after(() => {
            hsServiceMethodStub.restore();
        })
        
        it('should call service and return data', async () => {
            hsServiceMethodStub.resolves([])
            const req = ({params: {contractNbr : '1'}});
            const res = { send: sendSpy };
            await healthscoreController.getContractMitigations(req, res, nextSpy);
            expect(sendSpy).to.have.been.calledWith({ data: [] });
        });

        it('should handle error returned by service', async () => {
            hsServiceMethodStub.rejects('error');
            const req = ({params: {contractNbr : '1'}});
            const res = {};
            await healthscoreController.getContractMitigations(req, res, nextSpy);
            return hsServiceMethodStub().catch((error) => {
                expect(error.name).eql('error');
            });
        });
    });

    describe('getContractPolicy Test', () => {
        const hsServiceMethodStub = sinon.stub(healthscoreService, '_getContractPolicy');
        
        beforeEach(function(done) {
            done();
        });

        afterEach(function(done) {
          sendSpy.resetHistory();
          nextSpy.resetHistory();
          hsServiceMethodStub.reset();
          done();
        });

        after(() => {
            hsServiceMethodStub.restore();
        })
        
        it('should call service and return data', async () => {
            hsServiceMethodStub.resolves([])
            const req = ({params: {contractNbr : '1'}});
            const res = { send: sendSpy };
            await healthscoreController.getContractPolicy(req, res, nextSpy);
            expect(sendSpy).to.have.been.calledWith({ data: [] });
        });

        it('should handle error returned by service', async () => {
            hsServiceMethodStub.rejects('error');
            const req = ({params: {contractNbr : '1'}});
            const res = {};
            await healthscoreController.getContractPolicy(req, res, nextSpy);
            return hsServiceMethodStub().catch((error) => {
                expect(error.name).eql('error');
            });
        });
    });


    describe('getContractHRI Test', () => {
        const hsServiceMethodStub = sinon.stub(healthscoreService, '_getContractHRI');
        
        beforeEach(function(done) {
            done();
        });

        afterEach(function(done) {
          sendSpy.resetHistory();
          nextSpy.resetHistory();
          hsServiceMethodStub.reset();
          done();
        });

        after(() => {
            hsServiceMethodStub.restore();
        })
        
        it('should call service and return data', async () => {
            hsServiceMethodStub.resolves([])
            const req = ({params: {contractNbr : '1'}});
            const res = { send: sendSpy };
            await healthscoreController.getContractHRI(req, res, nextSpy);
            expect(sendSpy).to.have.been.calledWith({ data: [] });
        });

        it('should handle error returned by service', async () => {
            hsServiceMethodStub.rejects('error');
            const req = ({params: {contractNbr : '1'}});
            const res = {};
            await healthscoreController.getContractHRI(req, res, nextSpy);
            return hsServiceMethodStub().catch((error) => {
                expect(error.name).eql('error');
            });
        });
    });
    

    describe('getClientCIPInfo Test', () => {
        const hsServiceMethodStub = sinon.stub(healthscoreService, '_getClientCIPInfo');
        
        beforeEach(function(done) {
            done();
        });

        afterEach(function(done) {
          sendSpy.resetHistory();
          nextSpy.resetHistory();
          hsServiceMethodStub.reset();
          done();
        });

        after(() => {
            hsServiceMethodStub.restore();
        })
        
        it('should call service and return data', async () => {
            hsServiceMethodStub.resolves([])
            const req = ({params: {contractNbr : '1'}});
            const res = { send: sendSpy };
            await healthscoreController.getClientCIPInfo(req, res, nextSpy);
            expect(sendSpy).to.have.been.calledWith({ data: [] });
        });

        it('should handle error returned by service', async () => {
            hsServiceMethodStub.rejects('error');
            const req = ({params :{mcId : "1"}});
            const res = {};
            await healthscoreController.getClientCIPInfo(req, res, nextSpy);
            return hsServiceMethodStub().catch((error) => {
                expect(error.name).eql('error');
            });
        });
    });

    describe('getContractCIPInfo Test', () => {
        const hsServiceMethodStub = sinon.stub(healthscoreService, '_getContractCIPInfo');
        
        beforeEach(function(done) {
            done();
        });

        afterEach(function(done) {
          sendSpy.resetHistory();
          nextSpy.resetHistory();
          hsServiceMethodStub.reset();
          done();
        });

        after(() => {
            hsServiceMethodStub.restore();
        })
        
        it('should call service and return data', async () => {
            hsServiceMethodStub.resolves([])
            const req = ({params :{mcId : "1"}});
            const res = { send: sendSpy };
            await healthscoreController.getContractCIPInfo(req, res, nextSpy);
            expect(sendSpy).to.have.been.calledWith({ data: [] });
        });

        it('should handle error returned by service', async () => {
            hsServiceMethodStub.rejects('error');
            const req = ({params :{mcId : "1"}});
            const res = {};
            await healthscoreController.getContractCIPInfo(req, res, nextSpy);
            return hsServiceMethodStub().catch((error) => {
                expect(error.name).eql('error');
            });
        });
    });

    describe('getClientCMRiskInfo Test', () => {
        const hsServiceMethodStub = sinon.stub(healthscoreService, '_getClientCMRiskInfo');
        
        beforeEach(function(done) {
            done();
        });

        afterEach(function(done) {
          sendSpy.resetHistory();
          nextSpy.resetHistory();
          hsServiceMethodStub.reset();
          done();
        });

        after(() => {
            hsServiceMethodStub.restore();
        })
        
        it('should call service and return data', async () => {
            hsServiceMethodStub.resolves([])
            const req = ({params :{mcId : "1"}});
            const res = { send: sendSpy };
            await healthscoreController.getClientCMRiskInfo(req, res, nextSpy);
            expect(sendSpy).to.have.been.calledWith({ data: [] });
        });

        it('should handle error returned by service', async () => {
            hsServiceMethodStub.rejects('error');
            const req = ({params :{mcId : "1"}});
            const res = { send: sendSpy };
            await healthscoreController.getClientCMRiskInfo(req, res, nextSpy);
            return hsServiceMethodStub().catch((error) => {
                expect(error.name).eql('error');
            });
        });
    });



    describe('getClientCDPInfo Test', () => {
        const hsServiceMethodStub = sinon.stub(healthscoreService, '_getClientCDPInfo');
        
        beforeEach(function(done) {
            done();
        });

        afterEach(function(done) {
          sendSpy.resetHistory();
          nextSpy.resetHistory();
          hsServiceMethodStub.reset();
          done();
        });

        after(() => {
            hsServiceMethodStub.restore();
        })
        
        it('should call service and return data', async () => {
            hsServiceMethodStub.resolves([])
            const req = ({params :{MCustomerNbr : "1"}});
            const res = { send: sendSpy };
            await healthscoreController.getClientCDPInfo(req, res, nextSpy);
            expect(sendSpy).to.have.been.calledWith({ data: [] });
        });

        it('should handle error returned by service', async () => {
            const statusSpy = sinon.spy();
            hsServiceMethodStub.rejects('error');
            const req = ({params :{MCustomerNbr : "1"}});
            const res = { send: sendSpy, status: statusSpy };
            await healthscoreController.getClientCDPInfo(req, res, nextSpy);
            return hsServiceMethodStub().catch((error) => {
                expect(statusSpy).to.have.been.calledWith(500);
            });
        });


    });    

    describe('getClientHRIInfo Test', () => {
        const hsServiceMethodStub = sinon.stub(healthscoreService, '_getClientHRIInfo');
        
        beforeEach(function(done) {
            done();
        });

        afterEach(function(done) {
          sendSpy.resetHistory();
          nextSpy.resetHistory();
          hsServiceMethodStub.reset();
          done();
        });

        after(() => {
            hsServiceMethodStub.restore();
        })
        
        it('should call service and return data', async () => {
            hsServiceMethodStub.resolves([])
            const req = ({params:{MasterClientNbr:"1", CustomerNbr:"1"}});
            const res = { send: sendSpy };
            await healthscoreController.getClientHRIInfo(req, res, nextSpy);
            expect(sendSpy).to.have.been.calledWith({ data: [] });
        });

        it('should handle error returned by service', async () => {
            hsServiceMethodStub.rejects('error');
            const req = ({params:{MasterClientNbr:"1",CustomerNbr:"1"}});
            const res = { send: sendSpy };
            await healthscoreController.getClientHRIInfo(req, res, nextSpy);
            return hsServiceMethodStub().catch((error) => {
                expect(error.name).eql('error');
            });
        });
    });

    describe('getClientQAInfo Test', () => {
        const hsServiceMethodStub = sinon.stub(healthscoreService, '_getClientQAInfo');
        
        beforeEach(function(done) {
            done();
        });

        afterEach(function(done) {
          sendSpy.resetHistory();
          nextSpy.resetHistory();
          hsServiceMethodStub.reset();
          done();
        });

        after(() => {
            hsServiceMethodStub.restore();
        })
        
        it('should call service and return data', async () => {
            hsServiceMethodStub.resolves([])
            const req = ({params :{mcId : "1"}});
            const res = { send: sendSpy };
            await healthscoreController.getClientQAInfo(req, res, nextSpy);
            expect(sendSpy).to.have.been.calledWith({ data: [] });
        });

        it('should handle error returned by service', async () => {
            hsServiceMethodStub.rejects('error');
            const req = ({params :{mcId : '1'}});
            const res = { send: sendSpy };
            await healthscoreController.getClientQAInfo(req, res, nextSpy);
            return hsServiceMethodStub().catch((error) => {
                expect(error.name).eql('error');
            });
        });
    });

    describe('getClientPolicyInfo Test', () => {
        const hsServiceMethodStub = sinon.stub(healthscoreService, '_getClientPolicyInfo');
        
        beforeEach(function(done) {
            done();
        });

        afterEach(function(done) {
          sendSpy.resetHistory();
          nextSpy.resetHistory();
          hsServiceMethodStub.reset();
          done();
        });

        after(() => {
            hsServiceMethodStub.restore();
        })
        
        it('should call service and return data', async () => {
            hsServiceMethodStub.resolves([])
            const req = ({params :{mcId : "1"}});
            const res = { send: sendSpy };
            await healthscoreController.getClientPolicyInfo(req, res, nextSpy);
            expect(sendSpy).to.have.been.calledWith({ data: [] });
        });

        it('should handle error returned by service', async () => {
            hsServiceMethodStub.rejects('error');
            const req = ({params :{mcId : '1'}});
            const res = { send: sendSpy };
            await healthscoreController.getClientPolicyInfo(req, res, nextSpy);
            return hsServiceMethodStub().catch((error) => {
                expect(error.name).eql('error');
            });
        });
    });

    describe('getContractingStatus Test', () => {
        const hsServiceMethodStub = sinon.stub(healthscoreService, '_getContractingStatus');
        
        beforeEach(function(done) {
            done();
        });

        afterEach(function(done) {
          sendSpy.resetHistory();
          nextSpy.resetHistory();
          hsServiceMethodStub.reset();
          done();
        });

        after(() => {
            hsServiceMethodStub.restore();
        })
        
        it('should call service and return data', async () => {
            hsServiceMethodStub.resolves([])
            const req = ({body: { ContractNbr: '1', CustomerNbr: '1', MasterClientNbr: '1' }});
            const res = { send: sendSpy };
            await healthscoreController.getContractingStatus(req, res, nextSpy);
            expect(sendSpy).to.have.been.calledWith({ data: [] });
        });

        it('should handle error returned by service', async () => {
            hsServiceMethodStub.rejects('error');
            const req = ({body: { ContractNbr: '1', CustomerNbr: '1', MasterClientNbr: '1' }});
            const res = {};
            await healthscoreController.getContractingStatus(req, res, nextSpy);
            return hsServiceMethodStub().catch((error) => {
                expect(error.name).eql('error');
            });
        });
    });

    describe('getDNO Test', () => {
        const hsServiceMethodStub = sinon.stub(healthscoreService, '_getDNO');
        
        beforeEach(function(done) {
            done();
        });

        afterEach(function(done) {
          sendSpy.resetHistory();
          nextSpy.resetHistory();
          hsServiceMethodStub.reset();
          done();
        });

        after(() => {
            hsServiceMethodStub.restore();
        })

        it('should call service and return data', async () => {
            hsServiceMethodStub.resolves([])
            const req = ({body: { ContractNbr: '1', CustomerNbr: '1', MasterClientNbr: '1' }});
            const res = { send: sendSpy };
            await healthscoreController.getDNO(req, res, nextSpy);
            expect(sendSpy).to.have.been.calledWith({ data: [] });
        });
    });

});
