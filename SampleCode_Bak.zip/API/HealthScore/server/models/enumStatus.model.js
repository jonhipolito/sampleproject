'use strict';

const Status = {
        Red : "R",
        Yellow : "Y",
        Green : "G"
    };

const HRILevel = {
    SAC_Watch : "SAC Watch",
    SAC_Action : "SAC Action",
    Corp_Watch : "Corporate Watch",
    Corp_Action : "Corporate Action",
    DTE_Watch :  "DTE Watch",
    DTE_Action : "DTE Action",
    Local_Watch : "Local Watch",
    Local_Action : "Local Action"
};

module.exports = {
    Status,
    HRILevel
}