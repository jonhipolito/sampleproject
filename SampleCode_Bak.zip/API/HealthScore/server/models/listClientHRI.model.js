'use strict';

module.exports = function(totalWatch, totalAction, totalHRIRecords, stat, chartDataAW, chartDataStat){
    this.watchTotal = totalWatch;
    this.actionTotal = totalAction;
    this.hriRecords = totalHRIRecords;
    this.OverallStat = stat;
    this.AWChartData = [];
        chartDataAW.forEach(e =>{
            this.AWChartData.push(e);
        });
    this.StatusChartData = []
        chartDataStat.forEach(d =>{
            this.StatusChartData.push(d);
        })
}