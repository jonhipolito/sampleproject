'use strict';
const cdpModel = require('./cdpdata.model');

module.exports = function(obj, totalControl, totalPastDue){
    this.TotalControl = totalControl;
    this.TotalPastDue = totalPastDue;
    this.model = [];
        obj.forEach(e =>{
            this.model.push(new cdpModel(e));
        });
}