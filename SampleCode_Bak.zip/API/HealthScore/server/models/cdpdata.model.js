'use strict';

module.exports = function(obj){
    this.MasterCustomerNbr = obj.MasterCustomerNbr;
    this.ClientName = obj.ClientName
    this.Current_WeightedOperationalRisk = obj.Current_WeightedOperationalRisk;
    this.Current_WeightedOperationalRiskBubbleColor =obj.Current_WeightedOperationalRiskBubbleColor;    
    this.ClientID = obj.ClientID;
}