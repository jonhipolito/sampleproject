'use strict';

const healthScoreService = require('./healthscore.service');

const errorMessage = 'An error has encountered.'

const getClientCDPInfo = (req, res, next) => {
    healthScoreService._getClientCDPInfo(req, req.params.MCustomerNbr)
        .then(message => {
            res.send({
                data: message
            });
        })
        .catch(error => {
            res.status(500).send({errors: error});
        })
}

const getClientCIPInfo = (req, res, next) => {
    healthScoreService._getClientCIPInfo(req.params.mcid, req.params.fcid)
        .then(message => {
            res.send({
                data: message
            });
        })
        .catch(error => {
            const err = new Error(error);
            next(err);
        })
}

const getClientCMRiskInfo = (req, res, next) => {
    healthScoreService._getClientCMRiskInfo(req.params.mcId, req.params.fcId).then(message => {
        res.send({
            data: message
        });
    }).catch(error => {
        const err = new Error(error);
        next(err);
    });
}

const getClientHRIInfo = (req, res, next) => {
    healthScoreService._getClientHRIInfo(req, req.params.MasterClientNbr, req.params.CustomerNbr)
        .then(message => {
            res.send({
                data: message
            });
        }).catch(error => {
            const err = new Error(error);
            // next(err);
            res.send(err);
        })
}

const getClientPolicyInfo = (req, res, next) => {
    healthScoreService._getClientPolicyInfo(req, req.params.mcid, req.params.fcid)
        .then(message => {
            res.send({
                data: message
            });
        }).catch(error => {
            const err = new Error(error);
            next(err);
        })
}

const getContractCIPInfo = (req, res, next) => {
    healthScoreService._getContractCIPInfo(req.params.contractId)
        .then(message => {
            res.send({
                data: message
            });
        })
        .catch(error => {
            const err = new Error(error);
            next(err);
        })
}

const getContractQARiskInfo = (req, res, next) => {
    healthScoreService._getContractQARiskInfo(req, req.params.contractNbr)
        .then(message => {
            res.send({
                data: message
            });
        }).catch(error => {
            const err = new Error(error);
            next(err);
        });
}

const getContractCMRiskInfo = (req, res, next) => {
    healthScoreService._getContractCMRiskInfo(req, req.params.contractNbr)
        .then(message => {
            res.send({
                data: message
            });
        }).catch(error => {
            const err = new Error(error);
            next(err);
        })
}

const getContractMitigations = (req, res, next) => {
    healthScoreService._getContractMitigations(req, req.params.contractNbr)
        .then(message => {
            res.send({
                data: message
            });
        }).catch(error => {
            const err = new Error(errorMessage);
            next(err);
        });
}

const getClientQAInfo = (req, res, next) => {
    healthScoreService._getClientQAInfo(req, req.params.mcid, req.params.fcid)
        .then(message => {
            res.send({
                data: message
            });
        })
        .catch(error => {
            const err = new Error(error);
            next(err);
        })
}

const getContractPolicy = (req, res, next) => {
    healthScoreService._getContractPolicy(req, req.params.contractNbr)
        .then(message => {
            res.send({
                data: message
            });
        })
        .catch(error => {
            const err = new Error(error);
            next(err);
        });
}

const getContractHRI = (req, res, next) => {
    healthScoreService._getContractHRI(req, req.params.contractNbr)
        .then(message => {
            res.send({
                data: message
            });
        }).catch(error => {
            const err = new Error(errorMessage);
            next(err);
        }
    );
}

const getDNO = (req, res, next) => {    
    healthScoreService._getDNO(req.body)
        .then(data => {
            res.send({
                data: data
            });
        });
}

const getContractingStatus = (req, res, next) => {    
    healthScoreService._getContractingStatus(req.body)
        .then(data => {
            res.send({
                data: data
            });
        }).catch(error => {
            const err = new Error(error);
            next(err);
        });
}

module.exports = {
    getClientCDPInfo,
    getClientCIPInfo,
    getClientCMRiskInfo,
    getClientHRIInfo,
    getClientPolicyInfo,
    getContractCIPInfo,
    getContractMitigations,
    getContractQARiskInfo,
    getContractCMRiskInfo,
    getClientQAInfo,
    getContractPolicy,
    getContractHRI,
    getDNO,
    getContractingStatus
}
