'use strict';

const express = require('express');

const healthScoreController = require('./healthscore.controller');
const { hasAccess } = require('./middlewares/accesscontrol');
const router = express.Router();

router.get('/getClientCDPInfo/:MCustomerNbr', hasAccess, healthScoreController.getClientCDPInfo);

router.get('/getClientCIPInfo/:mcid/:fcid', hasAccess, healthScoreController.getClientCIPInfo);

router.get('/getClientCMRiskInfo/:mcId/:fcId?', hasAccess, healthScoreController.getClientCMRiskInfo);

router.get('/getClientHRIInfo/:MasterClientNbr/:CustomerNbr?', hasAccess, healthScoreController.getClientHRIInfo);

router.get('/getClientPolicyInfo/:mcid/:fcid?', hasAccess, healthScoreController.getClientPolicyInfo);

router.get('/getClientQAInfo/:mcid/:fcid?', hasAccess, healthScoreController.getClientQAInfo);

router.get('/getContractCIPInfo/:contractId/', hasAccess, healthScoreController.getContractCIPInfo);

router.get('/getContractQARiskInfo/:contractNbr', hasAccess, healthScoreController.getContractQARiskInfo);

router.get('/getContractCMRiskInfo/:contractNbr', hasAccess, healthScoreController.getContractCMRiskInfo);

router.get('/getContractMitigations/:contractNbr', hasAccess, healthScoreController.getContractMitigations);

router.get('/getContractPolicy/:contractNbr', hasAccess, healthScoreController.getContractPolicy);

router.get('/getContractHRI/:contractNbr', hasAccess, healthScoreController.getContractHRI);

router.post('/getDNO', healthScoreController.getDNO);

router.post('/getContractingStatus', healthScoreController.getContractingStatus);

module.exports = router;
