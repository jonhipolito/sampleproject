'use strict';

const SpannerDB = require('../configs/db.connection');
const RiskSourceCM = '101201';
const RiskSourceCIP = '101202';

const getClientCIPInfo = async (selectedMCNbr, selectedFCNbr) => {
    let database = new SpannerDB();
    const queryOne = {
        sql: `SELECT value, label
        FROM
        (   
            SELECT COUNT (DISTINCT A.CIPId)  as value, C.PrimaryDecodeTxt as Label
            FROM RiskDetails as A 
            LEFT JOIN CodeDetail as B ON B.CodeTxt = A.RiskRatingCd 
            LEFT JOIN CodeDetail as C ON C.CodeTxt = A.RiskSourceCd
            WHERE C.PrimaryDecodeTxt = 'CIP'  
            AND B.PrimaryDecodeTxt IS NOT NULL
            AND ((A.MasterClientNbr = '` + selectedMCNbr + `' AND A.CustomerNbr = '` + selectedFCNbr + `'))
            GROUP BY C.PrimaryDecodeTxt
        )
        UNION ALL
        (
            SELECT COUNT(A.RiskRatingCd) as value,
			B.PrimaryDecodeTxt as label
            FROM RiskDetails as A 
            LEFT JOIN CodeDetail as B ON B.CodeTxt = A.RiskRatingCd 
            LEFT JOIN CodeDetail as C ON C.CodeTxt = A.RiskSourceCd
            WHERE C.PrimaryDecodeTxt = 'CIP'  
            AND B.PrimaryDecodeTxt IS NOT NULL
            AND ((A.MasterClientNbr = '` + selectedMCNbr + `' AND A.CustomerNbr = '` + selectedFCNbr + `'))
            GROUP BY B.PrimaryDecodeTxt, B.SecondaryDecodeTxt
        )
        
        UNION ALL
            
        (
            SELECT DISTINCT NULL as value, A.CIPRiskAsessment as label
            FROM RiskDetails as A 
            LEFT JOIN CodeDetail as C ON C.CodeTxt = A.RiskSourceCd
            WHERE C.PrimaryDecodeTxt = 'CIP'  
            AND A.CIPRiskAsessment IS NOT NULL
            AND ((A.MasterClientNbr = '` + selectedMCNbr + `' AND A.CustomerNbr = '` + selectedFCNbr + `'))
        )
        `,
    }

    const queryTwo = {
        sql: `SELECT value, label
        FROM
        (   
            SELECT COUNT (DISTINCT A.CIPId)  as value, C.PrimaryDecodeTxt as Label
            FROM RiskDetails as A 
            LEFT JOIN CodeDetail as B ON B.CodeTxt = A.RiskRatingCd 
            LEFT JOIN CodeDetail as C ON C.CodeTxt = A.RiskSourceCd
            WHERE C.PrimaryDecodeTxt = 'CIP'  
            AND B.PrimaryDecodeTxt IS NOT NULL
            AND A.MasterClientNbr = '` + selectedMCNbr + `'
            GROUP BY C.PrimaryDecodeTxt
        )
        UNION ALL
        (
            SELECT COUNT(A.RiskRatingCd) as value,
			B.PrimaryDecodeTxt as label
            FROM RiskDetails as A 
            LEFT JOIN CodeDetail as B ON B.CodeTxt = A.RiskRatingCd 
            LEFT JOIN CodeDetail as C ON C.CodeTxt = A.RiskSourceCd
            WHERE C.PrimaryDecodeTxt = 'CIP'  
            AND B.PrimaryDecodeTxt IS NOT NULL
            AND A.MasterClientNbr = '` + selectedMCNbr + `'
            GROUP BY B.PrimaryDecodeTxt, B.SecondaryDecodeTxt
        )
        UNION ALL
            
        (
            SELECT DISTINCT NULL as value, A.CIPRiskAsessment as label
            FROM RiskDetails as A 
            LEFT JOIN CodeDetail as C ON C.CodeTxt = A.RiskSourceCd
            WHERE C.PrimaryDecodeTxt = 'CIP'  
            AND A.CIPRiskAsessment IS NOT NULL
            AND A.MasterClientNbr = '` + selectedMCNbr + `'
        )`,
    }

    try {
        if (selectedMCNbr != 0) {
            if (selectedFCNbr == 0) {
                const [qTwoRows] = await database.run(queryTwo);
                return qTwoRows;
            } else {
                const [qOneRows] = await database.run(queryOne);
                return qOneRows;
            }
        }

    } catch (err) {
        console.log(err);
    } finally {
        await database.close();
    }
}

const getClientCMRiskList = async (selectedMCNbr, selectedFCNbr, type) => {
    let database = new SpannerDB();

    const queryOne = {
        sql: `
        SELECT COUNT(RD.value) as value, RR.PrimaryDecodeTxt as label
        FROM (
            SELECT RD.ContractNbr as contract, MIN(RD.RiskRatingCd) as value
            FROM RiskDetails as RD
            LEFT JOIN CodeDetail RS ON RS.CodeTxt = RD.RiskSourceCd
            WHERE RS.PrimaryDecodeTxt = 'CM'  
            AND ((CustomerNbr = '` + selectedFCNbr + `'))
            GROUP BY RD.ContractNbr
        ) as RD
        LEFT JOIN CodeDetail RR ON RR.CodeTxt = RD.value
        GROUP BY RR.PrimaryDecodeTxt

        UNION ALL
              
        SELECT COUNT(*) AS value, 'Not Started' AS label 
        FROM Contract C
        LEFT JOIN RiskDetails R USING(ContractNbr)
        LEFT JOIN CodeDetail RS ON RS.CodeTxt = R.RiskSourceCd
        WHERE C.CustomerNbr = '` + selectedFCNbr + `'
        AND R.CustomerNbr IS NULL`
    }

    const queryTwo = {
        sql: `
        SELECT COUNT(RD.value) as value, RR.PrimaryDecodeTxt as label
        FROM (
            SELECT RD.ContractNbr as contract, MIN(RD.RiskRatingCd) as value
            FROM RiskDetails as RD
            LEFT JOIN CodeDetail RS ON RS.CodeTxt = RD.RiskSourceCd
            WHERE RS.PrimaryDecodeTxt = 'CM'  
            AND ((MasterClientNbr = '` + selectedMCNbr + `'))
            GROUP BY RD.ContractNbr
        ) as RD
        LEFT JOIN CodeDetail RR ON RR.CodeTxt = RD.value
        GROUP BY RR.PrimaryDecodeTxt

        UNION ALL
                
        SELECT COUNT(*) AS value, 'Not Started' AS label 
        FROM Contract C
        LEFT JOIN RiskDetails R USING(ContractNbr)
        LEFT JOIN CodeDetail RS ON RS.CodeTxt = R.RiskSourceCd
        WHERE c.CustomerNbr IN (SELECT CustomerNbr FROM Customer WHERE MasterClientNbr = '` + selectedMCNbr + `')
        AND R.CustomerNbr IS NULL`
    }

    try {
        if (selectedMCNbr != 0) {
            if (selectedFCNbr == 0) {
                const [qTwoRows] = await database.run(queryTwo);
                return qTwoRows;
            } else {
                const [qOneRows] = await database.run(queryOne);
                return qOneRows;
            }
        }

    } catch (err) {
    } finally {
        await database.close();
    }
}

const getContractCIPInfo = async (selectedConNbr) => {
    let database = new SpannerDB();

    const query = {
        sql: `SELECT value, label
        FROM
        (
            SELECT COUNT(a.RiskRatingCd) as value,
			b.PrimaryDecodeTxt as label
            FROM RiskDetails as a 
            LEFT JOIN CodeDetail as b ON b.CodeTxt = A.RiskRatingCd 
            LEFT JOIN CodeDetail as c ON c.CodeTxt = A.RiskSourceCd
            WHERE c.PrimaryDecodeTxt = 'CIP'  
            AND b.PrimaryDecodeTxt IS NOT NULL
            AND ContractNbr = '` + selectedConNbr + `'
            GROUP BY b.PrimaryDecodeTxt, b.SecondaryDecodeTxt
        )
        UNION ALL
        (
            SELECT
            COUNT(B.MitigationStatusCd) AS value,
            C.PrimaryDecodeTxt AS label 
            FROM RiskDetails A
            INNER JOIN RiskMitigation B
            USING(RiskDetailsKey)
            LEFT JOIN CodeDetail AS c ON c.CodeTxt = B.MitigationStatusCd
            LEFT JOIN CodeDetail as d ON d.CodeTxt = A.RiskSourceCd
            WHERE ContractNbr = '` + selectedConNbr + `'
            AND d.PrimaryDecodeTxt = 'CIP'
            AND C.PrimaryDecodeTxt IS NOT NULL
            GROUP BY
            A.ContractNbr,
            B.MitigationStatusCd,
            C.PrimaryDecodeTxt
        )
        
        UNION ALL
        (
            SELECT DISTINCT 0 as value, CIPRiskAsessment as label
            FROM RiskDetails as a 
            LEFT JOIN CodeDetail as c ON c.CodeTxt = A.RiskSourceCd
            WHERE c.PrimaryDecodeTxt = 'CIP'  
            AND CIPRiskAsessment IS NOT NULL
            AND ContractNbr = '` + selectedConNbr + `'
        )`
    }

    try {
        const [qRows] = await database.run(query);
        return qRows;
    }
    catch (err) {
    } finally {
        await database.close();
    }
};

const getContractMitigations = async (contractNbr) => {
    let database = new SpannerDB();
    const query = {
        sql: `SELECT D.PrimaryDecodeTxt as RiskSource, Count(A.MitigationStatusCd) as Count, 
            B.ContractNbr, C.PrimaryDecodeTxt as Status, C.CodeTxt as StatusCode
            from RiskMitigation A
            inner join RiskDetails B
            on A.RiskDetailsKey = B.RiskDetailsKey
            inner join CodeDetail C
            on A.MitigationStatusCd = C.CodeTxt
            inner join CodeDetail D
            on B.RiskSourceCd = D.CodeTxt
            where B.ContractNbr = '` + contractNbr + `'
            and (B.RiskSourceCd = '` + RiskSourceCM + `' or B.RiskSourceCd = '` + RiskSourceCIP + `')
            group by RiskSource, B.ContractNbr, Status, StatusCode
            order by B.ContractNbr, RiskSource`
    }
    try {
        const [qRows] = await database.run(query);
        return qRows;
    } catch (err) {
    } finally {
        await database.close();
    }
};


const getContractCMRiskInfo = async (contractNbr) => {
    let database = new SpannerDB();
    const query = {
        sql: `SELECT A.ContractNbr, A.RiskDetailsKey, D.PrimaryDecodeTxt as RiskSource,  A.RiskRatingCd, E.PrimaryDecodeTxt as RiskRating, C.CategoryCd, F.PrimaryDecodeTxt as Category, B.MitigationStatusCd, G.PrimaryDecodeTxt as Status
            from RiskDetails A
            left join RiskMitigation B
            on A.RiskDetailsKey = B.RiskDetailsKey
            inner join RiskAssessmentQuestion C
            on A.RiskAssessmentQuestionKey = C.RiskAssessmentQuestionKey
            inner join CodeDetail D
            on A.RiskSourceCd = D.CodeTxt
            inner join CodeDetail E
            on A.RiskRatingCd = E.CodeTxt
            inner join CodeDetail F
            on C.CategoryCd = F.CodeTxt
            left join CodeDetail G
            on B.MitigationStatusCd = G.CodeTxt
            where A.RiskSourceCd = '` + RiskSourceCM + `'
            and A.ContractNbr = '` + contractNbr + `'
            order by A.RiskDetailsKey`
    }
    try {
        const [qRows] = await database.run(query);
        return qRows;
    } catch (err) {
    } finally {
        await database.close();
    }
};

const getDNO = async (filter) => {
    let database = new SpannerDB();
    const query = {
        sql: `SELECT DueDt, IsCritical, RAGStatusCd, SubmissionDelivStatusCd, SubmissionAcceptDt, CompletedDttm, ResubmissionDt
            from DeliverablesObligations
            WHERE ${filter}`
    }    
    try {
        const [qRows] = await database.run(query);
        return qRows;
    } catch (err) {
    } finally {
        await database.close();
    }
};

const getContractingStatus = async (filter) => {
    let database = new SpannerDB();
    /*
    const query = {
        sql: `SELECT CustomerNbr,Status, ExpectedSgnDt
            FROM ContractingStatus
            WHERE ${filter}
            `
    }
    */
    const query = {
        sql: `SELECT CustomerNbr,Status, ExpectedSgnDt, 
                DATE_DIFF(DATE_TRUNC(DATE(ExpectedSgnDt, '+00:00') , MONTH), DATE_TRUNC(DATE(CURRENT_TIMESTAMP, '+00:00') , MONTH), MONTH) as DiffMonth
            FROM ContractingStatus
            Where ${filter}
            and DATE_DIFF(DATE_TRUNC(DATE(ExpectedSgnDt, '+00:00') , MONTH), DATE_TRUNC(DATE(CURRENT_TIMESTAMP, '+00:00') , MONTH), MONTH) <= 2
            order by DiffMonth`
    }
    try {
        const [qRows] = await database.run(query);
        return qRows;
    } catch (err) {
    } finally {
        await database.close();
    }
};

module.exports = {
    getClientCIPInfo,
    getClientCMRiskList,
    getContractCIPInfo,
    getContractCMRiskInfo,
    getContractMitigations,
    getDNO,
    getContractingStatus
}
