'use strict';

const uuid = require('uuidv4');
const _ = require('lodash');
const healthScoreRepository = require('./healthscore.repository');
const cdpModel = require('./models/cdpResponse.model');
const hriModel = require('./models/listClientHRI.model');
const enums = require('./models/enumStatus.model');
const axios = require('axios');
const NodeCache = require("node-cache");
const request = require('request');
const ttl = 60 * 60 * 1; // cache for 1 Hour
const cache = new NodeCache({ stdTTL: ttl, checkperiod: ttl * 0.2 });

const _getClientCDPInfo = (req, MCustomerNbr) => {
  const args = { strMasterCustomerNbr: parseInt(MCustomerNbr) };
  const token = req.headers.authorization
  let data = {};
  let url = process.env.CDP_URL
  //let url = "https://cdpanalytics.ciostage.accenture.com/externalWebService/MMBData.asmx/GetMMBData";
  return new Promise(async function (resolve, reject) {
    try {
      const options = {
        url: url,
        body: JSON.stringify(args),
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': token
        }
      };

      request(options, function (error, response, body) {
        if (!error && response.statusCode == 200) {
          data = getCDPDataJson(response.body)
          // let ret = {
          //   status: "ok 200",
          //   body: response.body,
          //   option: options
          // }
          resolve(data);
        } else {
          // let ret = {
          //   status: "not ok 500",
          //   body: response.body,
          //   option: options
          // }
          resolve(null);
        }
      });
    }

    catch (err) {
      console.log(`ERROR: ` + err);
      // let ret = {
      //   status: "not really ok 500",
      //   body: err,
      //   option: null
      // }
      resolve(null);
    }
  });
}

const getCDPDataJson = (result) => {
  let data = [], model = {}, totalControl = 0, totalBadCount = 0;
  let arrTotalControl = [], arrTotalPastDue = [];
  result = JSON.parse(result).d;
  if (result.length > 0) {
    result.forEach(el => {
      arrTotalControl.push(el.TotalControlCount);
      arrTotalPastDue.push(el.BadControlCount);
      data.push(el);
    });
    totalControl = arrTotalControl.reduce((a, controlcount) => a + controlcount, 0);
    totalBadCount = arrTotalPastDue.reduce((a, badcount) => a + badcount, 0);
    model = new cdpModel(data, totalControl, totalBadCount);
  }
  return model;
}

const _getClientCIPInfo = (mcid, fcid) => {
  return new Promise(async function (resolve, reject) {
    try {
      var res = await healthScoreRepository.getClientCIPInfo(mcid, fcid);
      if (res && res.length > 0) {

        let resJSON = JSON.stringify(res);
        let resParse = JSON.parse(resJSON);

        var data = [{
          AboveNormalCount: 0,
          NormalCount: 0,
          HighCount: 0,
          NotStartedCount: 0,
          TotalScore: 0,
          RAGStatus: "Normal",
          CIPIdCount: 0
        }];

        resParse.forEach(x => {
          if (x.value != null) {
            switch (x.label) {
              case "High":
                //console.log("High", x.value);
                data[0].HighCount = x.value;
                data[0].TotalScore += x.value;
                break;
              case "Above Normal":
                //console.log("Above Normal", x.value);
                data[0].AboveNormalCount = x.value;
                data[0].TotalScore += x.value;
                break;
              case "Normal":
                //console.log("Normal", x.value);
                data[0].NormalCount = x.value;
                break;
              case "CIP":
                //console.log("CIPId", x.value);
                data[0].CIPIdCount = x.value;
                break;
              default:
                data[0].NotStartedCount = x.value;
                break;
            }
          }
          else if (x.value == null) {
            if (x.label == "High") {
              data[0].RAGStatus = x.label;
            }
            else if (x.label == "Above Normal" && data[0].RAGStatus != "High") {
              data[0].RAGStatus = x.label;
            }
          }
        });

        // if (data[0].HighCount > 0) {
        //   data[0].RAGStatus = "High"
        // } else if (data[0].AboveNormalCount > 0) {
        //   data[0].RAGStatus = "Above Normal"
        // }


        resolve(data);
      } else {
        resolve(res);
      }
      res.catch(err);
    } catch (err) {
      return reject(err);

    }
  })
}

const _getClientQAInfo = (req, MasterClientNbr, CustomerNbr) => {
  let data = {};
  return new Promise(async function (resolve, reject) {
    let url = "";
    const token = req.headers.authorization;
    if (CustomerNbr == null || CustomerNbr == 0) {
      url = process.env.QA_URL + 'getMCDetails?mClientId=' + MasterClientNbr
      //url = 'https://qcr-api-uat.ciostage.accenture.com/getMCDetails?mClientId=' + MasterClientNbr
    } else {
      url = process.env.QA_URL + 'getFCDetails?fClientId=' + CustomerNbr
      //url = 'https://qcr-api-uat.ciostage.accenture.com/getFCDetails?fClientId=' + CustomerNbr
    }

    const options = {
      url: url,
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': token
      },
    };

    try {
      request(options, function (error, response, body) {
        if (!error && response.statusCode == 200) {
          data = getClientQADataJSON(response.body);
          resolve(data);
          console.log('QA DATA', data);
        } else {
          console.log('QA', error);
          resolve(null);
        }
      });
    } catch (err) {
      return resolve(err);
    }
  });
}

const getClientQADataJSON = (result) => {
  result = JSON.parse(result);

  let qaReturn = {
    HighCount: 0,
    AboveNormalCount: 0,
    NormalCount: 0,
    UnavailableCount: 0
  }

  if (result.length != 0) {
    let data = [];

    if (result[0][0].TotalCountPerRiskDesc == 0 && result[0][1].TotalCountPerRiskDesc == 0) {
      if (result[0][2].TotalCountPerRiskDesc == 0) {
        data = [];
      }
    } else {
      for (var i = 0; i < result[0].length; i++) {

        if (result[0][i].RiskTierDesc == 'High') {
          qaReturn.HighCount = result[0][i].TotalCountPerRiskDesc;
        }

        if (result[0][i].RiskTierDesc == 'Above Normal') {
          qaReturn.AboveNormalCount = result[0][i].TotalCountPerRiskDesc;
        }

        if (result[0][i].RiskTierDesc == 'Normal') {
          qaReturn.NormalCount = result[0][i].TotalCountPerRiskDesc;
        }

        if (result[0][i].RiskTierDesc == '') {
          qaReturn.UnavailableCount = result[0][i].TotalCountPerRiskDesc;
        }
      }

      data.push({ "label": "High", "value": qaReturn.HighCount });
      data.push({ "label": "Above Normal", "value": qaReturn.AboveNormalCount });
      data.push({ "label": "Normal", "value": qaReturn.NormalCount });
      data.push({ "label": "Unavailable", "value": qaReturn.UnavailableCount });
    }
    return data;
  }

}


const _getClientCMRiskInfo = (selectedMCNbr, selectedFCNbr) => {
  return new Promise(async function (resolve, reject) {
    let riskInfoModel = {
      nm: "Normal",
      nmVal: 0,
      aNm: "Above Normal",
      aNmVal: 0,
      hg: "High",
      hgVal: 0,
      ns: "Not Started",
      nsVal: 0
    };

    let data = [];
    try {
      var res = await healthScoreRepository.getClientCMRiskList(selectedMCNbr, selectedFCNbr);
      if (res && res.length > 0) {
        let resJSON = JSON.stringify(res);
        let resParse = JSON.parse(resJSON);
        let hasValue = false


        for (var i = 0; i < res.length; i++) {
          if (resParse[i].value > 0) {
            hasValue = true;
          }
          
          if (riskInfoModel.nm == resParse[i].label) {
            riskInfoModel.nmVal = resParse[i].value
          }
          if (riskInfoModel.aNm == resParse[i].label) {
            riskInfoModel.aNmVal = resParse[i].value
          }
          if (riskInfoModel.hg == resParse[i].label) {
            riskInfoModel.hgVal = resParse[i].value
          }
          if (riskInfoModel.ns == resParse[i].label) {
            riskInfoModel.nsVal = resParse[i].value
          }
        }

        if (hasValue) {
          data.push({ "label": riskInfoModel.hg, "value": riskInfoModel.hgVal });
          data.push({ "label": riskInfoModel.aNm, "value": riskInfoModel.aNmVal });
          data.push({ "label": riskInfoModel.nm, "value": riskInfoModel.nmVal });
          data.push({ "label": riskInfoModel.ns, "value": riskInfoModel.nsVal });
        }
      }

      resolve(data)
      data.catch(err);
    } catch (err) {
      return reject(err);
    }
  })
}

const _getClientHRIInfo = (req, MasterClientNbr, CustomerNbr) => {
  return new Promise(async function (resolve, reject) {
    let url = "";
    const token = req.headers.authorization;
    if (CustomerNbr == null || CustomerNbr == 0) {
      url = process.env.HRI_URL + 'hriactiverecordpermasterclient/' + MasterClientNbr
      //url = 'https://ttrservices-test.quality.accenture.com/hrimmc/hriactiverecordpermasterclient/' + MasterClientNbr
    } else {
      url = process.env.HRI_URL + 'hriactiverecordperfinancialcustomer/' + CustomerNbr
      //url = 'https://ttrservices-test.quality.accenture.com/hrimmc/hriactiverecordperfinancialcustomer/' + CustomerNbr
    }

    const options = {
      url: url,
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': token
      },
    };

    try {
      request(options, function (error, response, body) {
        if (!error && response.statusCode == 200) {
          const token = getHRIDataJson(response.body);
          resolve(token);
        } else {
          console.log('HRI INTEGRATION ERROR', error);
          resolve(null);
        }
      });
    } catch (err) {
      return reject(err);
    }

  });
}

const getHRIDataJson = (result) => {
  let hriDetails = [], total_record = 0, watch_total = 0, action_total = 0,
    arr_status = [], status = "", action_watch = [], status_data = [];
  let model = {};
  result = JSON.parse(result);
  if (result && result.length > 0) {
    result.forEach(data => {

      hriDetails.push(data);
      arr_status.push(data.OverallStatusCd);
    });
    total_record = hriDetails.length;
    status = getStatus(arr_status);
    action_total = hriDetails.filter(x => x.HRIListLevel.indexOf("Action") > -1).length;
    watch_total = hriDetails.filter(x => x.HRIListLevel.indexOf("Watch") > -1).length;
    action_watch = chartActionWatchValue(hriDetails);
    status_data = chartStatusValue(hriDetails);
    model = new hriModel(watch_total, action_total, total_record, status, action_watch, status_data);
  }

  return model;
}

const getStatus = (stat) => {
  let temp = "";
  let green, yellow, red;
  if (stat.length > 0) {
    red = stat.indexOf(enums.Status.Red);
    yellow = stat.indexOf(enums.Status.Yellow);
    green = stat.indexOf(enums.Status.Green);
    if (red > -1) {
      temp = enums.Status.Red;
    }
    if (red == -1 && yellow > -1) {
      temp = enums.Status.Yellow;
    }
    if (red == -1 && yellow == -1) {
      temp = enums.Status.Green;
    }
    if (red == -1 && yellow == -1 && green == -1) {
      temp = "";
    }
  }
  return temp;
}

const chartActionWatchValue = (data) => {
  let watch = [], action = [], sac_watch = 0, sac_action = 0, corp_watch = 0, corp_action = 0,
    dte_watch = 0, dte_action = 0, local_watch = 0, local_action = 0, chartDataAW = [];

  sac_action = data.filter(x => x.HRIListLevel.toLowerCase() == enums.HRILevel.SAC_Action.toLowerCase()).length;
  action.push(sac_action);
  sac_watch = data.filter(x => x.HRIListLevel.toLowerCase() == enums.HRILevel.SAC_Watch.toLowerCase()).length;
  watch.push(sac_watch);

  corp_action = data.filter(x => x.HRIListLevel.toLowerCase() == enums.HRILevel.Corp_Action.toLowerCase()).length;
  action.push(corp_action);
  corp_watch = data.filter(x => x.HRIListLevel.toLowerCase() == enums.HRILevel.Corp_Watch.toLowerCase()).length;
  watch.push(corp_watch);

  dte_action = data.filter(x => x.HRIListLevel.toLowerCase() == enums.HRILevel.DTE_Action.toLowerCase()).length;
  action.push(dte_action);
  dte_watch = data.filter(x => x.HRIListLevel.toLowerCase() == enums.HRILevel.DTE_Watch.toLowerCase()).length;
  watch.push(dte_watch);

  local_action = data.filter(x => x.HRIListLevel.toLowerCase() == enums.HRILevel.Local_Action.toLowerCase()).length;
  action.push(local_action);
  local_watch = data.filter(x => x.HRIListLevel.toLowerCase() == enums.HRILevel.Local_Watch.toLowerCase()).length;
  watch.push(local_watch);

  chartDataAW.push(action);
  chartDataAW.push(watch);

  return chartDataAW;
}

const chartStatusValue = (data) => {
  let red = [], yellow = [], green = [], dte = [], sac = [], corp = [], local = [],
    red_stat = 0, yellow_stat = 0, green_stat = 0, chartDataStatus = [];

  sac = data.filter(x => x.HRIListLevel.indexOf("Special Attention") > -1);
  corp = data.filter(x => x.HRIListLevel.indexOf("Corporate") > -1);
  dte = data.filter(x => x.HRIListLevel.indexOf("DTE") > -1);
  local = data.filter(x => x.HRIListLevel.indexOf("Local") > -1);

  red_stat = sac.filter(x => (x.OverallStatusCd ? x.OverallStatusCd.toLowerCase() : x.OverallStatusCd) == enums.Status.Red.toLowerCase()).length;
  red.push(red_stat);
  yellow_stat = sac.filter(x => (x.OverallStatusCd ? x.OverallStatusCd.toLowerCase() : x.OverallStatusCd) == enums.Status.Yellow.toLowerCase()).length;
  yellow.push(yellow_stat);
  green_stat = sac.filter(x => (x.OverallStatusCd ? x.OverallStatusCd.toLowerCase() : x.OverallStatusCd) == enums.Status.Green.toLowerCase()).length;
  green.push(green_stat);

  red_stat = corp.filter(x => (x.OverallStatusCd ? x.OverallStatusCd.toLowerCase() : x.OverallStatusCd) == enums.Status.Red.toLowerCase()).length;
  red.push(red_stat);
  yellow_stat = corp.filter(x => (x.OverallStatusCd ? x.OverallStatusCd.toLowerCase() : x.OverallStatusCd) == enums.Status.Yellow.toLowerCase()).length;
  yellow.push(yellow_stat);
  green_stat = corp.filter(x => (x.OverallStatusCd ? x.OverallStatusCd.toLowerCase() : x.OverallStatusCd) == enums.Status.Green.toLowerCase()).length;
  green.push(green_stat);

  red_stat = dte.filter(x => (x.OverallStatusCd ? x.OverallStatusCd.toLowerCase() : x.OverallStatusCd) == enums.Status.Red.toLowerCase()).length;
  red.push(red_stat);
  yellow_stat = dte.filter(x => (x.OverallStatusCd ? x.OverallStatusCd.toLowerCase() : x.OverallStatusCd) == enums.Status.Yellow.toLowerCase()).length;
  yellow.push(yellow_stat);
  green_stat = dte.filter(x => (x.OverallStatusCd ? x.OverallStatusCd.toLowerCase() : x.OverallStatusCd) == enums.Status.Green.toLowerCase()).length;
  green.push(green_stat);

  red_stat = local.filter(x => (x.OverallStatusCd ? x.OverallStatusCd.toLowerCase() : x.OverallStatusCd) == enums.Status.Red.toLowerCase()).length;
  red.push(red_stat);
  yellow_stat = local.filter(x => (x.OverallStatusCd ? x.OverallStatusCd.toLowerCase() : x.OverallStatusCd) == enums.Status.Yellow.toLowerCase()).length;
  yellow.push(yellow_stat);
  green_stat = local.filter(x => (x.OverallStatusCd ? x.OverallStatusCd.toLowerCase() : x.OverallStatusCd) == enums.Status.Green.toLowerCase()).length;
  green.push(green_stat);

  chartDataStatus.push(red);
  chartDataStatus.push(yellow);
  chartDataStatus.push(green);

  return chartDataStatus;

}

const _getClientPolicyInfo = async (req, MasterClientNbr, CustomerNbr) => {
  let url = "";
  const token = req.headers.authorization;
  if (CustomerNbr == null || CustomerNbr == 0) {
    url = process.env.POLICY_URL + 'GetMasterClientLevelData?mcNumber=' + MasterClientNbr
    //url = `https://mmcapi-compliance.ciostage.accenture.com/mmrapi/GetMasterClientLevelData?mcNumber=${MasterClientNbr}`;
  } else {
    url = process.env.POLICY_URL + 'GetFinancialClientLevelData?fcNumber=' + CustomerNbr
    //url = `https://mmcapi-compliance.ciostage.accenture.com/mmrapi/GetFinancialClientLevelData?fcNumber=${CustomerNbr}`;
  }
  const options = {
    url: url,
    method: 'GET',
    headers: {
      'Authorization': token
    },
  };
  return new Promise(async function (resolve, reject) {
    try {
      request(options, function (error, response, body) {
        if (!error && response.statusCode == 200) {
          const data = ClientPolicyData(response.body);
          resolve(data);
        } else {
          console.log('Client Policy INTEGRATION ERROR', error);
          resolve(null);
        }
      });
    }
    catch (err) {
      return reject(err);
    }
  })
}

const ClientPolicyData = (data) => {
  if (data && data != undefined) {
    data = JSON.parse(data);
    let retRes = [];
    let result = {
      OverallCompliance: 0,
      ActiveCount: 0,
      NonCompliantCount: 0,
      RagStatusText: "",
      RagStatusColor: ""
    }
    result.OverallCompliance = Math.round(data.overallCompliance * 100);

    if (result.OverallCompliance >= 90) {
      result.RagStatusColor = "green";
      result.RagStatusText = "Compliant";
    }
    if (result.OverallCompliance >= 80 && result.OverallCompliance < 90) {
      result.RagStatusColor = "yellow";
      result.RagStatusText = "Compliance At Risk";
    }

    if (result.OverallCompliance < 80) {
      result.RagStatusColor = "red";
      result.RagStatusText = "Non-Compliant";
    }

    result.ActiveCount = data.activeContracts;
    result.NonCompliantCount = data.nonCompliantContracts;

    retRes.push(result);
    return retRes;
  }
}

const _getContractCIPInfo = (contractId) => {
  return new Promise(async function (resolve, reject) {
    try {
      var res = await healthScoreRepository.getContractCIPInfo(contractId);
      if (res && res.length > 0) {

        let resJSON = JSON.stringify(res);
        let resParse = JSON.parse(resJSON);


        var data = [{
          AboveNormalCount: 0,
          NormalCount: 0,
          HighCount: 0,
          NotStartedCount: 0,
          TotalScore: 0,
          OverdueCount: 0,
          OngoingCount: 0,
          CompletedCount: 0,
          CIPId: 0,
          CIPType: "",
          RAGStatus: "Normal"
        }];

        resParse.forEach(x => {
          if (x.value > 0 && x.CIPId != 0 && x.CIPType != '') {
            switch (x.label) {
              case "High":
                // console.log("High", x.value);
                data[0].HighCount = x.value;
                data[0].TotalScore += x.value;
                break;
              case "Above Normal":
                //console.log("Above Normal", x.value);
                data[0].AboveNormalCount = x.value;
                data[0].TotalScore += x.value;
                break;
              case "Normal":
                //console.log("Normal", x.value);
                data[0].NormalCount = x.value;
                break;
              case "Overdue":
                data[0].OverdueCount = x.value;
                break;
              case "In Progress (Due)":
                data[0].OngoingCount = x.value;
                break;
              case "Complete":
                data[0].CompletedCount = x.value;
                break;
              default:
                data[0].NotStartedCount = x.value;
                break;
            }
          }
          else if (x.value == 0 && x.CIPId == 0 && x.CIPType == '') {
            if (x.label == "High") {
              data[0].RAGStatus = x.label;
            }
            else if (x.label == "Above Normal" && data[0].RAGStatus != "High") {
              data[0].RAGStatus = x.label;
            }
          }
        });

        // if (data[0].HighCount > 0) {
        //   data[0].RAGStatus = "High"
        // } else if (data[0].AboveNormalCount > 0) {
        //   data[0].RAGStatus = "Above Normal"
        // }

        resParse.forEach(x => {
          if (x.CIPType != '' && x.CIPId != 0) {
            data[0].CIPId = x.CIPId;
            data[0].CIPType = x.CIPType;
          }
        })


        resolve(data);
      } else {
        resolve(res);
      }
      // if (res && res.length > 0) {

      //   let resJSON = JSON.stringify(res);
      //   let resParse = JSON.parse(resJSON);

      //   var data = [{
      //     AboveNormalCount: 0,
      //     NormalCount: 0,
      //     HighCount: 0,
      //     NotStartedCount: 0,
      //     TotalScore: 0,
      //     OverdueCount: 0,
      //     OngoingCount: 0,
      //     CompletedCount: 0,
      //     CIPId: 0,
      //     CIPType: "",
      //     RAGStatus: "Normal"
      //   }];

      //   resParse.forEach(x => {
      //     switch (x.label) {
      //       case "High":
      //         //console.log("High", x.value);
      //         data[0].HighCount = x.value;
      //         data[0].TotalScore += x.value;
      //         break;
      //       case "Above Normal":
      //         //console.log("Above Normal", x.value);
      //         data[0].AboveNormalCount = x.value;
      //         data[0].TotalScore += x.value;
      //         break;
      //       case "Normal":
      //         //console.log("Normal", x.value);
      //         data[0].NormalCount = x.value;
      //         break;
      //       case "Overdue":
      //         data[0].OverdueCount = x.value;
      //         break;
      //       case "In Progress":
      //         data[0].OngoingCount = x.value;
      //         break;
      //       case "Complete":
      //         data[0].CompletedCount = x.value;
      //         break;
      //       default:
      //         data[0].NotStartedCount = x.value;
      //         break;
      //     }
      //   });

      //   if (data[0].HighCount > 0) {
      //     data[0].RAGStatus = "High"
      //   } else if (data[0].AboveNormalCount > 0) {
      //     data[0].RAGStatus = "Above Normal"
      //   }

      //   resParse.forEach(x => {
      //     data[0].CIPId = x.CIPId;
      //     data[0].CIPType = x.CIPType;
      //   })


      //   resolve(data);
      // } else {
      //   resolve(res);
      // }

      res.catch(err);
    } catch (err) {
      return reject(err);

    }
  })
}

const _getContractQARiskInfo = (req, contractNbr) => {
  return new Promise(async function (resolve, reject) {
    getContractQAExternal(req, contractNbr).then(values => {
      let data = {
        plans: [],
        cmScore: null,
        director: null,
        highRisk: 0,
        normalRisk: 0,
        aboveNormalRisk: 0,
        unavailableRisk: 0,
        naRisk: 0,
        lastFinalizedQA: null,
        nextScheduledQA: null
      };
      if (values) {
        let resParse = JSON.parse(values);
        if (resParse.length > 3 && resParse[0] && resParse[0].length > 0 && resParse[0][0].PlanId !== null
          && resParse[1] && resParse[1].length > 0 && resParse[2] && resParse[2].length > 0 && resParse[3] && resParse[3].length > 0) {

          resParse[0].forEach(plan => {
            data.plans.push({ planId: plan.PlanId, planName: plan.PlanNm, riskScore: plan.RiskScore, riskStatus: plan.RiskTierDesc });
          });

          //for single plan, get the qa director and dates
          if (resParse[0].length === 1) {
            data.director = resParse[0][0].QADirectorEnterpriseId;
            data.lastFinalizedQA = resParse[0][0].LastFinalizedDt;
            data.nextScheduledQA = resParse[0][0].NextScheduleDt;
          }

          resParse[1].forEach(stat => {
            if (stat.StatDesc) {
              switch (stat.StatDesc.toLowerCase()) {
                case 'high':
                  data.highRisk = stat.StatCount;
                  break;
                case 'above normal':
                  data.aboveNormalRisk = stat.StatCount;
                  break;
                case 'normal':
                  data.normalRisk = stat.StatCount;
                  break;
                case 'n/a':
                  data.naRisk = stat.StatCount;
                  break;
                default:
                  break;
              }
            }
            else {
              data.unavailableRisk = stat.StatCount;
            }
          });

          data.cmScore = resParse[3][0].CMScore;
          resolve(data);
        }
        else {
          console.log('data is less or planId is null');
          resolve(null);
        }
      }
      else {
        console.log('data=null');
        resolve(null);
      }
    }).catch(error => {
      console.log(JSON.stringify(error));
      reject(error);
    });
  });
}

const _getContractCMRiskInfo = (req, contractNbr) => {
  return new Promise(async function (resolve, reject) {
    try {
      var res = await healthScoreRepository.getContractCMRiskInfo(contractNbr);
      if (res && res.length > 0) {
        let resJSON = JSON.stringify(res);
        let resParse = JSON.parse(resJSON);

        var data = {
          highRisk: 0,
          normalRisk: 0,
          aboveNormalRisk: 0,
          mitigateSection: [
            {
              section: 'Client Expectations/Context',
              mitigations: {
                completed: 0, overdue: 0, dueAndOngoing: 0
              }
            },
            {
              section: 'Alignment',
              mitigations: {
                completed: 0, overdue: 0, dueAndOngoing: 0
              }
            },
            {
              section: 'Contract & Deal Structure',
              mitigations: {
                completed: 0, overdue: 0, dueAndOngoing: 0
              }
            },
            {
              section: 'Solution Plan & Cost',
              mitigations: {
                completed: 0, overdue: 0, dueAndOngoing: 0
              }
            },
            {
              section: 'Underlying Capability',
              mitigations: {
                completed: 0, overdue: 0, dueAndOngoing: 0
              }
            },
            {
              section: 'Delivery Execution',
              mitigations: {
                completed: 0, overdue: 0, dueAndOngoing: 0
              }
            },
            {
              section: 'Other',
              mitigations: {
                completed: 0, overdue: 0, dueAndOngoing: 0
              }
            }
          ]
        };
        let riskDetailsKey = '';
        resParse.forEach(mit => {
          switch (mit.CategoryCd) {
            case '100301':
              setCategoryStatusCount(mit.MitigationStatusCd, data.mitigateSection[0].mitigations);
              break;
            case '100302':
              setCategoryStatusCount(mit.MitigationStatusCd, data.mitigateSection[1].mitigations);
              break;
            case '100303':
              setCategoryStatusCount(mit.MitigationStatusCd, data.mitigateSection[2].mitigations);
              break;
            case '100304':
              setCategoryStatusCount(mit.MitigationStatusCd, data.mitigateSection[3].mitigations);
              break;
            case '100305':
              setCategoryStatusCount(mit.MitigationStatusCd, data.mitigateSection[4].mitigations);
              break;
            case '100306':
              setCategoryStatusCount(mit.MitigationStatusCd, data.mitigateSection[5].mitigations);
              break;
            default:
              setCategoryStatusCount(mit.MitigationStatusCd, data.mitigateSection[6].mitigations);
              break;
          }
          if (mit.RiskDetailsKey !== riskDetailsKey) {
            riskDetailsKey = mit.RiskDetailsKey;
            switch (mit.RiskRatingCd) {
              case '100801':
                data.highRisk++;
                break;
              case '100802':
                data.aboveNormalRisk++;
                break;
              case '100803':
                data.normalRisk++;
                break;
              default:
                break;
            }
          }
        });
        resolve(data);
      }
      else {
        resolve(null);
      }
    }
    catch (err) {
      console.log('_getContractCMRiskInfo:ERROR: ' + JSON.stringify(err));
      return reject(err);
    }
  });

  function setCategoryStatusCount(mitigationStatusCd, mitigations) {
    switch (mitigationStatusCd) {
      case '101401':
        mitigations.dueAndOngoing++;
        break;
      case '101403':
        mitigations.completed++;
        break;
      case '101402':
        mitigations.overdue++;
        break;
      default:
        break;
    }
  }
}

const _getContractMitigations = (req, contractNbr) => {
  return new Promise((resolve, reject) => {
    Promise.all([getCMCIPMitigations(contractNbr), getQAMitigations(req, contractNbr)]).then(values => {
      let dataAvailable = false;
      let data = [
        {
          section: 'CM',
          mitigations: { Overdue: 0, Complete: 0, Ongoing: 0 }
        },
        {
          section: 'CIP',
          mitigations: { Overdue: 0, Complete: 0, Ongoing: 0 }
        },
        {
          section: 'QA',
          mitigations: { Overdue: 0, Complete: 0, Ongoing: 0 }
        }
      ];
      if (values[0] && values[0].length > 0) {
        dataAvailable = true;
        let resParse = JSON.parse(JSON.stringify(values[0]));
        resParse.forEach(mit => {
          switch (mit.RiskSource.toUpperCase()) {
            case 'CM':
              setMitigationStatusCount(mit, data[0].mitigations);
              break;
            case 'CIP':
              setMitigationStatusCount(mit, data[1].mitigations);
              break;
            default:
              break;
          }
        });
      }
      if (values[1] && values[1].length > 0 && values[1][0].Count > 0) {
        dataAvailable = true;
        setMitigationStatusCount(values[1][0], data[2].mitigations);
      }
      if (!dataAvailable) {
        data = null;
      }
      resolve(data);
    }).catch(error => {
      console.log(JSON.stringify(error));
      resolve(null);
    });
  });

  function setMitigationStatusCount(data, mitigations) {
    switch (data.StatusCode) {
      case '101402':
        mitigations.Overdue = data.Count;
        break;
      case '101401':
        mitigations.Ongoing = data.Count;
        break;
      case '101403':
        mitigations.Complete = data.Count;
        break;
      default:
        break;
    }
  }
}

const getContractQAExternal = (req, contractNbr) => { //CALL THE CONTRACT QA API EXTERNAL
  return new Promise(async function (resolve, reject) {
    const token = req.headers.authorization;
    let url = process.env.QA_URL + 'getContractDetails?contractId=' + contractNbr
    //let url = 'https://qcr-api-ops.ciostage.accenture.com/getContractDetails?contractId=' + contractNbr;
    const options = {
      url: url,
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': token
      },
    };
    request(options, function (error, response, body) {
      if (!error && response.statusCode == 200) {
        resolve(body);
      } else if (error || response.statusCode !== 204) {
        console.log('QA EXTERNAL INTEGRATION ERROR', error);
        reject(error);
      } else {
        resolve(null);
      }
    });
  });
}

const getQAMitigations = (req, contractNbr) => {
  return new Promise(async function (resolve, reject) {
    let qaMitigationObj = [{ Status: 'In Progress', StatusCode: '101401', Count: 0 }];
    getContractQAExternal(req, contractNbr).then(values => {
      qaMitigationObj[0].Count = JSON.parse(values)[2][0].NoOfMitigations; //GO TO THE MITIGATION
      resolve(qaMitigationObj);
    }).catch(error => {
      reject(error);
    });
  });
}

const getCMCIPMitigations = (contractNbr) => {
  return new Promise((resolve, reject) => {
    var res = healthScoreRepository.getContractMitigations(contractNbr);
    try {
      resolve(res);
      res.catch(err);
    } catch (err) {
      return reject(err);
    }
  });
}

const _getContractPolicy = (req, contractNbr) => {
  let data = [];
  const token = req.headers.authorization;
  let url = process.env.POLICY_URL + 'GetContractLevelData?contractNumber=' + contractNbr
  //let url = `https://mmcapi-compliance.ciostage.accenture.com/mmrapi/GetContractLevelData?contractNumber=${contractNbr}`;

  const options = {
    url: url,
    method: 'GET',
    headers: {
      'Authorization': token
    },
  };
  return new Promise(async function (resolve, reject) {
    try {
      request(options, function (error, response, body) {
        if (!error && response.statusCode == 200) {
          data.push(JSON.parse(body));
          resolve(data);
        } else {
          console.log('CONTRACT POLICY INTEGRATION ERROR', error);
          resolve(null);
        }
      });
    }
    catch (err) {
      return reject(err);
    }
  })
}

const _getContractHRI = (req, ContractNbr) => {
  return new Promise(async function (resolve, reject) {
    const token = req.headers.authorization;
    let url = process.env.HRI_URL + 'hriactiverecordpercontract/' + ContractNbr;
    //let url = 'https://ttrservices-test.quality.accenture.com/hrimmc/hriactiverecordpercontract/' + ContractNbr;

    const options = {
      url: url,
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': token
      },
    };
    request(options, function (error, response, body) {
      if (!error && response.statusCode === 200) {
        resolve(JSON.parse(body));
      }
      else if (error || response.statusCode !== 204) {
        console.log('CONTRACT HRI INTEGRATION ERROR', error);
        reject(error);
      }
      else {
        resolve(null);
      }
    });
  });
}

const _getDNO = (body) => {
  const pendingStatus = ['102501', '102503', '102505', '102508']
  const acceptedStatus = ['102506', '102502'];
  return new Promise(async (resolve, reject) => {
    let filter;
    if (body.ContractNbr) {
      filter = `ContractNbr = '${body.ContractNbr}'`
    }
    else if (body.CustomerNbr) {
      filter = `CustomerNbr = '${body.CustomerNbr}'`
    }
    else if (body.MasterClientNbr) {
      filter = `MasterClientNbr = '${body.MasterClientNbr}'`
    }
    var res = await healthScoreRepository.getDNO(filter);    

    if (!res) {
      res = [];
    }
    let arr = [];
    res.forEach(r => {
      let row = r.toJSON();
      if (pendingStatus.indexOf(row.SubmissionDelivStatusCd) > -1) {
        let due;
        if (row.SubmissionDelivStatusCd == '102508' && row.ResubmissionDt) {
          due = dateDiffInDays(new Date(), new Date(row.ResubmissionDt));
        }
        else {
          due = dateDiffInDays(new Date(), new Date(row.DueDt));
        }
        //console.log("due",due);
        row.due = due;
        if (due >= 0 && due <= 7) {
          row.neardue = "week"
        }
        else if (due >= 8 && due <= 30) {
          row.neardue = "month"
        }
        else if (due > 30 && due <= 60) {
          row.neardue = "months"
        }
        else if (due < 0 && due >= -7) {
          row.pastdue = "week"
        }
        else if (due <= -8 && due >= -30) {
          row.pastdue = "month"
        }
        else if (due < -30) {
          row.pastdue = "months"
        }
      }
      if (acceptedStatus.indexOf(row.SubmissionDelivStatusCd) > -1) {
        let accepted;
        if (row.SubmissionDelivStatusCd == '102506') {
          accepted = dateDiffInDays(new Date(), new Date(row.SubmissionAcceptDt));
        }
        else {
          accepted = dateDiffInDays(new Date(), new Date(row.CompletedDttm));
        }
        //console.log("accepted: ",accepted);
        row.accepted = accepted;
        if (accepted <= 0 && accepted >= -90) {
          row.acceptedlast90days = true;
        }
        else {
          row.acceptedlast90days = false;
        }
      }
      arr.push(row);
    });    
    //console.log("arr",arr);

    let Rejected = ['102508','102513']
    let PendingAcceptance = ['102505','102510']
    let Accepted = ['102502', '102506','102511']
    let result = {
      PastDueDate: {
        GreaterThanOneMonth: {
          critical: arr.filter(x => x.pastdue == "months" && x.IsCritical).length,
          nonCritical: arr.filter(x => x.pastdue == "months" && !x.IsCritical).length
        },
        OneMonth: {
          critical: arr.filter(x => x.pastdue == "month" && x.IsCritical).length,
          nonCritical: arr.filter(x => x.pastdue == "month" && !x.IsCritical).length
        },
        OneWeek: {
          critical: arr.filter(x => x.pastdue == "week" && x.IsCritical).length,
          nonCritical: arr.filter(x => x.pastdue == "week" && !x.IsCritical).length
        }
      },
      NearDueDate: {
        TwoMonths: {
          critical: arr.filter(x => x.neardue == "months" && x.IsCritical).length,
          nonCritical: arr.filter(x => x.neardue == "months" && !x.IsCritical).length
        },
        OneMonth: {
          critical: arr.filter(x => x.neardue == "month" && x.IsCritical).length,
          nonCritical: arr.filter(x => x.neardue == "month" && !x.IsCritical).length
        },
        OneWeek: {
          critical: arr.filter(x => x.neardue == "week" && x.IsCritical).length,
          nonCritical: arr.filter(x => x.neardue == "week" && !x.IsCritical).length
        }
      },
      ByStatus: {
        Rejected: {
          critical: arr.filter(x => Rejected.indexOf(x.SubmissionDelivStatusCd) > -1 && x.IsCritical).length,
          nonCritical: arr.filter(x => Rejected.indexOf(x.SubmissionDelivStatusCd) > -1 && !x.IsCritical).length
        },
        PendingAcceptance: {
          critical: arr.filter(x => PendingAcceptance.indexOf(x.SubmissionDelivStatusCd) > -1 && x.IsCritical).length,
          nonCritical: arr.filter(x => PendingAcceptance.indexOf(x.SubmissionDelivStatusCd) > -1 && !x.IsCritical).length
        },
        Accepted: {
          critical: arr.filter(x => Accepted.indexOf(x.SubmissionDelivStatusCd) > -1 && x.acceptedlast90days && x.IsCritical).length,
          nonCritical: arr.filter(x => Accepted.indexOf(x.SubmissionDelivStatusCd) > -1 && x.acceptedlast90days && !x.IsCritical).length
        }
      }
    }
    resolve(result);
  });
}

const _getContractingStatus = (body) => {

  return new Promise(async (resolve, reject) => {
    let filter;
    if (body.ContractNbr) {
      filter = `ContractNbr = '${body.ContractNbr}'`
    }
    else if (body.CustomerNbr) {
      filter = `CustomerNbr = '${body.CustomerNbr}' AND MasterClientNbr = '${body.MasterClientNbr}'`
    }
    else if (body.MasterClientNbr) {
      filter = `MasterClientNbr = '${body.MasterClientNbr}'`
    }

    try {
      var res = await healthScoreRepository.getContractingStatus(filter);  
      
      if (!res) {
        res = [];
      } 
      else {
        res = JSON.parse(JSON.stringify(res));
      }
            
      let result =  {
        PastDue: { 
          NotStarted: 0, WithDeliveryTeam: 0, InLegalReview: 0, ClientForReview: 0, AwaitingSignature: 0, Signed: 0 
        },
        DueThisMonth: { 
          NotStarted: 0, WithDeliveryTeam: 0, InLegalReview: 0, ClientForReview: 0, AwaitingSignature: 0, Signed: 0 
        },
        DueNextMonth: { 
          NotStarted: 0, WithDeliveryTeam: 0, InLegalReview: 0, ClientForReview: 0, AwaitingSignature: 0, Signed: 0 
        },
        DueTwoMonthsOut: { 
          NotStarted: 0, WithDeliveryTeam: 0, InLegalReview: 0, ClientForReview: 0, AwaitingSignature: 0, Signed: 0 
        }
      }

      res.forEach(row => {
        if (row.DiffMonth < 0) {
          addContractStatusCount([result.PastDue, result.DueThisMonth, result.DueNextMonth, result.DueTwoMonthsOut], row);
        }
        if (row.DiffMonth === 0) {
          addContractStatusCount([result.DueThisMonth, result.DueNextMonth, result.DueTwoMonthsOut], row);
        }
        else if (row.DiffMonth === 1) {
          addContractStatusCount([result.DueNextMonth, result.DueTwoMonthsOut], row);
        }
        else if (row.DiffMonth === 2) {
          addContractStatusCount([result.DueTwoMonthsOut], row);
        }
      });    

      resolve(result);
      result.catch(err);
    } catch (err) {
      return reject(err);
    }
  });
  
  function addContractStatusCount(arrGroup, data) {
    switch (data.Status.toLowerCase()) {
      case 'not started':
      case '103400':
        arrGroup.forEach(g => {
          g.NotStarted++;
        });
        break;
      case 'with delivery team':
      case '103401':
        arrGroup.forEach(g => {
          g.WithDeliveryTeam++;
        });
        break;
      case 'in legal review':
      case '103402':
        arrGroup.forEach(g => {
          g.InLegalReview++;
        });
        break;
      case 'with client for review':
      case '103405':
        arrGroup.forEach(g => {
          g.ClientForReview++;
        });
        break;
      case 'awaiting signature':
      case '103403':
        arrGroup.forEach(g => {
          g.AwaitingSignature++;
        });
        break;
      case 'signed':
      case '103404':
        arrGroup.forEach(g => {
          g.Signed++;
        });
        break;
      default:
        break;
    }
  }
}

function dateDiffInDays(a, b) {
  var MS_PER_DAY = 1000 * 60 * 60 * 24;
  var utc1 = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
  var utc2 = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());
  return Math.floor((utc2 - utc1) / MS_PER_DAY);
}

module.exports = {
  _getClientCDPInfo,
  _getClientCIPInfo,
  _getClientQAInfo,
  _getClientCMRiskInfo,
  _getClientHRIInfo,
  _getClientPolicyInfo,
  _getContractCIPInfo,
  _getContractQARiskInfo,
  _getContractCMRiskInfo,
  _getContractMitigations,
  _getContractPolicy,
  _getContractHRI,
  _getDNO,
  _getContractingStatus
}
