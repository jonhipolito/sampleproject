'use strict';

const accesscontrolRoute = require('../API/AccessControl/server/accesscontrol.route'),
    auditlogRoute = require('../API/AuditLog/server/auditlog.route'),
    commonRoute = require('../API/Common/server/common.route'),
    dashboardRoute = require('../API/Dashboard/server/dashboard.route'),
    risksissuesRoute = require('../API/RisksIssues/server/risksissues.route'),
    issuesRisksRoute = require('../API/IssuesRisks/server/issues-risks.route'),
    healthscoreRoute = require('../API/HealthScore/server/healthscore.route'),
    detailsRoute = require('../API/Details/server/details.route'),
    DandORoute = require('../API/DnO/server/dno.route'),
    sidebarRoute = require('../API/Sidebar/server/sidebar.route'),
    contractstatusRoute = require('../API/ContractStatus/server/contractstatus.route');


function init(server) {
    server.use('/api/accesscontrol', accesscontrolRoute);
    server.use('/api/auditlog', auditlogRoute);
    server.use('/api/common', commonRoute);
    server.use('/api/dashboard', dashboardRoute);
    server.use('/api/risksissues', risksissuesRoute);
    server.use('/api/issues-risks', issuesRisksRoute);
    server.use('/api/healthscore',healthscoreRoute),
    server.use('/api/details',detailsRoute);
    server.use('/api/sidebar',sidebarRoute);
    server.use('/api/contractstatus', contractstatusRoute);
    server.use('/api/dno',DandORoute);
}

module.exports = {
    init: init
};
