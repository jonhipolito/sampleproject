'use strict';
require('dotenv').config(); // Loads .env (for local) 

const
    express = require('express'),
    middlewares = require('../API/AccessControl/server/middlewares'),
    logRequest = require('morgan'), // use to log every request
    server = express(),
    config = require('../API/AccessControl/configs'),
    routes = require('./routes');

// Server settings
server.set('env', config.env);
server.set('port', config.port);
server.set('hostname', config.hostname);

// parse the url
server.use(express.urlencoded({ extended: false }))
server.use(express.json());

middlewares.init(server);

// init route
routes.init(server);

let hostname = server.get('hostname'),
    port = server.get('port');

server.listen(port, function () {
    console.log('Express server listening on - http://' + hostname + ':' + port);
});

// module.exports = server.start(); //for unit testing