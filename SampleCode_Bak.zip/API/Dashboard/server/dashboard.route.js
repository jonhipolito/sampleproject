'use strict';

const express = require('express');

const dashboardController = require('./dashboard.controller');

const { hasAccess } = require('./middlewares/accesscontrol');

const router = express.Router();


module.exports = router;