'use strict';

const SpannerDB = require('../configs/db.connection');