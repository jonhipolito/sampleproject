process.env.NODE_ENV = 'test';

const sinon = require('sinon');
const chai = require('chai');
const sinonChai = require('sinon-chai');
chai.use(sinonChai);
const expect = chai.expect;
const {describe, beforeEach, afterEach, after, it} = require('mocha');

const IssuesRisksController = require('../server/issues-risks.controller');
const IssuesRisksService = require('../server/issues-risks.service');

describe('Testing IssuesRisksController', () => {
  describe('Testing processMitigationStatus', () => {
    const err = 'err';
    const sendSpy = sinon.spy();
    const nextSpy = sinon.spy();
    const processMitigationStatusMock = sinon.stub();
    const getServiceStub = sinon.stub(IssuesRisksController, 'getService');

    beforeEach(function(done) {
      getServiceStub.returns({
        processMitigationStatus: processMitigationStatusMock
      });
      done();
    });

    afterEach(function(done) {
      sendSpy.resetHistory();
      nextSpy.resetHistory();
      getServiceStub.reset();
      processMitigationStatusMock.reset();
      done();
    });

    after(function(done) {
      getServiceStub.restore();
      done();
    });

    it('processMitigationStatus should call service', async () => {
      processMitigationStatusMock.resolves();

      const req = {};
      const res = {send: sendSpy};
      await IssuesRisksController.processMitigationStatus(req, res, nextSpy);

      expect(processMitigationStatusMock).to.have.been.called;
      expect(sendSpy).to.have.been.calledWith(200);
    });

    it('processMitigationStatus should call next if error occurred', async () => {
      processMitigationStatusMock.throws(err);

      const req = {};
      const res = {};
      await IssuesRisksController.processMitigationStatus(req, res, nextSpy);

      expect(nextSpy.calledOnce).to.be.true;
      const error = nextSpy.firstCall.args[0];
      expect(error).to.be.instanceOf(Error);
      expect(error.message).to.eq(err);
    });
  });

  describe('Testing getService', () => {
    const getInstanceStub = sinon.stub(IssuesRisksService, 'getInstance');

    after(function(done) {
      getInstanceStub.restore();
      done();
    });

    it('getService should call getInstance of IssuesRisksService', async () => {
      const instance = new IssuesRisksService({});
      getInstanceStub.returns(instance);
      const actual = IssuesRisksController.getService();

      const a = IssuesRisksService.getInstance();
      expect(a).to.be.eq(instance);
      expect(actual).to.be.instanceOf(IssuesRisksService);
      expect(actual).to.be.eq(instance);
    });
  });
});
