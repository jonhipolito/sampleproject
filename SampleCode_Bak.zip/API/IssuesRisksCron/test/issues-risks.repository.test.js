process.env.NODE_ENV = 'test';

require('dotenv').config();
const chai = require('chai');
const expect = chai.expect;
const sinon = require('sinon');
const {describe, afterEach, after, it} = require('mocha');

const IssuesRisksRepository = require('../server/issues-risks.repository');

describe('Testing IssuesRisksRepository', () => {
  describe('Testing getInstance', () => {
    it('getInstance', async function() {
      const result = IssuesRisksRepository.getInstance();
      expect(result).to.not.be.null;
    });
  });

  describe('Testing getDatabase', () => {
    it('getDatabase', async function() {
      const repository = new IssuesRisksRepository();
      const result = repository.getDatabase();
      expect(result).to.not.be.null;
    });
  });

  describe('Testing runQueryWithTransaction', () => {
    it('runQueryWithTransaction', async function() {
      const repository = new IssuesRisksRepository();
      const result = await repository.runQueryWithTransaction(
        {},
        {
          run() {
            return [
              [
                {
                  toJSON() {
                    return {};
                  }
                }
              ]
            ];
          }
        }
      );
      expect(result).to.not.be.null;
    });
  });

  describe('Testing processMitigationStatus', () => {
    const repository = new IssuesRisksRepository();
    const stubDb = sinon.stub(repository, 'getDatabase');
    const stub = sinon.stub(repository, 'runQueryWithTransaction');

    afterEach(function(done) {
      stubDb.reset();
      stub.reset();
      done();
    });

    after(function(done) {
      stubDb.restore();
      stub.restore();
      done();
    });

    it(`processMitigationStatus`, async function() {
      stubDb.returns({
        runTransactionAsync(action) {
          action({
            end() {
              console.log('end');
            },
            commit() {
              console.log('commit');
            }
          });
        },
        close() {
          console.log('close');
        }
      });
      stub.resolves([]);
      await repository.processMitigationStatus();
      expect(stub.called).to.true;
    });
  });

  describe('Testing processMitigationStatus err ', () => {
    const repository = new IssuesRisksRepository();
    const stubDb = sinon.stub(repository, 'getDatabase');
    const stub = sinon.stub(repository, 'runQueryWithTransaction');

    afterEach(function(done) {
      stub.reset();
      stubDb.reset();
      done();
    });

    after(function(done) {
      stub.restore();
      stubDb.restore();
      done();
    });

    it(`processMitigationStatus err`, async function() {
      stubDb.returns({
        async runTransactionAsync(action) {
          await action({
            end() {
              console.log('end');
            },
            async rollback() {
              console.log('rollback');
            },
            async commit() {
              throw new Error('err');
            }
          });
        },
        close() {
          console.log('close');
        }
      });
      try {
        await repository.processMitigationStatus();
      } catch (err) {
        expect(err.message).to.eq('err');
      }
    });
  });

  describe('Testing processMitigationStatus err 2', () => {
    const repository = new IssuesRisksRepository();
    const stubDb = sinon.stub(repository, 'getDatabase');

    afterEach(function(done) {
      stubDb.reset();
      done();
    });

    after(function(done) {
      stubDb.restore();
      done();
    });

    it(`processMitigationStatus err 2`, async function() {
      stubDb.returns({
        async runTransactionAsync() {
          throw new Error('err 2');
        },
        close() {
          console.log('close');
        }
      });
      try {
        await repository.processMitigationStatus();
      } catch (err) {
        expect(err.message).to.eq('err 2');
      }
    });
  });
});
