require('./issues-risks.controller.test');
require('./issues-risks.service.test');
require('./issues-risks.repository.test');
