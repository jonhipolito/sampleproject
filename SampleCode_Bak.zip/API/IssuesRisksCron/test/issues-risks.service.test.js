process.env.NODE_ENV = 'test';

const expect = require('chai').expect;
const sinon = require('sinon');
const {describe, after, it} = require('mocha');

const IssuesRisksService = require('../server/issues-risks.service');
const IssuesRisksRepository = require('../server/issues-risks.repository');

describe('Testing IssuesRisksService', () => {
  describe('Testing processMitigationStatus', () => {
    const processMitigationStatusStub = sinon.stub().resolves({});

    const service = new IssuesRisksService({
      processMitigationStatus: processMitigationStatusStub
    });

    it('processMitigationStatus should call repository', async () => {
      await service.processMitigationStatus();
      expect(processMitigationStatusStub.called);
    });
  });

  describe('Testing getService', () => {
    const getInstanceStub = sinon.stub(IssuesRisksRepository, 'getInstance');
    after(function(done) {
      getInstanceStub.restore();
      done();
    });

    it('getService should call getInstance of IssuesRisksRepository', async () => {
      const instance = new IssuesRisksRepository();
      getInstanceStub.returns(instance);
      IssuesRisksService.getInstance();
      expect(getInstanceStub).to.be.have.been.called;
    });
  });
});
