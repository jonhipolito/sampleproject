'use strict';

const { authentication } = require('./authentication');
const { logError, handleError } = require('./errorhandler');

const init = function(server) {
  // verify request from Cron
  server.use(authentication);

  // log error
  server.use(logError);

  // handle error
  server.use(handleError);
};

module.exports = {
  init
};
