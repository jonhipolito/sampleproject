'use strict';

const authentication = (req, res, next) => {
  const isCron = req.header('X-Appengine-Cron')
  if (!isCron) {
    return res.send(401);
  }
  next();
};

module.exports = { authentication };
