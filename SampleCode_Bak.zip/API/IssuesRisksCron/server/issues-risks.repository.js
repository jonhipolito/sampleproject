'use strict';

const SpannerDB = require('../configs/db.connection');

class IssuesRisksRepository {
  constructor() {
    this.migitationStatusInProgress = '101401';
    this.migitationStatusOverdue = '101402';
  }

  static getInstance() {
    return new IssuesRisksRepository();
  }

  async processMitigationStatus() {
    const database = this.getDatabase();
    const query = {
      sql: `UPDATE RiskMitigation
            SET MitigationStatusCd='${this.migitationStatusOverdue}'
            WHERE TIMESTAMP_DIFF(DueDttm, CURRENT_TIMESTAMP, MINUTE)<=-1440
              AND MitigationStatusCd='${this.migitationStatusInProgress}'`
    };
    try {
      await database.runTransactionAsync(async transaction => {
        try {
          await this.runQueryWithTransaction(query, transaction);
          await transaction.commit();
        } catch (err) {
          console.log(err);
          await transaction.rollback();
          throw err;
        } finally {
          transaction.end();
        }
      });
    } catch (err) {
      console.log(err);
      throw err;
    } finally {
      await database.close();
    }
  }

  /**
   * @param {ExecuteSqlRequest|*} query
   * @param {Transaction|*} transaction
   */
  async runQueryWithTransaction(query, transaction) {
    console.log(`DEBUG:ENTER_runQueryWithTransaction`);
    const [rows] = await transaction.run(query);
    return rows.map(o => o.toJSON());
  }

  /**
   * @returns {Database}
   */
  getDatabase() {
    return new SpannerDB();
  }
}

module.exports = IssuesRisksRepository;
