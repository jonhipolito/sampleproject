'use strict';

const IssuesRisksService = require('./issues-risks.service');

class IssuesRisksController {
  static getService() {
    return IssuesRisksService.getInstance();
  }

  static async processMitigationStatus(req, res, next) {
    try {
      const service = IssuesRisksController.getService();
      await service.processMitigationStatus();
      res.send(200);
    } catch (err) {
      next(new Error(err));
    }
  }
}

module.exports = IssuesRisksController;
