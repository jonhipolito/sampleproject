'use strict';

const express = require('express');
const IssuesRisksController = require('./issues-risks.controller');
const router = express.Router();

router.get('/processRiskMitigationStatus', IssuesRisksController.processMitigationStatus);

module.exports = router;
