'use strict';

const IssuesRisksRepository = require('./issues-risks.repository');

class IssuesRisksService {
  constructor(issuesRisksRepository) {
    this.repository = issuesRisksRepository;
  }

  static getInstance() {
    return new IssuesRisksService(IssuesRisksRepository.getInstance());
  }

  async processMitigationStatus() {
    return await this.repository.processMitigationStatus();
  }
}

module.exports = IssuesRisksService;
