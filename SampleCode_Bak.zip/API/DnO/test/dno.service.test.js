process.env.NODE_ENV = 'test';
const dAndoRepository = require('../server/dno.repository');
const dAndoService = require('../server/dno.service');
const sinon = require('sinon');
const chai = require('chai');
const should = chai.should();
const expect = require('chai').expect;

describe('Testing DnO Service', () => {

    
    describe('Create Details Form Test Insert Success', () => {
        before(() => {
            var obj = { length: '0' };
            sinon.stub(dAndoRepository, 'getDelivsObligationsTypeCd').returns(obj);
        })

        after(() => {
            dAndoRepository.getDelivsObligationsTypeCd.restore();
        })

        it("should insert new Details", function (done) {
            var body = { MasterClientNbr: "0123456789", ContractNbr: "CSP1", CreateDttm: "2019-09-20T16:00:00Z",
                        CreateUserId: "test.user",CustomberNbr: "5432106789",DelivsObligationsKey: "test123",
                        DelivsObligationsDesc: "test",DelivsObligationsNm:"test nm",DelivsObligationsTypeCd:"123300",
                        DueDt: "2019-10-20T16:00:00Z",IsCritical:false,RAGStatusCd:"01245",ResponsiblePartyArr:["01244"],
                        SubmissionLevelCd:"01234",SubmissionDelivStatusCd:"01124",UpdateDttm:"2019-09-18T03:55:00.01351Z",
                        UpdateUserId:"" }

            dAndoRepository.createDetailsForm(body)
                .then(message => {
                    message.should.eql('inserted new Details');
                })
                .finally(done())
        });

    });

});