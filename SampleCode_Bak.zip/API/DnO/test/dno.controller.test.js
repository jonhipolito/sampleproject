process.env.NODE_ENV = 'test';
const dAndoController = require('../server/dno.controller');
const dAndoService = require('../server/dno.service');
const sinon = require('sinon');
const chai = require('chai');
const should = chai.should();
const expect = require('chai').expect;

describe('Testing DnO Controller', () => {

    describe('Create Details Form Success', () => {
        before(() => {
            sinon.stub(dAndoService, '_createDetailsForm').returns(new Promise((resolve, reject) => {
                resolve('insert success');
            }));
        })

        after(() => {
            dAndoService._createDetailsForm.restore();
        })

        it("should send a message after insert", function () {
            var req = new Object();
            var res = new Object();

            res.send = function (val) {
                val.should.have.property('message');
                val.should.have.property('message').eql('insert success');
            }

            dAndoController.createDetailInfo(req, res, {});
        });

    });

    describe('getDnOGrid', () => {
        describe('getDnOGrid - success', () => {
            before(() => {
                sinon.stub(dAndoService, '_getDnOGrid').returns(new Promise((resolve, reject) => {
                    resolve('data');
                }));
            })

            after(() => {
                dAndoService._getDnOGrid.restore();
            })

            it("should send a grid data", function () {
                var req = ({
                    params: {
                        mc: '1800002',
                        fc: '2800002',
                        con: '3800002'
                    }
                });
                var res = new Object();

                res.send = function (val) {
                    val.should.have.property('grid');
                    val.should.have.property('grid').eql('data');
                }

                dAndoController.getDnOGrid(req, res, {});
            });
        });

        describe('getDnOGrid - error', () => {
            before(() => {
                sinon.stub(dAndoService, '_getDnOGrid').rejects(new Error('Fake Service Error'));
            })

            after(() => {
                dAndoService._getDnOGrid.restore();
            })

            it("should return an error", function () {
                var req = ({
                    params: {
                        mc: '1800002',
                        fc: '2800002',
                        con: '3800002'
                    }
                });
                var res = new Object();
                var callback = sinon.spy();

                dAndoController.getDnOGrid(req, res, callback);

                try {
                    new ErrorThrowingObject();
                    // Force the test to fail since error wasn't thrown
                    should.fail('no error was thrown when it should have been')
                }
                catch (error) {
                    // console.log(error);
                    // done();
                }
            });

        });
    });

});