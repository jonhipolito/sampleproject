'use strict';

const express = require('express');

const dAndoController = require('./dno.controller');

const router = express.Router();

router.get('/getTestInfo', dAndoController.getTestInfo);
router.get('/getDnOGrid/:mc/:fc/:con', dAndoController.getDnOGrid);
router.post('/saveGrid', dAndoController.saveGrid);
router.get('/getDetailsCd', dAndoController.getDetailsCd);
router.get('/getDetailsForm/:key', dAndoController.getDetailsForm);

// router.post('/createDetailsForm', function(req, res) {
//     dAndoController.createDetailInfo
// });

router.post('/createDetailsForm', dAndoController.createDetailInfo);
router.post('/updateDetailsForm', dAndoController.createDetailInfo);
router.post('/deleteRecords', dAndoController.deleteRecords)
router.post('/dnoExport', dAndoController.dnoExport)
router.get('/dnoGetSignedUrl', dAndoController.dnoGetSignedUrl);
router.post('/dnoImport', dAndoController.dnoImport);
router.post('/saveUserGridView', dAndoController.saveUserGridView);
router.get('/getUserGridView/:pageCd',dAndoController.getUserGridView);
router.post('/updateRecordTimeStamp', dAndoController.updateRecordTimeStamp);
module.exports = router;