'use strict';

const dAndoScoreService = require('./dno.service');

const errorMessage = 'An error has encountered.'

const getTestInfo = (req, res, next) => {
    dAndoScoreService._getTestInfo()
        .then(message => {
            res.send({
                data: message
            });
        })
        .catch(error => {
            res.status(500).send({ errors: error });
        })
}

const createDetailInfo = (req, res, next) => {
    dAndoScoreService._createDetailsForm(req.body)
        .then(message => {
            res.send({
                data: message
            });
        })
        .catch(error => {
            res.status(500).send({ errors: error });
        })
}

const getDnOGrid = (req, res, next) => {
    dAndoScoreService._getDnOGrid(req.params.mc, req.params.fc, req.params.con)
        .then(message => {
            res.status(200).json({
                data: message
            });
        })
        .catch(error => {
            const err = new Error(error);
            next(err);
        })
}

const saveGrid = (req, res, next) => {
    dAndoScoreService._saveGrid(req.body)
        .then(message => {
            res.send({
                data: message
            });
        })
        .catch(error => {
            res.status(500).send({ errors: error });
        })
}

const updateDetailInfo = (req, res, next) => {
    dAndoScoreService._updateDetailsForm(req.body)
        .then(message => {
            res.send({
                data: message
            });
        })
        .catch(error => {
            res.status(500).send({ errors: error });
        })
}

const deleteRecords = (req, res, next) => {
    if (!req.body) {
        res.status(200);
        return;
    }
    dAndoScoreService._deleteRecords(req.body)
        .then(message => {
            res.send({
                data: message
            });
        })
        .catch(error => {
            res.status(500).send({ errors: error });
    })
}

const getDetailsCd = (req, res, next) => {
    dAndoScoreService._getDetailsCd()
        .then(message => {
            res.send({
                data: message
            });
        })
        .catch(error => {
            res.status(500).send({ errors: error });
        })
}

const getDetailsForm = (req, res, next) => {
    dAndoScoreService._getDetailsForm(req.params.key)
        .then(data => {
            res.status(200).json({
                data: data
            });
        })
        .catch(error => {
            const err = new Error(error);
            next(err);
        })
}

const dnoExport = (req, res, next) => {
    dAndoScoreService._dnoExport(req.body)
        .then(data => {
            res.set('Response-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            res.status(200).send(data);
        })
        .catch(error => {
            const err = new Error(error);
            next(err);
        })
}

const dnoGetSignedUrl = (req, res, next) => {
    dAndoScoreService._generateSignedUploadUrl()
        .then(data => {
            res.status(200).send(data);
        })
        .catch(error => {
            res.status(500).send(error);
        })
}

const dnoImport = (req, res, next) => {
    try {
        dAndoScoreService._dnoImport(req.body)
        .then(data => {
            res.status(200).send(data);
        }, error => {            
            res.status(500).send(error);
        });
    }
    catch(err) {        
        res.status(500).send(err);
    }

}

const saveUserGridView = (req, res, next) => {
    dAndoScoreService._saveUserGridView(req.body)
        .then(message => {
            res.send({
                data: message
            });
        })
        .catch(error => {
            res.status(500).send({ errors: error });
        })
}

const getUserGridView = (req, res, next) => {
    dAndoScoreService._getUserGridView(req.params.pageCd)
        .then(data => {
            res.status(200).json({
                data: data
            });
        })
        .catch(error => {
            const err = new Error(error);
            next(err);
        })
}

const updateRecordTimeStamp = (req, res, next) => {
    dAndoScoreService._updateRecordTimeStamp(req.body)
        .then(data => {
            res.status(200).send();
        })
        .catch(error => {
            const err = new Error(error);
            next(err);
        })
}

module.exports = {
    getTestInfo,
    getDnOGrid,
    createDetailInfo,
    saveGrid,
    updateDetailInfo,
    deleteRecords,
    getDetailsCd,
    getDetailsForm,
    dnoExport,
    dnoGetSignedUrl,
    dnoImport,
    saveUserGridView,
    getUserGridView,
    updateRecordTimeStamp
}
