'use strict';

const detailsModel = require('./models/dno-create-details.model');
const responsible = require('./models/responsible.model');

const uuid = require('uuidv4');
const _ = require('lodash');
const dAndoRepository = require('./dno.repository');
const moment = require('moment');
const Excel = require('exceljs');
const { Storage } = require('@google-cloud/storage');
const random = require('string-random');

var ImportColumns = [
  { name: 'ID', type: 'int', required: false },
  { name: 'Master Client', type: 'string', required: true },
  { name: 'Financial Client', type: 'string', required: false },
  { name: 'Contract', type: 'string', required: false },
  { name: 'Type', type: 'string', required: true, codeheader: 1023 },
  { name: 'Name', type: 'string', required: true, length: 500, validateChar: true },
  { name: 'Description', type: 'string', required: true, validateChar: true },
  { name: 'Acceptance', type: 'string', required: true, codeheader: 1027 },
  { name: 'Delivery Status', type: 'string', required: true, codeheader: 1025 },
  { name: 'RAG Status', type: 'string', required: true, codeheader: 1024 },
  { name: 'Responsible', type: 'string', required: true },
  { name: 'Critical', type: 'string', required: true },
  { name: 'Due Date', type: 'date', required: true },
  { name: 'Completed/Submitted Date', type: 'date', required: false },
  { name: 'Completed/Submitted By', type: 'string', required: false, validateChar: true },
  { name: 'Review Period', type: 'int' },
  { name: 'Date', type: 'date', required: false },
  { name: 'By', type: 'string', required: false, length: 50, validateChar: true },
  { name: 'Client Reference', type: 'string', required: false, length: 300, validateChar: true },
  { name: 'Contract Document', type: 'string', required: false, length: 300, validateChar: true },
  { name: 'Section/Paragraph', type: 'string', required: false, length: 300, validateChar: true },
  { name: 'Workstream', type: 'string', required: false, length: 300, validateChar: true },
  { name: 'Tower', type: 'string', required: false, length: 300, validateChar: true },
  { name: 'Comments', type: 'string', required: false, validateChar: true },

];

const _getTestInfo = () => {
  return new Promise(async function (resolve, reject) {
    var res = await dAndoRepository.getTestInfo();
    resolve(res);
  });
}

const _createDetailsForm = async (model) => {
  let res;
  let detModel = new detailsModel(model);
  detModel.DetailID = detModel.DetailID ? detModel.DetailID : generateRandomID()
  let newModel = [];

  return new Promise((resolve, reject) => {
    try {
      //Create new records for recurrence
      if (model.recurrenceFrequency) {
        model.recurDueDate.map(duedate => {
          var cloneObj = _.cloneDeep(detModel);
          cloneObj.DueDt = duedate;
          cloneObj.DelivsObligationsKey = uuid();
          cloneObj.DetailID = generateRandomID();
          cloneObj.CreateDttm = 'spanner.commit_timestamp()';
          cloneObj.CreateUserId = process.env.ENTERPRISEID;
          reccurenceCheckDate(cloneObj);
          newModel.push(cloneObj);
        })
      }

      //Push original create/update model
      newModel.push(detModel);

      res = dAndoRepository.createDetailsForm(newModel);
      resolve(res);
    } catch (err) {
      console.log(err);
      return new Error(err);
    }
  });
}

const _getDnOGrid = (mc, fc, con) => {
  return new Promise(async function (resolve, reject) {
    var res = await dAndoRepository.getDnOGrid(mc, fc, con);
    var conOptions = await dAndoRepository.getContractOptions(mc);

    try {
      let data = {
        grid: [],
        contractOptions: [],
      }
      let rows = [];
      if (res) {
        res.forEach(row => {
          row = _validateRagStatus(row);

          row.forEach(col => {
            if (col.value && col.name == 'DueDt') {
              var dateValue = moment(col.value).format('DD-MMM-YYYY');
              col.value = dateValue;
            }
          })
          rows.push(row);
        })
      }
      else {
        rows = null;
      }
      data.grid = rows;
      data.contractOptions = conOptions;
      resolve(data);
      data.catch(err);

    } catch (err) {

      return reject(err);

    }
  })
}

const _saveGrid = (body) => {
  return new Promise(async function (resolve, reject) {
    try {
      var res;
      for (let x = 0; x < body.length; x++) {
        var rowJSON = {};
        rowJSON.DelivsObligationsKey = body[x].DelivsObligationsKey;
        rowJSON.DelivsObligationsNm = body[x].DelivsObligationsNm;
        rowJSON.DelivsObligationsDesc = body[x].DelivsObligationsDesc;
        rowJSON.DueDt = moment.utc(moment(body[x].DueDt, "DD-MMM-YYYY").format("YYYY-MM-DD")).format();
        rowJSON.CustomerNbr = GetNbr(body[x].Customer);
        rowJSON.ContractNbr = GetNbr(body[x].Contract);
        rowJSON.UpdateDttm = new Date();
        rowJSON.UpdateUserId = process.env.ENTERPRISEID;
        res = await dAndoRepository.updateDeliverablesObligation(rowJSON, body[x]);
      }
      resolve(res);
      res.catch(err);
    } catch (err) {
      return reject(err);
    }
  })
}

const _deleteRecords = async (body) => {
  try {
    return await dAndoRepository.deleteRecords(body.DelivsObligationsKeys);
  } catch (err) {
    console.error('ERROR:', err);
    return reject(err);
  } finally {

  }
}


const _getDetailsCd = () => {
  return new Promise(async function (resolve, reject) {
    var res = await dAndoRepository.getDetailsCd();
    try {
      var data;
      if (res) {
        let resJSON = JSON.stringify(res);
        let resParse = JSON.parse(resJSON);

        let type = resParse.filter(x => x.CodeHeaderId == 1023);
        let rag = resParse.filter(x => x.CodeHeaderId == 1024);
        let responsible = resParse.filter(x => x.CodeHeaderId == 1026);
        let level = resParse.filter(x => x.CodeHeaderId == 1027);
        let delivStatus = resParse.filter(x => x.CodeHeaderId == 1025);

        data = {
          type: type,
          rag: rag,
          responsible: responsible,
          level: level,
          delivStatus: delivStatus
        }

      } else {
        data = res;
      }
      resolve(data);

    } catch (err) {

      return reject(err);

    }
  })
}

const _getDetailsForm = (key) => {
  return new Promise(async function (resolve, reject) {
    var res = await dAndoRepository.getDetailsForm(key, process.env.ENTERPRISEID);
    try {
      resolve(res);
      res.catch(err);
    } catch (err) {
      return reject(err);
    }
  })
}

function GetFromArray(arr, findprop, returnprop, value) {
  if (!arr) {
    return '';
  }
  let row = arr.find(x => x[findprop].toUpperCase() == value.toUpperCase());
  if (row) {
    return row[returnprop];
  }
  else {
    return '';
  }
}

function GetResponsible(codedetails, respArray = [], findprop = 'CodeTxt', returnprop = 'PrimaryDecodeTxt', returnArray = false) {
  let vals = [];
  if (!respArray) {
    return '';
  }
  respArray.forEach(x => {
    let val = GetFromArray(codedetails, findprop, returnprop, x.trim());
    if (val) {
      vals.push(val)
    }
  })
  if (returnArray) {
    return vals.sort();
  }
  return vals.sort().join(', ');
}

function ComputeDeliveryStatus(codedetail, rec) {
  let SubmissionLevel = GetFromArray(codedetail, "CodeTxt", "PrimaryDecodeTxt", rec.SubmissionLevelCd)
  switch (SubmissionLevel.toUpperCase()) {
    case "Not Required".toUpperCase():
      rec.SubmissionDelivStatusCd = GetFromArray(codedetail, "PrimaryDecodeTxt", "CodeTxt", "Pending");
      if (rec.CompletedDttm) {
        rec.SubmissionDelivStatusCd = GetFromArray(codedetail, "PrimaryDecodeTxt", "CodeTxt", "Completed");
      }
      break;
    case "Required".toUpperCase():
      rec.SubmissionDelivStatusCd = GetFromArray(codedetail, "PrimaryDecodeTxt", "CodeTxt", "Pending Submission");
      if (rec.SubmittedDttm) {
        rec.SubmissionDelivStatusCd = GetFromArray(codedetail, "PrimaryDecodeTxt", "CodeTxt", "Submitted");
      }
      break;
    case "Required with Acceptance".toUpperCase():
    case "Required with Deemed Acceptance".toUpperCase():
      rec.SubmissionDelivStatusCd = GetFromArray(codedetail, "PrimaryDecodeTxt", "CodeTxt", "Pending Submission");
      if (rec.SubmissionAcceptDt > rec.SubmittedDttm && rec.SubmissionAcceptDt > rec.SubmissionRejectDt) {
        rec.SubmissionDelivStatusCd = GetFromArray(codedetail, "PrimaryDecodeTxt", "CodeTxt", "Accepted");
      }
      if (rec.SubmissionRejectDt > rec.SubmissionAcceptDt && rec.SubmissionRejectDt > rec.SubmittedDttm) {
        rec.SubmissionDelivStatusCd = GetFromArray(codedetail, "PrimaryDecodeTxt", "CodeTxt", "Rejected");
      }
      if (rec.SubmittedDttm > rec.SubmissionAcceptDt && rec.SubmittedDttm > rec.SubmissionRejectDt) {
        rec.SubmissionDelivStatusCd = GetFromArray(codedetail, "PrimaryDecodeTxt", "CodeTxt", "Pending Acceptance");
      }
      break;
  }
  return rec
}
function ValidateDeliveryStatus(SubmissionLevel, DeliveryStatus) {
  SubmissionLevel = SubmissionLevel.toUpperCase()
  DeliveryStatus = DeliveryStatus.toUpperCase()
  let notRequired = ['Pending', 'Completed'];
  let required = ['Pending Submission', 'Submitted'];
  let requiredAcceptance = ['Pending Submission', 'Pending Acceptance', 'Accepted', 'Rejected'];
  let requiredDeemedAcceptance = ['Pending Submission', 'Pending Acceptance', 'Accepted', 'Rejected', 'Deemed Accepted'];
  switch (SubmissionLevel) {
    case "Not Required".toUpperCase():
      return notRequired.map(x => x.toUpperCase()).indexOf(DeliveryStatus) > -1
    case "Required".toUpperCase():
      return required.map(x => x.toUpperCase()).indexOf(DeliveryStatus) > -1
    case "Required with Acceptance".toUpperCase():
      return requiredAcceptance.map(x => x.toUpperCase()).indexOf(DeliveryStatus) > -1
    case "Required with Deemed Acceptance".toUpperCase():
      return requiredDeemedAcceptance.map(x => x.toUpperCase()).indexOf(DeliveryStatus) > -1
    default:
      return false;
  }
}

function ProcessHeaderRow(row) {
  let keys = row.map(x => {
    return x.model.value;
  });
  let cnt = 1;
  keys.forEach(key => {
    let col = {};
    let k = key.replace("*", "").replace(":", "").toUpperCase();
    ImportColumns.forEach((col, idx) => {
      if (col.name.toUpperCase() == k) {
        col.index = idx + 1;
        if (key.indexOf('*') > key.length - 3) {
          col.required = true;
        }
        else {
          col.required = false;
        }
      }
    });
  });
}
async function GetDnOExportDetails(body) {
  let dnofilter, mcfcconfilter;
  if (body.ContractNbr) {
    dnofilter = `do.ContractNbr = '${body.ContractNbr}'`
    mcfcconfilter = `con.ContractNbr = '${body.ContractNbr}'`
  }
  else if (body.CustomerNbr) {
    dnofilter = `do.CustomerNbr = '${body.CustomerNbr}'`
    mcfcconfilter = `cus.CustomerNbr = '${body.CustomerNbr}'`
  }
  else if (body.MasterClientNbr) {
    dnofilter = `do.MasterClientNbr = '${body.MasterClientNbr}'`
    mcfcconfilter = `mc.MasterClientNbr = '${body.MasterClientNbr}'`
  }

  let dno = dAndoRepository.QueryDnO(dnofilter, process.env.ENTERPRISEID);
  let cd = await dAndoRepository.getDetailsCd();
  let mcfccon = await dAndoRepository.GetMCFCCON(mcfcconfilter, process.env.ENTERPRISEID);
  dno = await dno;
  let codedetail = [];
  cd.forEach(x => {
    let item = x.toJSON();
    codedetail.push(item);
  });
  let details = [];
  dno.slice(0, 2000).forEach(row => {
    row = _validateRagStatus(row);
    let item = row.toJSON();
    item.ID = item.DetailID;
    item.MC = item.MasterClientNbr ? GetFromArray(mcfccon, "MasterClientNbr", "MasterClientNm", item.MasterClientNbr) + ' - ' + item.MasterClientNbr : '';
    item.FC = item.CustomerNbr ? GetFromArray(mcfccon, "CustomerNbr", "CustomerNm", item.CustomerNbr) + ' - ' + item.CustomerNbr : '';
    item.CON = item.ContractNbr ? GetFromArray(mcfccon, "ContractNbr", "ContractNm", item.ContractNbr) + ' - ' + item.ContractNbr : '';
    item.Type = item.DelivsObligationsTypeCd ? GetFromArray(codedetail, "CodeTxt", "PrimaryDecodeTxt", item.DelivsObligationsTypeCd) : '';
    item.Name = item.DelivsObligationsNm;
    item.Description = item.DelivsObligationsDesc;
    item.Acceptance = item.SubmissionLevelCd ? GetFromArray(codedetail, "CodeTxt", "PrimaryDecodeTxt", item.SubmissionLevelCd) : '';
    item.DeliveryStatus = item.SubmissionDelivStatusCd ? GetFromArray(codedetail, "CodeTxt", "PrimaryDecodeTxt", item.SubmissionDelivStatusCd) : '';
    item.Responsible = GetResponsible(codedetail, item.ResponsiblePartyArr);
    item.Critical = item.IsCritical ? "Yes" : "No";
    item.DueDt = new Date(item.DueDt);
    if (item.Acceptance == 'Not Required') {
      item.CompletedSubmittedDate = item.CompletedDttm ? new Date(item.CompletedDttm) : null;
      item.CompletedSubmittedBy = item.CompletedBy;
    }
    else {
      item.CompletedSubmittedDate = item.CompletedDttm ? new Date(item.SubmittedDttm) : null;
      item.CompletedSubmittedBy = item.SubmittedBy;
    }

    item.ReviewPeriod = item.SubmissionReviewPeriod;
    item.Date = new Date(item.CreateDttm);
    item.By = item.CreateUserId;
    details.push(item);
  });
  return details;
}
function ArrayFind(arr, prop, value, ret) {
  let val = arr.find(x => x[prop] == value);
  if (val) {
    return val[ret];
  }
  return '';
}
function GenerateTemplate(details) {
  return new Promise(async (resolve) => {
    const storage = new Storage();
    if (details) {
      let readstream = storage.bucket(process.env.STORAGEBUCKET).file(`excel-templates/DNO - Template.xlsx`).createReadStream();
      var workbook = new Excel.Workbook();
      let writeStream = workbook.xlsx.createInputStream();
      readstream.pipe(writeStream);
      writeStream.on('done', async () => {
        let ws = workbook.getWorksheet("Insert Deliverables Information");
        ProcessHeaderRow(ws.getRow(1)._cells);
        let cols = ImportColumns;
        let ctr = 2;
        details.forEach(d => {
          ws.getCell(ctr, ArrayFind(cols, 'name', 'ID', 'index')).value = d.ID
          ws.getCell(ctr, ArrayFind(cols, 'name', 'Master Client', 'index')).value = d.MC
          ws.getCell(ctr, ArrayFind(cols, 'name', 'Financial Client', 'index')).value = d.FC
          ws.getCell(ctr, ArrayFind(cols, 'name', 'Contract', 'index')).value = d.CON
          ws.getCell(ctr, ArrayFind(cols, 'name', 'Type', 'index')).value = d.Type
          ws.getCell(ctr, ArrayFind(cols, 'name', 'Name', 'index')).value = d.Name
          ws.getCell(ctr, ArrayFind(cols, 'name', 'Description', 'index')).value = d.Description
          ws.getCell(ctr, ArrayFind(cols, 'name', 'Acceptance', 'index')).value = d.Acceptance
          ws.getCell(ctr, ArrayFind(cols, 'name', 'Delivery Status', 'index')).value = d.DeliveryStatus
          ws.getCell(ctr, ArrayFind(cols, 'name', 'RAG Status', 'index')).value = d.RAGStatus
          ws.getCell(ctr, ArrayFind(cols, 'name', 'Responsible', 'index')).value = d.Responsible
          ws.getCell(ctr, ArrayFind(cols, 'name', 'Critical', 'index')).value = d.Critical
          ws.getCell(ctr, ArrayFind(cols, 'name', 'Due Date', 'index')).value = d.DueDt
          if (d.Acceptance == 'Not Required') {
            ws.getCell(ctr, ArrayFind(cols, 'name', 'Completed/Submitted Date', 'index')).value = d.CompletedDttm
            ws.getCell(ctr, ArrayFind(cols, 'name', 'Completed/Submitted By', 'index')).value = d.CompletedBy
          }
          else {
            ws.getCell(ctr, ArrayFind(cols, 'name', 'Completed/Submitted Date', 'index')).value = d.SubmittedDttm
            ws.getCell(ctr, ArrayFind(cols, 'name', 'Completed/Submitted By', 'index')).value = d.SubmittedBy
          }
          ws.getCell(ctr, ArrayFind(cols, 'name', 'Review Period', 'index')).value = d.ReviewPeriod
          ws.getCell(ctr, ArrayFind(cols, 'name', 'Date', 'index')).value = d.Date
          ws.getCell(ctr, ArrayFind(cols, 'name', 'By', 'index')).value = d.By
          ws.getCell(ctr, ArrayFind(cols, 'name', 'Client Reference', 'index')).value = d.OptionalClientReference
          ws.getCell(ctr, ArrayFind(cols, 'name', 'Contract Document', 'index')).value = d.OptionalContractDocument
          ws.getCell(ctr, ArrayFind(cols, 'name', 'Section/Paragraph', 'index')).value = d.OptionalSectionParagraph
          ws.getCell(ctr, ArrayFind(cols, 'name', 'Workstream', 'index')).value = d.OptionalWorkstream
          ws.getCell(ctr, ArrayFind(cols, 'name', 'Tower', 'index')).value = d.OptionalTower
          ws.getCell(ctr, ArrayFind(cols, 'name', 'Comments', 'index')).value = d.OptionalComments
          ctr++;
        });

        formatExcel(ws);
        workbook.xlsx.writeBuffer()
          .then(function (buffer) {
            resolve(buffer);
          });
      });
    }
    else {
      let file = storage.bucket(process.env.STORAGEBUCKET).file(`excel-templates/DNO - Template.xlsx`)
      file.download(function (err, contents) {
        resolve(contents);
      });
    }
  });
}
const formatExcel = async (ws) => {
  ws.unprotect();
  let cnt = 0;
  ws.eachRow({ includeEmpty: true }, function (row, rowNumber) {
    if (rowNumber > 1) {
      for (let x = 1; x <= cnt; x++) {
        row.getCell(x).protection = {
          locked: false,
          hidden: false
        };
      }
    }
    else {
      row.eachCell({ includeEmpty: true }, function (cell, colNumber) {
        cnt++;
        cell.alignment = { vertical: 'middle', horizontal: 'center' };
        cell.protection = {
          locked: true,
          hidden: false
        };
      });
    }
  });
  await ws.protect('Orion', {
    selectLockedCells: true,
    selectUnlockedCells: true,
    formatCells: true,
    formatColumns: true,
    deleteRows: true
  });
}
const _dnoExport = (body) => {
  return new Promise(async (resolve) => {
    let details = null;
    if (body.ExportType == 'Existing') {
      details = await GetDnOExportDetails(body);
    }

    try {
      let result = await GenerateTemplate(details);
      resolve(result);
    } catch (error) {
      console.log("_dnoExport", error);
    } finally {
    }
  });
}

const _generateSignedUploadUrl = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const storage = new Storage();
      const options = {
        version: 'v4',
        action: 'write',
        expires: Date.now() + 10 * 60 * 1000,
      };
      let date = new Date().toISOString();
      let Filename = `${process.env.ENTERPRISEID}/DNO - ${date}.xlsx`
      const [url] = await storage.bucket(process.env.STORAGEBUCKET)
        .file(`user-imports/${Filename}`).getSignedUrl(options);

      console.log("signed-url", url);
      resolve({
        Url: url,
        Filename: Filename
      });
    } catch (error) {
      console.log("error: ", error);
      reject(error);
    }

  });
}

const GetRowValues = (row) => {
  let val = {
    ID: row[ArrayFind(ImportColumns, 'name', 'ID', 'index')],
    MasterClient: row[ArrayFind(ImportColumns, 'name', 'Master Client', 'index')],
    FinancialClient: row[ArrayFind(ImportColumns, 'name', 'Financial Client', 'index')],
    Contract: row[ArrayFind(ImportColumns, 'name', 'Contract', 'index')],
    Type: row[ArrayFind(ImportColumns, 'name', 'Type', 'index')],
    Name: row[ArrayFind(ImportColumns, 'name', 'Name', 'index')],
    Description: row[ArrayFind(ImportColumns, 'name', 'Description', 'index')],
    Acceptance: row[ArrayFind(ImportColumns, 'name', 'Acceptance', 'index')],
    DeliveryStatus: row[ArrayFind(ImportColumns, 'name', 'Delivery Status', 'index')],
    RAGStatus: row[ArrayFind(ImportColumns, 'name', 'RAG Status', 'index')],
    Responsible: row[ArrayFind(ImportColumns, 'name', 'Responsible', 'index')],
    Critical: row[ArrayFind(ImportColumns, 'name', 'Critical', 'index')],
    DueDate: row[ArrayFind(ImportColumns, 'name', 'Due Date', 'index')],
    CompletedSubmittedDate: row[ArrayFind(ImportColumns, 'name', 'Completed/Submitted Date', 'index')],
    CompletedSubmittedBy: row[ArrayFind(ImportColumns, 'name', 'Completed/Submitted By', 'index')],
    ReviewPeriod: row[ArrayFind(ImportColumns, 'name', 'Review Period', 'index')],
    Date: row[ArrayFind(ImportColumns, 'name', 'Date', 'index')],
    By: row[ArrayFind(ImportColumns, 'name', 'By', 'index')],
    ClientReference: row[ArrayFind(ImportColumns, 'name', 'Client Reference', 'index')],
    ContractDocument: row[ArrayFind(ImportColumns, 'name', 'Contract Document', 'index')],
    SectionParagraph: row[ArrayFind(ImportColumns, 'name', 'Section/Paragraph', 'index')],
    Workstream: row[ArrayFind(ImportColumns, 'name', 'Workstream', 'index')],
    Tower: row[ArrayFind(ImportColumns, 'name', 'Tower', 'index')],
    Comments: row[ArrayFind(ImportColumns, 'name', 'Comments', 'index')]
  }
  Object.keys(val).forEach(v => {
    if (val[v] && (typeof val[v] === 'string' || val[v] instanceof String)) {
      val[v] = val[v].toString().trim()
    }
    if (val[v] == undefined) {
      val[v] = null;
    }
  });
  return val;
}

const _validateImportRow = (ws, row, rowNum, mcfccon, input, codedetail, dnos) => {
  return new Promise(async (resolve) => {
    let errors = [];
    let requiredCols = ImportColumns.filter(x => x.required);
    let codedetailCols = ImportColumns.filter(x => x.codeheader);
    let dateCols = ImportColumns.filter(x => x.type == 'date');
    let stringCols = ImportColumns.filter(x => x.type == 'string');
    let intCols = ImportColumns.filter(x => x.type == 'int');
    let invalidChars = RegExp(/[<>"%;()&@+{}#:?*$~|'/\-[\]]/)
    for (let x = 0; x < requiredCols.length; x++) {
      if (!row[requiredCols[x].index]) {
        errors.push({
          cell: ws.getRow(rowNum).getCell(requiredCols[x].index)._address,
          error: 'This is a required field.'
        })
      }
    }
    for (let x = 0; x < stringCols.length; x++) {
      if (row[stringCols[x].index] && stringCols[x].length && row[stringCols[x].index].length > stringCols[x].length) {
        errors.push({
          cell: ws.getRow(rowNum).getCell(stringCols[x].index)._address,
          error: `Value should not exceed ${stringCols[x].length} character`
        })
      }
      if (row[stringCols[x].index] && stringCols[x].validateChar && invalidChars.test(row[stringCols[x].index])) {
        errors.push({
          cell: ws.getRow(rowNum).getCell(stringCols[x].index)._address,
          error: `Value contains an invalid character`
        })
      }
    }
    for (let x = 0; x < intCols.length; x++) {
      if (row[intCols[x].index] && isNaN(row[intCols[x].index])) {
        errors.push({
          cell: ws.getRow(rowNum).getCell(intCols[x].index)._address,
          error: `Value is not a valid number.`
        })
      }
    }
    for (let x = 0; x < codedetailCols.length; x++) {
      if (row[codedetailCols[x].index] && codedetail.filter(y => y.PrimaryDecodeTxt.toUpperCase() == row[codedetailCols[x].index].toUpperCase()).length == 0) {
        errors.push({
          cell: ws.getRow(rowNum).getCell(codedetailCols[x].index)._address,
          error: 'The field has an invalid value.'
        })
      }
    }
    for (let x = 0; x < dateCols.length; x++) {
      if (row[dateCols[x].index] && !moment(row[dateCols[x].index]).isValid()) {
        errors.push({
          cell: ws.getRow(rowNum).getCell(dateCols[x].index)._address,
          error: 'The value is not a valid date.'
        })
      }
    }
    let val = GetRowValues(row);
    if (val.ID) {
      let record = dnos.filter(x => {
        x = x.toJSON();
        return x.DetailID == val.ID
      });
      if (record.length == 0) {
        errors.push({
          cell: ws.getRow(rowNum).getCell(ImportColumns.find(x => x.name == "ID").index)._address,
          error: 'The ID you are trying to edit does not exist or you do not have access.'
        })
      }
      else {
        let rec = record[0].toJSON();
        if ((new Date(val.CompletedSubmittedDate) > new Date(rec.SubmissionRejectDt) && rec.SubmissionRejectDt) || (new Date(val.CompletedSubmittedDate) > new Date(rec.SubmissionAcceptDt) && rec.SubmissionAcceptDt)) {
          errors.push({
            cell: ws.getRow(rowNum).getCell(ImportColumns.find(x => x.name == "Completed/Submitted Date").index)._address,
            error: 'Submitted date should be less than Accepted/Rejected dates.'
          })
        }
      }
    }
    if (val.MasterClient) {
      let mcArr = val.MasterClient.split("-");
      if (mcArr.length > 0) {
        let mc = mcArr[mcArr.length - 1].trim();
        let hierarchy = mcfccon.filter(x => x.MasterClientNbr = mc);
        if (hierarchy.filter(x => val.MasterClient.indexOf(x.MasterClientNbr) > -1).length == 0) {
          errors.push({
            cell: ws.getRow(rowNum).getCell(ImportColumns.find(x => x.name == "ID").index)._address,
            error: 'You are trying to import to a Master Client that does not exist or you do not have access'
          })
        }
        if (val.FinancialClient && val.FinancialClient.length > 0 && hierarchy.filter(x => val.FinancialClient.indexOf(x.CustomerNbr) > -1).length == 0) {
          errors.push({
            cell: ws.getRow(rowNum).getCell(ImportColumns.find(x => x.name == "Financial Client").index)._address,
            error: 'You are trying to import to a Financial Client that does not exist or you do not have access'
          })
        }
        if (val.Contract && val.Contract.length > 0 && hierarchy.filter(x => val.Contract.indexOf(x.ContractNbr) > -1).length == 0) {
          errors.push({
            cell: ws.getRow(rowNum).getCell(ImportColumns.find(x => x.name == "Contract").index)._address,
            error: 'You are trying to import to a Contract that does not exist or you do not have access'
          })
        }
      }
    }

    if (input && val.MasterClient) {
      if (input.MasterClientNbr && val.MasterClient && val.MasterClient.indexOf(input.MasterClientNbr) == -1) {
        errors.push({
          cell: ws.getRow(rowNum).getCell(ImportColumns.find(x => x.name == "Master Client").index)._address,
          error: 'You cannot import to a Master Client that is not in your active view'
        })
      }
      else if (input.FinancialClientNbr && val.FinancialClient && val.FinancialClient.indexOf(input.FinancialClientNbr) == -1) {
        errors.push({
          cell: ws.getRow(rowNum).getCell(ImportColumns.find(x => x.name == "Financial Client").index)._address,
          error: 'You cannot import to a Financial Client that is not in your active view'
        })
      }
      else if (input.ContractNbr && val.Contract && val.Contract.indexOf(input.ContractNbr) == -1) {
        errors.push({
          cell: ws.getRow(rowNum).getCell(ImportColumns.find(x => x.name == "Contract").index)._address,
          error: 'You cannot import to a Contract that is not in your active view'
        })
      }
      else if ((input.FinancialClientNbr || input.ContractNbr) && !val.FinancialClient && !val.Contract) {
        errors.push({
          cell: ws.getRow(rowNum).getCell(ImportColumns.find(x => x.name == "Master Client").index)._address,
          error: 'You cannot import to a Master Client while you are viewing at a Financial Client/Contract level'
        })
      }
      else if (input.ContractNbr && !val.Contract) {
        errors.push({
          cell: ws.getRow(rowNum).getCell(ImportColumns.find(x => x.name == "Master Client").index)._address,
          error: 'You cannot import to a Master/Financial Client while you are viewing at a Contract level'
        })
      }
    }

    if (!ValidateDeliveryStatus(val.Acceptance, val.DeliveryStatus)) {
      errors.push({
        cell: ws.getRow(rowNum).getCell(ImportColumns.find(x => x.name == "Delivery Status").index)._address,
        error: 'The selected Delivery Status is not valid for the selected Acceptance value.'
      })
    }

    if (GetResponsible(codedetail, val.Responsible.split(","), "PrimaryDecodeTxt", "CodeTxt", true).length == 0) {
      errors.push({
        cell: ws.getRow(rowNum).getCell(ImportColumns.find(x => x.name == "Delivery Status").index)._address,
        error: 'The field has an invalid value.'
      })
    }
    resolve(errors);
  });
}

const _validateRagStatus = (row) => {
  let dueDt;
  let todayDt;
  let ragStatus;
  let delivStatus;
  let ragIndex;

  console.log("DNO validate", row);
  row.forEach((col, index) => {
    if (col.value && col.name == "RAGStatus") {
      ragStatus = col.value;
      ragIndex = index;
    }

    if (col.value && col.name == 'DueDt') {
      dueDt = moment(col.value).format('DD-MMM-YYYY');
      todayDt = moment().format('DD-MMM-YYYY');
    }

    if (col.value && col.name == 'SubmissionDelivStatus') {
      delivStatus = col.value;
    }
  });

  if (dueDt && ragStatus && delivStatus) {
    if (
      delivStatus == "Completed"
      || delivStatus == "Submitted"
      || delivStatus == "Accepted"
      || delivStatus == "Deemed Accepted"
    ) {
      row[ragIndex].value = "Green";
    } else {
      if ((todayDt > dueDt && (
        delivStatus == "Pending"
        || delivStatus == "Pending Submission"
        || delivStatus == "Pending Acceptance")
      ) || delivStatus == "Rejected") {
        row[ragIndex].value = "Red";
      }
      if (dueDt == todayDt && delivStatus == "Pending Submission") {
        row[ragIndex].value = "Amber";
      }
    }
  }

  return row;
}

const _processImportRows = async (rows, access, codedetail, dnos) => {
  return new Promise(async (resolve, reject) => {
    let compStatus = ['Submitted', 'Accepted', 'Rejected', 'Deemed Accepted']
    let recs = [];
    for (let y = 0; y < rows.length; y++) {
      let mcfccon = JSON.parse(JSON.stringify(access));
      let val = GetRowValues(rows[y]);
      console.log("val", JSON.stringify(val))
      let rec;
      if (val.ID) {
        let record = dnos.filter(x => {
          x = x.toJSON()
          return x.DetailID == val.ID
        });
        if (record.length > 0) {
          rec = record[0].toJSON();
        }
      }
      else {
        rec = new detailsModel({});
        rec.DelivsObligationsKey = uuid();
        rec.CreateUserId = process.env.ENTERPRISEID;
        rec.CreateDttm = 'spanner.commit_timestamp()';
        rec.DetailID = generateRandomID()
      }
      let hierarchy;
      if (val.Contract) {
        let conArr = val.Contract.split("-");
        let con = conArr[conArr.length - 1].trim();
        hierarchy = mcfccon.find(x => x.ContractNbr == con.replace(/ /g, ""));
      }
      else if (val.FinancialClient) {
        let cusArr = val.FinancialClient.split("-");
        let cus = cusArr[cusArr.length - 1].trim();
        hierarchy = mcfccon.find(x => x.CustomerNbr == cus.replace(/ /g, ""));
      }
      else {
        let mcArr = val.MasterClient.split("-");
        let mc = mcArr[mcArr.length - 1].trim();
        hierarchy = mcfccon.find(x => x.MasterClientNbr == mc.replace(/ /g, ""));
      }
      if (!val.ID) {
        rec.MasterClientNbr = hierarchy.MasterClientNbr;
      }
      rec.CustomerNbr = ''
      rec.ContractNbr = ''
      if (val.FinancialClient) {
        rec.CustomerNbr = hierarchy.CustomerNbr;
      }
      if (val.Contract) {
        rec.ContractNbr = hierarchy.ContractNbr;
      }
      rec.DelivsObligationsTypeCd = GetFromArray(codedetail, "PrimaryDecodeTxt", "CodeTxt", val.Type);
      rec.DelivsObligationsNm = val.Name;
      rec.DelivsObligationsDesc = val.Description;
      rec.SubmissionLevelCd = GetFromArray(codedetail, "PrimaryDecodeTxt", "CodeTxt", val.Acceptance);
      rec.SubmissionDelivStatusCd = GetFromArray(codedetail, "PrimaryDecodeTxt", "CodeTxt", val.DeliveryStatus);
      rec.RAGStatusCd = GetFromArray(codedetail, "PrimaryDecodeTxt", "CodeTxt", val.RAGStatus);
      rec.ResponsiblePartyArr = GetResponsible(codedetail, val.Responsible.split(","), "PrimaryDecodeTxt", "CodeTxt", true);
      rec.IsCritical = val.Critical == "Yes" ? true : false;
      rec.DueDt = moment(val.DueDate).isValid() ? moment.utc(new Date((new Date(val.DueDate)).toDateString())).toDate() : null;
      rec.SubmittedDttm = val.Acceptance.toUpperCase() != "Not Required".toUpperCase() ? moment(val.CompletedSubmittedDate).isValid() ? moment.utc(new Date((new Date(val.CompletedSubmittedDate)).toDateString())).toDate() : null : null;
      rec.SubmittedBy = val.Acceptance.toUpperCase() != "Not Required".toUpperCase() ? val.CompletedSubmittedBy : null;
      rec.CompletedDttm = val.Acceptance.toUpperCase() == "Not Required".toUpperCase() ? moment(val.CompletedSubmittedDate).isValid() ? moment.utc(new Date((new Date(val.CompletedSubmittedDate)).toDateString())).toDate() : null : null;
      rec.CompletedBy = val.Acceptance.toUpperCase() == "Not Required".toUpperCase() ? val.CompletedSubmittedBy : null;
      rec.SubmissionReviewPeriod = val.ReviewPeriod ? val.ReviewPeriod : rec.SubmissionReviewPeriod;
      rec.UpdateUserId = process.env.ENTERPRISEID;
      rec.UpdateDttm = 'spanner.commit_timestamp()';
      rec.OptionalClientReference = val.ClientReference;
      rec.OptionalComments = val.Comments;
      rec.OptionalContractDocument = val.ContractDocument;
      rec.OptionalSectionParagraph = val.SectionParagraph;
      rec.OptionalTower = val.Tower;
      rec.OptionalWorkstream = val.Workstream;
      rec = ComputeDeliveryStatus(codedetail, rec);
      delete rec.RecurDueDate;
      delete rec.RAGStatus;
      recs.push(rec);
      if (recs.length == 500) {
        await dAndoRepository.createDetailsForm(recs);
        console.log("500")
        recs = [];
      }
    }
    if (recs.length > 0) {
      await dAndoRepository.createDetailsForm(recs);
    }
    console.log("end")
    resolve();
  });
}

const _dnoImport = (body) => {
  const storage = new Storage();
  let proms = [];
  let rows = [];

  return new Promise(async (resolve, reject) => {
    let readstream = storage.bucket(process.env.STORAGEBUCKET).file(`user-imports/${body.Filename}`).createReadStream();
    var workbook = new Excel.Workbook();
    let xlsxStream = workbook.xlsx.createInputStream();
    let mcfccon = await dAndoRepository.GetMCFCCON(`mmc.MasterClientNbr = '${body.MasterClientNbr}'`, process.env.ENTERPRISEID);
    let dnos = await dAndoRepository.QueryDnO(`do.MasterClientNbr = '${body.MasterClientNbr}'`, process.env.ENTERPRISEID);
    let cd = await dAndoRepository.getDetailsCd();
    let codedetail = [];
    cd.forEach(x => {
      let item = x.toJSON();
      codedetail.push(item);
    });
    readstream.pipe(xlsxStream);
    xlsxStream.on('done', () => {
      let ws = workbook.getWorksheet("Insert Deliverables Information");
      let rsWs = workbook.getWorksheet("Responsible&Status");
      if (rsWs.getRow(1).getCell(2) == "1" && ws) {
        ProcessHeaderRow(ws.getRow(1)._cells);
        ws.eachRow((row, rowNumber) => {
          if (rowNumber > 1) {
            proms.push(new Promise(async (res) => {
              let errors = await _validateImportRow(ws, row.values, rowNumber, mcfccon, body, codedetail, dnos);
              rows.push(row.values);
              res(errors);
            }));
          }
        })
      }
      else {
        resolve({
          errors: [{
            cell: '',
            error: 'You are using an invalid or an old version of the template. Please download and use the latest template.'
          }]
        });
      }
      Promise.all(proms).then(async (errors) => {
        console.log("errors", errors);
        let err = [];
        errors.forEach(x => err = err.concat(x));
        let resp = {};
        if (err.length == 0) {
          await _processImportRows(rows, mcfccon, codedetail, dnos);
          resp.success = true;
        }
        else {
          resp.errors = err;
        }
        resolve(resp);
      });
    })
      .on('error', (arg) => {
        console.log('arg:', arg)
        resolve({
          errors: [{
            cell: '',
            error: 'You are using an invalid or an old version of the template. Please download and use the latest template.'
          }]
        });
      });
  });
}

function generateRandomID() {
  const date = new Date();
  const basicNumber =
    date
      .getFullYear()
      .toString()
      .substring(3, 4) +
    (date.getMonth() + 1).toString() +
    date.getDate().toString();
  let num = random(10 - basicNumber.length, { letters: false }) + basicNumber;
  return num;
}

function GetNbr(value) {
  if (value) {
    return value.split('-').pop().trim();
  }
  else {
    return '';
  }
}

function reccurenceCheckDate(obj) {
  if (obj && obj.DueDt && (
    obj.SubmissionDelivStatusCd == 102501 ||
    obj.SubmissionDelivStatusCd == 102503 ||
    obj.SubmissionDelivStatusCd == 102505)
  ) {
    var dueDt = moment(obj.DueDt).format('DD-MMM-YYYY');
    var todayDt = moment().format('DD-MMM-YYYY');
    if (dueDt > todayDt && obj.RAGStatusCd != 102401) {
      obj.RAGStatusCd = 102401;
    }

    if (dueDt == todayDt && obj.RAGStatusCd != 102402) {
      obj.RAGStatusCd = 102402;
    }
  }
}

const _saveUserGridView = async (model) => {
  let res;
  model['EnterpriseID'] = process.env.ENTERPRISEID;
  model['CreateDttm'] = 'spanner.commit_timestamp()';
  model['CreateUserId'] = process.env.ENTERPRISEID;
  model['UpdateDttm'] = 'spanner.commit_timestamp()';
  model['UpdateUserId'] = process.env.ENTERPRISEID;
  return new Promise((resolve, reject) => {
    try {
      res = dAndoRepository.createGridView(model);
      resolve(res);
    } catch (err) {
      console.log(err);
      return new Error(err);
    }
  });
}

const _getUserGridView = (pageCd) => {
  return new Promise(async function (resolve, reject) {
    var res = await dAndoRepository.getUserGridView(pageCd, process.env.ENTERPRISEID);
    try {
      resolve(res);
      res.catch(err);
    } catch (err) {
      return reject(err);
    }
  })
}

const _updateRecordTimeStamp = async (body) => {
  try {
    await dAndoRepository.updateRecordTimeStamp(body.DelivsObligationsKey, body.UpdateDttm);
    return;
  } catch (err) {
    console.error('ERROR:', err);
    return reject(err);
  } finally {
  }
}

module.exports = {
  _getTestInfo,
  _createDetailsForm,
  _getDnOGrid,
  _saveGrid,
  _deleteRecords,
  _getDetailsCd,
  _getDetailsForm,
  _dnoExport,
  _generateSignedUploadUrl,
  _dnoImport,
  _saveUserGridView,
  _getUserGridView,
  _updateRecordTimeStamp
}