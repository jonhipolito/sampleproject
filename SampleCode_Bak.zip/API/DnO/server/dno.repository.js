'use strict';

const SpannerDB = require('../configs/db.connection');

const getTestInfo = async () => {
    return 'HELLO WORLD!';
}

const createDetailsForm = async (model) => {
    let database = new SpannerDB();
    const DeliverablesObligationsTable = database.table('DeliverablesObligations');

    try {
        console.log(JSON.stringify(model));
        var detailsForm = await DeliverablesObligationsTable.upsert(model);
        if (detailsForm) {
            return model;
        }
    } catch (err) {
        console.log(err);
        throw err;
    } finally {
        // Close the database when finished.
        await database.close();
    }
}

const getDnOGrid = async (mc, fc, con) => {
    const database = new SpannerDB();

    var dnoGridQuery = await getDNOGridQuery(mc, fc, con);

    try {
        let [dnoGridRows] = await database.run(dnoGridQuery);
        if (dnoGridRows.length > 0) {
            return dnoGridRows;
        } else {
            return null;
        }
    } catch (err) {
        throw err;
    } finally {
        // Close the database when finished.
        await database.close();
    }
}

const getDNOGridQuery = async (mc, fc, con) => {

    var query = `SELECT DelivsObligationsKey,
    DetailID,
    DelivsObligationsNm,
    DelivsObligationsDesc,
    cd1.PrimaryDecodeTxt AS DelivsObligationsType,
    cd2.PrimaryDecodeTxt AS RAGStatus,
    (SELECT ARRAY_TO_STRING((SELECT ARRAY_AGG(PrimaryDecodeTxt) FROM CodeDetail WHERE CodeTxt IN UNNEST(dno.ResponsiblePartyArr)), ', ')) AS ResponsibleParty,
    cd3.PrimaryDecodeTxt AS SubmissionDelivStatus,
    DueDt,
    dno.UpdateDttm as LastUpdate,
    CASE
        WHEN cus.CustomerNbr = '' OR  cus.CustomerNbr IS NULL THEN NULL
        ELSE concat(concat(cus.CustomerNm, ' - '), cus.CustomerNbr)
    END AS Customer,
    CASE
        WHEN con.ContractNbr = '' OR  con.ContractNbr IS NULL THEN NULL
        ELSE concat(concat(con.ContractNm, ' - '), con.ContractNbr)
    END AS Contract
    FROM DeliverablesObligations dno
    LEFT JOIN CodeDetail cd1
    ON dno.DelivsObligationsTypeCd = cd1.CodeTxt
    LEFT JOIN CodeDetail cd2
    ON dno.RAGStatusCd = cd2.CodeTxt
    LEFT JOIN CodeDetail cd3
    ON dno.SubmissionDelivStatusCd = cd3.CodeTxt 
	LEFT JOIN Customer cus
	ON dno.CustomerNbr = cus.CustomerNbr
	LEFT JOIN Contract con
	ON dno.ContractNbr = con.ContractNbr `;

    if (con != 'null') {
        query += `WHERE dno.ContractNbr = '${con}' 
                ORDER BY DueDt `
    } else if (fc != 'null') {
        query += `WHERE dno.CustomerNbr = '${fc}' 
                ORDER BY DelivsObligationsType,DelivsObligationsNm,DelivsObligationsDesc `;
    } else if (mc != 'null') {
        query += `WHERE dno.MasterClientNbr = '${mc}' 
                ORDER BY DelivsObligationsType,DelivsObligationsNm,DelivsObligationsDesc `;
    }
    return query;
}

const getDelivsObligationsTypeCd = async (typeCd) => {
    const database = new SpannerDB();

    var query = `SELECT CodeTxt FROM CodeDetail cd
    INNER JOIN CodeHeader ch ON cd.CodeHeaderId = ch.CodeHeaderId
    WHERE ch.CategoryDesc = 'DelivsObligationsType' AND cd.PrimaryDecodeTxt = '${typeCd}' LIMIT 1`;

    try {
        let [rows] = await database.run(query);
        if (rows.length > 0) {
            return rows[0];
        } else {
            return null;
        }
    } catch (err) {
        throw err;
    } finally {
        // Close the database when finished.
        await database.close();
    }
}

const getRAGStatusCd = async (ragStatusCd) => {
    const database = new SpannerDB();

    var query = `SELECT CodeTxt FROM CodeDetail cd
    INNER JOIN CodeHeader ch ON cd.CodeHeaderId = ch.CodeHeaderId
    WHERE ch.CategoryDesc = 'RAGStatus' AND cd.PrimaryDecodeTxt = '${ragStatusCd}' LIMIT 1`;

    try {
        let [rows] = await database.run(query);
        if (rows.length > 0) {
            return rows[0];
        } else {
            return null;
        }
    } catch (err) {
        throw err;
    } finally {
        // Close the database when finished.
        await database.close();
    }
}

const getSubmissionDelivStatusCd = async (statusCd) => {
    const database = new SpannerDB();

    var query = `SELECT CodeTxt FROM CodeDetail cd
    INNER JOIN CodeHeader ch ON cd.CodeHeaderId = ch.CodeHeaderId
    WHERE ch.CategoryDesc = 'SubmissionDelivStatus' AND cd.PrimaryDecodeTxt = '${statusCd}' LIMIT 1`;

    try {
        let [rows] = await database.run(query);
        if (rows.length > 0) {
            return rows[0];
        } else {
            return null;
        }
    } catch (err) {
        throw err;
    } finally {
        // Close the database when finished.
        await database.close();
    }
}

const getSubmissionLevelStatusCd = async (statusCd) => {
    const database = new SpannerDB();

    var query = `SELECT CodeTxt FROM CodeDetail cd
    INNER JOIN CodeHeader ch ON cd.CodeHeaderId = ch.CodeHeaderId
    WHERE ch.CategoryDesc = 'SubmissionLevel' AND cd.PrimaryDecodeTxt = '${statusCd}' LIMIT 1`;

    try {
        let [rows] = await database.run(query);
        if (rows.length > 0) {
            return rows[0];
        } else {
            return null;
        }
    } catch (err) {
        throw err;
    } finally {
        // Close the database when finished.
        await database.close();
    }
}

const getResponsibleCodeTxt = async (statusCd) => {
    const database = new SpannerDB();

    var query = `SELECT CodeTxt FROM CodeDetail cd
    INNER JOIN CodeHeader ch ON cd.CodeHeaderId = ch.CodeHeaderId
    WHERE ch.CategoryDesc = 'ResponsibleParty' AND cd.PrimaryDecodeTxt IN(${statusCd})`;

    try {
        let [rows] = await database.run(query);
        if (rows.length > 0) {
            return rows;
        } else {
            return null;
        }
    } catch (err) {
        throw err;
    } finally {
        // Close the database when finished.
        await database.close();
    }
}

const updateDeliverablesObligation = async (model, data) => {
    let database = new SpannerDB();
    const DeliverablesObligationsTable = database.table('DeliverablesObligations');

    try {
        var ragStatusCd = await getRAGStatusCd(data.RAGStatus)
        model.RAGStatusCd = ragStatusCd[0].value;
        var delivsObligationsTypeCd = await getDelivsObligationsTypeCd(data.DelivsObligationsType)
        model.DelivsObligationsTypeCd = delivsObligationsTypeCd[0].value;
        var responsibleParty = data.ResponsibleParty.split(", ").map(element => "'" + element + "'").join(',');
        var responsiblePartyCode = await getResponsibleCodeTxt(responsibleParty);
        var codes = responsiblePartyCode.map(element => element[0].value);
        model.ResponsiblePartyArr = codes;
        var commitTimestamp = await DeliverablesObligationsTable.update(model);
        return commitTimestamp;
    } catch (err) {
        throw err;
    } finally {
        // Close the database when finished.
        await database.close();
    }
}

const deleteRecords = async (keys) => {
    let database = new SpannerDB();
    const DeliverablesObligationsTable = database.table('DeliverablesObligations');

    try {
        var commitTimestamp = await DeliverablesObligationsTable.deleteRows(keys);
        return commitTimestamp;
    } catch (err) {
        console.log(err);
        throw err;
    } finally {
        // Close the database when finished.
        await database.close();
    }
}

const getDetailsCd = async () => {
    const database = new SpannerDB();

    var query = `SELECT CodeTxt, PrimaryDecodeTxt, CodeHeaderId FROM CodeDetail 
    WHERE CodeHeaderId IN (1023, 1024, 1026, 1025, 1027) 
    ORDER BY CodeTxt ASC`;

    try {
        let [rows] = await database.run(query);
        if (rows.length > 0) {
            return rows;
        } else {
            return null;
        }
    } catch (err) {
        throw err;
    } finally {
        // Close the database when finished.
        await database.close();
    }
}

const getDetailsForm = async (key, user) => {
    const database = new SpannerDB();

    var dnoDetailsQuery = {
        sql: `SELECT dno.DelivsObligationsKey, dno.ContractNbr,dno.CustomerNbr,
    dno.DelivsObligationsDesc,dno.DelivsObligationsNm,dno.DelivsObligationsTypeCd,dno.DetailID,
    dno.DueDt,dno.EndAfter,dno.EndBy,dno.IsCritical,dno.MasterClientNbr,dno.OptionalClientReference,
    dno.OptionalComments,dno.OptionalContractDocument,dno.OptionalSectionParagraph,dno.OptionalTower,
    dno.OptionalWorkstream, dno.RAGStatusCd,dno.Recurrence,  
    dno.ResponsiblePartyArr,dno.ResubmissionDt,dno.SubmissionAcceptDt,dno.SubmissionAcceptedBy,dno.CompletedBy,dno.SubmittedBy,
    dno.SubmissionDelivStatusCd,dno.SubmittedDttm,dno.CompletedDttm,dno.SubmissionLevelCd,dno.SubmissionLinkToDocs,
    dno.SubmissionRejectDt,dno.SubmissionRejectedBy,dno.SubmissionReviewPeriod,
    dno.CreateUserId, dno.CreateDttm,
    mc.MasterClientNm, cus.CustomerNm, con.ContractNm
    FROM DeliverablesObligations dno 
    INNER JOIN MMCSecurityData mmc
    ON mmc.MasterClientNbr = dno.MasterClientNbr
    LEFT JOIN MasterClient mc
    ON mc.MasterClientNbr = dno.MasterClientNbr
    LEFT JOIN Customer cus
    ON cus.CustomerNbr = dno.CustomerNbr
    LEFT JOIN Contract con
    ON con.ContractNbr = dno.ContractNbr
    WHERE DelivsObligationsKey = @key
    AND mmc.EnterpriseID = @EnterpriseID
    `,
    params: {
        key: key,
        EnterpriseID: user
    }};

    try {
        let [dnoDetailsRows] = await database.run(dnoDetailsQuery);
        if (dnoDetailsRows.length > 0) {
            return dnoDetailsRows[0];
        } else {
            return null;
        }
    } catch (err) {
        throw err;
    } finally {
        // Close the database when finished.
        await database.close();
    }
}

async function GetMCFCCON(filter, user) {
    const database = new SpannerDB();
    const [rows] = await database.run({
        sql: `
            SELECT mc.MasterClientNbr,mc.MasterClientNm,cus.CustomerNbr,cus.CustomerNm,con.ContractNbr,con.ContractNm FROM MasterClient mc
            LEFT JOIN Customer cus
            ON mc.MasterClientNbr = cus.MasterClientNbr
            LEFT JOIN Contract con
            ON con.CustomerNbr= cus.CustomerNbr
            INNER JOIN MMCSecurityData mmc
            ON mc.MasterClientNbr = mmc.MasterClientNbr
            WHERE mmc.EnterpriseId = '${user}'
        ` + (filter ? ' AND ' + filter : '')

    });
    let items = [];
    rows.forEach(x => {
        let item = x.toJSON();
        items.push(item);
    })
    return items;
}

async function QueryDnO(filter, user) {
    const database = new SpannerDB();
    const [rows] = await database.run({
        sql: `
            SELECT do.*, ragcd.PrimaryDecodeTxt AS RAGStatus
            FROM DeliverablesObligations do
            INNER JOIN MMCSecurityData mmc
            ON do.MasterClientNbr = mmc.MasterClientNbr
            LEFT JOIN CodeDetail ragcd
            ON do.RAGStatusCd = ragcd.CodeTxt
            WHERE ${filter} 
            AND mmc.EnterpriseId = '${user}'
            ORDER BY DetailID
        `
    });
    return rows;
}

async function GenerateDNOID() {
    const database = new SpannerDB();
    const [rows] = await database.run({
        sql: `
            SELECT UNIX_MICROS(CURRENT_TIMESTAMP()) as ID
        `
    });
    if(rows && rows.length > 0) {
        return rows[0].toJSON().ID;
    }
    return null;
    
}

const getContractOptions = async (mc) => {
    let database = new SpannerDB();
  
    const query = {
      sql: `SELECT ContractNbr, CONCAT(ContractNm, ' - ', ContractNbr) AS ContractNm, CustomerNbr FROM Contract 
      WHERE CustomerNbr IN (SELECT CustomerNbr FROM Customer AS cus WHERE MasterClientNbr = '` + mc + `') ORDER BY LOWER(ContractNm) ASC`,
    };
    try {
      const [qOneRows] = await database.run(query);      
      return qOneRows;
    } catch (err) {
    } finally {
      await database.close();
    }
}

const createGridView = async (model) => {
    let database = new SpannerDB();
    const UserGridViewTable = database.table('UserGridView');

    try {
        console.log(model);
        var userGridView = await UserGridViewTable.upsert(model);
        if (userGridView) {
            return model;
        }
    } catch (err) {
        console.log(err);
        throw err;
    } finally {
        // Close the database when finished.
        await database.close();
    }
}

const getUserGridView = async (pageCd, user) => {
    const database = new SpannerDB();

    var userGridViewQuery = {
        sql: `SELECT *
        FROM UserGridView
        WHERE EnterpriseID = @EnterpriseID AND PageCd = @PageCd`,
        params: {
            EnterpriseID: user,
            PageCd: pageCd
    }};

    try {
        let [userGridViewRows] = await database.run(userGridViewQuery);
        if (userGridViewRows.length > 0) {
            return userGridViewRows[0];
        } else {
            return null;
        }
    } catch (err) {
        throw err;
    } finally {
        // Close the database when finished.
        await database.close();
    }
}

const updateRecordTimeStamp = async (key, date) => {
    return await new Promise(async (resolve) => {
        try {
            let database = new SpannerDB();
            let script = `UPDATE DeliverablesObligations 
                SET UpdateDttm = '${date}'
                WHERE DelivsObligationsKey = '${key}'`
            await database.runTransaction(async (err, transaction) => {
                await transaction.runUpdate(script);
                await transaction.commit();
                resolve();
                await database.close();
            });
        } catch (err) {
            console.log("updateRecordTimeStamp Error: ", err);
        } finally {
        }
    });
}

module.exports = {
    getTestInfo,
    getDnOGrid,
    createDetailsForm,
    getDelivsObligationsTypeCd,
    getRAGStatusCd,
    getSubmissionDelivStatusCd,
    updateDeliverablesObligation,
    getSubmissionLevelStatusCd,
    getResponsibleCodeTxt,
    deleteRecords,
    getDetailsCd,
    getDetailsForm,
    GetMCFCCON,
    QueryDnO,
    GenerateDNOID,
    getContractOptions,
    createGridView,
    getUserGridView,
    updateRecordTimeStamp
}