'use strict';

const responsible = {
        ACN : "Accenture",
        Client : "Client",
        Joint : "Joint",
        Subcon : "Subcontractor"
    };

module.exports ={
    responsible
}