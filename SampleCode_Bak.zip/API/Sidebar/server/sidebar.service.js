'use strict';

const sidebarRepository = require('./sidebar.repository');
const request = require('request');
const uuid = require('uuidv4');
const NodeCache = require("node-cache");
const ttl = 60 * 60 * 1; // cache for 1 Hour
const OneDay = ttl * 24;
const cache = new NodeCache({
  stdTTL: ttl,
  checkperiod: ttl * 0.2
});

const _createFolder = async (body) => {
  try {
    if (body.FolderName) {
      let model = {
        BookmarkPersonalFolderKey: uuid(),
        FolderName: body.FolderName,
        CreateDttm: 'spanner.commit_timestamp()',
        CreateUserId: process.env.ENTERPRISEID,
        UpdateDttm: 'spanner.commit_timestamp()',
        UpdateUserId: process.env.ENTERPRISEID,
      }
      await sidebarRepository.createFolder(model);
    }
  } catch (err) {
    console.error('ERROR:', err);
    return reject(err);
  } finally {

  }
}

const _renameFolder = async (body) => {
  try {
    await sidebarRepository.renameFolder(body.FolderName, body.BookmarkPersonalFolderKey, process.env.ENTERPRISEID);
    return;
  } catch (err) {
    console.error('ERROR:', err);
    return reject(err);
  } finally {

  }
}

const _deleteFolder = async (body) => {
  try {
    await sidebarRepository.deleteFolder(body.BookmarkPersonalFolderKey);
    return;
  } catch (err) {
    console.error('ERROR:', err);
    return reject(err);
  } finally {

  }
}

const _getBookmarks = async (req) => {
  let bookmarks;
  let bookmarkview = [];
  try {
    bookmarks = await sidebarRepository.getBookmarks();
    let folders = [...new Set(bookmarks.map(item => item.toJSON().BookmarkPersonalFolderKey))];
    folders.forEach(f => {
      let b = bookmarks.filter(b => b.toJSON().BookmarkPersonalFolderKey == f);
      bookmarkview.push({
        BookmarkPersonalFolderKey: f,
        FolderName: b[0].toJSON().FolderName,
        URLs: b[0].toJSON().Url ? b.map(bb => {
          return {
            Url: bb.toJSON().Url,
            UrlName: bb.toJSON().UrlName,
            BookmarkPersonalUrlKey: bb.toJSON().BookmarkPersonalUrlKey
          }
        }) : []
      });
    });
    return bookmarkview;
  } catch (err) {
    console.error('ERROR:', err);
  } finally { }
}

const _getSharedBookmarks = async (MasterClientNbr) => {
  if (!MasterClientNbr) {
    return null;
  }
  try {
    let bookmarks = await sidebarRepository.getSharedBookmarks(MasterClientNbr);
    let sharedbookmarks = {
      MasterClientNbr: MasterClientNbr,
      MasterClientNm: bookmarks[0].toJSON().MasterClientNm,
      URLs: bookmarks[0].toJSON().Url ? bookmarks.map(x => {
        let y = x.toJSON();
        return {
          BookmarkSharedKey: y.BookmarkSharedKey,
          Url: y.Url,
          UrlName: y.UrlName,
          CreateUserId: y.CreateUserId
        }
      }) : []
    }
    return sharedbookmarks;
  } catch (err) {
    console.error('ERROR:', err);
  } finally { }
}

const _createLink = async (body) => {
  if (!body.BookmarkPersonalFolderKey) {
    return null;
  }
  try {
    let model = {
      BookmarkPersonalFolderKey: body.BookmarkPersonalFolderKey,
      BookmarkPersonalUrlKey: uuid(),
      Url: body.NewLink,
      UrlName: body.NewLinkName,
      CreateDttm: 'spanner.commit_timestamp()',
      CreateUserId: process.env.ENTERPRISEID,
      UpdateDttm: 'spanner.commit_timestamp()',
      UpdateUserId: process.env.ENTERPRISEID,
    }
    let bookmarks = await sidebarRepository.createLink(model);
    return bookmarks;
  } catch (err) {
    console.error('ERROR:', err);
  } finally { }
}

const _createSharedLink = async (body) => {
  if (!body.MasterClientNbr) {
    return null;
  }
  try {
    let model = {
      BookmarkSharedKey: uuid(),
      MasterClientNbr: body.MasterClientNbr,
      Url: body.NewLink,
      UrlName: body.NewLinkName,
      CreateDttm: 'spanner.commit_timestamp()',
      CreateUserId: process.env.ENTERPRISEID,
      UpdateDttm: 'spanner.commit_timestamp()',
      UpdateUserId: process.env.ENTERPRISEID,
    }
    let bookmarks = await sidebarRepository.createSharedLink(model);
    return bookmarks;
  } catch (err) {
    console.error('ERROR:', err);
  } finally { }
}

const _updateLink = async (body) => {
  try {
    let model = {
      BookmarkPersonalUrlKey: body.BookmarkPersonalUrlKey,
      Url: body.NewLink,
      UrlName: body.NewLinkName,
      UpdateDttm: 'spanner.commit_timestamp()',
      UpdateUserId: process.env.ENTERPRISEID,
    }
    await sidebarRepository.updateLink(model);
    return;
  } catch (err) {
    console.error('ERROR:', err);
    return reject(err);
  } finally {

  }
}

const _deleteLink = async (body) => {
  try {
    await sidebarRepository.deleteLink(body.BookmarkPersonalUrlKey, process.env.ENTERPRISEID);
    return;
  } catch (err) {
    console.error('ERROR:', err);
    return reject(err);
  } finally {

  }
}

const _updateSharedLink = async (body) => {
  try {
    let model = {
      BookmarkSharedKey: body.BookmarkSharedKey,
      MasterClientNbr: body.MasterClientNbr,
      Url: body.NewLink,
      UrlName: body.NewLinkName,
      UpdateDttm: 'spanner.commit_timestamp()',
      UpdateUserId: process.env.ENTERPRISEID,
    }
    await sidebarRepository.updateSharedLink(model, body.BookmarkSharedKey, process.env.ENTERPRISEID);
    return;
  } catch (err) {
    console.error('ERROR:', err);
    return reject(err);
  } finally {

  }
}
const _deleteSharedLink = async (body) => {
  try {
    await sidebarRepository.deleteSharedLink(body.BookmarkSharedKey, process.env.ENTERPRISEID);
    return;
  } catch (err) {
    console.error('ERROR:', err);
    return reject(err);
  } finally {

  }
}

const _getFavicon = (param) => {
  return new Promise((resolve) => {
    let img = cache.get(param.url);
    if (!img) {
      try {
        request.get(param.url + "/favicon.ico", { encoding: null }, function (error, response, body) {
          if (!error) {
            cache.set(param.url, body, OneDay);
            resolve(body);
          }
          else {
            resolve(null);
          }
        });
        return;
      } catch (err) {
        console.error('ERROR:', err);
        return reject(err);
      } finally {
      }
    }
    else {
      resolve(img);
    }

  });
}

const _getCodeDetails = async () => {
  var res = await sidebarRepository.getCodeDetails();
  try {
    var data;
    if (res) {
      let resJSON = JSON.stringify(res);
      let resParse = JSON.parse(resJSON);

      let level = resParse.filter(x => x.CategoryDesc == 'PriorityLevel');
      let status = resParse.filter(x => x.CategoryDesc == 'PriorityStatus');

      data = {
        level: level,
        status: status
      }

    } else {
      data = res;
    }
    return data;

  } catch (err) {
    console.error('ERROR:', err);
  } finally { }
}

const _getCodeDetailsDefault = async () => {
  try {
    let res = await _getCodeDetails();
    let resLevel = res.level.find(x => x.PrimaryDecodeTxt == 'Medium');
    let resStatus = res.status.find(x => x.PrimaryDecodeTxt == 'To-Do');
    var data = {
      level: '',
      status: ''
    };
    
    if (resLevel) {
      data.level = resLevel.CodeTxt;
    }
    if (resStatus) {
      data.status = resStatus.CodeTxt;
    }

    return data;
  }
  catch (err) {
    console.error('ERROR:', err);
    return reject(err);
  } finally {

  }
}

const _createPriority = async (body) => {
  let priority;
  let createPriorityArr = [];
  try {
    if (body) {
      if (body.AssignToMe) {
        //Insert data in Priorities table for the Creator
        let model = {
          PrioritiesKey: uuid(),
          PriorityDesc: body.PriorityDesc,
          PriorityLevelCd: body.PriorityLevelCd,
          StatusCd: body.StatusCd,
          DueDt: body.DueDt,
          CreatedFor: process.env.ENTERPRISEID,
          Comments: body.Comments,
          AssociatedClients: body.AssociatedClients ? body.AssociatedClients : null,
          AssociatedContracts: body.AssociatedContracts ? body.AssociatedContracts : null,
          AssociatedRI: body.AssociatedRI ? body.AssociatedRI : null,
          CreateDttm: 'spanner.commit_timestamp()',
          CreateUserId: process.env.ENTERPRISEID,
          UpdateDttm: 'spanner.commit_timestamp()',
          UpdateUserId: process.env.ENTERPRISEID,
        }

        createPriorityArr.push(model);
      }

      if (body.OtherAssignees && body.OtherAssignees.length > 0) {
        //Insert data in Priorities table for Other Assignees
        for (let i = 0; i < body.OtherAssignees.length; i++) {
          console.log("body.OtherAssignees.length", body.OtherAssignees.length);
          console.log("body.OtherAssignees", body.OtherAssignees);
          console.log("body.OtherAssignees[i]", body.OtherAssignees[i]);
          let model = {
            PrioritiesKey: uuid(),
            PriorityDesc: body.PriorityDesc,
            PriorityLevelCd: body.PriorityLevelCd,
            StatusCd: body.StatusCd,
            DueDt: body.DueDt,
            CreatedFor: body.OtherAssignees[i],
            Comments: body.Comments,
            AssociatedClients: body.AssociatedClients ? body.AssociatedClients : null,
            AssociatedContracts: body.AssociatedContracts ? body.AssociatedContracts : null,
            AssociatedRI: body.AssociatedRI ? body.AssociatedRI : null,
            CreateDttm: 'spanner.commit_timestamp()',
            CreateUserId: process.env.ENTERPRISEID,
            UpdateDttm: 'spanner.commit_timestamp()',
            UpdateUserId: process.env.ENTERPRISEID,
          }
  
          createPriorityArr.push(model);
        }
      }

      await sidebarRepository.createPriority(createPriorityArr);
      // priority = await sidebarRepository.getPriority(model.PrioritiesKey);
      
      // return priority;
    }
  } catch (err) {
    console.error('ERROR:', err);
    return reject(err);
  } finally {

  }
}

const _updatePriority = async (body) => {
  let priority;
  try {
    if (body) {
      //Update the Priority
      let model = {
        PrioritiesKey: body.PrioritiesKey,
        PriorityDesc: body.PriorityDesc,
        PriorityLevelCd: body.PriorityLevelCd,
        StatusCd: body.StatusCd,
        DueDt: body.DueDt,
        Comments: body.Comments,
        AssociatedClients: body.AssociatedClients ? body.AssociatedClients : null,
        AssociatedContracts: body.AssociatedContracts ? body.AssociatedContracts : null,
        AssociatedRI: body.AssociatedRI ? body.AssociatedRI : null,
        UpdateDttm: 'spanner.commit_timestamp()',
        UpdateUserId: process.env.ENTERPRISEID,
      }
      await sidebarRepository.updatePriority(model);

      priority = await sidebarRepository.getPriority(body.PrioritiesKey);
      
      return priority;
    }
  } catch (err) {
    console.error('ERROR:', err);    
  } finally {

  }
}

const _getPriorities = async (filter, sort) => {
  let priorities;

  try {
    if (filter == 'mypriorities' && (sort == 'deadline' || sort == 'null' || !sort)) {
      //In sidebar, mypriorities
      //In expanded view, mypriorities - deadline
      priorities = await sidebarRepository.getMyPriorities_deadline();
    }
    else if (filter == 'mypriorities' && sort == 'prioritylevel') {
      //In expanded view, mypriorities - prioritylevel
      priorities = await sidebarRepository.getMyPriorities_prioritylevel();
    }
    else if (filter == 'delegatedpriorities' && (sort == 'deadline' || sort == 'null' || !sort)) {
      //In sidebar, delegatedpriorities
      //In expanded view, delegatedpriorities - deadline
      priorities = await sidebarRepository.getDelegatedPriorities_deadline();
    }
    else {
      //In expanded view, delegatedpriorities - prioritylevel
      priorities = await sidebarRepository.getDelegatedPriorities_prioritylevel();
    }
    let resJSONPriorities = JSON.stringify(priorities);
    let resParsePriorities = JSON.parse(resJSONPriorities);
    if (resParsePriorities.length > 0) {
      for (let i = 0; i < resParsePriorities.length; i++) {
        if (resParsePriorities[i].Tags && resParsePriorities[i].Tags.length > 1) {
          resParsePriorities[i].Tags.sort();
        }
      }
    }
    return resParsePriorities;
  } catch (err) {
    console.error('ERROR:', err);
  } finally { }
}

const _deletePriority = async (body) => {
  try {
    await sidebarRepository.deletePriority(body.PrioritiesKey);

    return;
  } catch (err) {
    console.error('ERROR:', err);
    return reject(err);
  } finally {

  }
}

module.exports = {
  _createFolder,
  _renameFolder,
  _deleteFolder,
  _getBookmarks,
  _getSharedBookmarks,
  _createLink,
  _createSharedLink,
  _updateLink,
  _deleteLink,
  _updateSharedLink,
  _deleteSharedLink,
  _getFavicon,
  _getCodeDetails,
  _createPriority,
  _updatePriority,
  _getPriorities,
  _deletePriority
}