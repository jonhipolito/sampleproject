'use strict';

const express = require('express');
const router = express.Router();
const sidebarController = require('./sidebar.controller');

router.post('/CreateFolder', sidebarController.createFolder);
router.post('/RenameFolder', sidebarController.renameFolder);
router.post('/DeleteFolder', sidebarController.deleteFolder);
router.get('/GetBookmarks', sidebarController.getBookmarks);
router.get('/GetSharedBookmarks/:MasterClientNbr', sidebarController.getSharedBookmarks);
router.post('/CreateLink', sidebarController.createLink);
router.post('/UpdateLink', sidebarController.updateLink);
router.post('/DeleteLink', sidebarController.deleteLink);
router.post('/CreateSharedLink', sidebarController.createSharedLink);
router.post('/UpdateSharedLink', sidebarController.updateSharedLink);
router.post('/DeleteSharedLink', sidebarController.deleteSharedLink);
router.post('/GetFavicon', sidebarController.getFavicon);
router.get('/GetCodeDetails', sidebarController.getCodeDetails);
router.post('/CreatePriority', sidebarController.createPriority);
router.post('/UpdatePriority', sidebarController.updatePriority);
router.get('/GetPriorities/:filter/:sort?', sidebarController.getPriorities);
router.post('/DeletePriority', sidebarController.deletePriority);
module.exports = router;