'use strict';

const sidebarService = require('./sidebar.service');

const createFolder = (req, res, next) => {
    if (!req.body) {
        res.status(200);
        return;
    }

    sidebarService._createFolder(req.body)
        .then(data => {
            sidebarService._getBookmarks(req.body).then(bookmarks => {
                res.status(200).send(bookmarks);
            });
        })
}

const renameFolder = (req, res, next) => {
    if (!req.body) {
        res.status(200);
        return;
    }
    sidebarService._renameFolder(req.body)
        .then(data => {
            res.status(200).send(data);
        })
}

const deleteFolder = (req, res, next) => {
    if (!req.body) {
        res.status(200);
        return;
    }
    sidebarService._deleteFolder(req.body)
        .then(data => {
            res.status(200).send(data);
        })
}

const getBookmarks = (req, res, next) => {
    sidebarService._getBookmarks(req)
        .then(data => {
            res.status(200).send(data);
        })
}

const getSharedBookmarks = (req, res, next) => {
    sidebarService._getSharedBookmarks(req.params.MasterClientNbr)
        .then(data => {
            res.status(200).send(data);
        })
}

const createLink = (req, res, next) => {
    sidebarService._createLink(req.body)
        .then(data => {
            sidebarService._getBookmarks(req.body).then(bookmarks => {
                res.status(200).send(bookmarks);
            });
        });
}

const createSharedLink = (req, res, next) => {
    sidebarService._createSharedLink(req.body)
        .then(async(data) => {
            let sharebookmarks = await sidebarService._getSharedBookmarks(req.body.MasterClientNbr)
            res.status(200).send(sharebookmarks);
        });
}

const updateLink = (req, res, next) => {
    sidebarService._updateLink(req.body)
        .then(data => {
            res.status(200).send();
        });
}

const deleteLink = (req, res, next) => {
    sidebarService._deleteLink(req.body)
        .then(data => {
            res.status(200).send();
        });
}

const updateSharedLink = (req, res, next) => {
    sidebarService._updateSharedLink(req.body)
        .then(data => {
            res.status(200).send();
        });
}

const deleteSharedLink = (req, res, next) => {
    sidebarService._deleteSharedLink(req.body)
        .then(data => {
            res.status(200).send();
        });
}

const getFavicon = (req, res, next) => {
    sidebarService._getFavicon(req.body)
        .then(data => {
            res.set('Content-Type', 'image/x-icon');
            res.send(data);
        });
}

const getCodeDetails = (req, res, next) => {
    sidebarService._getCodeDetails()
        .then(data => {
            res.status(200).send(data);
        })
}

const createPriority = (req, res, next) => {
    if (!req.body) {
        res.status(200);
        return;
    }

    sidebarService._createPriority(req.body)
        .then(data => {
            res.status(200).send(data);
        })
}

const updatePriority = (req, res, next) => {
    if (!req.body) {
        res.status(200);
        return;
    }

    sidebarService._updatePriority(req.body)
        .then(data => {
            res.status(200).send(data);
        })
}

const getPriorities = (req, res, next) => {
    sidebarService._getPriorities(req.params.filter, req.params.sort)
        .then(data => {
            res.status(200).send(data);
        })
}

const deletePriority = (req, res, next) => {
    if (!req.body) {
        res.status(200);
        return;
    }
    sidebarService._deletePriority(req.body)
        .then(data => {
            res.status(200).send(data);
        })
}

module.exports = {
    createFolder,
    renameFolder,
    deleteFolder,
    getBookmarks,
    getSharedBookmarks,
    createLink,
    createSharedLink,
    updateLink,
    deleteLink,
    updateSharedLink,
    deleteSharedLink,
    getFavicon,
    getCodeDetails,
    createPriority,
    updatePriority,
    getPriorities,
    deletePriority
}