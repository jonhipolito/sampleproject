'use strict';

const SpannerDB = require('../configs/db.connection');

const createFolder = async (model) => {
    let database = new SpannerDB();
    const BookmarkPersonalFolderTable = database.table('BookmarkPersonalFolder');
    try {
        await BookmarkPersonalFolderTable.insert(model);
    } catch (err) {
        console.log("createFolder Error: ", err);
    } finally {
        await database.close();
    }
}

const renameFolder = async (name, key, user) => {
    return await new Promise(async (resolve) => {
        try {
            let database = new SpannerDB();
            let script = `UPDATE BookmarkPersonalFolder 
                SET FolderName = '${name}',
                UpdateDttm = PENDING_COMMIT_TIMESTAMP(),
                UpdateUserId = '${user}'
                WHERE BookmarkPersonalFolderKey = '${key}'`
            await database.runTransaction(async (err, transaction) => {
                await transaction.runUpdate(script);
                await transaction.commit();
                resolve();
                await database.close();
            });
        } catch (err) {
            console.log("renameFolder Error: ", err);
        } finally {
        }
    });
}

const deleteFolder = async (key) => {
    return await new Promise(async (resolve) => {
        try {
            let database = new SpannerDB();
            let script = `DELETE FROM BookmarkPersonalFolder                 
                WHERE BookmarkPersonalFolderKey = '${key}'`
            await database.runTransaction(async (err, transaction) => {
                await transaction.runUpdate(script);
                await transaction.commit();
                resolve();
                await database.close();
            });
        } catch (err) {
            console.log("renameFolder Error: ", err);
        } finally {
        }
    });
}

const getBookmarks = async (model) => {
    let database = new SpannerDB();
    const getUrlsQuery = {
        sql: `SELECT f.BookmarkPersonalFolderKey, u.BookmarkPersonalUrlKey, FolderName, Url, UrlName
            FROM BookmarkPersonalFolder f
            LEFT JOIN BookmarkPersonalUrl u
            ON f.BookmarkPersonalFolderKey = u.BookmarkPersonalFolderKey
            WHERE f.CreateUserId = '${process.env.ENTERPRISEID}'
            ORDER BY LOWER(FolderName)`
    };
    try {
        let [bookmarks] = await database.run(getUrlsQuery);
        return bookmarks;
    } catch (err) {
        console.log("getBookmarks Error: ", err);
    } finally {
        await database.close();
    }
}

const getSharedBookmarks = async (MasterClientNbr) => {
    let database = new SpannerDB();
    const getSharedBookmarkQuery = {
        sql: `SELECT BookmarkSharedKey, MasterClientNm, mc.MasterClientNbr, UrlName, Url, bs.CreateUserId
            FROM MasterClient mc
            LEFT JOIN BookmarkShared bs
            ON mc.MasterClientNbr = bs.MasterClientNbr  
            WHERE mc.MasterClientNbr = '${MasterClientNbr}'
            ORDER BY LOWER(UrlName)`
    };
    try {
        let [bookmarks] = await database.run(getSharedBookmarkQuery);
        return bookmarks;
    } catch (err) {
        console.log("getBookmarks Error: ", err);
    } finally {
        await database.close();
    }
}

const createLink = async (model) => {
    let database = new SpannerDB();
    const BookmarkPersonalUrlTable = database.table('BookmarkPersonalUrl');
    try {
        await BookmarkPersonalUrlTable.insert(model);
    } catch (err) {
        console.log("createLink Error: ", err);
    } finally {
        await database.close();
    }
}

const createSharedLink = async (model) => {
    let database = new SpannerDB();
    const BookmarkPersonalUrlTable = database.table('BookmarkShared');
    console.log("model", model);
    try {
        await BookmarkPersonalUrlTable.insert(model);
    } catch (err) {
        console.log("createSharedLink Error: ", err);
    } finally {
        await database.close();
    }
}

const updateLink = async (model) => {
    console.log("model", model);
    return await new Promise(async (resolve) => {
        try {
            let database = new SpannerDB();
            let script = `UPDATE BookmarkPersonalUrl 
                SET Url = '${model.Url}',
                UrlName = '${model.UrlName}',
                UpdateDttm = PENDING_COMMIT_TIMESTAMP(),
                UpdateUserId = '${model.UpdateUserId}'
                WHERE BookmarkPersonalUrlKey = '${model.BookmarkPersonalUrlKey}'
                AND CreateUserId = '${model.UpdateUserId}'`
            await database.runTransaction(async (err, transaction) => {
                await transaction.runUpdate(script);
                await transaction.commit();
                resolve();
                await database.close();
            });
        } catch (err) {
            console.log("updateLink Error: ", err);
        } finally {
        }
    });
}

const deleteLink = async (key, eid) => {
    return await new Promise(async (resolve) => {
        try {
            let database = new SpannerDB();
            let script = `DELETE FROM BookmarkPersonalUrl                 
            WHERE BookmarkPersonalUrlKey = '${key}'
            AND CreateUserId = '${eid}'`
            await database.runTransaction(async (err, transaction) => {
                await transaction.runUpdate(script);
                await transaction.commit();
                resolve();
                await database.close();
            })
        } catch (err) {
            console.log("deleteLink Error: ", err);
        } finally {
        }
    });
}


const updateSharedLink = async (model) => {
    return await new Promise(async (resolve) => {
        try {
            console.log("model",model);
            let database = new SpannerDB();
            let script = `UPDATE BookmarkShared 
                SET Url = '${model.Url}',
                UrlName = '${model.UrlName}',
                UpdateDttm = PENDING_COMMIT_TIMESTAMP(),
                UpdateUserId = '${model.UpdateUserId}'
                WHERE BookmarkSharedKey = '${model.BookmarkSharedKey}'
                AND CreateUserId = '${model.UpdateUserId}'`
            await database.runTransaction(async (err, transaction) => {
                await transaction.runUpdate(script);
                await transaction.commit();
                resolve();
                await database.close();
            });
        } catch (err) {
            console.log("updateSharedLink Error: ", err);
        } finally {
        }
    });
}

const deleteSharedLink = async (key, eid) => {
    return await new Promise(async (resolve) => {
        try {
            let database = new SpannerDB();
            let script = `DELETE FROM BookmarkShared                 
            WHERE BookmarkSharedKey = '${key}'
            AND CreateUserId = '${eid}'`
            await database.runTransaction(async (err, transaction) => {
                await transaction.runUpdate(script);
                await transaction.commit();
                resolve();
                await database.close();
            });
        } catch (err) {
            console.log("deleteSharedLink Error: ", err);
        } finally {
        }
    })
}

const getCodeDetails = async () => {
    let database = new SpannerDB();
    const query = {
        sql: `SELECT cd.CodeTxt, cd.PrimaryDecodeTxt, ch.CategoryDesc
                FROM CodeDetail cd
                INNER JOIN CodeHeader ch
                    ON cd.CodeHeaderId = ch.CodeHeaderId
                WHERE ch.CategoryDesc IN ('PriorityLevel', 'PriorityStatus') 
                ORDER BY CodeTxt ASC`
    };
    try {
        let [codeDetails] = await database.run(query);
        return codeDetails;
    } catch (err) {
        console.log("getCodeDetails Error: ", err);
    } finally {
        await database.close();
    }
}

const createPriority = async (model) => {
    let database = new SpannerDB();
    console.log("model",model);
    const PrioritiesTable = database.table('Priorities');
    try {
        await PrioritiesTable.insert(model);
    } catch (err) {
        console.log("createPriority Error: ", err);
    } finally {
        await database.close();
    }
}

const updatePriority = async (model) => {
    let database = new SpannerDB();
    console.log("model",model);
    const PrioritiesTable = database.table('Priorities');
    try {
        await PrioritiesTable.update(model);
    } catch (err) {
        console.log("updatePriority Error: ", err);
    } finally {
        await database.close();
    }
}

const getMyPriorities_deadline = async () => {
    let database = new SpannerDB();
    const query = {
        sql: `SELECT p.PrioritiesKey
                    ,p.PriorityDesc
                    ,p.PriorityLevelCd
                    ,p.StatusCd
                    ,p.DueDt
                    ,p.CreatedFor
                    ,p.Comments
                    ,p.AssociatedClients
                    ,p.AssociatedContracts
                    ,p.AssociatedRI
                    ,p.CreateUserId
                    ,p.CreateDttm
                    ,p.UpdateUserId
                    ,p.UpdateDttm
                    ,'mypriority' AS PriorityType
                FROM Priorities p
                INNER JOIN CodeDetail cd
                    ON p.PriorityLevelCd = cd.CodeTxt
                WHERE p.CreatedFor = '${process.env.ENTERPRISEID}'
                ORDER BY p.DueDt ASC, cd.SecondaryDecodeTxt ASC`
    };
    try {
        let [priorities] = await database.run(query);
        return priorities;
    } catch (err) {
        console.log("getMyPriorities_deadline Error: ", err);
    } finally {
        await database.close();
    }
}

const getMyPriorities_prioritylevel = async () => {
    let database = new SpannerDB();
    const query = {
        sql: `SELECT p.PrioritiesKey
                    ,p.PriorityDesc
                    ,p.PriorityLevelCd
                    ,p.StatusCd
                    ,p.DueDt
                    ,p.CreatedFor
                    ,p.Comments
                    ,p.AssociatedClients
                    ,p.AssociatedContracts
                    ,p.AssociatedRI
                    ,p.CreateUserId
                    ,p.CreateDttm
                    ,p.UpdateUserId
                    ,p.UpdateDttm
                    ,'mypriority' AS PriorityType
                FROM Priorities p
                INNER JOIN CodeDetail cd
                    ON p.PriorityLevelCd = cd.CodeTxt
                WHERE p.CreatedFor = '${process.env.ENTERPRISEID}'
                ORDER BY cd.SecondaryDecodeTxt ASC, p.DueDt ASC`
    };
    try {
        let [priorities] = await database.run(query);
        return priorities;
    } catch (err) {
        console.log("getMyPriorities_prioritylevel Error: ", err);
    } finally {
        await database.close();
    }
}

const getDelegatedPriorities_deadline = async () => {
    let database = new SpannerDB();
    const query = {
        sql: `SELECT p.PrioritiesKey
                    ,p.PriorityDesc
                    ,p.PriorityLevelCd
                    ,p.StatusCd
                    ,p.DueDt
                    ,p.CreatedFor
                    ,p.Comments
                    ,p.AssociatedClients
                    ,p.AssociatedContracts
                    ,p.AssociatedRI
                    ,p.CreateUserId
                    ,p.CreateDttm
                    ,p.UpdateUserId
                    ,p.UpdateDttm
                    ,'delegated' AS PriorityType
                FROM Priorities p
                INNER JOIN CodeDetail cd
                    ON p.PriorityLevelCd = cd.CodeTxt
                WHERE p.CreateUserId = '${process.env.ENTERPRISEID}'
                    AND p.CreatedFor != '${process.env.ENTERPRISEID}'
                ORDER BY p.DueDt ASC, cd.SecondaryDecodeTxt ASC`
    };
    try {
        let [priorities] = await database.run(query);
        return priorities;
    } catch (err) {
        console.log("getDelegatedPriorities_deadline Error: ", err);
    } finally {
        await database.close();
    }
}

const getDelegatedPriorities_prioritylevel = async () => {
    let database = new SpannerDB();
    const query = {
        sql: `SELECT p.PrioritiesKey
                    ,p.PriorityDesc
                    ,p.PriorityLevelCd
                    ,p.StatusCd
                    ,p.DueDt
                    ,p.CreatedFor
                    ,p.Comments
                    ,p.AssociatedClients
                    ,p.AssociatedContracts
                    ,p.AssociatedRI
                    ,p.CreateUserId
                    ,p.CreateDttm
                    ,p.UpdateUserId
                    ,p.UpdateDttm
                    ,'delegated' AS PriorityType
                FROM Priorities p
                INNER JOIN CodeDetail cd
                    ON p.PriorityLevelCd = cd.CodeTxt
                WHERE p.CreateUserId = '${process.env.ENTERPRISEID}'
                    AND p.CreatedFor != '${process.env.ENTERPRISEID}'
                ORDER BY cd.SecondaryDecodeTxt ASC, p.DueDt ASC`
    };
    try {
        let [priorities] = await database.run(query);
        return priorities;
    } catch (err) {
        console.log("getDelegatedPriorities_prioritylevel Error: ", err);
    } finally {
        await database.close();
    }
}

const getPriority = async (key) => {
    let database = new SpannerDB();
    const query = {
        sql: `SELECT PrioritiesKey
                    ,PriorityDesc
                    ,PriorityLevelCd
                    ,StatusCd
                    ,DueDt
                    ,CreatedFor
                    ,Comments
                    ,AssociatedClients
                    ,AssociatedContracts
                    ,AssociatedRI
                    ,CreateUserId
                    ,CreateDttm
                    ,UpdateUserId
                    ,UpdateDttm
            FROM Priorities
            WHERE PrioritiesKey = '${key}'`
    };
    try {
        let [priority] = await database.run(query);
        return priority;
    } catch (err) {
        console.log("getPriority Error: ", err);
    } finally {
        await database.close();
    }
}

const deletePriority = async (key) => {
    return await new Promise(async (resolve) => {
        try {
            let database = new SpannerDB();
            let script = `DELETE FROM Priorities
            WHERE PrioritiesKey = '${key}'`
            await database.runTransaction(async (err, transaction) => {
                await transaction.runUpdate(script);
                await transaction.commit();
                resolve();
                await database.close();
            })
        } catch (err) {
            console.log("deletePriority Error: ", err);
        } finally {
        }
    });
}

module.exports = {
    createFolder,
    renameFolder,
    deleteFolder,
    getBookmarks,
    getSharedBookmarks,
    createLink,
    createSharedLink,
    updateLink,
    deleteLink,
    updateSharedLink,
    deleteSharedLink,
    getCodeDetails,
    createPriority,
    updatePriority,
    getMyPriorities_deadline,
    getMyPriorities_prioritylevel,
    getDelegatedPriorities_deadline,
    getDelegatedPriorities_prioritylevel,
    getPriority,
    deletePriority,
}