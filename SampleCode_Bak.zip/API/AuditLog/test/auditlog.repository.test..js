process.env.NODE_ENV = 'test';

const auditlogRepository = require('../server/auditlog.repository');
// const sinon = require('sinon');
const chai = require('chai');
const should = chai.should();
// const expect = require('chai').expect;
require('dotenv').config(); // Loads .env (for local)         

describe('Testing AuditLog Repository', () => {
    describe('getTokenExpiration', () => {
        describe('getTokenExpiration - successfully', () => {

            it("should return tokenexpiration json", async function () {
                const eid = process.env.ENTERPRISEID.toLowerCase(); // ensure the eid has entry in TokenExpiration table

                var result = await auditlogRepository.getTokenExpiration(eid);

                result.should.include.keys('TokenExpirationKey', 'EnterpriseId', 'Expiration');
                result.should.have.property('EnterpriseId').eql(eid);
                result.should.be.an('object');
            });

            it("should return null", async function () {
                const eid = process.env.ENTERPRISEID + 'unittest'; // ensure the eid has NO entry in TokenExpiration table

                var result = await auditlogRepository.getTokenExpiration(eid);

                should.equal(result, null);
            });
        });

        describe('getTokenExpiration - error', () => {
            let env;
            before(() => {
                env = Object.assign({}, process.env);
            })
    
            after(() => {
                process.env = env;
            })

            it("should throw an error", async function () {
                process.env.UNIT_TEST_DATABASE_ID = 'unit test'; // alter the database config to throw an error
                const eid = process.env.ENTERPRISEID.toLowerCase();

                var result = await auditlogRepository.getTokenExpiration(eid);

                result.message.should.eql('Error: 3 INVALID_ARGUMENT: Invalid CreateSession request.');
            });
        });
    });

    describe('insertAuditLog', () => {
        describe('insertAuditLog - successfully', () => {

            it("should insert auditlog", async function () {
                const objectname = 'Unit Test';
                const eventtypename = 'Test';
                const eid = process.env.ENTERPRISEID.toLowerCase(); // ensure the eid has entry in TokenExpiration table

                var result = await auditlogRepository.insertAuditLog(objectname, eventtypename);

                result.should.have.property('commitTimestamp');
                result.should.be.an('object');
            });
        });

        describe('insertAuditLog - error', () => {
            let env;
            before(() => {
                env = Object.assign({}, process.env);
            })
    
            after(() => {
                process.env = env;
            })

            it("should throw an error", async function () {
                process.env.UNIT_TEST_DATABASE_ID = 'unit test'; // alter the database config to throw an error
                const objectname = 'Unit Test';
                const eventtypename = 'Test';
                const eid = process.env.ENTERPRISEID.toLowerCase();

                var result = await auditlogRepository.insertAuditLog(objectname, eventtypename);

                result.message.should.eql('Error: 3 INVALID_ARGUMENT: Invalid CreateSession request.');
            });
        });
    });

    describe('insertTokenExpiration', () => {
        describe('insertTokenExpiration - successfully', () => {

            it("should insert token expiration", async function () {
                const exp = '1555043561';
                const eid = process.env.ENTERPRISEID.toLowerCase(); // ensure the eid has entry in TokenExpiration table

                var result = await auditlogRepository.insertTokenExpiration(eid, exp);

                result.should.have.property('commitTimestamp');
                result.should.be.an('object');
            });
        });

        describe('insertTokenExpiration - error', () => {
            let env;
            before(() => {
                env = Object.assign({}, process.env);
            })
    
            after(() => {
                process.env = env;
            })

            it("should throw an error", async function () {
                process.env.UNIT_TEST_DATABASE_ID = 'unit test'; // alter the database config to throw an error
                const exp = '1555043561';
                const eid = process.env.ENTERPRISEID.toLowerCase();

                var result = await auditlogRepository.insertTokenExpiration(eid, exp);

                result.message.should.eql('Error: 3 INVALID_ARGUMENT: Invalid CreateSession request.');
            });
        });
    });

    describe('updateTokenExpiration', () => {
        describe('updateTokenExpiration - successfully', () => {

            it("should insert token expiration", async function () {
                const exp = '1234567890';
                const eid = process.env.ENTERPRISEID.toLowerCase(); // ensure the eid has entry in TokenExpiration table
                var row = await auditlogRepository.getTokenExpiration(eid);
                row.Expiration = exp;

                var result = await auditlogRepository.updateTokenExpiration(row);

                result.should.have.property('commitTimestamp');
                result.should.be.an('object');
            });
        });

        describe('updateTokenExpiration - error', () => {
            let env;
            before(() => {
                env = Object.assign({}, process.env);
            })
    
            after(() => {
                process.env = env;
            })

            it("should throw an error", async function () {
                process.env.UNIT_TEST_DATABASE_ID = 'unit test'; // alter the database config to throw an error
                const exp = '0987654321';
                const eid = process.env.ENTERPRISEID.toLowerCase();

                var result = await auditlogRepository.updateTokenExpiration(eid, exp);

                result.message.should.eql('Error: 3 INVALID_ARGUMENT: Invalid CreateSession request.');
            });
        });
    });
});