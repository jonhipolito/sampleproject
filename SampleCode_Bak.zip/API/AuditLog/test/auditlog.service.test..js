process.env.NODE_ENV = 'test';

const auditlogRepository = require('../server/auditlog.repository');
const auditlogService = require('../server/auditlog.service');
const sinon = require('sinon');
const chai = require('chai');
const should = chai.should();

describe('Testing AuditLog Service', () => {

    describe('_postnewlog - successfull', () => {

        describe('', () => {
            before(() => {
                sinon.stub(auditlogRepository, 'getTokenExpiration').returns(null);
                sinon.stub(auditlogRepository, 'insertAuditLog').returns(null);
                sinon.stub(auditlogRepository, 'insertTokenExpiration').returns(null);
            })
            after(() => {
                auditlogRepository.getTokenExpiration.restore();
                auditlogRepository.insertAuditLog.restore();
                auditlogRepository.insertTokenExpiration.restore();
            })

            it("should insert audit log and expiration", function (done) {
                var req = ({
                    body: { objectname: "Home Page", eventtypename: "Visit" },
                    headers: { authorization: "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ik4tbEMwbi05REFMcXdodUhZbkhRNjNHZUNYYyIsImtpZCI6Ik4tbEMwbi05REFMcXdodUhZbkhRNjNHZUNYYyJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTU1MDM5NjYyLCJuYmYiOjE1NTUwMzk2NjIsImV4cCI6MTU1NTA0MzU2MiwiYWlvIjoiQVZRQXEvOExBQUFBTU44ZXZwMmZkY2EwY2tNWUVNRTZ0MFA3dFNZTENNSGRHTkVsbWQyb2E1V1JwOXVNNjJ4REtvWldFTWg0OG5hRkhKVHdwLzVUTWxvTUYrME5yTnBIZWVENW1KY0xlRHY4UFRHTS8xT0dTTXc9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkdhcmNpYSIsImdpdmVuX25hbWUiOiJFbGlhemFyIiwiaXBhZGRyIjoiMTQ0LjM2LjEzOC4yNTEiLCJuYW1lIjoiR2FyY2lhLCBFbGlhemFyIFMuIiwibm9uY2UiOiIyY2ExY2EyOS1iYTJiLTRjYzAtODFmZC04Y2FlYzY0MzA5ZjEiLCJvaWQiOiIyMDZjNjNlZi05NWRkLTQ4NTQtYmM3Zi01NTQxMjUwZDE5NGUiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTE5MDU3NzEiLCJzdWIiOiI1VE5CS0k2clo0TlBJd0I5V19uY3hYNklCN2VKb0xhdGI3WEVwcklaUkFBIiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJlbGlhemFyLnMuZ2FyY2lhQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXBuIjoiZWxpYXphci5zLmdhcmNpYUBkcy5kZXYuYWNjZW50dXJlLmNvbSIsInV0aSI6Ikw3RWFrdmZUWmttdk0zSDhVajNUQUEiLCJ2ZXIiOiIxLjAifQ.kI3RPac_0D5CTMFGmW18v-a-R2xNAlCw71vqAyJcd1mth-ufu7TsNVzg85TpSm1TTYkQl2HiRuAEv72lHzoivORO9luRWrjxe1eYz8XYhuzvFUbkybI_uOVWtVlzOWYwpGanR8-8ERxxs2kBJdRUQ4_R4OR8-MzMD2rMcot9XhMoVUiXmcUKcHOv1nZFVBfUMuPRSRJvtno1TaCJO35dH3PM-t6LVp0wbmNdkPqNRbIwufj4-DrmmjuXQopRu5vquJvENpl4W71xG9jtQI9_ksYvCICYOHxyq_sCMlsNBTW96G7l0CJdXnOuv74WZdGddflJ8CWLMEzsBT_R_R7mBw" }
                })

                auditlogService._postnewlog(req)
                    .then(message => {
                        message.should.eql('new audit log inserted');
                    })
                    .finally(done())
            });
        });

        describe('', () => {
            before(() => {
                var obj = { Expiration: 'test expiration' }
                sinon.stub(auditlogRepository, 'getTokenExpiration').returns(obj);
                sinon.stub(auditlogRepository, 'insertAuditLog').returns(null);
                sinon.stub(auditlogRepository, 'updateTokenExpiration').returns(null);
            })
            after(() => {
                auditlogRepository.getTokenExpiration.restore();
                auditlogRepository.insertAuditLog.restore();
                auditlogRepository.updateTokenExpiration.restore();
            })

            it("should insert audit log and update expiration", function (done) {
                var req = ({
                    body: { objectname: "Home Page", eventtypename: "Visit" },
                    headers: { authorization: "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ik4tbEMwbi05REFMcXdodUhZbkhRNjNHZUNYYyIsImtpZCI6Ik4tbEMwbi05REFMcXdodUhZbkhRNjNHZUNYYyJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTU1MDM5NjYyLCJuYmYiOjE1NTUwMzk2NjIsImV4cCI6MTU1NTA0MzU2MiwiYWlvIjoiQVZRQXEvOExBQUFBTU44ZXZwMmZkY2EwY2tNWUVNRTZ0MFA3dFNZTENNSGRHTkVsbWQyb2E1V1JwOXVNNjJ4REtvWldFTWg0OG5hRkhKVHdwLzVUTWxvTUYrME5yTnBIZWVENW1KY0xlRHY4UFRHTS8xT0dTTXc9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkdhcmNpYSIsImdpdmVuX25hbWUiOiJFbGlhemFyIiwiaXBhZGRyIjoiMTQ0LjM2LjEzOC4yNTEiLCJuYW1lIjoiR2FyY2lhLCBFbGlhemFyIFMuIiwibm9uY2UiOiIyY2ExY2EyOS1iYTJiLTRjYzAtODFmZC04Y2FlYzY0MzA5ZjEiLCJvaWQiOiIyMDZjNjNlZi05NWRkLTQ4NTQtYmM3Zi01NTQxMjUwZDE5NGUiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTE5MDU3NzEiLCJzdWIiOiI1VE5CS0k2clo0TlBJd0I5V19uY3hYNklCN2VKb0xhdGI3WEVwcklaUkFBIiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJlbGlhemFyLnMuZ2FyY2lhQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXBuIjoiZWxpYXphci5zLmdhcmNpYUBkcy5kZXYuYWNjZW50dXJlLmNvbSIsInV0aSI6Ikw3RWFrdmZUWmttdk0zSDhVajNUQUEiLCJ2ZXIiOiIxLjAifQ.kI3RPac_0D5CTMFGmW18v-a-R2xNAlCw71vqAyJcd1mth-ufu7TsNVzg85TpSm1TTYkQl2HiRuAEv72lHzoivORO9luRWrjxe1eYz8XYhuzvFUbkybI_uOVWtVlzOWYwpGanR8-8ERxxs2kBJdRUQ4_R4OR8-MzMD2rMcot9XhMoVUiXmcUKcHOv1nZFVBfUMuPRSRJvtno1TaCJO35dH3PM-t6LVp0wbmNdkPqNRbIwufj4-DrmmjuXQopRu5vquJvENpl4W71xG9jtQI9_ksYvCICYOHxyq_sCMlsNBTW96G7l0CJdXnOuv74WZdGddflJ8CWLMEzsBT_R_R7mBw" }
                })

                auditlogService._postnewlog(req)
                    .then(message => {
                        message.should.eql('new audit log inserted');
                    })
                    .finally(done())
            });
        });

        describe('', () => {
            before(() => {
                var obj = { Expiration: '1555043562' }
                sinon.stub(auditlogRepository, 'getTokenExpiration').returns(obj);
            })
            after(() => {
                auditlogRepository.getTokenExpiration.restore();
            })

            it("should not insert audit log and should not insert expiration", function (done) {
                var req = ({
                    body: { objectname: "Home Page", eventtypename: "Visit" },
                    headers: { authorization: "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ik4tbEMwbi05REFMcXdodUhZbkhRNjNHZUNYYyIsImtpZCI6Ik4tbEMwbi05REFMcXdodUhZbkhRNjNHZUNYYyJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTU1MDM5NjYyLCJuYmYiOjE1NTUwMzk2NjIsImV4cCI6MTU1NTA0MzU2MiwiYWlvIjoiQVZRQXEvOExBQUFBTU44ZXZwMmZkY2EwY2tNWUVNRTZ0MFA3dFNZTENNSGRHTkVsbWQyb2E1V1JwOXVNNjJ4REtvWldFTWg0OG5hRkhKVHdwLzVUTWxvTUYrME5yTnBIZWVENW1KY0xlRHY4UFRHTS8xT0dTTXc9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkdhcmNpYSIsImdpdmVuX25hbWUiOiJFbGlhemFyIiwiaXBhZGRyIjoiMTQ0LjM2LjEzOC4yNTEiLCJuYW1lIjoiR2FyY2lhLCBFbGlhemFyIFMuIiwibm9uY2UiOiIyY2ExY2EyOS1iYTJiLTRjYzAtODFmZC04Y2FlYzY0MzA5ZjEiLCJvaWQiOiIyMDZjNjNlZi05NWRkLTQ4NTQtYmM3Zi01NTQxMjUwZDE5NGUiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTE5MDU3NzEiLCJzdWIiOiI1VE5CS0k2clo0TlBJd0I5V19uY3hYNklCN2VKb0xhdGI3WEVwcklaUkFBIiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJlbGlhemFyLnMuZ2FyY2lhQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXBuIjoiZWxpYXphci5zLmdhcmNpYUBkcy5kZXYuYWNjZW50dXJlLmNvbSIsInV0aSI6Ikw3RWFrdmZUWmttdk0zSDhVajNUQUEiLCJ2ZXIiOiIxLjAifQ.kI3RPac_0D5CTMFGmW18v-a-R2xNAlCw71vqAyJcd1mth-ufu7TsNVzg85TpSm1TTYkQl2HiRuAEv72lHzoivORO9luRWrjxe1eYz8XYhuzvFUbkybI_uOVWtVlzOWYwpGanR8-8ERxxs2kBJdRUQ4_R4OR8-MzMD2rMcot9XhMoVUiXmcUKcHOv1nZFVBfUMuPRSRJvtno1TaCJO35dH3PM-t6LVp0wbmNdkPqNRbIwufj4-DrmmjuXQopRu5vquJvENpl4W71xG9jtQI9_ksYvCICYOHxyq_sCMlsNBTW96G7l0CJdXnOuv74WZdGddflJ8CWLMEzsBT_R_R7mBw" }
                })

                auditlogService._postnewlog(req)
                    .then(message => {
                        message.should.eql('no action needed - nothing inserted');
                    })
                    .finally(done())
            });
        });
    });

    describe('_postnewlog - Catch Error', () => {
        before(() => {
            // var obj = { Expiration: '1555043562' }
            sinon.stub(auditlogRepository, 'getTokenExpiration').rejects(new Error('Fake Repository Error'));
        })
        after(() => {
            auditlogRepository.getTokenExpiration.restore();
        })
        it("should catch an error", function (done) {
            var req = ({
                body: { objectname: "Home Page", eventtypename: "Visit" },
                headers: { authorization: "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ik4tbEMwbi05REFMcXdodUhZbkhRNjNHZUNYYyIsImtpZCI6Ik4tbEMwbi05REFMcXdodUhZbkhRNjNHZUNYYyJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTU1MDM5NjYyLCJuYmYiOjE1NTUwMzk2NjIsImV4cCI6MTU1NTA0MzU2MiwiYWlvIjoiQVZRQXEvOExBQUFBTU44ZXZwMmZkY2EwY2tNWUVNRTZ0MFA3dFNZTENNSGRHTkVsbWQyb2E1V1JwOXVNNjJ4REtvWldFTWg0OG5hRkhKVHdwLzVUTWxvTUYrME5yTnBIZWVENW1KY0xlRHY4UFRHTS8xT0dTTXc9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkdhcmNpYSIsImdpdmVuX25hbWUiOiJFbGlhemFyIiwiaXBhZGRyIjoiMTQ0LjM2LjEzOC4yNTEiLCJuYW1lIjoiR2FyY2lhLCBFbGlhemFyIFMuIiwibm9uY2UiOiIyY2ExY2EyOS1iYTJiLTRjYzAtODFmZC04Y2FlYzY0MzA5ZjEiLCJvaWQiOiIyMDZjNjNlZi05NWRkLTQ4NTQtYmM3Zi01NTQxMjUwZDE5NGUiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTE5MDU3NzEiLCJzdWIiOiI1VE5CS0k2clo0TlBJd0I5V19uY3hYNklCN2VKb0xhdGI3WEVwcklaUkFBIiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJlbGlhemFyLnMuZ2FyY2lhQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXBuIjoiZWxpYXphci5zLmdhcmNpYUBkcy5kZXYuYWNjZW50dXJlLmNvbSIsInV0aSI6Ikw3RWFrdmZUWmttdk0zSDhVajNUQUEiLCJ2ZXIiOiIxLjAifQ.kI3RPac_0D5CTMFGmW18v-a-R2xNAlCw71vqAyJcd1mth-ufu7TsNVzg85TpSm1TTYkQl2HiRuAEv72lHzoivORO9luRWrjxe1eYz8XYhuzvFUbkybI_uOVWtVlzOWYwpGanR8-8ERxxs2kBJdRUQ4_R4OR8-MzMD2rMcot9XhMoVUiXmcUKcHOv1nZFVBfUMuPRSRJvtno1TaCJO35dH3PM-t6LVp0wbmNdkPqNRbIwufj4-DrmmjuXQopRu5vquJvENpl4W71xG9jtQI9_ksYvCICYOHxyq_sCMlsNBTW96G7l0CJdXnOuv74WZdGddflJ8CWLMEzsBT_R_R7mBw" }
            })

            auditlogService._postnewlog(req)
                .catch(error => {
                    error.message.should.eql('Fake Repository Error');
                })
                .finally(done())
        });

    });

    describe('_postnewlog - Out of Scope Error', () => {
        it("should return out of scope error", function (done) {
            var req = ({
                body: { objectname: "Test Page", eventtypename: "Test" }, // values should not be equal to 'Home Page' and 'Visit
                headers: { authorization: "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ik4tbEMwbi05REFMcXdodUhZbkhRNjNHZUNYYyIsImtpZCI6Ik4tbEMwbi05REFMcXdodUhZbkhRNjNHZUNYYyJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTU1MDM5NjYyLCJuYmYiOjE1NTUwMzk2NjIsImV4cCI6MTU1NTA0MzU2MiwiYWlvIjoiQVZRQXEvOExBQUFBTU44ZXZwMmZkY2EwY2tNWUVNRTZ0MFA3dFNZTENNSGRHTkVsbWQyb2E1V1JwOXVNNjJ4REtvWldFTWg0OG5hRkhKVHdwLzVUTWxvTUYrME5yTnBIZWVENW1KY0xlRHY4UFRHTS8xT0dTTXc9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkdhcmNpYSIsImdpdmVuX25hbWUiOiJFbGlhemFyIiwiaXBhZGRyIjoiMTQ0LjM2LjEzOC4yNTEiLCJuYW1lIjoiR2FyY2lhLCBFbGlhemFyIFMuIiwibm9uY2UiOiIyY2ExY2EyOS1iYTJiLTRjYzAtODFmZC04Y2FlYzY0MzA5ZjEiLCJvaWQiOiIyMDZjNjNlZi05NWRkLTQ4NTQtYmM3Zi01NTQxMjUwZDE5NGUiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTE5MDU3NzEiLCJzdWIiOiI1VE5CS0k2clo0TlBJd0I5V19uY3hYNklCN2VKb0xhdGI3WEVwcklaUkFBIiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJlbGlhemFyLnMuZ2FyY2lhQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXBuIjoiZWxpYXphci5zLmdhcmNpYUBkcy5kZXYuYWNjZW50dXJlLmNvbSIsInV0aSI6Ikw3RWFrdmZUWmttdk0zSDhVajNUQUEiLCJ2ZXIiOiIxLjAifQ.kI3RPac_0D5CTMFGmW18v-a-R2xNAlCw71vqAyJcd1mth-ufu7TsNVzg85TpSm1TTYkQl2HiRuAEv72lHzoivORO9luRWrjxe1eYz8XYhuzvFUbkybI_uOVWtVlzOWYwpGanR8-8ERxxs2kBJdRUQ4_R4OR8-MzMD2rMcot9XhMoVUiXmcUKcHOv1nZFVBfUMuPRSRJvtno1TaCJO35dH3PM-t6LVp0wbmNdkPqNRbIwufj4-DrmmjuXQopRu5vquJvENpl4W71xG9jtQI9_ksYvCICYOHxyq_sCMlsNBTW96G7l0CJdXnOuv74WZdGddflJ8CWLMEzsBT_R_R7mBw" }
            })

            auditlogService._postnewlog(req)
                .catch(error => {
                    error.message.should.eql('Out of Scope');
                })
                .finally(done())
        });

    });

    describe('_postnewlog - Insert Audit Log Error', () => {
        it("should catch insert audit log error", function (done) {
            auditlogService._postnewlog(null)
                .catch(error => {
                    error.message.should.eql('Cannot read property \'obj\' of null');
                })
                .finally(done())
        });

    });

});