process.env.NODE_ENV = 'test';
const auditlogController = require('../server/auditlog.controller');
const auditlogService = require('../server/auditlog.service');
const sinon = require('sinon');
const chai = require('chai');
const should = chai.should();
const expect = require('chai').expect;

describe('Testing AuditLog Controller', () => {

    describe('POST auditlog - successfull', () => {

        before(() => {
            sinon.stub(auditlogService, '_postnewlog').returns(new Promise((resolve, reject) => {
                resolve('unit test');
            }));
        })

        after(() => {
            auditlogService._postnewlog.restore();
        })

        it("should send a message after insert", function () {
            var req = new Object();
            var res = new Object();

            res.send = function (val) {
                val.should.have.property('message');
                val.should.have.property('message').eql('unit test');
            }

            auditlogController.postnewlog(req, res, {});
        });
    });

    describe('POST auditlog - Error', () => {
        before(() => {
            sinon.stub(auditlogService, '_postnewlog').rejects(new Error('Fake Service Error'));
        })

        after(() => {
            auditlogService._postnewlog.restore();
        })
        
        it("should return an error", function () {
            var req = ({
                body: { objectname: "Home Page", eventtypename: "Visit" }
                , headers: { authorization: undefined }
            })
            var res = new Object();
            var callback = sinon.spy();

            auditlogController.postnewlog(req, res, callback);

            try {
                new ErrorThrowingObject();
                // Force the test to fail since error wasn't thrown
                should.fail('no error was thrown when it should have been')
            }
            catch (error) {
                // console.log(error);
                // done();
            }
        });
        
    });
});