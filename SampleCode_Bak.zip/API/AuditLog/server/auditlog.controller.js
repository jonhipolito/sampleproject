'use strict';

const service = require('./auditlog.service');

const postnewlog = (req, res, next) => {
    service._postnewlog(req.body)
        .then(log => {
            res.send({
                message: log
            });
        })
        .catch(error => {
            const err = new Error(error);
            next(err);
        })
}

module.exports = {
    postnewlog
}