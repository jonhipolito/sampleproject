'use strict';

const auditLogRepository = require('./auditlog.repository');
const jwt = require('jsonwebtoken');
const AuditLogModel =  require('./models/auditlog.model');

const _postnewlog = (body) => {
  return new Promise(async function (resolve, reject) {
    // let message;
    // if (req.body.objectname === 'Home Page' && req.body.eventtypename === 'Visit') {
    //   try {
    //     const jwtToken = req.headers.authorization.substring(7);
    //     const decoded = jwt.decode(jwtToken, { complete: true });

    //     let tokenExpirationRow = await auditLogRepository.getTokenExpiration(process.env.ENTERPRISEID);
    //     if (tokenExpirationRow != null) {
    //       if (decoded.payload.exp != tokenExpirationRow.Expiration) {
    //         auditLogRepository.insertAuditLog(req.body.objectname, req.body.eventtypename, process.env.ENTERPRISEID);
    //         tokenExpirationRow.Expiration = decoded.payload.exp;
    //         auditLogRepository.updateTokenExpiration(tokenExpirationRow);
    //         message = 'new audit log inserted, updated the token expiration';
    //       } else {
    //         // Do Nothing
    //         message = 'no action needed - nothing inserted';
    //       }
    //     } else {
    //       auditLogRepository.insertAuditLog(req.body.objectname, req.body.eventtypename, process.env.ENTERPRISEID);
    //       auditLogRepository.insertTokenExpiration(process.env.ENTERPRISEID, decoded.payload.exp);
    //       message = 'new audit log inserted, new token expiration inserted';
    //     }

    //     resolve(message);

    //   } catch (error) {
    //     reject(error);
    //   }

    // } else {
    //   reject(new Error('Out of Scope'));
    // }
    // else { // For Future Releases
      try {
        let model = new AuditLogModel(body.obj, body.eventtype, process.env.ENTERPRISEID)
        auditLogRepository.insertAuditLog(model);
        resolve('new audit log inserted');
      } catch (error) {
        console.error('ERROR:', error);
        reject(error);
      }
    // }
  });
}

module.exports = {
  _postnewlog
}