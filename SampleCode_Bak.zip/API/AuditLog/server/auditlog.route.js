'use strict';

const express = require('express');

const auditlogController = require('./auditlog.controller');

const router = express.Router();

router.post('/postnewlog', auditlogController.postnewlog);

module.exports = router;