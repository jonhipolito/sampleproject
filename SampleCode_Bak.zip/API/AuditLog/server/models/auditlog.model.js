'use strict';

const uuid = require('uuidv4');

module.exports = function (objnm, evnttypnm, eid) {
    this.AuditLogKey = uuid();
    this.ObjectNm = objnm;
    this.EventTypeNm = evnttypnm;
    this.EventDt = 'spanner.commit_timestamp()';
    this.EnterpriseId = eid;
    this.CreateDttm = 'spanner.commit_timestamp()';
}