'use strict';

const uuid = require('uuidv4');

module.exports = function (eid, exprtn) {
    this.TokenExpirationKey = uuid();
    this.EnterpriseId = eid;
    this.Expiration = exprtn;
}