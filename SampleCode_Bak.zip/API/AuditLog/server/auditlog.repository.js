'use strict';

const uuid = require('uuidv4'),
    SpannerDB = require('../configs/db.connection'),
    AuditLogModel = require('./models/auditlog.model'),
    TokenExpirationModel = require('./models/tokenexpiration.model');

const getTokenExpiration = async eid => {
    const database = new SpannerDB();
    const query = {
        sql: `SELECT * FROM TokenExpiration WHERE EnterpriseId = '${eid}' LIMIT 1`,
    };

    // Queries top 1 from the TokenExpiration table
    try {
        const [row] = await database.run(query);
        if (row.length > 0) {
            return row[0].toJSON();
        } else {
            return null;
        }
    } catch (err) {
        return new Error(err);
    } finally {
        // Close the database when finished.
        await database.close();
    }
}

const insertAuditLog = async (model) => {

    let database = new SpannerDB();
    const auditLogTable = database.table('AuditLog');

    // let rowToInsert = [];
    // let model = new AuditLogModel(objectname, eventtypename, process.env.ENTERPRISEID);
    // rowToInsert.push(model);

    try {
        console.log(model);
        var commitTimestamp = await auditLogTable.insert(model);
        return commitTimestamp[0];
    } catch (err) {
        return new Error(err);
    } finally {
        await database.close();
    }
}

const insertTokenExpiration = async (eid, exp) => {

    let database = new SpannerDB();
    const tokenExpirationTable = database.table('TokenExpiration');

    let rowToInsert = [];
    let model = new TokenExpirationModel(eid, exp);
    rowToInsert.push(model);

    try {
        var commitTimestamp = await tokenExpirationTable.insert(rowToInsert);
        return commitTimestamp[0];
    } catch (err) {
        return new Error(err);
    } finally {
        await database.close();
    }
}

const updateTokenExpiration = async (row) => {

    let database = new SpannerDB();
    const tokenExpirationTable = database.table('TokenExpiration');

    try {
        var commitTimestamp = await tokenExpirationTable.update(row);
        return commitTimestamp[0];
    } catch (err) {
        return new Error(err);
    } finally {
        await database.close();
    }
}

module.exports = {
    getTokenExpiration
    ,insertAuditLog
    ,insertTokenExpiration
    ,updateTokenExpiration
}
