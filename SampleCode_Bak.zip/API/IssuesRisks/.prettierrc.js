module.exports = {
    printWidth: 140,
    semi: true,
    singleQuote: true,
    trailingComma: 'none',
    bracketSpacing: false,
    arrowParens: 'avoid',
    requirePragma: false,
    proseWrap: 'preserve'
};