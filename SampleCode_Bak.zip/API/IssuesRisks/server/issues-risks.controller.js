'use strict';
const uuid = require('uuidv4');
const IssuesRisksService = require('./issues-risks.service');
const consultationCallExportService = require('./consultation-call-export.service');

/** Class representing an IssuesRisksController. */
class IssuesRisksController {
  /**
   * @return {IssuesRisksService}
   */
  static getService() {
    return IssuesRisksService.getInstance();
  }

  static async getRiskDetails(req, res, next) {
    try {
      const {riskDetailsKey} = req.params;
      const service = IssuesRisksController.getService();
      const details = await service.getDetails(riskDetailsKey);
      res.status(200).json(details);
    } catch (err) {
      next(new Error(err));
    }
  }

  static async getRiskNba(req, res, next) {
    try {
      const {questionKey} = req.params;
      const service = IssuesRisksController.getService();
      const nbaArr = await service.getNba(questionKey);
      res.status(200).json(nbaArr);
    } catch (err) {
      next(new Error(err));
    }
  }

  static async createRiskDetails(req, res, next) {
    try {
      const model = req.body;
      const service = IssuesRisksController.getService();
      const result = await service.createDetails(model);
      const details = {
        RiskDetailsKey: result.RiskDetailsKey || null
      };
      if (result.message) {
        details.message = result.message;
      }
      res.status(200).json(details);
    } catch (err) {
      next(new Error(err));
    }
  }

  static async updateRiskDetails(req, res, next) {
    try {
      const {riskDetailsKey} = req.params;
      const {authorization} = req.headers;
      const model = req.body;
      model.token = authorization || '';
      const service = IssuesRisksController.getService();
      const result = await service.updateDetails(riskDetailsKey, model);
      const details = {
        RiskDetailsKey: result.RiskDetailsKey || null
      };
      res.status(200).json(details);
    } catch (err) {
      next(new Error(err));
    }
  }

  static async createRiskFeedback(req, res, next) {
    try {
      const model = req.body;
      const service = IssuesRisksController.getService();
      const feedbackResult = await service.createFeedback(model);
      res.status(200).json(feedbackResult);
    } catch (err) {
      next(new Error(err));
    }
  }

  static async getRiskCodes(req, res, next) {
    try {
      const category = req.query.category;
      const service = IssuesRisksController.getService();
      const codes = await service.getCodes(category);
      res.status(200).json(codes);
    } catch (err) {
      next(new Error(err));
    }
  }

  static async getRiskQuestions(req, res, next) {
    try {
      const {contractNbr} = req.query;
      const service = IssuesRisksController.getService();
      const questions = await service.getQuestions(contractNbr);
      res.status(200).json(questions);
    } catch (err) {
      next(new Error(err));
    }
  }

  static async getRiskQuestion(req, res, next) {
    try {
      const {questionKey} = req.params;
      const service = IssuesRisksController.getService();
      const question = await service.getQuestion(questionKey);
      res.status(200).json(question);
    } catch (err) {
      next(new Error(err));
    }
  }

  static async getRiskHistoryList(req, res, next) {
    try {
      const {riskDetailsKey} = req.params;
      const service = IssuesRisksController.getService();
      const histories = await service.getHistoryList(riskDetailsKey);
      res.status(200).json(histories);
    } catch (err) {
      next(new Error(err));
    }
  }

  static async getRiskHistory(req, res, next) {
    try {
      const {riskDetailsKey, historyKey} = req.params;
      const service = IssuesRisksController.getService();
      const history = await service.getHistory(historyKey, riskDetailsKey);
      res.status(200).json(history);
    } catch (err) {
      next(new Error(err));
    }
  }

  static async getContractScores(req, res, next) {
    try {
      const {contractNbr} = req.query;
      const service = IssuesRisksController.getService();
      const contractScore = await service.getContractScores(contractNbr || null);
      res.status(200).json(contractScore);
    } catch (err) {
      next(new Error(err));
    }
  }

  static async getCCDownload(req, res, next) {
    try {
      const downloadItem = await consultationCallExportService.getDownloadItemByEid(process.env.ENTERPRISEID, 'Risks & Issues sent to CC');

      res.status(200).json({
        data: downloadItem
      });
    } catch (err) {
      next(new Error(err));
    }
  }

  static async updateCCDownloadStatus(req, res, next) {
    try {
      const {downloadKey, status} = req.query;
      const updateResult = await consultationCallExportService.updateDownloadStatus(downloadKey, status);
      res.status(200).json({
        data: updateResult
      });
    } catch (err) {
      next(new Error(err));
    }
  }

  static async postCCDownload(req, res, next) {
    try {
      const eid = process.env.ENTERPRISEID;
      const downloadKey = uuid();
      const insertResult = await consultationCallExportService.insertDownloadItem(eid, downloadKey);
      const {startdate, enddate} = req.query;
      if (insertResult) {
        // don't add await here, it will execute in backend threading
        // noinspection ES6MissingAwait
        consultationCallExportService.exportConsultationCall(eid, downloadKey, startdate, enddate);
        res.status(200).json({
          data: 'ok'
        });
      }
    } catch (err) {
      next(new Error(err));
    }
  }

  static async isGlobalCM(req, res, next) {
    try {
      const eid = process.env.ENTERPRISEID;
      const result = await consultationCallExportService.isGlobalCM(eid);
      res.status(200).json({
        data: result
      });
    } catch (err) {
      next(new Error(err));
    }
  }
}

module.exports = IssuesRisksController;
