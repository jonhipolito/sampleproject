'use strict';

const express = require('express');
const IssuesRisksController = require('./issues-risks.controller');
const router = express.Router();
const {hasAccess} = require('./middlewares/accesscontrol');

router.get('/contract-scores', hasAccess, IssuesRisksController.getContractScores);

router.get('/codes', hasAccess, IssuesRisksController.getRiskCodes);

router.get('/questions', hasAccess, IssuesRisksController.getRiskQuestions);

router.get('/questions/:questionKey', hasAccess, IssuesRisksController.getRiskQuestion);

router.get('/questions/:questionKey/nba', IssuesRisksController.getRiskNba);

router.post('/download/status', IssuesRisksController.updateCCDownloadStatus);

router.get('/isGlobalCM', IssuesRisksController.isGlobalCM);

router.get('/download', IssuesRisksController.getCCDownload);

router.post('/feedback', IssuesRisksController.createRiskFeedback);

router.post('/download', IssuesRisksController.postCCDownload);

/**
 * @swagger
 *
 * /issues-risks/{riskDetailsKey}:
 *   get:
 *     tags:
 *       - Issues-Risks
 *     summary: Get details of Issue/Risk by key
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: riskDetailsKey
 *         description: Key of Issue/Risk.
 *         in: path
 *         required: true
 *         type: string
 *     responses:
 *       200:
 *         description: OK
 *         content:
 *           application/json:
 *
 */
router.get('/:riskDetailsKey', IssuesRisksController.getRiskDetails);

router.post('/', IssuesRisksController.createRiskDetails);

router.put('/:riskDetailsKey', IssuesRisksController.updateRiskDetails);

router.get('/:riskDetailsKey/histories', IssuesRisksController.getRiskHistoryList);

router.get('/:riskDetailsKey/histories/:historyKey', IssuesRisksController.getRiskHistory);

module.exports = router;
