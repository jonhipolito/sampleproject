'use strict';

const request = require('request');

class IssuesRisksHttp {
  async sendCIPComments(events, token) {
    return new Promise((resolve, reject) => {
      let options = {
        method: 'post',
        body: { events },
        json: true,
        uri: process.env.CIP_COMMENT_ENDPOINT,
        headers: {
          'Content-Type': 'application/json',
          Authorization: token
        }
      };

      request.post(options, function(error, response, body) {
        if (!error && response.statusCode === 200) {
          console.log(`sendCIPComment_successful: ${body}`);
          resolve(response.statusMessage);
        } else {
          console.log(`sendCIPComment_error: ${error}`);
          reject(error);
        }
      });
    });
  }
}

module.exports = IssuesRisksHttp;
