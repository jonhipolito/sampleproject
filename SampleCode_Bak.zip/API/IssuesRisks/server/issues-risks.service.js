'use strict';

const IssuesRisksRepository = require('./issues-risks.repository');
const random = require('string-random');

/** Class representing an IssuesRisksService. */
class IssuesRisksService {
  /**
   * Create an IssuesRiskService
   * @param {IssuesRisksRepository} issuesRisksRepository
   * @return {IssuesRisksService} An IssuesRisksService object.
   */
  constructor(issuesRisksRepository) {
    this.repository = issuesRisksRepository;
    this.maxRetryAttempts = 3;
  }

  /**
   * Get an instance of IssuesRisksService
   * @return {IssuesRisksService} An instance of IssuesRisksService
   */
  static getInstance() {
    return new IssuesRisksService(IssuesRisksRepository.getInstance());
  }

  /**
   * Get a RiskDetails
   * @param {string} riskDetailsKey
   * @return {RiskDetailsModel}
   */
  async getDetails(riskDetailsKey) {
    return this.repository.get(riskDetailsKey);
  }

  /**
   * Get Nba List
   * @return {Array<any>}
   */
  async getNba(questionKey) {
    return await this.repository.getNba(questionKey);
  }

  /**
   * Create a RiskDetails
   * @param {RiskDetailsModel|*} riskDetails
   * @return {RiskDetails} RiskDetailsKey
   */
  async createDetails(riskDetails) {
    try {
      let generateIDNumber = 1;
      if (riskDetails.Mitigations) {
        generateIDNumber += riskDetails.Mitigations.filter(el => el.AssigneeUserId != null).length;
      }

      const newIDList = await this.generateRandomID(generateIDNumber);

      let IDIndex = 0;
      riskDetails.RiskNbr = newIDList[IDIndex].RiskID;

      riskDetails.Mitigations.map(item => {
        if (item.AssigneeUserId !== null) {
          IDIndex++;
          item.MitigationNbr = newIDList[IDIndex].RiskID;
        }
        return item;
      });
      return await this.repository.addRisk(riskDetails);
    } catch (err) {
      if (err.message.startsWith(`ISSUES_RISKS_ERROR: question is being rated by others`)) {
        return {
          message: 'duplicate data'
        };
      } else {
        console.log(`<<< ORIGINAL_REQUEST_FAILED: RETRYING >>>`);
        console.log(err);
        return await this.retryWhen(() => {
          return this.repository.addRisk(riskDetails);
        }, this.maxRetryAttempts);
      }
    }
  }

  /**
   * Update a RiskDetails
   * @param {string} riskDetailsKey
   * @param {RiskDetailsModel|*} riskDetails
   * @return {string} RiskDetailsKey
   */
  async updateDetails(riskDetailsKey, riskDetails) {
    riskDetails.RiskDetailsKey = riskDetailsKey;
    try {
      if (riskDetails.Mitigations) {
        const IDList = await this.generateRandomID(
          riskDetails.Mitigations.filter(
            o => o.AssigneeUserId !== null && (o.MitigationNbr === undefined || o.MitigationNbr === null || o.MitigationNbr === '')
          ).length
        );
        let index = 0;
        riskDetails.Mitigations.forEach(o => {
          if (o.AssigneeUserId !== null && (o.MitigationNbr === undefined || o.MitigationNbr === null || o.MitigationNbr === '')) {
            o.MitigationNbr = IDList[index].RiskID;
            index++;
          }
        });
      }
      return await this.repository.updateRisk(riskDetails);
    } catch (error) {
      console.log(`<<< ORIGINAL_REQUEST_FAILED: RETRYING >>>`);
      console.log(error);
      return await this.retryWhen(() => {
        return this.repository.updateRisk(riskDetails);
      }, this.maxRetryAttempts);
    }
  }

  async retryWhen(action, remainingRetryAttempts) {
    if (remainingRetryAttempts > 0) {
      remainingRetryAttempts--;
      try {
        console.log(`<<< RETRYING: retry remaining ${remainingRetryAttempts} >>>`);
        return await action();
      } catch (err) {
        if (err.message.startsWith(`ISSUES_RISKS_ERROR: question is being rated by others`)) {
          return {
            message: 'duplicate data'
          };
        } else {
          console.log('<<< RETRYING: retry failed >>>');
          console.log(err);
          return await this.retryWhen(action, remainingRetryAttempts);
        }
      }
    } else {
      throw new Error('RETRY_FAILED: Exceeded max retry attempts');
    }
  }

  /**
   * Create a Feedback
   * @param {Array<RiskFeedbackModel>} feedback
   */
  async createFeedback(feedback) {
    return await this.repository.addFeedback(feedback);
  }

  async getCodes(category) {
    const CodeHeaderCategory = {
      Types: 'RiskType',
      Statuses: 'RiskStatus',
      Ratings: 'RiskRating',
      Sources: 'RiskSource',
      MitigationStatuses: 'RiskMitigationStatus',
      LeadReviewStatuses: 'RiskLeadReviewStatus',
      ConsultationCallStatuses: 'RiskConsultationCallStatus',
      Parties: 'RiskConsultationCallInvolvedParty',
      FinancialsBillMechanisms: 'RiskFinancialsBillMechanism',
      FinRevenueCCI: 'RiskFinRevenueCCI',
      RatingLevel: 'RatingLevel'
    };

    const categoryDesc = CodeHeaderCategory[category];

    if (categoryDesc) {
      if (categoryDesc === 'RiskConsultationCallInvolvedParty' || categoryDesc === 'RatingLevel') {
        return await Promise.all([
          this.repository.getCodesByCategory(categoryDesc),
          this.repository.getCodesByParentCategory(categoryDesc)
        ]).then(async ([Parties, PartyChildren]) => {
          Parties.map(party => {
            party.Children = PartyChildren.filter(child => child.ParentId === party.CodeDetailId);
            return party;
          });
          return Parties;
        });
      } else {
        return await this.repository.getCodesByCategory(categoryDesc);
      }
    } else {
      return [];
    }
  }

  async getQuestions(contractNbr) {
    return await this.repository.getQuestions(contractNbr);
  }

  async getQuestion(riskAssessmentQuestionKey) {
    const assessmentQuestion = await this.repository.getQuestion(riskAssessmentQuestionKey);

    const [category, subCategory, question, statements] = await Promise.all([
      this.repository.getCode(assessmentQuestion.CategoryCd),
      this.repository.getCode(assessmentQuestion.SubCategoryCd),
      this.repository.getCode(assessmentQuestion.RiskQuestionCd),
      this.repository.getCodes(assessmentQuestion.StatementArr)
    ]);

    return {
      Question: question,
      Statements: statements,
      Category: category.PrimaryDecodeTxt,
      CategoryMaterialLink: category.SecondaryDecodeTxt,
      SubCategory: subCategory.PrimaryDecodeTxt
    };
  }

  async getHistoryList(riskDetailsKey) {
    return await this.repository.getHistories(riskDetailsKey);
  }

  /**
   * Get RiskHistory
   * @param {string} historyKey
   * @param {string} riskDetailsKey
   * @return {RiskDetailsModel}
   */
  async getHistory(historyKey, riskDetailsKey) {
    let {ContentTxt} = await this.repository.getHistory(historyKey, riskDetailsKey);

    ContentTxt = JSON.parse(ContentTxt);

    return ContentTxt;
  }

  /**
   * Get ContractScores
   * @param {string} contractNbr
   * @return {Array}
   */
  async getContractScores(contractNbr) {
    const contractScores = await this.repository.getContractScores(contractNbr);
    return contractScores.map(o => ({
      Score: [o.ContractScoreRating, o.ContractScore],
      ScoreNoCM: [o.ContractScoreNoCMRating, o.ContractScoreNoCM],
      ContractNbr: o.ContractNbr
    }));
  }

  /**
   * Generate Random ID with 10 length
   * @param {int} number
   * @return {boolean} generate successful
   */
  async generateRandomID(number) {
    const IDList = [];
    const date = new Date();
    const basicNumber =
      date
        .getFullYear()
        .toString()
        .substring(3, 4) +
      (date.getMonth() + 1).toString() +
      date.getDate().toString();

    for (let index = 0; index < number; index++) {
      IDList.push({RiskID: random(10 - basicNumber.length, {letters: false}) + basicNumber});
    }

    const result = await this.repository.addRiskID(IDList);
    if (result === true) {
      return IDList;
    } else {
      console.log(result);
      return this.generateRandomID(number);
    }
  }
}

module.exports = IssuesRisksService;
