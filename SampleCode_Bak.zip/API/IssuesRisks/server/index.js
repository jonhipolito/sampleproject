'use strict';

const express = require('express');
const middlewares = require('./middlewares');
const logRequest = require('morgan'); // use to log every request
require('dotenv').config(); // Loads .env (for local)

module.exports = function() {
  const server = express();

  const create = function(config) {
    // Server settings
    server.set('env', config.env);
    server.set('port', config.port);
    server.set('hostname', config.hostname);

    // parse the url
    server.use(express.urlencoded({ extended: false }));
    server.use(express.json());

    middlewares.init(server);

    // log all request
    if (process.env.NODE_ENV !== 'test') {
      server.use(logRequest('dev'));
    }

    // init route
    const issuesRisksRoute = require('./issues-risks.route');
    server.use(`/${process.env.SERVICE_PATH_PREFIX}/api/issues-risks`, issuesRisksRoute);
  };

  const start = function() {
    const hostname = server.get('hostname');
    const port = server.get('port');

    server.listen(port, function() {
      console.log(`Express server listening on - http://${hostname}:${port}`);
    });

    return server;
  };

  return {
    create,
    start
  };
};
