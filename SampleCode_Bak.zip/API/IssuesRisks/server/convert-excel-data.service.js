'use strict';

const allLinkColumns = [
  'CustomerNm',
  'CustomerNbr',
  'ContractNm',
  'GeographicUnitDesc',
  'GeographicRegionDesc',
  'CountryNm',
  'CategoryCd',
  'SubCategoryCd',
  'RiskTypeCd',
  'OperatingGroupNm',
  'BookaPreferredSlot',
  'CCSlotRequestUserId',
  'CMGeoLead',
  'CMOgLead',
  'DateRequested',
  'RequestConfidentialInd',
  'CMUserId1',
  'CMUserId2',
  'CMUserId3',
  'CMUserId4',
  'CMUserId5',
  'CMUserId6',
  'CMUserId7',
  'CMUserId8',
  'CMUserId9',
  'CMUserId10'
];

const allColumnsPrefix = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
    'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
    'AA', 'AB', 'AC', 'AD', 'AE', 'AF', 'AG', 'AH', 'AI', 'AJ', 'AK', 'AL', 'AM', 'AN',
    'AO', 'AP', 'AQ', 'AR', 'AS', 'AT', 'AU', 'AV', 'AW', 'AX', 'AY', 'AZ',
    'BA', 'BB', 'BC', 'BD', 'BE', 'BF', 'BG', 'BH', 'BI', 'BJ', 'BK', 'BL', 'BM', 'BN',
    'BO', 'BP', 'BQ', 'BR', 'BS', 'BT', 'BU'
];

function formatDate(datetime) {
  if (datetime) {
    var year = datetime.getFullYear(),
      month = ('0' + (datetime.getMonth() + 1)).slice(-2),
      date = ('0' + datetime.getDate()).slice(-2),
      hour = ('0' + datetime.getHours()).slice(-2),
      minute = ('0' + datetime.getMinutes()).slice(-2),
      second = ('0' + datetime.getSeconds()).slice(-2);

    var result = year + '-' + month + '-' + date;
    return result;
  } else {
    return null;
  }
}

// convert javascript's date to excel's number
function formatDateToNum(datetime) {
  if (datetime) {
    var returnDateTime = 25569.0 + (datetime.getTime() - datetime.getTimezoneOffset() * 60 * 1000) / (1000 * 60 * 60 * 24);
    return returnDateTime.toString().substr(0, 5);
  } else {
    return null;
  }
}

function convertStrArr2Json(strArr) {
  var retVal = [];
  try {
    // retVal = JSON.parse(strArr || '[]')
    retVal = eval(strArr || '[]');
  } catch (error) {
    // don't throw
  }
  return retVal;
}

function removeHTMLTag(str) {
  str = (str || '').replace(/<\/?[^>]*>/g, ''); //remove HTML tag
  // str = str.replace(/[ | ]*\n/g,'\n'); //remove blank
  //str = str.replace(/\n[\s| | ]*\r/g,'\n'); //remove blank
  // str=str.replace(/ /ig,'');//remove empty
  return str;
}

function escape2Html(str) {
  var arrEntities = {lt: '<', gt: '>', nbsp: ' ', amp: '&', quot: '"'};
  return (str || '').replace(/&(lt|gt|nbsp|amp|quot);/gi, function(all, t) {
    return arrEntities[t];
  });
}

function getCodeDetail(code, codeDetails) {
  return Array.from(codeDetails || []).find(t => t.CodeTxt === code) || {};
}

function getConsCallFinRevenueCCI(riskConsultationCallKey, typeCode, consCallFinRevenueCCIs) {
  return (
    Array.from(consCallFinRevenueCCIs || []).find(t => t.RiskConsultationCallKey === riskConsultationCallKey && t.TypeCd === typeCode) || {}
  );
}

function getInvolvedParty(riskConsultationCallKey, partyCategoryCd, involvedParties, codeDetails) {
  const involvedParty =
    Array.from(involvedParties || []).find(
      t => t.RiskConsultationCallKey === riskConsultationCallKey && t.PartyCategoryCd == partyCategoryCd
    ) || {};

  const partyArr = Array.from(convertStrArr2Json(involvedParty.PartyArr))
    .map((element, i) => {
      return getCodeDetail(element, codeDetails);
    })
    .filter(t => t.PrimaryDecodeTxt);

  return partyArr.map(t => t.PrimaryDecodeTxt).join(', ');
}

function getStatements(statementArr, codeDetails) {
  var retVal = [{}, {}, {}, {}, {}, {}];
  Array.from(convertStrArr2Json(statementArr))
    .map((element, i) => {
      return getCodeDetail(element, codeDetails);
    })
    .forEach((element, i) => {
      if (i >= 6) {
        return;
      }
      retVal[i] = element;
    });

  return retVal;
}

function getCMUsers(cmUsers) {
  var retVal = ['', '', '', '', '', '', '', '', '', ''];
  Array.from(convertStrArr2Json(cmUsers)).forEach((element, i) => {
    if (i >= 10) {
      return;
    }
    retVal[i] = element;
  });
  // only have up to 5 CM users
  return retVal;
}

function getLeadReviews(riskDetailsKey, leadReviews) {
  var retVal = [{}, {}, {}];
  Array.from(leadReviews)
    .filter(t => t.RiskDetailsKey === riskDetailsKey)
    .forEach((element, i) => {
      if (i >= 3) {
        return; // don't use break
      }
      retVal[i] = element;
    });
  // 1 risk issue only have up to 3 lead reviews
  return retVal;
}

function getMitigations(riskDetailsKey, mitigations) {
  var retVal = [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}]; // 20
  Array.from(mitigations)
    .filter(t => t.RiskDetailsKey === riskDetailsKey)
    .forEach((element, i) => {
      if (i >= 20) {
        return;
      }
      retVal[i] = element;
    });
  return retVal;
}

function getlinkText(column, row) {
  return "='Dump Table'!$" + allColumnsPrefix[column] + '$' + (row + 2);
}

function convertDataToExcelDto(consultationCalls, consCallFinRevenueCCIs, involvedParties, leadReviews, mitigations, codeDetails) {
  return Array.from(consultationCalls || []).map((t, index) => {
    var item_consCallFinRevenueCCIForRevenue = getConsCallFinRevenueCCI(t.RiskConsultationCallKey, '101701', consCallFinRevenueCCIs);
    var item_consCallFinRevenueCCIForCCI = getConsCallFinRevenueCCI(t.RiskConsultationCallKey, '101702', consCallFinRevenueCCIs);
    var item_consCallFinRevenueCCIForCCIPercent = getConsCallFinRevenueCCI(t.RiskConsultationCallKey, '101703', consCallFinRevenueCCIs);

    var InvolvedPartyBusiness = getInvolvedParty(t.RiskConsultationCallKey, '101001', involvedParties, codeDetails);
    var InvolvedPartyFinance = getInvolvedParty(t.RiskConsultationCallKey, '101002', involvedParties, codeDetails);
    var InvolvedPartyLegal = getInvolvedParty(t.RiskConsultationCallKey, '101003', involvedParties, codeDetails);
    var InvolvedPartyOther = getInvolvedParty(t.RiskConsultationCallKey, '101004', involvedParties, codeDetails);

    var item_statements = getStatements(t.StatementArr, codeDetails);
    var item_cmUsers = getCMUsers(t.CMUsersArr);
    var item_leadReviews = getLeadReviews(t.RiskDetailsKey, leadReviews);
    var item_mitigations = getMitigations(t.RiskDetailsKey, mitigations);

    var obj = {
      CustomerNm: t.CustomerNm || '',
      CustomerNbr: t.CustomerNbr || '',
      ContractNm: t.ContractNm || '',
      ContractNbr: t.ContractNbr || '',
      MasterClientNm: t.MasterClientNm || '',
      MasterClientNbr: t.MasterClientNbr || '',
      GeographicUnitDesc: t.GeographicUnitDesc || '',
      GeographicRegionDesc: t.GeographicRegionDesc || '',
      CountryNm: t.CountryNm || '',
      CategoryCd: getCodeDetail(t.CategoryCd, codeDetails).PrimaryDecodeTxt || '',
      SubCategoryCd: getCodeDetail(t.SubCategoryCd, codeDetails).PrimaryDecodeTxt || '',
      RiskTypeCd: getCodeDetail(t.RiskTypeCd, codeDetails).PrimaryDecodeTxt || '',
      OperatingGroupNm: t.OperatingGroupNm || '',
      RiskDesc: escape2Html(removeHTMLTag(t.RiskDesc)) || '',
      RiskLeadReviewDttm: formatDateToNum(t.RiskLeadReviewDttm) || '',
      RiskLeadReviewStatusCd: getCodeDetail(t.RiskLeadReviewStatusCd, codeDetails).PrimaryDecodeTxt || '',
      RiskNbr: t.RiskNbr || '',
      RiskQMDReviewInd: t.RiskQMDReviewInd == 'Y' ? 'Yes' : 'No',
      RiskQMDReviewDttm: formatDateToNum(t.RiskQMDReviewDttm) || '',
      RiskRatingCd: getCodeDetail(t.RiskRatingCd, codeDetails).PrimaryDecodeTxt || '',
      RiskSourceCd: getCodeDetail(t.RiskSourceCd, codeDetails).PrimaryDecodeTxt || '',
      RiskStatusCd: getCodeDetail(t.RiskStatusCd, codeDetails).PrimaryDecodeTxt || '',
      Statement1: item_statements[0].PrimaryDecodeTxt || '',
      Statement2: item_statements[1].PrimaryDecodeTxt || '',
      Statement3: item_statements[2].PrimaryDecodeTxt || '',
      Statement4: item_statements[3].PrimaryDecodeTxt || '',
      Statement5: item_statements[4].PrimaryDecodeTxt || '',
      Statement6: item_statements[5].PrimaryDecodeTxt || '',
      BookaPreferredSlot: formatDateToNum(t.BookaPreferredSlot) || '',
      CCSlotRequestUserId: t.CCSlotRequestUserId || '',
      CMActionsDesc: escape2Html(removeHTMLTag(t.CMActionsDesc)) || '',
      CMGeoLead: t.CMGeoLead || '',
      CMOgLead: t.CMOgLead || '',
      OnHriListInd: t.OnHriListInd == 'Y' ? 'Yes' : t.OnHriListInd == 'N' ? 'No' : '',
      DateRequested: formatDateToNum(t.DateRequested) || '',
      RequestConfidentialInd: t.RequestConfidentialInd == 'Y' ? 'Yes' : t.RequestConfidentialInd == 'N' ? 'No' : '',
      DoesWantToTakeCC: t.ConsultationCallStatusCd == '100901' || t.ConsultationCallStatusCd == '100903' ? 'Yes' : 'No',
      ExposureContractDesc: escape2Html(removeHTMLTag(t.ExposureContractDesc)) || '',
      ExposureFinancialDesc: escape2Html(removeHTMLTag(t.ExposureFinancialDesc)) || '',
      InvolvedPartyBusiness: InvolvedPartyBusiness,
      InvolvedPartyFinance: InvolvedPartyFinance,
      InvolvedPartyLegal: InvolvedPartyLegal,
      InvolvedPartyOther: InvolvedPartyOther,
      FinancialsBillingTermsNm: t.FinancialsBillingTermsNm || '',
      FinancialsBillMechanismCd: getCodeDetail(t.FinancialsBillMechanismCd, codeDetails).PrimaryDecodeTxt || '',
      FinancialsCurrentFYRevenueNbr: t.FinancialsCurrentFYRevenueNbr || '',
      FinancialsFYRevenueNbr: t.FinancialsFYRevenueNbr || '',
      FinancialsTotalContractNbr: t.FinancialsTotalContractNbr || '',
      ResolutionTimeFrameDesc: escape2Html(removeHTMLTag(t.ResolutionTimeFrameDesc)) || '',
      ReviewerCompletedDt: formatDateToNum(t.ReviewerCompletedDt) || '',
      ReviewerFollowupDt: formatDateToNum(t.ReviewerFollowupDt) || '',
      ReviewerNoteDesc: escape2Html(removeHTMLTag(t.ReviewerNoteDesc)) || '',
      ReviewerShareInd: t.ReviewerShareInd == 'Y' ? 'Yes' : t.ReviewerShareInd == 'N' ? 'No' : '',
      ConsultationCallStatusCd: getCodeDetail(t.ConsultationCallStatusCd, codeDetails).PrimaryDecodeTxt || '',
      RevenueEACNbr: item_consCallFinRevenueCCIForRevenue.EACNbr || '',
      RevenueODENbr: item_consCallFinRevenueCCIForRevenue.ODENbr || '',
      RevenueVarianceNbr: item_consCallFinRevenueCCIForRevenue.VarianceNbr || '',
      CCIEACNbr: item_consCallFinRevenueCCIForCCI.EACNbr || '',
      CCIODENbr: item_consCallFinRevenueCCIForCCI.ODENbr || '',
      CCIVarianceNbr: item_consCallFinRevenueCCIForCCI.VarianceNbr || '',
      CCIPercentEACNbr: item_consCallFinRevenueCCIForCCIPercent.EACNbr || '',
      CCIPercentODENbr: item_consCallFinRevenueCCIForCCIPercent.ODENbr || '',
      CCIPercentVarianceNbr: item_consCallFinRevenueCCIForCCIPercent.VarianceNbr || '',
      CMUserId1: item_cmUsers[0] || '',
      CMUserId2: item_cmUsers[1] || '',
      CMUserId3: item_cmUsers[2] || '',
      CMUserId4: item_cmUsers[3] || '',
      CMUserId5: item_cmUsers[4] || '',
      CMUserId6: item_cmUsers[5] || '',
      CMUserId7: item_cmUsers[6] || '',
      CMUserId8: item_cmUsers[7] || '',
      CMUserId9: item_cmUsers[8] || '',
      CMUserId10: item_cmUsers[9] || ''
    };

    // set link for cc info sheet
    var excelColumnIndex = 0;
    for (const key in obj) {
      //obj.hasOwnProperty(key)
      if (allLinkColumns.findIndex(t => t === key) >= 0) {
        obj[key + '_LINK'] = getlinkText(excelColumnIndex, index);
      }

      excelColumnIndex++;
    }

    //set lead review
    Array.from(item_leadReviews).forEach((element, i) => {
      var prefix = 'LeadReview' + (i + 1) + '_';
      obj[prefix + 'DesignatedReviewerUserIdArr'] = element.DesignatedReviewerUserIdArr || '';
      obj[prefix + 'LeadReviewDttm'] = formatDateToNum(element.LeadReviewDttm) || '';
      obj[prefix + 'LeadReviewStatusCd'] = getCodeDetail(element.LeadReviewStatusCd, codeDetails).PrimaryDecodeTxt || '';
    });

    // set mitigations
    Array.from(item_mitigations).forEach((element, i) => {
      var prefix = 'Mitigation' + (i + 1) + '_';
      obj[prefix + 'AssigneeUserId'] = element.AssigneeUserId || '';
      obj[prefix + 'DueDttm'] = formatDateToNum(element.DueDttm) || '';
      obj[prefix + 'MitigationDesc'] = element.MitigationDesc || '';
      obj[prefix + 'MitigationStatusCd'] = getCodeDetail(element.MitigationStatusCd, codeDetails).PrimaryDecodeTxt || '';
    });

    return obj;
  });
}

module.exports = {
  allLinkColumns,
  allColumnsPrefix,
  convertDataToExcelDto,
  formatDate,
  convertStrArr2Json,
  removeHTMLTag,
  escape2Html,
  getConsCallFinRevenueCCI,
  getInvolvedParty,
  getStatements,
  getCMUsers,
  getLeadReviews,
  getMitigations,
  getlinkText,
  getCodeDetail,
  formatDateToNum
};
