const swaggerUi = require('swagger-ui-express');
const swaggerJSDoc = require('swagger-jsdoc');

const swaggerDefinition = {
  info: {
    title: 'Issues Risks APIs', // Title (required)
    version: '1.0.0' // Version (required)
  },
  basePath: '/api' // Base path (optional)
};

const apis = ['server/issues-risks.route.js'];

const start = function(server) {
  const swaggerSpec = swaggerJSDoc({
    swaggerDefinition,
    apis
  });
  server.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));
};

module.exports = {
  start,
  apis,
  modulePath: 'IssuesRisks'
};
