'use strict';
const IssuesRisksRepository = require('./issues-risks.repository');

async function getAllConsultationCalls(strStartDate, strEndDate) {
  const query = {
    sql: `
            SELECT
            rd.RiskDetailsKey,
              cc.RiskConsultationCallKey,

              rd.CustomerNm,
              rd.CustomerNbr,
              rd.ContractNm,
              rd.ContractNbr,
              rd.MasterClientNm,
              rd.MasterClientNbr,

              gu.GeographicUnitDesc,
              gr.GeographicRegionDesc,
              ct.CountryNm,
              ra.CategoryCd,
              ra.SubCategoryCd,
              rd.RiskTypeCd,
              og.OperatingGroupNm,

              rd.RiskDesc,
              rd.RiskLeadReviewDttm,
              rd.RiskLeadReviewStatusCd,
              rd.RiskNbr,
              rd.RiskQMDReviewDttm,
              rd.RiskQMDReviewInd,
              rd.RiskRatingCd,
              rd.RiskSourceCd,
              rd.RiskStatusCd,
              rd.StatementArr,

              cc.BookaPreferredSlot,
              cc.CCSlotRequestUserId,
              cc.CMActionsDesc,
              cc.CMGeoLead,
              cc.CMOgLead,
              cc.OnHriListInd,
              cc.DateRequested,
              cc.RequestConfidentialInd,
              cc.ExposureContractDesc,
              cc.ExposureFinancialDesc,
              cc.FinancialsBillingTermsNm,
              cc.FinancialsBillMechanismCd,
              cc.FinancialsCurrentFYRevenueNbr,
              cc.FinancialsFYRevenueNbr,
              cc.FinancialsTotalContractNbr,
              cc.ResolutionTimeFrameDesc,
              cc.ReviewerCompletedDt,
              cc.ReviewerFollowupDt,
              cc.ReviewerNoteDesc,
              cc.ReviewerShareInd,
              cc.ConsultationCallStatusCd,
              cc.FinancialsBillMechanismCd,
              cc.CMUsersArr

            FROM RiskDetails rd
            LEFT JOIN RiskConsultationCall cc ON rd.RiskDetailsKey = cc.RiskDetailsKey
            LEFT JOIN Contract co ON co.ContractNbr = rd.ContractNbr
            LEFT JOIN Country ct ON ct.CountryCd = co.CountryCd
            LEFT JOIN GeographicUnit gu ON gu.GeographicUnitCd = ct.GeographicUnitCd
            LEFT JOIN GeographicRegion gr ON gu.GeographicRegionCd = gr.GeographicRegionCd
            LEFT JOIN RiskAssessmentQuestion ra ON ra.RiskAssessmentQuestionKey = rd.RiskAssessmentQuestionKey

            LEFT JOIN(SELECT DISTINCT chm.ContractNbr, og.OperatingGroupNm 
                            FROM ContractHierarchyMapping chm 
                                JOIN ClientServiceGroup csg ON csg.ClientServiceGroupCd = chm.ClientServiceGroupCd 
                                JOIN OperatingUnit ou ON ou.OperatingUnitCd = csg.OperatingUnitCd 
                                JOIN OperatingGroup og ON og.OperatingGroupCd = ou.OperatingGroupCd) AS og
                        ON og.ContractNbr = rd.ContractNbr

            WHERE rd.RiskSourceCd = '101201'
            AND
                rd.CreateDttm between TIMESTAMP(DATE(@strStartDate), 'UTC')
                and TIMESTAMP_ADD(TIMESTAMP(DATE(@strEndDate), 'UTC'), INTERVAL 1 DAY)

            `,
    params: {
      strStartDate: strStartDate, //"2019-08-27"
      strEndDate: strEndDate
    }
  };

  return await IssuesRisksRepository.getInstance().runQuery(query);
}

async function getAllCodeDetail() {
  const query = {
    sql: `
            SELECT PrimaryDecodeTxt, CodeTxt FROM codeDetail
            `,
    params: {}
  };

  return await IssuesRisksRepository.getInstance().runQuery(query);
}

async function getAllRiskConsCallFinRevenueCCI(strStartDate, strEndDate) {
  const query = {
    sql: `
        SELECT 
        rf.RiskConsultationCallKey, rf.TypeCd, rf.ODENbr, rf.EACNbr, rf.VarianceNbr
        FROM RiskDetails rd
        JOIN RiskConsultationCall cc ON rd.RiskDetailsKey = cc.RiskDetailsKey
        JOIN RiskConsCallFinRevenueCCI rf ON rf.RiskConsultationCallKey= cc.RiskConsultationCallKey
        WHERE rd.RiskSourceCd = '101201'
                    AND
                        rd.CreateDttm between TIMESTAMP(DATE(@strStartDate), 'UTC')
                        and TIMESTAMP_ADD(TIMESTAMP(DATE(@strEndDate), 'UTC'), INTERVAL 1 DAY)
            `,
    params: {
      strStartDate: strStartDate,
      strEndDate: strEndDate
    }
  };

  return await IssuesRisksRepository.getInstance().runQuery(query);
}

async function getAllLeadReview(strStartDate, strEndDate) {
  const query = {
    sql: `
        SELECT rr.RiskDetailsKey, rr.DesignatedReviewerUserIdArr, rr.DesignatedReviewerUserIdArr, rr.LeadReviewDttm, rr.LeadReviewStatusCd 
        FROM RiskDetails rd
        JOIN RiskLeadReview rr ON rr.RiskDetailsKey= rd.RiskDetailsKey
        WHERE rd.RiskSourceCd = '101201'
                    AND
                        rd.CreateDttm between TIMESTAMP(DATE(@strStartDate), 'UTC')
                        and TIMESTAMP_ADD(TIMESTAMP(DATE(@strEndDate), 'UTC'), INTERVAL 1 DAY)
            `,
    params: {
      strStartDate: strStartDate,
      strEndDate: strEndDate
    }
  };

  return await IssuesRisksRepository.getInstance().runQuery(query);
}

async function getAllMitigation(strStartDate, strEndDate) {
  const query = {
    sql: `
        SELECT rm.RiskDetailsKey, rm.AssigneeUserId, rm.DueDttm, rm.MitigationDesc, rm.MitigationStatusCd 
        FROM RiskDetails rd
        JOIN RiskMitigation rm ON rm.RiskDetailsKey= rd.RiskDetailsKey
        WHERE rd.RiskSourceCd = '101201'
                    AND
                        rd.CreateDttm between TIMESTAMP(DATE(@strStartDate), 'UTC')
                        and TIMESTAMP_ADD(TIMESTAMP(DATE(@strEndDate), 'UTC'), INTERVAL 1 DAY)
            `,
    params: {
      strStartDate: strStartDate,
      strEndDate: strEndDate
    }
  };

  return await IssuesRisksRepository.getInstance().runQuery(query);
}

async function getAllInvolvedParty(strStartDate, strEndDate) {
  const query = {
    sql: `
        select rp.RiskConsultationCallKey,rp.PartyCategoryCd,rp.PartyArr
        FROM RiskDetails rd
        JOIN RiskConsultationCall cc ON rd.RiskDetailsKey = cc.RiskDetailsKey
        JOIN RiskConsCallInvolvedParty rp on cc.RiskConsultationCallKey = rp.RiskConsultationCallKey
        WHERE rd.RiskSourceCd = '101201'
                    AND
                        rd.CreateDttm between TIMESTAMP(DATE(@strStartDate), 'UTC')
                        and TIMESTAMP_ADD(TIMESTAMP(DATE(@strEndDate), 'UTC'), INTERVAL 1 DAY)
            `,
    params: {
      strStartDate: strStartDate,
      strEndDate: strEndDate
    }
  };

  return await IssuesRisksRepository.getInstance().runQuery(query);
}

async function isGlobalCM(eid) {
  const query = {
    sql: `
            SELECT
                count(1) as count
            FROM
                MMCSecurityData sec 
            WHERE 
                RTRIM(sec.EnterpriseId) = @eid
            AND 
                sec.IsGlobalCM = 'Y'
            `,
    params: {
      eid
    }
  };

  return await IssuesRisksRepository.getInstance().runQuery(query);
}

async function getDownloadItemByEid(eid, category) {
  const query = {
    sql: `
        SELECT DownloadKey, Category, FileName, FileSize, FileUrl, Status, CreateUserId, CreateDttm, UpdateUserId, UpdateDttm
        FROM RiskDownload
        WHERE CreateUserId = @eid
            AND Category = @category
            AND TIMESTAMP_ADD(UpdateDttm, INTERVAL 1 DAY) > CURRENT_TIMESTAMP()
        order by UpdateDttm desc LIMIT 1
            `,
    params: {
      eid,
      category
    }
  };

  return await IssuesRisksRepository.getInstance().runQuery(query);
}

async function getDownloadItemByKey(key) {
  const query = {
    sql: `
            SELECT
            DownloadKey, Category, FileName, FileSize, FileUrl, Status, CreateUserId, CreateDttm, UpdateUserId, UpdateDttm
            FROM
            RiskDownload
            WHERE
            DownloadKey = @key
            `,
    params: {
      key
    }
  };

  return await IssuesRisksRepository.getInstance().runQuery(query);
}

async function insertDownloadItem(obj) {
  const query = {
    sql: `
           INSERT INTO RiskDownload(DownloadKey, Category, FileName, FileSize, FileUrl, Status, CreateUserId, CreateDttm, UpdateUserId, UpdateDttm)
           VALUES
             (@DownloadKey, @Category, @FileName, @FileSize, @FileUrl, @Status, @CreateUserId, @CreateDttm, @UpdateUserId, @UpdateDttm)
            `,
    params: {
      DownloadKey: obj.DownloadKey,
      Category: obj.Category,
      FileName: obj.FileName,
      FileSize: obj.FileSize,
      FileUrl: obj.FileUrl,
      Status: obj.Status,
      CreateUserId: obj.CreateUserId,
      CreateDttm: obj.CreateDttm,
      UpdateUserId: obj.UpdateUserId,
      UpdateDttm: obj.UpdateDttm
    }
  };

  return await IssuesRisksRepository.getInstance().runUpdate(query);
}

async function updateDownloadItem(obj) {
  const query = {
    sql: `
           UPDATE RiskDownload SET Category = @Category, FileName = @FileName, FileSize = @FileSize,
            FileUrl = @FileUrl, Status = @Status,  UpdateDttm = @UpdateDttm
           WHERE
            DownloadKey = @DownloadKey
            `,
    params: {
      DownloadKey: obj.DownloadKey,
      Category: obj.Category,
      FileName: obj.FileName,
      FileSize: obj.FileSize,
      FileUrl: obj.FileUrl,
      Status: obj.Status,
      CreateUserId: obj.CreateUserId,
      CreateDttm: obj.CreateDttm,
      UpdateUserId: obj.UpdateUserId,
      UpdateDttm: obj.UpdateDttm
    }
  };

  return await IssuesRisksRepository.getInstance().runUpdate(query);
}

async function updateDownloadStatus(downloadKey, status) {
  const query = {
    sql: `
           UPDATE RiskDownload SET  Status = @status,  UpdateDttm = @updateDttm
           WHERE
            DownloadKey = @downloadKey
            `,
    params: {
      status: status,
      downloadKey: downloadKey,
      updateDttm: new Date()
    }
  };

  return await IssuesRisksRepository.getInstance().runUpdate(query);
}

function getExampleData() {
  const data = [];
  for (let index = 0; index < 100; index++) {
    data.push({
      customerNbr: index + 1,
      customerNm: 'customerNm - 00' + (index + 1),
      contractNm: 'contractNm - 00' + (index + 1),
      geographicUnitDesc: 'geographicUnitDesc - 00' + (index + 1),
      geographicRegionDesc: 'geographicRegionDesc - 00' + (index + 1),
      countryNm: 'countryNm - 00' + (index + 1),
      riCategory: 'riCategory - 00' + (index + 1),
      riSubCategory: 'riSubCategory - 00' + (index + 1),
      riskTypeDesc: 'riskTypeDesc - 00' + (index + 1),
      operatingGroupNm: 'operatingGroupNm - 00' + (index + 1),
      confidentialSlotRequested: 'Yes',
      cMGeoLead: 'cMGeoLead - 00' + (index + 1),
      cMOgLead: 'cMOgLead - 00' + (index + 1),
      dateRequested: '1/20/2019',
      bookaPreferredSlot: '1/21/2019',
      updateUserId: 'updateUserId - 00' + (index + 1),
      cMUserId1: 'cMUserId1 - 00' + (index + 1),
      cMUserId2: 'cMUserId2 - 00' + (index + 1),
      cMUserId3: 'cMUserId3 - 00' + (index + 1),
      cMUserId4: 'cMUserId4 - 00' + (index + 1),
      cMUserId5: 'cMUserId5 - 00' + (index + 1)
    });
  }
  return data;
}

module.exports = {
  getAllConsultationCalls,
  getDownloadItemByEid,
  getDownloadItemByKey,
  insertDownloadItem,
  updateDownloadItem,
  updateDownloadStatus,
  getAllCodeDetail,
  getAllRiskConsCallFinRevenueCCI,
  getAllLeadReview,
  getAllMitigation,
  getAllInvolvedParty,
  isGlobalCM,
  getExampleData
};
