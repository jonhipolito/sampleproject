'use strict';
const fs = require('fs');
const path = require('path');
const ejsExcel = require('ejsexcel');
const moment = require('moment');
const {Storage} = require('@google-cloud/storage');
const storage = new Storage();

const consultationCallExportRepository = require('./consultation-call-export.repository');
const convertExcelDataService = require('./convert-excel-data.service');

async function isGlobalCM(eid) {
  const [item] = await consultationCallExportRepository.isGlobalCM(eid);
  return (item.count || 0) > 0;
}

async function getDownloadItemByEid(eid, category) {
  const [downloadItem] = await consultationCallExportRepository.getDownloadItemByEid(eid, category);
  if (downloadItem) {
    // force to update the status to failed if the download timeout
    var newCreatDttm = moment(downloadItem.UpdateDttm)
      .add(5, 'm')
      .toDate();

    if (downloadItem && downloadItem.Status == 'In Progress' && newCreatDttm < new Date()) {
      downloadItem.Status = 'Failed';
      await consultationCallExportRepository.updateDownloadStatus(downloadItem.DownloadKey, downloadItem.Status);
    }
  }

  return downloadItem;
}

async function insertDownloadItem(eid, downloadKey) {
  var obj = {
    DownloadKey: downloadKey,
    Category: 'Risks & Issues sent to CC',
    FileName: '',
    FileSize: '',
    FileUrl: '',
    Status: 'In Progress',
    CreateUserId: eid,
    CreateDttm: new Date(),
    UpdateUserId: eid,
    UpdateDttm: new Date()
  };

  return await consultationCallExportRepository.insertDownloadItem(obj);
}

async function updateDownloadStatus(downloadKey, status) {
  return await consultationCallExportRepository.updateDownloadStatus(downloadKey, status);
}

async function exportConsultationCall(eid, downloadKey, startdate, enddate) {
  const bucketName = process.env.ORION_APPSPOT_BUCKET_NAME;
  const templateFileName = path.join(process.env.TEMPLATE_BASE_PATH, 'server/templates/Risks & Issues sent to CC Template.xlsx');
  //the template file must be put in /temp folder, or it will throw  EROFS: read-only file system issue
  const tempDir = '/tmp/';
  const filefullname = path.join(tempDir, `Risk and Issues Sent for CC - ${eid}.xlsx`);
  const filename = path.basename(filefullname);

  if (!fsExistsSync(tempDir)) {
    fs.mkdirSync(tempDir);
  }

  try {
    // 1. get data from db
    var strStartDate = startdate || convertExcelDataService.formatDate(new Date());
    var strEndDate = enddate || convertExcelDataService.formatDate(new Date());
    const [consultationCalls, consCallFinRevenueCCIs, involvedParties, leadReviews, mitigations, codeDetails] = await Promise.all([
      consultationCallExportRepository.getAllConsultationCalls(strStartDate, strEndDate),
      consultationCallExportRepository.getAllRiskConsCallFinRevenueCCI(strStartDate, strEndDate),
      consultationCallExportRepository.getAllInvolvedParty(strStartDate, strEndDate),
      consultationCallExportRepository.getAllLeadReview(strStartDate, strEndDate),
      consultationCallExportRepository.getAllMitigation(strStartDate, strEndDate),
      consultationCallExportRepository.getAllCodeDetail()
    ]);

    console.log('1. data has been retrived from db', new Date());

    // 2. convert all data to excel data transfer object arrray for export
    var excelDtos = convertExcelDataService.convertDataToExcelDto(
      consultationCalls,
      consCallFinRevenueCCIs,
      involvedParties,
      leadReviews,
      mitigations,
      codeDetails
    );
    console.log('2. data has been converted', new Date());

    // 3. render excel file with template and data
    await renderExcel(templateFileName, excelDtos, filefullname);
    console.log('3. excel has been rendered', new Date());

    // 4. upload the excel file to cloud storage
    console.log(`3.9 bucketName is ${bucketName}, filefullname is ${filefullname}`, new Date());
    await uploadExcelToGCPStorage(bucketName, filefullname);
    console.log('4. file has been updated', new Date());

    // 5. get the signed url of object in google storage
    var signedUrl = await getSignedUrl(bucketName, filename);

    // 6. get meta data of object in google storage
    var metadata = await getFileMetadata(bucketName, filename);

    // 7. change the db download record
    const [downloadItem] = await consultationCallExportRepository.getDownloadItemByKey(downloadKey);

    if (downloadItem) {
      downloadItem.FileName = filename;
      downloadItem.FileSize = metadata.size;
      downloadItem.FileUrl = signedUrl;
      downloadItem.Status = 'Ready for Download';
      downloadItem.UpdateUserId = eid;
      downloadItem.UpdateDttm = new Date();
      await consultationCallExportRepository.updateDownloadItem(downloadItem);
    }

    // 8. remove the local file
    removefileForLocal(filefullname);
  } catch (error) {
    console.log('10. file exported failed', error);
    await consultationCallExportRepository.updateDownloadStatus(downloadKey, 'Failed');
    throw error;
  }
}

/**
 * render excel file
 * @param  {string} templateFileName
 * @param  {object} data
 * @param  {string} exportFileName
 */
async function renderExcel(templateFileName, data, exportFileName) {
  const exlBuf = fs.readFileSync(templateFileName);
  var exlBuf2 = await ejsExcel.renderExcel(exlBuf, data);
  fs.writeFileSync(exportFileName, exlBuf2);
}

/**
 * upload excel to google storage, filefullname is your local file full name
 * @param  {string} bucketName
 * @param  {string} filefullname
 */
async function uploadExcelToGCPStorage(bucketName, filefullname) {
  await storage.bucket(bucketName).upload(filefullname, {
    gzip: true,
    metadata: {
      // Enable long-lived HTTP caching headers
      // Use only if the contents of the file will never change
      // (If the contents will change, use cacheControl: 'no-cache')
      cacheControl: 'public, max-age=31536000'
    }
  });
  console.log(`${filefullname} uploaded to ${bucketName}.`);
}

/**
 * get signed url of object in google storage
 * @param  {string} bucketName
 * @param  {string} filename
 */
async function getSignedUrl(bucketName, filename) {
  const options = {
    version: 'v4',
    action: 'read',
    expires: Date.now() + 24 * 60 * 60 * 1000 // one day 24 * 60 * 60 * 1000
  };
  // Get a v4 signed URL for reading the file
  const [url] = await storage
    .bucket(bucketName)
    .file(filename)
    .getSignedUrl(options);

  return url;
}

/**
 * get file's metadata
 * @param  {string} bucketName
 * @param  {string} filename
 */
async function getFileMetadata(bucketName, filename) {
  // Gets the metadata for the file
  const [metadata] = await storage
    .bucket(bucketName)
    .file(filename)
    .getMetadata();

  // console.log(`File: ${metadata.name}`);
  // console.log(`Bucket: ${metadata.bucket}`);
  // console.log(`Storage class: ${metadata.storageClass}`);
  // console.log(`Self link: ${metadata.selfLink}`);
  // console.log(`ID: ${metadata.id}`);
  // console.log(`Size: ${metadata.size}`);
  // console.log(`Updated: ${metadata.updated}`);
  // console.log(`Generation: ${metadata.generation}`);
  // console.log(`Metageneration: ${metadata.metageneration}`);
  // console.log(`Etag: ${metadata.etag}`);
  // console.log(`Owner: ${metadata.owner}`);
  // console.log(`Component count: ${metadata.component_count}`);
  // console.log(`Crc32c: ${metadata.crc32c}`);
  // console.log(`md5Hash: ${metadata.md5Hash}`);
  // console.log(`Cache-control: ${metadata.cacheControl}`);
  // console.log(`Content-type: ${metadata.contentType}`);
  // console.log(`Content-disposition: ${metadata.contentDisposition}`);
  // console.log(`Content-encoding: ${metadata.contentEncoding}`);
  // console.log(`Content-language: ${metadata.contentLanguage}`);
  // console.log(`Media link: ${metadata.mediaLink}`);
  // console.log(`KMS Key Name: ${metadata.kmsKeyName}`);
  // console.log(`Temporary Hold: ${metadata.temporaryHold}`);
  // console.log(`Event-based hold: ${metadata.eventBasedHold}`);
  // console.log(`Effective Expiration Time: ${metadata.effectiveExpirationTime}`);
  // console.log(`Metadata: ${metadata.metadata}`);
  return metadata;
}

function fsExistsSync(path) {
  try {
    fs.accessSync(path, fs.F_OK);
  } catch (e) {
    return false;
  }
  return true;
}

/**
 * remove file from your local, filefullname is your local file full name
 * @param  {string} filefullname
 */
function removefileForLocal(filefullname) {
  fs.unlinkSync(filefullname);
}

module.exports = {
  storage,
  getDownloadItemByEid,
  exportConsultationCall,
  insertDownloadItem,
  updateDownloadStatus,
  isGlobalCM,
  renderExcel,
  uploadExcelToGCPStorage,
  getSignedUrl,
  getFileMetadata,
  fsExistsSync,
  removefileForLocal
};
