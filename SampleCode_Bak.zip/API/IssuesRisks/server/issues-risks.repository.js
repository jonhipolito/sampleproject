'use strict';

const uuid = require('uuidv4');
const SpannerDB = require('../configs/db.connection');
const {Spanner} = require('@google-cloud/spanner');
const _ = require('lodash');
const IssuesRisksHttp = require('./issues-risks.http');
const calc = require('js-calculation');

/** Class representing an IssuesRisksRepository. */
class IssuesRisksRepository {
  /**
   * @return {IssuesRisksRepository} An IssuesRisksRepository object.
   */
  constructor() {
    this.initHistoryIterationNbr = 0;
    this.historyIterationNbrStep = 1;
    // this.riskStatusPendingReview = '100703';
    // this.riskStatusReviewed = '100704';
    this.riskSourceCM = '101201';
    this.riskSourceCIP = '101202';
    // this.riskMitigationStatusInProgress = '101401';
    // this.riskMitigationStatusOverDue = '101402';
    // this.riskMitigationStatusCompleted = '101403';
    // this.riskMitigationStatusNotApplied = '101400';
    this.riskRatingNormalMultiplier = 1;
    this.riskRatingAboveNormalMultiplier = 4;
    this.riskRatingHighMultiplier = 10;
    this.riskRatingHigh = '100801';
    this.riskRatingAboveNormal = '100802';
    this.riskRatingNormal = '100803';
    this.contractScorePercentage = 100 / 100;
    this.contractScoreCategoryPercentages = {
      '100301': 0.15,
      '100302': 0.2,
      '100303': 0.1,
      '100304': 0.2,
      '100305': 0.1,
      '100306': 0.25,
      '100307': 0.15
    };
    this.riskContractScoreRatingHigh = '101901';
    this.riskContractScoreRatingAboveNormal = '101902';
    this.riskContractScoreRatingNormal = '101903';
    this.riskContractScoreRatingNA = '101904';
    this.riskConsultationCallNotRequest = '100902';
    // this.riskConsultationCallPending = '100901';
    // this.riskConsultationCallCompleted = '100903';
    // this.riskQuestionQARefCM = '102001';
    this.riskQuestionQARefNoCM = '102002';
    this.riskMitigationStatusCategory = 'RiskMitigationStatus';
    this.CIPCommentEventNewMitigation = 'new_mitigation';
    this.CIPCommentEventUpdateMitigation = 'update_mitigation';
    this.CIPCommentEventUpdateRiskRating = 'update_risk_rating';
  }

  static getInstance() {
    return new IssuesRisksRepository();
  }

  /**
   * @param {RiskDetailsModel|*} riskDetailsModel
   * @return {RiskDetails} RiskDetailsKey
   */
  async addRisk(riskDetailsModel) {
    const database = this.getDatabase();
    const enterpriseId = process.env.ENTERPRISEID;
    const updateAt = new Date().toISOString();
    try {
      return await database.runTransactionAsync(async transaction => {
        const requestContext = {
          RiskDetailsModel: riskDetailsModel,
          database: database,
          transaction: transaction,
          enterpriseId: enterpriseId,
          updateAt: updateAt
        };
        try {
          await this.createRiskDetails(requestContext);
          await this.createRiskMitigations(requestContext);
          await this.createRiskLeadReviews(requestContext);
          await this.createRiskConsultationCall(requestContext);
          await this.updateRiskScore(requestContext);
          await this.createRiskHistory(requestContext);
          await this.addToDb(requestContext);
          await transaction.commit();
        } finally {
          if (!transaction.ended) {
            transaction.end();
          }
        }
        return requestContext.RiskDetails;
      });
    } catch (err) {
      if (err.message.startsWith('ISSUES_RISKS_ERROR: question is being rated by others')) {
        throw err;
      } else {
        this.errorHandling(err, {errorKey: 'ADD_RISK_ERROR'});
        throw new Error('ADD_RISK_ERROR');
      }
    } finally {
      await this.closeDatabase(database);
    }
  }

  async closeDatabase(database) {
    await database.close(err => {
      if (err) {
        if (err.message.startsWith('Error: 1 session leak(s) detected.')) {
          console.log(`SESSION_LEAK_ERROR: ${err}`);
        } else {
          console.log(`DATABASE_CLOSING_ERROR: ${err}`);
        }
      }
    });
  }

  /**
   * @param {RiskRequestContext|*} context
   */
  async createRiskDetails(context) {
    context.RiskDetails = {};
    context.RiskDetails.RiskDetailsKey = uuid();
    context.RiskDetails.CreateDttm = context.updateAt;
    context.RiskDetails.CreateUserId = context.enterpriseId;
    context.RiskDetails.UpdateDttm = context.updateAt;
    context.RiskDetails.UpdateUserId = context.enterpriseId;
    context.RiskDetails.RiskNbr = context.RiskDetailsModel.RiskNbr;
    context.RiskDetails.ContractNbr = context.RiskDetailsModel.ContractNbr;
    context.RiskDetails.ContractNm = context.RiskDetailsModel.ContractNm;
    context.RiskDetails.CustomerNbr = context.RiskDetailsModel.CustomerNbr;
    context.RiskDetails.CustomerNm = context.RiskDetailsModel.CustomerNm;
    context.RiskDetails.MasterClientNbr = context.RiskDetailsModel.MasterClientNbr;
    context.RiskDetails.MasterClientNm = context.RiskDetailsModel.MasterClientNm;
    context.RiskDetails.RiskAssessmentQuestionKey = context.RiskDetailsModel.RiskAssessmentQuestionKey;
    context.RiskDetails.RiskDesc = context.RiskDetailsModel.RiskDesc;
    context.RiskDetails.RiskLeadReviewDttm = context.RiskDetailsModel.RiskLeadReviewDttm;
    context.RiskDetails.RiskLeadReviewStatusCd = context.RiskDetailsModel.RiskLeadReviewStatusCd;
    context.RiskDetails.RiskRatingCd = context.RiskDetailsModel.RiskRatingCd;
    context.RiskDetails.RiskScore = 0;
    context.RiskDetails.RiskScoreNoCM = 0;
    context.RiskDetails.RiskSourceCd = context.RiskDetailsModel.RiskSourceCd;
    context.RiskDetails.RiskStatusCd = context.RiskDetailsModel.RiskStatusCd;
    context.RiskDetails.RiskTypeCd = context.RiskDetailsModel.RiskTypeCd;
    context.RiskDetails.StatementArr = context.RiskDetailsModel.StatementArr;
    context.RiskDetails.NBAInd = 'Y';
    if (context.RiskDetailsModel.QMDCall) {
      context.RiskDetails.RiskQMDReviewDttm = context.RiskDetailsModel.QMDCall.RiskQMDReviewDttm || null;
      context.RiskDetails.RiskQMDReviewInd = context.RiskDetailsModel.QMDCall.RiskQMDReviewInd || 'N';
    } else {
      context.RiskDetails.RiskQMDReviewDttm = null;
      context.RiskDetails.RiskQMDReviewInd = 'N';
    }
  }

  /**
   * @param {Array} riskID
   * @return {boolean} Create IDs successful
   */
  async addRiskID(riskID) {
    const database = this.getDatabase();
    try {
      return await database.runTransactionAsync(async transaction => {
        const requestContext = {
          RiskID: riskID,
          database: database,
          transaction: transaction
        };

        await this.addIDToDb(requestContext);
        await transaction.commit();

        return Promise.resolve(true);
      });
    } catch (err) {
      console.log(err);
      throw err;
    } finally {
      await this.closeDatabase(database);
    }
  }

  /**
   * @param {Array<RiskFeedbackModel|*>} feedbackList
   * @return {Promise<{}>} Create feedback successful
   */
  async addFeedback(feedbackList) {
    const database = this.getDatabase();
    const enterpriseId = process.env.ENTERPRISEID;
    const updateAt = new Date().toISOString();
    try {
      return await database.runTransactionAsync(async transaction => {
        const requestContext = {
          riskFeedbackList: feedbackList,
          transaction: transaction,
          enterpriseId: enterpriseId,
          updateAt: updateAt
        };

        await this.addFeedbackToDb(requestContext);
        await transaction.commit();
        return Promise.resolve(requestContext.riskFeedbackList);
      });
    } catch (err) {
      console.log(err);
      throw err;
    } finally {
      await this.closeDatabase(database);
    }
  }

  /**
   * @param {RiskRequestContext|*} context
   */
  async createRiskMitigations(context) {
    const {Mitigations} = context.RiskDetailsModel;
    if (Mitigations && Mitigations.length > 0) {
      context.NewRiskMitigations = Mitigations.map(o => {
        return {
          RiskDetailsKey: context.RiskDetails.RiskDetailsKey,
          RiskMitigationKey: uuid(),
          AssigneeUserId: o.AssigneeUserId,
          DueDttm: o.DueDttm,
          MitigationDesc: o.MitigationDesc,
          MitigationStatusCd: o.MitigationStatusCd,
          MitigationSourceCd: o.MitigationSourceCd || this.riskSourceCM,
          CreateDttm: o.CreateDttm || context.updateAt,
          CreateUserId: o.CreateUserId || context.enterpriseId,
          UpdateDttm: o.UpdateDttm || context.updateAt,
          UpdateUserId: o.UpdateUserId || context.enterpriseId,
          RiskNextBestActionKey: o.RiskNextBestActionKey || null,
          MitigationTitle: o.MitigationTitle || null,
          MitigationTypeCd: o.MitigationTypeCd || null,
          MitigationNbr: o.MitigationNbr || null,
          OriginalNBATitle: o.OriginalNBATitle || null,
          OriginalNBADesc: o.OriginalNBADesc || null
        };
      });
    }
  }

  /**
   * @param {RiskRequestContext|*} context
   */
  async createRiskLeadReviews(context) {
    if (context.RiskDetails && context.RiskDetails.RiskSourceCd === this.riskSourceCM) {
      const {LeadReviews} = context.RiskDetailsModel;
      if (LeadReviews && LeadReviews.length > 0) {
        context.NewRiskLeadReviews = LeadReviews.map(o => {
          return {
            RiskDetailsKey: context.RiskDetails.RiskDetailsKey,
            RiskLeadReviewKey: uuid(),
            DesignatedReviewerUserIdArr: o.DesignatedReviewerUserIdArr,
            LeadReviewDttm: o.LeadReviewDttm,
            LeadReviewStatusCd: o.LeadReviewStatusCd,
            RecordedUserId: o.RecordedUserId,
            CreateDttm: o.CreateDttm || context.updateAt,
            CreateUserId: o.CreateUserId || context.enterpriseId,
            UpdateDttm: o.UpdateDttm || context.updateAt,
            UpdateUserId: o.UpdateUserId || context.enterpriseId
          };
        });
      }
    }
  }

  /**
   * @param {RiskRequestContext|*} context
   */
  async createRiskConsultationCall(context) {
    if (context.RiskDetails && context.RiskDetails.RiskSourceCd === this.riskSourceCM) {
      const {ConsultationCall} = context.RiskDetailsModel;
      if (ConsultationCall.ConsultationCallStatusCd) {
        context.RiskConsultationCall = {
          RiskConsultationCallKey: uuid(),
          RiskDetailsKey: context.RiskDetails.RiskDetailsKey,
          CreateDttm: context.updateAt,
          CreateUserId: context.enterpriseId,
          UpdateDttm: context.updateAt,
          UpdateUserId: context.enterpriseId,
          ReviewerShareInd: ConsultationCall.ReviewerShareInd || 'N',
          CMActionsDesc: ConsultationCall.CMActionsDesc,
          ConsultationCallStatusCd: ConsultationCall.ConsultationCallStatusCd,
          ExposureContractDesc: ConsultationCall.ExposureContractDesc,
          ExposureFinancialDesc: ConsultationCall.ExposureFinancialDesc,
          FinancialsBillingTermsNm: ConsultationCall.FinancialsBillingTermsNm,
          FinancialsBillMechanismCd: ConsultationCall.FinancialsBillMechanismCd,
          FinancialsCurrentFYRevenueNbr: ConsultationCall.FinancialsCurrentFYRevenueNbr,
          FinancialsFYRevenueNbr: ConsultationCall.FinancialsFYRevenueNbr,
          FinancialsTotalContractNbr: ConsultationCall.FinancialsTotalContractNbr,
          ResolutionTimeFrameDesc: ConsultationCall.ResolutionTimeFrameDesc,
          ReviewerCompletedDt: ConsultationCall.ReviewerCompletedDt,
          ReviewerFollowupDt: ConsultationCall.ReviewerFollowupDt,
          ReviewerNoteDesc: ConsultationCall.ReviewerNoteDesc,
          CCSlotRequestUserId: ConsultationCall.CCSlotRequestUserId,
          DateRequested: ConsultationCall.DateRequested,
          BookaPreferredSlot: ConsultationCall.BookaPreferredSlot,
          CMOgLead: ConsultationCall.CMOgLead || null,
          CMGeoLead: ConsultationCall.CMGeoLead || null,
          CMUsersArr: ConsultationCall.CMUsersArr || null,
          RequestConfidentialInd: ConsultationCall.RequestConfidentialInd || null,
          OnHriListInd: ConsultationCall.OnHriListInd || null
        };

        const {ConsCallInvolvedParty, ConsCallFinRevenueCCI} = ConsultationCall;
        if (ConsCallInvolvedParty && ConsCallInvolvedParty.length > 0) {
          context.RiskConsCallInvolvedParties = ConsCallInvolvedParty.map(o => {
            return {
              RiskConsultationCallKey: context.RiskConsultationCall.RiskConsultationCallKey,
              RiskConsCallInvolvedPartyKey: uuid(),
              PartyArr: o.PartyArr,
              PartyCategoryCd: o.PartyCategoryCd,
              CreateDttm: o.CreateDttm || context.updateAt,
              CreateUserId: o.CreateUserId || context.enterpriseId,
              UpdateDttm: o.UpdateDttm || context.updateAt,
              UpdateUserId: o.UpdateUserId || context.enterpriseId
            };
          });
        }
        if (ConsCallFinRevenueCCI && ConsCallFinRevenueCCI.length > 0) {
          context.RiskConsCallFinRevenueCCIs = ConsultationCall.ConsCallFinRevenueCCI.map(o => {
            return {
              RiskConsultationCallKey: context.RiskConsultationCall.RiskConsultationCallKey,
              RiskConsCallFinRevenueCCIKey: uuid(),
              TypeCd: o.TypeCd,
              EACNbr: o.EACNbr,
              ODENbr: o.ODENbr,
              VarianceNbr: o.VarianceNbr,
              CreateDttm: o.CreateDttm || context.updateAt,
              CreateUserId: o.CreateUserId || context.enterpriseId,
              UpdateDttm: o.UpdateDttm || context.updateAt,
              UpdateUserId: o.UpdateUserId || context.enterpriseId
            };
          });
        }
      }
    }
  }

  /**
   * @param {RiskRequestContext|*} context
   */
  async updateRiskScore(context) {
    if (context.RiskDetails && context.RiskDetails.RiskSourceCd === this.riskSourceCM && context.RiskDetailsModel.CMRiskRatingUpdated) {
      const {RiskDetailsKey, ContractNbr, RiskAssessmentQuestionKey, RiskRatingCd} = context.RiskDetails;
      const {CategoryCd, WeightNbr, QuestionQARefArr} = await this.getQuestion(RiskAssessmentQuestionKey);
      const percentage = this.contractScorePercentage;
      let assessedRisks = await this.getAssessedRisksPerCategory(CategoryCd, ContractNbr, context.transaction);
      assessedRisks = assessedRisks.filter(o => o.RiskDetailsKey !== RiskDetailsKey);
      assessedRisks.push({
        RiskDetailsKey,
        WeightNbr,
        RiskRatingCd,
        CategoryCd,
        ContractNbr,
        QuestionQARefArr
      });
      let risksNoCM = assessedRisks.filter(o => o.QuestionQARefArr.includes(this.riskQuestionQARefNoCM));

      const categoryTotalScore = this._sum(
        _.chain(assessedRisks)
          .map(o => o.WeightNbr)
          .value()
      );

      const categoryTotalScoreNoCM = this._sum(
        _.chain(risksNoCM)
          .map(o => o.WeightNbr)
          .value()
      );

      const scoredRisks = assessedRisks.map(o => {
        const {RiskDetailsKey, WeightNbr, RiskRatingCd} = o;
        const multiplier = this.determineRiskRatingMultiplier(RiskRatingCd);
        const riskScore = this._multiply(this._multiply(this._divide(WeightNbr, categoryTotalScore), percentage), multiplier);
        const riskScoreNoCM =
          categoryTotalScoreNoCM === 0
            ? 0
            : this._multiply(this._multiply(this._divide(WeightNbr, categoryTotalScoreNoCM), percentage), multiplier);
        if (RiskDetailsKey === context.RiskDetails.RiskDetailsKey) {
          context.RiskDetails.RiskScore = riskScore;
          context.RiskDetails.RiskScoreNoCM = riskScoreNoCM;
        }
        return {
          RiskDetailsKey,
          RiskScore: riskScore,
          RiskScoreNoCM: riskScoreNoCM,
          QuestionQARefArr: o.QuestionQARefArr,
          CategoryCd: o.CategoryCd
        };
      });
      context.ScoreUpdatedRiskDetails = scoredRisks
        .filter(o => o.RiskDetailsKey !== RiskDetailsKey)
        .map(o => ({
          RiskDetailsKey: o.RiskDetailsKey,
          RiskScore: o.RiskScore,
          RiskScoreNoCM: o.RiskScoreNoCM
        }));

      const percentages = this.contractScoreCategoryPercentages;
      let riskScores = await this.getRiskScores(ContractNbr, context.transaction);
      riskScores = riskScores.filter(o => !scoredRisks.some(x => x.RiskDetailsKey === o.RiskDetailsKey));
      riskScores = riskScores.concat(scoredRisks);

      let riskScoresNoCM = riskScores.filter(o => o.QuestionQARefArr.includes(this.riskQuestionQARefNoCM));

      const totalScore = this.calcContractScoreTotalScore(riskScores, percentages, 'RiskScore');
      const totalScoreNoCM = this.calcContractScoreTotalScore(riskScoresNoCM, percentages, 'RiskScoreNoCM');

      const overallRating = this.calcContractScoreRating(totalScore);
      const overallRatingNoCM = this.calcContractScoreRating(totalScoreNoCM);

      const contractScore = await this.getContractScore(ContractNbr, context.transaction);
      if (contractScore) {
        context.RiskContractScore = contractScore;
      } else {
        context.RiskContractScore = {
          RiskContractScoreKey: uuid(),
          ContractNbr,
          CreateDttm: context.updateAt,
          CreateUserId: context.enterpriseId
        };
      }
      context.RiskContractScore.ContractScore = overallRating[1];
      context.RiskContractScore.ContractScoreRatingCd = overallRating[0];
      context.RiskContractScore.ContractScoreNoCM = overallRatingNoCM[1];
      context.RiskContractScore.ContractScoreNoCMRatingCd = overallRatingNoCM[0];
      context.RiskContractScore.UpdateDttm = context.updateAt;
      context.RiskContractScore.UpdateUserId = context.enterpriseId;
    }
  }

  /**
   * @param {RiskRequestContext|*} context
   */
  async createRiskHistory(context) {
    const historyTypes = this.determineShouldCreateHistory(context.RiskDetailsModel);
    if (historyTypes && historyTypes.length > 0) {
      const consultationCall = Object.assign({}, context.RiskConsultationCall, {
        ConsCallInvolvedParty: context.RiskConsCallInvolvedParties,
        ConsCallFinRevenueCCI: context.RiskConsCallFinRevenueCCIs
      });
      const ContentTxt = JSON.stringify(
        Object.assign({}, context.RiskDetails, {
          Mitigations: [
            ...(context.NoChangeRiskMitigations || []),
            ...(context.UpdateRiskMitigations || []),
            ...(context.NewRiskMitigations || [])
          ],
          LeadReviews: [
            ...(context.NoChangeRiskLeadReviews || []),
            ...(context.UpdateRiskLeadReviews || []),
            ...(context.NewRiskLeadReviews || [])
          ],
          ConsultationCall: consultationCall,
          QMDCall: {
            RiskQMDReviewDttm: context.RiskDetails.RiskQMDReviewDttm,
            RiskQMDReviewInd: context.RiskDetails.RiskQMDReviewInd
          }
        })
      );
      let HistoryNm = 'Iteration';
      let iterationNbr = this.initHistoryIterationNbr;
      const lastHistory = await this.getLastHistoryIteration(context.RiskDetails, context.transaction);
      if (lastHistory && lastHistory.HistoryNm) {
        iterationNbr = Number.parseInt(lastHistory.HistoryNm.split(' ')[1]);
      }
      const historyCount = historyTypes.length;
      context.RiskHistories = historyTypes.map((o, i) => ({
        RiskDetailsKey: context.RiskDetails.RiskDetailsKey,
        RiskHistoryKey: uuid(),
        ContentTxt,
        CreateDttm: context.RiskDetailsModel.HistoryDttm || context.updateAt,
        CreateUserId: context.enterpriseId,
        EnterpriseId: context.enterpriseId,
        HistoryNm: `${HistoryNm} ${iterationNbr + this.historyIterationNbrStep + i} - ${o}`,
        UpdateDttm: new Date(new Date(context.updateAt).valueOf() - historyCount + i).toISOString(),
        UpdateUserId: context.enterpriseId
      }));
    }
  }

  /**
   * @param {RiskDetailsModel} riskDetails
   */
  determineShouldCreateHistory(riskDetails) {
    const historyTypes = [];

    if (riskDetails.CMRiskToIssue) {
      historyTypes.push('Risk Converted to Issue');
    }
    if (riskDetails.CMIssueToRisk) {
      historyTypes.push('Issue Converted to Risk');
    }
    if (riskDetails.ReadyForReview) {
      historyTypes.push('Ready for Review');
    }
    if (riskDetails.LeadReviewCompleted) {
      historyTypes.push('Lead Review Completed');
    }
    if (riskDetails.ConsultationCallFlagged) {
      historyTypes.push('Consultation Call Flagged');
    }
    if (riskDetails.ConsultationCallCompleted) {
      historyTypes.push('Consultation Call Completed');
    }
    return historyTypes;
  }

  /**
   * @param {string} riskDetailsKey
   * @return {RiskDetailsModel}
   */
  async get(riskDetailsKey) {
    let details = await this.getDetails(riskDetailsKey);
    if (details) {
      details = await Promise.all([
        this.getMitigations(riskDetailsKey),
        this.getLeadReviews(riskDetailsKey),
        this.getConsultationCall(riskDetailsKey)
      ]).then(async ([mitigations, leadReviews, consultationCall]) => {
        details.Mitigations = mitigations;
        if (details.RiskSourceCd === this.riskSourceCM) {
          if (consultationCall) {
            const {RiskConsultationCallKey} = consultationCall;
            const [consCallInvolvedParty, finRevenueCCI] = await Promise.all([
              this.getConsultationCallInvolvedParties(RiskConsultationCallKey),
              this.getConsultationCallFinRevenueCCI(RiskConsultationCallKey)
            ]);
            consultationCall.ConsCallInvolvedParty = consCallInvolvedParty;
            consultationCall.ConsCallFinRevenueCCI = finRevenueCCI;
          }
          details.LeadReviews = leadReviews;
          details.ConsultationCall = consultationCall || {};
          details.QMDCall = {
            RiskQMDReviewInd: details.RiskQMDReviewInd,
            RiskQMDReviewDttm: details.RiskQMDReviewDttm
          };
          delete details.RiskQMDReviewInd;
          delete details.RiskQMDReviewDttm;
        }
        return details;
      });
    }
    return details || {};
  }

  async getDetails(riskDetailsKey) {
    const EnterpriseID = process.env.ENTERPRISEID;
    const query = {
      sql: `SELECT rd.*
                  FROM RiskDetails rd
                  INNER JOIN MMCSecurityData mmc
                  ON rd.MasterClientNbr = mmc.MasterClientNbr
                  WHERE rd.RiskDetailsKey = @riskDetailsKey
                  AND mmc.EnterpriseID = @EnterpriseID`,
      params: {
        riskDetailsKey,
        EnterpriseID
      }
    };
    return await this.runQueryGetSingle(query);
  }

  async getNba(questionKey) {
    const query = {
      sql: `SELECT NBATitle,NBADesc,QuestionCd,StatementCdArr,RiskNextBestActionKey,RiskTypeCdArr
            FROM RiskNextBestAction AS ra INNER JOIN  RiskAssessmentQuestion AS rq ON rq.RiskQuestionCd=ra.QuestionCd 
            WHERE rq.RiskAssessmentQuestionKey =@questionKey
            `,
      params: {
        questionKey
      }
    };
    return await this.runQuery(query);
  }

  async getMitigations(riskDetailsKey) {
    const query = {
      sql: `SELECT rm.*
FROM RiskMitigation rm 
LEFT JOIN@{JOIN_TYPE=APPLY_JOIN} CodeDetail rd ON rm.MitigationStatusCd = rd.CodeTxt
WHERE rm.RiskDetailsKey = @riskDetailsKey
ORDER BY rm.MitigationTypeCd ASC, rd.CodeTxt ASC, rm.DueDttm ASC`,
      params: {
        riskDetailsKey
      }
    };
    return await this.runQuery(query);
  }

  async getLeadReviews(riskDetailsKey) {
    const query = {
      sql: `SELECT *
            FROM RiskLeadReview rlr
            WHERE rlr.RiskDetailsKey = @riskDetailsKey
            ORDER BY rlr.CreateDttm ASC`,
      params: {
        riskDetailsKey
      }
    };
    return await this.runQuery(query);
  }

  async getConsultationCall(riskDetailsKey) {
    const query = {
      sql: `SELECT *
            FROM RiskConsultationCall rcc
            WHERE rcc.RiskDetailsKey = @riskDetailsKey`,
      params: {
        riskDetailsKey
      }
    };
    return await this.runQueryGetSingle(query);
  }

  async getConsultationCallInvolvedParties(riskConsultationCallKey) {
    const query = {
      sql: `SELECT * 
            FROM RiskConsCallInvolvedParty rp 
            WHERE rp.riskConsultationCallKey = @riskConsultationCallKey`,
      params: {
        riskConsultationCallKey
      }
    };
    return await this.runQuery(query);
  }

  async getConsultationCallFinRevenueCCI(riskConsultationCallKey) {
    const query = {
      sql: `SELECT *
            FROM RiskConsCallFinRevenueCCI rr
            WHERE rr.riskConsultationCallKey = @riskConsultationCallKey`,
      params: {
        riskConsultationCallKey
      }
    };
    return await this.runQuery(query);
  }

  /**
   * @param {RiskDetailsModel|*} riskDetailsModel
   * @return {string} RiskDetailsKey
   */
  async updateRisk(riskDetailsModel) {
    const database = this.getDatabase();
    const enterpriseId = process.env.ENTERPRISEID;
    const updateAt = new Date().toISOString();

    try {
      return await database.runTransactionAsync(async transaction => {
        const requestContext = {
          RiskDetailsModel: riskDetailsModel,
          database: database,
          transaction: transaction,
          enterpriseId: enterpriseId,
          updateAt: updateAt
        };
        try {
          await this.updateRiskDetails(requestContext);
          await this.updateRiskMitigations(requestContext);
          await this.updateRiskLeadReviews(requestContext);
          await this.updateRiskConsultationCall(requestContext);
          await this.updateRiskScore(requestContext);
          await this.createRiskHistory(requestContext);
          await this.updateToDb(requestContext);
          await transaction.commit();
          await this.publishCIPEvents(requestContext);
        } finally {
          if (!transaction.ended) {
            transaction.end();
          }
        }
        return requestContext.RiskDetails;
      });
    } catch (err) {
      this.errorHandling(err, {errorKey: 'UPDATE_RISK_ERROR'});
      throw new Error('UPDATE_RISK_ERROR');
    } finally {
      await this.closeDatabase(database);
    }
  }

  /**
   * @param {RiskRequestContext|*} context
   */
  async updateRiskDetails(context) {
    context.RiskDetails = {};
    context.RiskDetails.CreateDttm = context.RiskDetailsModel.CreateDttm;
    context.RiskDetails.CreateUserId = context.RiskDetailsModel.CreateUserId;
    context.RiskDetails.CustomerNbr = context.RiskDetailsModel.CustomerNbr;
    context.RiskDetails.CustomerNm = context.RiskDetailsModel.CustomerNm;
    context.RiskDetails.MasterClientNbr = context.RiskDetailsModel.MasterClientNbr;
    context.RiskDetails.MasterClientNm = context.RiskDetailsModel.MasterClientNm;
    context.RiskDetails.CIPReasonforChangeTxt = context.RiskDetailsModel.CIPReasonforChangeTxt;
    context.RiskDetails.RiskDetailsKey = context.RiskDetailsModel.RiskDetailsKey;
    context.RiskDetails.UpdateDttm = context.updateAt;
    context.RiskDetails.UpdateUserId = context.enterpriseId;
    context.RiskDetails.ContractNbr = context.RiskDetailsModel.ContractNbr;
    context.RiskDetails.ContractNm = context.RiskDetailsModel.ContractNm;
    context.RiskDetails.RiskAssessmentQuestionKey = context.RiskDetailsModel.RiskAssessmentQuestionKey;
    context.RiskDetails.RiskDesc = context.RiskDetailsModel.RiskDesc;
    context.RiskDetails.RiskLeadReviewDttm = context.RiskDetailsModel.RiskLeadReviewDttm;
    context.RiskDetails.RiskLeadReviewStatusCd = context.RiskDetailsModel.RiskLeadReviewStatusCd;
    context.RiskDetails.RiskNbr = context.RiskDetailsModel.RiskNbr;
    context.RiskDetails.RiskRatingCd = context.RiskDetailsModel.RiskRatingCd;
    context.RiskDetails.RiskSourceCd = context.RiskDetailsModel.RiskSourceCd;
    context.RiskDetails.RiskStatusCd = context.RiskDetailsModel.RiskStatusCd;
    context.RiskDetails.RiskTypeCd = context.RiskDetailsModel.RiskTypeCd;
    context.RiskDetails.StatementArr = context.RiskDetailsModel.StatementArr;
    context.RiskDetails.NBAInd = 'Y';
    if (context.RiskDetailsModel.QMDCall) {
      context.RiskDetails.RiskQMDReviewDttm = context.RiskDetailsModel.QMDCall.RiskQMDReviewDttm || null;
      context.RiskDetails.RiskQMDReviewInd = context.RiskDetailsModel.QMDCall.RiskQMDReviewInd || 'N';
    } else {
      context.RiskDetails.RiskQMDReviewDttm = null;
      context.RiskDetails.RiskQMDReviewInd = 'N';
    }
    if (context.RiskDetails.RiskSourceCd === this.riskSourceCIP) {
      if (context.RiskDetailsModel.CIPRiskRatingUpdated) {
        const event = {
          EventName: this.CIPCommentEventUpdateRiskRating,
          CreateUserId: context.RiskDetails.CreateUserId,
          CreateDttm: context.RiskDetails.CreateDttm,
          UpdateUserId: context.RiskDetails.UpdateUserId,
          UpdateDttm: context.RiskDetails.UpdateDttm,
          RiskRatingCd: context.RiskDetails.RiskRatingCd,
          RiskDetailsKey: context.RiskDetails.RiskDetailsKey,
          MMCLinkToRiskDetails: context.RiskDetailsModel.MMCLinkToRiskDetails,
          CIPId: context.RiskDetailsModel.CIPId,
          CIPType: context.RiskDetailsModel.CIPType,
          Level3RiskId: context.RiskDetailsModel.CIPRiskId
        };
        context.CIPUpdateRiskRatingEvents = [event];
      }
    }
  }

  /**
   * @param {RiskRequestContext|*} context
   */
  async updateRiskMitigations(context) {
    const {Mitigations} = context.RiskDetailsModel;
    if (Mitigations && Mitigations.length > 0) {
      const deleteMitigations = Mitigations.filter(o => o.IsDelete);
      const newMitigations = Mitigations.filter(o => !o.IsDelete && !o.RiskMitigationKey);
      const updateMitigations = Mitigations.filter(o => !o.IsDelete && o.RiskMitigationKey && o.MitigationUpdated);
      const noChangeMitigations = Mitigations.filter(o => !o.IsDelete && o.RiskMitigationKey && !o.MitigationUpdated);
      let mitigationStatus = [];
      if (deleteMitigations.length > 0) {
        context.DeleteRiskMitigations = deleteMitigations.map(o => {
          delete o.IsDelete;
          return o;
        });
        context.deleteRiskMitigation = true;
      }
      if (newMitigations.length > 0) {
        context.NewRiskMitigations = newMitigations.map(o => {
          return {
            RiskDetailsKey: context.RiskDetailsModel.RiskDetailsKey,
            RiskMitigationKey: uuid(),
            AssigneeUserId: o.AssigneeUserId,
            DueDttm: o.DueDttm,
            MitigationDesc: o.MitigationDesc,
            MitigationStatusCd: o.MitigationStatusCd,
            MitigationSourceCd: o.MitigationSourceCd,
            CreateDttm: o.CreateDttm || context.updateAt,
            CreateUserId: o.CreateUserId || context.enterpriseId,
            UpdateDttm: o.UpdateDttm || context.updateAt,
            UpdateUserId: o.UpdateUserId || context.enterpriseId,
            RiskNextBestActionKey: o.RiskNextBestActionKey,
            MitigationTitle: o.MitigationTitle,
            MitigationTypeCd: o.MitigationTypeCd,
            MitigationNbr: o.MitigationNbr,
            OriginalNBATitle: o.OriginalNBATitle,
            OriginalNBADesc: o.OriginalNBADesc
          };
        });
        if (context.RiskDetailsModel.RiskSourceCd === this.riskSourceCIP) {
          mitigationStatus = await this.getCodesByCategory(this.riskMitigationStatusCategory);
          context.CIPNewMitigationEvents = newMitigations.map(o => ({
            EventName: this.CIPCommentEventNewMitigation,
            RiskRatingCd: context.RiskDetails.RiskRatingCd,
            RiskDetailsKey: context.RiskDetails.RiskDetailsKey,
            RiskMitigationKey: o.RiskMitigationKey,
            MMCLinkToRiskDetails: context.RiskDetailsModel.MMCLinkToRiskDetails,
            CIPId: context.RiskDetailsModel.CIPId,
            CIPType: context.RiskDetailsModel.CIPType,
            Level3RiskId: context.RiskDetailsModel.CIPRiskId,
            MitigationCreateUserId: o.CreateUserId,
            MitigationCreateDttm: o.CreateDttm,
            MitigationUpdateUserId: o.UpdateUserId,
            MitigationUpdateDttm: o.UpdateDttm,
            MitigationStatus: mitigationStatus.find(x => x.CodeTxt === o.MitigationStatusCd).PrimaryDecodeTxt,
            MitigationDueDate: o.DueDttm,
            MitigationOwner: o.AssigneeUserId,
            MitigationDescription: o.MitigationDesc
          }));
        }
      }
      if (updateMitigations.length > 0) {
        if (context.RiskDetailsModel.RiskSourceCd === this.riskSourceCIP) {
          if (mitigationStatus.length === 0) {
            mitigationStatus = await this.getCodesByCategory(this.riskMitigationStatusCategory);
          }
          context.CIPUpdateMitigationEvents = updateMitigations
            .filter(o => o.CIPMitigationUpdated === true)
            .map(o => ({
              EventName: this.CIPCommentEventUpdateMitigation,
              RiskRatingCd: context.RiskDetails.RiskRatingCd,
              RiskDetailsKey: context.RiskDetails.RiskDetailsKey,
              RiskMitigationKey: o.RiskMitigationKey,
              MMCLinkToRiskDetails: context.RiskDetailsModel.MMCLinkToRiskDetails,
              CIPId: context.RiskDetailsModel.CIPId,
              CIPType: context.RiskDetailsModel.CIPType,
              Level3RiskId: context.RiskDetailsModel.CIPRiskId,
              MitigationCreateUserId: o.CreateUserId,
              MitigationCreateDttm: o.CreateDttm,
              MitigationUpdateUserId: o.UpdateUserId,
              MitigationUpdateDttm: o.UpdateDttm,
              MitigationStatus: mitigationStatus.find(x => x.CodeTxt === o.MitigationStatusCd).PrimaryDecodeTxt,
              MitigationDueDate: o.DueDttm,
              MitigationOwner: o.AssigneeUserId,
              MitigationDescription: o.MitigationDesc
            }));
        }

        context.UpdateRiskMitigations = updateMitigations.map(o => {
          delete o.MitigationUpdated;
          delete o.CIPMitigationUpdated;
          return o;
        });
      }
      if (noChangeMitigations.length > 0) {
        context.NoChangeRiskMitigations = noChangeMitigations.map(o => {
          delete o.MitigationUpdated;
          return o;
        });
      }
    }
  }

  /**
   * @param {RiskRequestContext|*} context
   */
  async updateRiskLeadReviews(context) {
    if (context.RiskDetails.RiskSourceCd === this.riskSourceCM) {
      const {LeadReviews} = context.RiskDetailsModel;
      if (LeadReviews && LeadReviews.length > 0) {
        const deleteLeadReviews = LeadReviews.filter(o => o.IsDelete);
        const newLeadReviews = LeadReviews.filter(o => !o.IsDelete && !o.RiskLeadReviewKey);
        const updateLeadReviews = LeadReviews.filter(o => !o.IsDelete && o.RiskLeadReviewKey);
        if (deleteLeadReviews.length > 0) {
          context.DeleteRiskLeadReviews = deleteLeadReviews.map(o => {
            o.RiskDetailsKey = context.RiskDetails.RiskDetailsKey;
            delete o.IsDelete;
            return o;
          });
        }
        if (newLeadReviews.length > 0) {
          context.NewRiskLeadReviews = newLeadReviews.map(o => {
            return {
              RiskDetailsKey: context.RiskDetails.RiskDetailsKey,
              RiskLeadReviewKey: uuid(),
              DesignatedReviewerUserIdArr: o.DesignatedReviewerUserIdArr,
              LeadReviewDttm: o.LeadReviewDttm,
              LeadReviewStatusCd: o.LeadReviewStatusCd,
              RecordedUserId: o.RecordedUserId,
              CreateDttm: o.CreateDttm || context.updateAt,
              CreateUserId: o.CreateUserId || context.enterpriseId,
              UpdateDttm: o.UpdateDttm || context.updateAt,
              UpdateUserId: o.UpdateUserId || context.enterpriseId
            };
          });
        }
        if (updateLeadReviews.length > 0) {
          context.UpdateRiskLeadReviews = updateLeadReviews.map(o => {
            return {
              RiskDetailsKey: context.RiskDetails.RiskDetailsKey,
              RiskLeadReviewKey: o.RiskLeadReviewKey,
              DesignatedReviewerUserIdArr: o.DesignatedReviewerUserIdArr,
              LeadReviewDttm: o.LeadReviewDttm,
              LeadReviewStatusCd: o.LeadReviewStatusCd,
              RecordedUserId: o.RecordedUserId,
              CreateDttm: o.CreateDttm || context.updateAt,
              CreateUserId: o.CreateUserId || context.enterpriseId,
              UpdateDttm: o.UpdateDttm || context.updateAt,
              UpdateUserId: o.UpdateUserId || context.enterpriseId
            };
          });
        }
      }
    }
  }

  /**
   * @param {RiskRequestContext|*} context
   */
  async updateRiskConsultationCall(context) {
    if (context.RiskDetails.RiskSourceCd === this.riskSourceCM) {
      const {ConsultationCall} = context.RiskDetailsModel;
      if (ConsultationCall.ConsultationCallStatusCd) {
        if (!ConsultationCall.RiskConsultationCallKey) {
          await this.createRiskConsultationCall(context);
        } else {
          if (ConsultationCall.ConsultationCallStatusCd === this.riskConsultationCallNotRequest) {
            await this.deleteRiskConsultationCall(context);
          } else {
            context.RiskConsultationCall = {
              RiskConsultationCallKey: ConsultationCall.RiskConsultationCallKey,
              RiskDetailsKey: context.RiskDetails.RiskDetailsKey,
              CreateDttm: ConsultationCall.CreateDttm || context.updateAt,
              CreateUserId: ConsultationCall.CreateUserId || context.enterpriseId,
              UpdateDttm: context.updateAt,
              UpdateUserId: context.enterpriseId,
              ReviewerShareInd: ConsultationCall.ReviewerShareInd || 'N',
              CMActionsDesc: ConsultationCall.CMActionsDesc,
              ConsultationCallStatusCd: ConsultationCall.ConsultationCallStatusCd,
              ExposureContractDesc: ConsultationCall.ExposureContractDesc,
              ExposureFinancialDesc: ConsultationCall.ExposureFinancialDesc,
              FinancialsBillingTermsNm: ConsultationCall.FinancialsBillingTermsNm,
              FinancialsBillMechanismCd: ConsultationCall.FinancialsBillMechanismCd,
              FinancialsCurrentFYRevenueNbr: ConsultationCall.FinancialsCurrentFYRevenueNbr,
              FinancialsFYRevenueNbr: ConsultationCall.FinancialsFYRevenueNbr,
              FinancialsTotalContractNbr: ConsultationCall.FinancialsTotalContractNbr,
              ResolutionTimeFrameDesc: ConsultationCall.ResolutionTimeFrameDesc,
              ReviewerCompletedDt: ConsultationCall.ReviewerCompletedDt,
              ReviewerFollowupDt: ConsultationCall.ReviewerFollowupDt,
              ReviewerNoteDesc: ConsultationCall.ReviewerNoteDesc,
              CCSlotRequestUserId: ConsultationCall.CCSlotRequestUserId,
              DateRequested: ConsultationCall.DateRequested,
              BookaPreferredSlot: ConsultationCall.BookaPreferredSlot,
              CMOgLead: ConsultationCall.CMOgLead,
              CMGeoLead: ConsultationCall.CMGeoLead,
              CMUsersArr: ConsultationCall.CMUsersArr,
              RequestConfidentialInd: ConsultationCall.RequestConfidentialInd,
              OnHriListInd: ConsultationCall.OnHriListInd
            };
            const {ConsCallInvolvedParty, ConsCallFinRevenueCCI} = ConsultationCall;
            if (ConsCallInvolvedParty && ConsCallInvolvedParty.length > 0) {
              context.RiskConsCallInvolvedParties = ConsCallInvolvedParty.map(o => {
                return {
                  RiskConsultationCallKey: context.RiskConsultationCall.RiskConsultationCallKey,
                  RiskConsCallInvolvedPartyKey: o.RiskConsCallInvolvedPartyKey || uuid(),
                  PartyArr: o.PartyArr,
                  PartyCategoryCd: o.PartyCategoryCd,
                  CreateDttm: o.CreateDttm || context.updateAt,
                  CreateUserId: o.CreateUserId || context.enterpriseId,
                  UpdateDttm: context.updateAt,
                  UpdateUserId: context.enterpriseId
                };
              });
            }

            if (ConsCallFinRevenueCCI && ConsCallFinRevenueCCI.length > 0) {
              context.RiskConsCallFinRevenueCCIs = ConsultationCall.ConsCallFinRevenueCCI.map(o => {
                return {
                  RiskConsultationCallKey: context.RiskConsultationCall.RiskConsultationCallKey,
                  RiskConsCallFinRevenueCCIKey: o.RiskConsCallFinRevenueCCIKey || uuid(),
                  TypeCd: o.TypeCd,
                  EACNbr: o.EACNbr,
                  ODENbr: o.ODENbr,
                  VarianceNbr: o.VarianceNbr,
                  CreateDttm: o.CreateDttm || context.updateAt,
                  CreateUserId: o.CreateUserId || context.enterpriseId,
                  UpdateDttm: context.updateAt,
                  UpdateUserId: context.enterpriseId
                };
              });
            }
          }
        }
      }
    }
  }

  /**
   * @param {RiskRequestContext|*} context
   */
  async deleteRiskConsultationCall(context) {
    const {ConsultationCall} = context.RiskDetailsModel;
    context.RiskConsultationCall = {};
    context.RiskConsCallInvolvedParties = [];
    context.RiskConsCallFinRevenueCCIs = [];

    context.DeleteRiskConsultationCall = {
      RiskDetailsKey: context.RiskDetails.RiskDetailsKey,
      RiskConsultationCallKey: ConsultationCall.RiskConsultationCallKey
    };

    const {ConsCallInvolvedParty, ConsCallFinRevenueCCI} = ConsultationCall;

    if (ConsCallInvolvedParty && ConsCallInvolvedParty.length > 0) {
      context.DeleteRiskConsCallInvolvedParties = ConsCallInvolvedParty.map(o => ({
        RiskConsultationCallKey: ConsultationCall.RiskConsultationCallKey,
        RiskConsCallInvolvedPartyKey: o.RiskConsCallInvolvedPartyKey
      }));
    }

    if (ConsCallFinRevenueCCI && ConsCallFinRevenueCCI.length > 0) {
      context.DeleteRiskConsCallFinRevenueCCIs = ConsCallFinRevenueCCI.map(o => ({
        RiskConsultationCallKey: ConsultationCall.RiskConsultationCallKey,
        RiskConsCallFinRevenueCCIKey: o.RiskConsCallFinRevenueCCIKey
      }));
    }
  }

  async getCode(codeTxt) {
    const query = {
      sql: `SELECT cd.CodeDetailId, cd.CodeTxt, cd.PrimaryDecodeTxt, cd.SecondaryDecodeTxt, cd.ParentId 
            FROM CodeDetail cd 
            WHERE cd.CodeTxt = @codeTxt AND CodeDetailStatusInd = 'Y' LIMIT 1`,
      params: {
        codeTxt
      }
    };
    return await this.runQueryGetSingle(query);
  }

  async getCodesByCategory(categoryDesc) {
    const query = {
      sql: `SELECT cd.CodeDetailId, cd.CodeTxt, cd.PrimaryDecodeTxt, cd.SecondaryDecodeTxt, cd.ParentId 
            FROM CodeHeader ch
            LEFT JOIN CodeDetail cd ON ch.CodeHeaderId = cd.CodeHeaderId 
            WHERE ch.CategoryDesc = @categoryDesc AND CodeDetailStatusInd = 'Y' AND cd.ParentId = 0`,
      params: {
        categoryDesc
      }
    };
    return await this.runQuery(query);
  }

  async getCodesByParentCategory(categoryDesc) {
    const query = {
      sql: `SELECT c.CodeDetailId, c.CodeTxt, c.PrimaryDecodeTxt, c.SecondaryDecodeTxt, c.ParentId 
FROM CodeDetail c 
INNER JOIN (SELECT cd.CodeDetailId
            FROM CodeHeader ch
            LEFT JOIN CodeDetail cd ON ch.CodeHeaderId = cd.CodeHeaderId 
            WHERE ch.CategoryDesc = @categoryDesc AND CodeDetailStatusInd = 'Y' AND cd.ParentId = 0) p ON c.ParentId = p.CodeDetailId
WHERE c.CodeDetailStatusInd = 'Y'
            `,
      params: {
        categoryDesc
      }
    };
    return await this.runQuery(query);
  }

  async getCodesByCategories(categoryArray) {
    const query = {
      sql: `SELECT cd.CodeDetailId, cd.CodeTxt, cd.PrimaryDecodeTxt, cd.SecondaryDecodeTxt, cd.ParentId 
            FROM CodeHeader ch
            LEFT JOIN CodeDetail cd ON ch.CodeHeaderId = cd.CodeHeaderId 
            WHERE ch.CategoryDesc IN UNNEST (@categoryArray) AND CodeDetailStatusInd = 'Y'`,
      params: {
        categoryArray
      }
    };
    return await this.runQuery(query);
  }

  async getCodes(codeTxtArray) {
    const query = {
      sql: `SELECT cd.CodeDetailId, cd.CodeTxt, cd.PrimaryDecodeTxt, cd.SecondaryDecodeTxt, cd.ParentId 
            FROM CodeDetail cd
            WHERE cd.CodeTxt IN UNNEST (@codeTxtArray) AND CodeDetailStatusInd = 'Y'`,
      params: {
        codeTxtArray
      }
    };
    return await this.runQuery(query);
  }

  async getQuestion(riskAssessmentQuestionKey) {
    const query = {
      sql: `SELECT RiskAssessmentQuestionKey, CategoryCd, SubCategoryCd, StatementArr, RiskQuestionCd, WeightNbr, QuestionQARefArr
      FROM RiskAssessmentQuestion raq 
      WHERE raq.RiskAssessmentQuestionKey = @riskAssessmentQuestionKey LIMIT 1`,
      params: {
        riskAssessmentQuestionKey
      }
    };
    return await this.runQueryGetSingle(query);
  }

  async getQuestions(contractNbr) {
    const query = {
      sql: `SELECT rd.RiskDetailsKey, raq.*
FROM RiskAssessmentQuestion raq
LEFT JOIN (SELECT rd.*
           FROM RiskDetails rd
           WHERE (rd.ContractNbr=@contractNbr)) rd ON raq.RiskAssessmentQuestionKey = rd.RiskAssessmentQuestionKey
ORDER BY raq.QuestionOrderNbr ASC`,
      params: {
        contractNbr
      }
    };
    return await this.runQuery(query);
  }

  /**
   * @param {RiskDetails} riskDetails
   * @param {Snapshot} transaction
   */
  async getLastHistoryIteration(riskDetails, transaction) {
    const {RiskDetailsKey} = riskDetails;
    const query = {
      sql: `SELECT * FROM RiskHistory rh WHERE rh.RiskDetailsKey=@riskDetailsKey ORDER BY rh.UpdateDttm DESC, rh.HistoryNm DESC LIMIT 1`,
      params: {
        riskDetailsKey: RiskDetailsKey
      }
    };

    return await this.runQueryGetSingleWithTransaction(query, transaction);
  }

  async getHistories(riskDetailsKey) {
    const query = {
      sql: `SELECT rh.RiskHistoryKey, rh.HistoryNm, rh.CreateDttm, rh.EnterpriseId FROM RiskHistory rh WHERE rh.RiskDetailsKey=@riskDetailsKey ORDER BY rh.UpdateDttm DESC, rh.HistoryNm DESC`,
      params: {
        riskDetailsKey
      }
    };

    return await this.runQuery(query);
  }

  async getHistory(historyKey, riskDetailsKey) {
    const query = {
      sql: `SELECT * FROM RiskHistory rh WHERE rh.RiskDetailsKey=@riskDetailsKey AND rh.RiskHistoryKey=@historyKey LIMIT 1`,
      params: {
        riskDetailsKey,
        historyKey
      }
    };

    return await this.runQueryGetSingle(query);
  }

  calcContractScoreTotalScore(riskScores, percentages, questionQARef) {
    const scoreList = _.chain(riskScores)
      .groupBy(o => o.CategoryCd)
      .map((scores, category) => {
        const scoresPerCategory = _.chain(scores)
          .map(x => x[questionQARef])
          .value();
        const sumOfScoresPerCategory = this._sum(scoresPerCategory);
        const total = this._multiply(sumOfScoresPerCategory, percentages[category]);
        return {
          total,
          category
        };
      })
      .map(o => o.total)
      .value();
    return this._sum(scoreList);
  }

  calcContractScoreRating(score) {
    const roundingScore = Math.round(score * 100) / 100;
    if (score === 0) {
      return [this.riskContractScoreRatingNA, 0];
    } else if (roundingScore >= 0.1 && roundingScore < 1.5) {
      return [this.riskContractScoreRatingNormal, roundingScore];
    } else if (roundingScore >= 1.5 && roundingScore < 3) {
      return [this.riskContractScoreRatingAboveNormal, roundingScore];
    } else if (roundingScore >= 3) {
      return [this.riskContractScoreRatingHigh, roundingScore];
    } else {
      return [this.riskContractScoreRatingNA, 0];
    }
  }

  async getAssessedRisksPerCategory(categoryCd, contractNbr, transaction) {
    const query = {
      sql: `SELECT rd.RiskDetailsKey, rd.RiskRatingCd, raq.WeightNbr, raq.CategoryCd, rd.ContractNbr, raq.QuestionQARefArr
FROM RiskDetails rd
INNER JOIN RiskAssessmentQuestion raq ON rd.RiskAssessmentQuestionKey = raq.RiskAssessmentQuestionKey
WHERE rd.ContractNbr = @contractNbr
  AND raq.CategoryCd = @categoryCd
  AND rd.RiskSourceCd = '${this.riskSourceCM}'`,
      params: {
        categoryCd,
        contractNbr,
        riskSourceCd: this.riskSourceCM
      }
    };
    return await this.runQueryWithTransaction(query, transaction);
  }

  determineRiskRatingMultiplier(riskRatingCd) {
    if (riskRatingCd === this.riskRatingNormal) {
      return this.riskRatingNormalMultiplier;
    } else if (riskRatingCd === this.riskRatingAboveNormal) {
      return this.riskRatingAboveNormalMultiplier;
    } else if (riskRatingCd === this.riskRatingHigh) {
      return this.riskRatingHighMultiplier;
    } else {
      throw new Error('Rating of Risk is not valid.');
    }
  }

  /**
   * @param {string} contractNbr
   * @param {Snapshot} transaction
   */
  async getRiskScores(contractNbr, transaction) {
    const query = {
      sql: `SELECT rd.RiskDetailsKey, rd.RiskScore, raq.CategoryCd, rd.ContractNbr, raq.QuestionQARefArr, rd.RiskScoreNoCM
FROM RiskDetails rd
INNER JOIN RiskAssessmentQuestion raq ON rd.RiskAssessmentQuestionKey = raq.RiskAssessmentQuestionKey
WHERE rd.ContractNbr = @contractNbr
  AND rd.RiskSourceCd = '${this.riskSourceCM}'`,
      params: {
        contractNbr
      }
    };
    return await this.runQueryWithTransaction(query, transaction);
  }

  async getContractScore(contractNbr, transaction) {
    const query = {
      sql: `SELECT * FROM RiskContractScore rcs WHERE rcs.ContractNbr=@contractNbr`,
      params: {
        contractNbr
      }
    };
    return await this.runQueryGetSingleWithTransaction(query, transaction);
  }

  async getContractScores(contractNbr) {
    const queryWithParams = {
      sql: `SELECT rcs.*, cd.PrimaryDecodeTxt ContractScoreRating, cd2.PrimaryDecodeTxt ContractScoreNoCMRating
FROM RiskContractScore rcs 
LEFT JOIN@{JOIN_TYPE=APPLY_JOIN} CodeDetail cd ON cd.CodeTxt = rcs.ContractScoreRatingCd
LEFT JOIN@{JOIN_TYPE=APPLY_JOIN} CodeDetail cd2 ON cd2.CodeTxt = rcs.ContractScoreNoCMRatingCd
WHERE rcs.ContractNbr=@contractNbr`,
      params: {
        contractNbr
      }
    };
    const query = {
      sql: `SELECT * FROM RiskContractScore`
    };
    if (contractNbr) {
      return this.runQuery(queryWithParams);
    } else {
      return this.runQuery(query);
    }
  }

  async publishCIPComments(events, token) {
    try {
      const http = new IssuesRisksHttp();
      return await http.sendCIPComments(events, token);
    } catch (err) {
      console.log(`SEND_CIP_COMMENTS_ERROR: ${err}`);
    }
  }

  /**
   * @param {RiskRequestContext|*} context
   */
  async publishCIPEvents(context) {
    const events = [
      ...(context.CIPNewMitigationEvents || []),
      ...(context.CIPUpdateMitigationEvents || []),
      ...(context.CIPUpdateRiskRatingEvents || [])
    ];
    if (events.length > 0) {
      await this.publishCIPComments(events, context.RiskDetailsModel.token);
    }
  }

  /**
   * @param {ExecuteSqlRequest|*} query
   * @param {TimestampBounds|*} options
   */
  async runQuery(query, options = {}) {
    const database = this.getDatabase();
    try {
      const [rows] = await database.run(query, options);
      return rows.map(o => o.toJSON());
    } catch (err) {
      console.log(err);
      console.log(query);
      throw err;
    } finally {
      await this.closeDatabase(database);
    }
  }

  /**
   * @param {ExecuteSqlRequest} query
   * @param {Snapshot} transaction
   */
  async runQueryWithTransaction(query, transaction) {
    const [rows] = await transaction.run(query);
    return rows.map(o => o.toJSON());
  }

  /**
   * @param {ExecuteSqlRequest|*} query
   */
  async runUpdate(query) {
    const database = this.getDatabase();
    try {
      return await database.runTransactionAsync(async transaction => {
        try {
          const [rowCount] = await transaction.runUpdate(query);
          await transaction.commit();
          return rowCount;
        } catch (err) {
          throw err;
        } finally {
          if (!transaction.ended) {
            transaction.end();
          }
        }
      });
    } catch (err) {
      throw err;
    } finally {
      await this.closeDatabase(database);
    }
  }

  /**
   * @param {ExecuteSqlRequest|*} query
   * @param {TimestampBounds|*} options
   */
  async runQueryGetSingle(query, options = {}) {
    const database = this.getDatabase();
    try {
      const [rows] = await database.run(query, options);
      if (rows.length > 0) {
        return rows[0].toJSON();
      } else {
        return null;
      }
    } catch (err) {
      console.log(err);
      console.log(query);
      throw err;
    } finally {
      await this.closeDatabase(database);
    }
  }

  /**
   * @param {ExecuteSqlRequest|*} query
   * @param {Snapshot} transaction
   */
  async runQueryGetSingleWithTransaction(query, transaction) {
    const [rows] = await transaction.run(query);
    if (rows.length > 0) {
      return rows[0].toJSON();
    } else {
      return null;
    }
  }

  /**
   * @param {RiskIDRequestContext|*} context
   */
  async addIDToDb(context) {
    // RiskID
    if (context.RiskID && context.RiskID.length > 0) {
      context.transaction.insert('RiskID', context.RiskID);
    }
  }

  /**
   * @param {RiskFeedbackRequestContext|*} context
   */
  async addFeedbackToDb(context) {
    // Feedback
    if (context.riskFeedbackList && context.riskFeedbackList.length > 0) {
      context.riskFeedbackList.map(o => {
        o.RiskNBARecordKey = uuid();
        o.RiskDetailsKey = o.RiskDetailsKey === null ? '' : o.RiskDetailsKey;
        o.CreateDttm = context.updateAt;
        o.CreateUserId = context.enterpriseId;
        o.UpdateDttm = context.updateAt;
        o.UpdateUserId = context.enterpriseId;
        return o;
      });
      context.transaction.insert('RiskNBARecord', context.riskFeedbackList);

      const feedbackArr = context.riskFeedbackList.map(o => {
        return {
          RiskFeedbackKey: uuid(),
          RiskDetailsKey: o.RiskDetailsKey,
          RiskNextBestActionKey: o.RiskNextBestActionKey,
          RatingLevelCd: o.RatingLevelCd,
          RatingQuestionCdArr: o.RatingQuestionCdArr,
          RatingDesc: o.RatingDesc,
          CreateDttm: context.updateAt,
          CreateUserId: context.enterpriseId,
          UpdateDttm: context.updateAt,
          UpdateUserId: context.enterpriseId
        };
      });

      context.transaction.insert('RiskFeedback', feedbackArr);
    }
  }

  /**
   * @param {RiskRequestContext|*} context
   */
  async addToDb(context) {
    // RiskDetails
    if (context.RiskDetails) {
      const queryExistAssessment = {
        sql: `SELECT COUNT(1) Count FROM RiskDetails WHERE RiskAssessmentQuestionKey = @RiskAssessmentQuestionKey AND ContractNbr = @ContractNbr`,
        params: {
          RiskAssessmentQuestionKey: context.RiskDetails.RiskAssessmentQuestionKey,
          ContractNbr: context.RiskDetails.ContractNbr
        }
      };
      const {Count} = await this.runQueryGetSingleWithTransaction(queryExistAssessment, context.transaction);
      if (Count > 0) {
        console.log(`#### Captured ${Count} assessments under ContractNbr: ${context.RiskDetails.ContractNbr}`);
        throw new Error('ISSUES_RISKS_ERROR: question is being rated by others');
      }

      context.RiskDetails.RiskScore = this.floatSafe(context.RiskDetails.RiskScore);
      context.RiskDetails.RiskScoreNoCM = this.floatSafe(context.RiskDetails.RiskScoreNoCM);
      context.transaction.insert('RiskDetails', context.RiskDetails);
    }

    // Mitigations
    if (context.NewRiskMitigations && context.NewRiskMitigations.length > 0) {
      context.transaction.insert('RiskMitigation', context.NewRiskMitigations);
    }

    // LeadReviews
    if (context.NewRiskLeadReviews && context.NewRiskLeadReviews.length > 0) {
      context.transaction.insert('RiskLeadReview', context.NewRiskLeadReviews);
    }

    // ConsultationCall
    if (context.RiskConsultationCall) {
      context.transaction.insert(
        'RiskConsultationCall',
        [context.RiskConsultationCall].map(o => {
          o.FinancialsCurrentFYRevenueNbr = this.floatSafe(o.FinancialsCurrentFYRevenueNbr);
          o.FinancialsFYRevenueNbr = this.floatSafe(o.FinancialsFYRevenueNbr);
          o.FinancialsTotalContractNbr = this.floatSafe(o.FinancialsTotalContractNbr);
          return o;
        })
      );
      if (context.RiskConsCallInvolvedParties && context.RiskConsCallInvolvedParties.length > 0) {
        context.transaction.insert('RiskConsCallInvolvedParty', context.RiskConsCallInvolvedParties);
      }
      if (context.RiskConsCallFinRevenueCCIs && context.RiskConsCallFinRevenueCCIs.length > 0) {
        const CCIs = context.RiskConsCallFinRevenueCCIs.map(o => {
          o.EACNbr = this.floatSafe(o.EACNbr);
          o.ODENbr = this.floatSafe(o.ODENbr);
          o.VarianceNbr = this.floatSafe(o.VarianceNbr);
          return o;
        });
        context.transaction.insert('RiskConsCallFinRevenueCCI', CCIs);
      }
    }

    // ContractScore
    if (context.RiskContractScore) {
      if (context.ScoreUpdatedRiskDetails.length > 0) {
        context.transaction.update(
          'RiskDetails',
          context.ScoreUpdatedRiskDetails.map(o => {
            o.RiskScore = this.floatSafe(o.RiskScore);
            o.RiskScoreNoCM = this.floatSafe(o.RiskScoreNoCM);
            return o;
          })
        );
      }
      context.transaction.upsert(
        'RiskContractScore',
        [context.RiskContractScore].map(o => {
          o.ContractScore = this.floatSafe(o.ContractScore);
          o.ContractScoreNoCM = this.floatSafe(o.ContractScoreNoCM);
          return o;
        })
      );
    }

    // RiskHistory
    if (context.RiskHistories && context.RiskHistories.length) {
      context.transaction.insert('RiskHistory', context.RiskHistories);
    }
  }

  /**
   * @param {RiskRequestContext|*} context
   */
  async updateToDb(context) {
    // RiskDetails
    if (context.RiskDetails) {
      await context.transaction.update(
        'RiskDetails',
        [context.RiskDetails].map(o => {
          if (o.RiskScore !== undefined) {
            o.RiskScore = this.floatSafe(o.RiskScore);
          }
          if (o.RiskScoreNoCM !== undefined) {
            o.RiskScoreNoCM = this.floatSafe(o.RiskScoreNoCM);
          }
          return o;
        })
      );
    }

    // Mitigations
    if (context.DeleteRiskMitigations && context.DeleteRiskMitigations.length > 0) {
      await context.transaction.deleteRows(
        'RiskMitigation',
        context.DeleteRiskMitigations.map(o => [o.RiskDetailsKey, o.RiskMitigationKey])
      );
    }
    if (context.UpdateRiskMitigations && context.UpdateRiskMitigations.length > 0) {
      await context.transaction.update('RiskMitigation', context.UpdateRiskMitigations);
    }
    if (context.NewRiskMitigations && context.NewRiskMitigations.length > 0) {
      await context.transaction.insert('RiskMitigation', context.NewRiskMitigations);
    }

    // LeadReviews
    if (context.DeleteRiskLeadReviews && context.DeleteRiskLeadReviews.length > 0) {
      await context.transaction.deleteRows(
        'RiskLeadReview',
        context.DeleteRiskLeadReviews.map(o => [o.RiskDetailsKey, o.RiskLeadReviewKey])
      );
    }
    if (context.UpdateRiskLeadReviews && context.UpdateRiskLeadReviews.length > 0) {
      await context.transaction.update('RiskLeadReview', context.UpdateRiskLeadReviews);
    }
    if (context.NewRiskLeadReviews && context.NewRiskLeadReviews.length > 0) {
      await context.transaction.insert('RiskLeadReview', context.NewRiskLeadReviews);
    }

    // ConsultationCall
    if (context.DeleteRiskConsultationCall) {
      if (context.DeleteRiskConsCallInvolvedParties && context.DeleteRiskConsCallInvolvedParties.length > 0) {
        context.transaction.deleteRows(
          'RiskConsCallInvolvedParty',
          context.DeleteRiskConsCallInvolvedParties.map(o => [o.RiskConsultationCallKey, o.RiskConsCallInvolvedPartyKey])
        );
      }
      if (context.DeleteRiskConsCallFinRevenueCCIs && context.DeleteRiskConsCallFinRevenueCCIs.length > 0) {
        context.transaction.deleteRows(
          'RiskConsCallFinRevenueCCI',
          context.DeleteRiskConsCallFinRevenueCCIs.map(o => [o.RiskConsultationCallKey, o.RiskConsCallFinRevenueCCIKey])
        );
      }
      await context.transaction.deleteRows(
        'RiskConsultationCall',
        [context.DeleteRiskConsultationCall].map(o => [o.RiskDetailsKey, o.RiskConsultationCallKey])
      );
    } else {
      if (context.RiskConsultationCall) {
        context.transaction.upsert(
          'RiskConsultationCall',
          [context.RiskConsultationCall].map(o => {
            o.FinancialsCurrentFYRevenueNbr = this.floatSafe(o.FinancialsCurrentFYRevenueNbr);
            o.FinancialsFYRevenueNbr = this.floatSafe(o.FinancialsFYRevenueNbr);
            o.FinancialsTotalContractNbr = this.floatSafe(o.FinancialsTotalContractNbr);
            return o;
          })
        );
        if (context.RiskConsCallInvolvedParties && context.RiskConsCallInvolvedParties.length > 0) {
          context.transaction.upsert('RiskConsCallInvolvedParty', context.RiskConsCallInvolvedParties);
        }
        if (context.RiskConsCallFinRevenueCCIs && context.RiskConsCallFinRevenueCCIs.length > 0) {
          context.transaction.upsert(
            'RiskConsCallFinRevenueCCI',
            context.RiskConsCallFinRevenueCCIs.map(o => {
              o.EACNbr = this.floatSafe(o.EACNbr);
              o.ODENbr = this.floatSafe(o.ODENbr);
              o.VarianceNbr = this.floatSafe(o.VarianceNbr);
              return o;
            })
          );
        }
      }
    }

    // ContractScore
    if (context.RiskContractScore) {
      if (context.ScoreUpdatedRiskDetails.length > 0) {
        context.transaction.update(
          'RiskDetails',
          context.ScoreUpdatedRiskDetails.map(o => {
            o.RiskScore = this.floatSafe(o.RiskScore);
            o.RiskScoreNoCM = this.floatSafe(o.RiskScoreNoCM);
            return o;
          })
        );
      }
      context.transaction.upsert(
        'RiskContractScore',
        [context.RiskContractScore].map(o => {
          o.ContractScore = this.floatSafe(o.ContractScore);
          o.ContractScoreNoCM = this.floatSafe(o.ContractScoreNoCM);
          return o;
        })
      );
    }

    // RiskHistory
    if (context.RiskHistories && context.RiskHistories.length > 0) {
      context.transaction.insert('RiskHistory', context.RiskHistories);
    }
  }

  /**
   * @returns {Database}
   */
  getDatabase() {
    return new SpannerDB();
  }

  floatSafe(number) {
    return number === null ? number : Spanner.float(Number(number));
  }

  _divide(n1, n2) {
    const result = calc.division(n1, n2);
    if (!result) {
      return 0;
    } else {
      return result;
    }
  }

  _multiply(n1, n2) {
    const result = calc.multiplication(n1, n2);
    if (!result) {
      return 0;
    } else {
      return result;
    }
  }

  _sum(numbers) {
    if (numbers && numbers.length > 0) {
      let result = 0;
      numbers.forEach(o => {
        result = calc.addition(result, o);
      });
      return result;
    } else {
      return 0;
    }
  }

  /**
   * @param {Error} err
   * @param {any|{errorKey: *}} data
   */
  async errorHandling(err, data) {
    console.log(`${data.errorKey} ${err} | ${err.stack}`);
  }
}

module.exports = IssuesRisksRepository;
