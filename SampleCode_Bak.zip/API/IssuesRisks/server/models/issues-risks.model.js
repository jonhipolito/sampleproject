'use strict';

// eslint-disable-next-line no-unused-vars
class Entity {
  constructor() {
    this.CreateDttm = null;
    this.CreateUserId = null;
    this.UpdateDttm = null;
    this.UpdateUserId = null;
  }
}

/** Class representing a RiskAssessmentQuestion. */
// eslint-disable-next-line no-unused-vars
class RiskAssessmentQuestion extends Entity {
  constructor() {
    super();
    this.RiskAssessmentQuestionKey = null;
    this.CategoryCd = null;
    this.ImpactCd = null;
    this.QuestionOrderNbr = null;
    this.QuestionQARefArr = null;
    this.RiskQuestionCd = null;
    this.StatementArr = null;
    this.SubCategoryCd = null;
    this.WeightNbr = null;
  }
}

/** Class representing a RiskConsCallFinRevenueCCI. */
// eslint-disable-next-line no-unused-vars
class RiskConsCallFinRevenueCCI extends Entity {
  constructor() {
    super();
    this.RiskConsCallFinRevenueCCIKey = null;
    this.RiskConsultationCallKey = null;
    /**
     * @type {Spanner.Float}
     */
    this.EACNbr = null;
    /**
     * @type {Spanner.Float}
     */
    this.ODENbr = null;
    this.TypeCd = null;
    /**
     * @type {Spanner.Float}
     */
    this.VarianceNbr = null;
  }
}

/** Class representing a RiskConsCallInvolvedParty. */
// eslint-disable-next-line no-unused-vars
class RiskConsCallInvolvedParty extends Entity {
  constructor() {
    super();
    this.RiskConsCallInvolvedPartyKey = null;
    this.RiskConsultationCallKey = null;
    this.PartyArr = null;
    this.PartyCategoryCd = null;
  }
}

/** Class representing a RiskConsultationCall. */
// eslint-disable-next-line no-unused-vars
class RiskConsultationCall extends Entity {
  constructor() {
    super();
    this.RiskConsultationCallKey = null;
    this.RiskDetailsKey = null;
    this.CMActionsDesc = null;
    this.ConsultationCallStatusCd = null;
    this.ExposureContractDesc = null;
    this.ExposureFinancialDesc = null;
    this.FinancialsBillingTermsNm = null;
    this.FinancialsBillMechanismCd = null;
    this.CMOgLead = null;
    this.CMGeoLead = null;
    /**
     * @type {Spanner.Float}
     */
    this.FinancialsCurrentFYRevenueNbr = null;
    /**
     * @type {Spanner.Float}
     */
    this.FinancialsFYRevenueNbr = null;
    /**
     * @type {Spanner.Float}
     */
    this.FinancialsTotalContractNbr = null;
    this.ResolutionTimeFrameDesc = null;
    this.ReviewerCompletedDt = null;
    this.ReviewerFollowupDt = null;
    this.ReviewerNoteDesc = null;
    this.ReviewerShareInd = null;
    this.CCSlotRequestUserId = null;
    this.DateRequested = null;
    this.BookaPreferredSlot = null;

    this.CMUsersArr = null;
    this.RequestConfidentialInd = null;
    this.OnHriListInd = null;
  }
}

/** Class representing a RiskContractScore. */
// eslint-disable-next-line no-unused-vars
class RiskContractScore extends Entity {
  constructor() {
    super();
    this.RiskContractScoreKey = null;
    this.ContractNbr = null;
    /**
     * @type {Spanner.Float}
     */
    this.ContractScore = null;
    this.ContractScoreRatingCd = null;
    /**
     * @type {Spanner.Float}
     */
    this.ContractScoreNoCM = null;
    this.ContractScoreNoCMRatingCd = null;
  }
}

/** Class representing a RiskDetails. */
// eslint-disable-next-line no-unused-vars
class RiskDetails extends Entity {
  constructor() {
    super();
    this.RiskDetailsKey = null;
    this.CIPCategoryNm = null;
    this.CIPId = null;
    this.CIPOpportunityId = null;
    this.CIPRatingNm = null;
    this.CIPReasonforChangeTxt = null;
    this.CIPRiskId = null;
    this.CIPRiskStatementNm = null;
    this.CIPRiskTitleNm = null;
    this.CIPRiskURI = null;
    this.CIPSubCategoryNm = null;
    this.CIPType = null;
    this.ContractNbr = null;
    this.ContractNm = null;
    this.CustomerNbr = null;
    this.CustomerNm = null;
    this.MasterClientNbr = null;
    this.MasterClientNm = null;
    this.MMCLinkToRiskDetails = null;
    this.RiskAssessmentQuestionKey = null;
    this.RiskDesc = null;
    this.RiskLeadReviewDttm = null;
    this.RiskLeadReviewStatusCd = null;
    this.RiskNbr = null;
    this.RiskQMDReviewDttm = null;
    this.RiskQMDReviewInd = null;
    this.RiskRatingCd = null;
    this.RiskScore = null;
    this.RiskScoreNoCM = null;
    this.RiskSourceCd = null;
    this.RiskStatusCd = null;
    this.RiskTypeCd = null;
    this.StatementArr = null;
    this.NBAInd = null;
  }
}

/** Class representing a RiskHistory. */
// eslint-disable-next-line no-unused-vars
class RiskHistory extends Entity {
  constructor() {
    super();
    this.RiskDetailsKey = null;
    this.RiskHistoryKey = null;
    this.ContentTxt = null;
    this.EnterpriseId = null;
    this.HistoryNm = null;
  }
}

/** Class representing a RiskLeadReview. */
// eslint-disable-next-line no-unused-vars
class RiskLeadReview extends Entity {
  constructor() {
    super();
    this.RiskDetailsKey = null;
    this.RiskLeadReviewKey = null;
    this.DesignatedReviewerUserIdArr = null;
    this.LeadReviewDttm = null;
    this.LeadReviewStatusCd = null;
    this.RecordedUserId = null;
  }
}

/** Class representing a RiskMitigation. */
// eslint-disable-next-line no-unused-vars
class RiskMitigation extends Entity {
  constructor() {
    super();
    this.RiskDetailsKey = null;
    this.RiskMitigationKey = null;
    this.AssigneeUserId = null;
    this.DueDttm = null;
    this.MitigationDesc = null;
    this.MitigationStatusCd = null;
    this.MitigationSourceCd = null;
    this.RiskNextBestActionKey = null;
    this.MitigationTitle = null;
    this.MitigationTypeCd = null;
    this.MitigationNbr = null;
    this.CIPMitigationUpdated = null;
  }
}

/** Class representing a RiskMitigationModel. */
// eslint-disable-next-line no-unused-vars
class RiskMitigationModel extends RiskMitigation {
  constructor() {
    super();
    // use to flag if a mitigation is modified from client only, will not be persisted
    this.MitigationUpdated = null;
    // use to flag if a mitigation is deleted from client only, will not be persisted
    this.IsDelete = null;
    // use to flag if a mitigation is new added, will not be persisted
    this.IsNew = null;
    // use to flag if a mitigation is updated, will not be persisted
    this.IsUpdate = null;
  }
}

/** Class representing a RiskQMDCallModel. */
// eslint-disable-next-line no-unused-vars
class RiskQMDCallModel {
  constructor() {
    this.RiskQMDReviewDttm = null;
    this.RiskQMDReviewInd = null;
  }
}

/** Class representing a RiskDetailsModel. */
// eslint-disable-next-line no-unused-vars
class RiskDetailsModel extends RiskDetails {
  constructor() {
    super();
    /**
     * @type {Array<RiskLeadReview>}
     */
    this.LeadReviews = [];
    /**
     * @type {Array<RiskMitigationModel>}
     */
    this.Mitigations = [];
    /**
     * @type {RiskConsultationCallModel|{}}
     */
    this.ConsultationCall = {};
    /**
     * @type {RiskQMDCallModel|{}}
     */
    this.QMDCall = {};
    // create history, use to flag if save ready for review from client, will not be persisted
    this.ReadyForReview = false;
    // create history, use to flag if lead review completed from client, will not be persisted
    this.LeadReviewCompleted = false;
    // create history, use to flag if consultation call has been flagged from client, will not be persisted
    this.ConsultationCallFlagged = false;
    // create history, use to flag if consultation call is completed from client, will not be persisted
    this.ConsultationCallCompleted = false;
    // create history, use to flag if a risk converted to an issue from client, will not be persisted
    this.CMRiskToIssue = false;
    // create history, use to flag if an issue converted to a risk from client, will not be persisted
    this.CMIssueToRisk = false;
    // send CIP comment, use to flag if a/an CIP Risk rating is changed from client, will not be persisted
    this.CIPRiskRatingUpdated = false;
    // CM rating changed, use to flag if a/an CM Risk/Issue rating is changed from client, will not be persisted
    this.CMRiskRatingUpdated = false;
    // create history, use to log the history date from client
    this.HistoryDttm = null;
    this.NBAInd = null;
  }
}

/** Class representing a RiskConsultationCallModel. */
// eslint-disable-next-line no-unused-vars
class RiskConsultationCallModel extends RiskConsultationCall {
  constructor() {
    super();
    /**
     * @type {Array<RiskConsCallFinRevenueCCI>}
     */
    this.ConsCallFinRevenueCCI = [];
    /**
     * @type {Array<RiskConsCallInvolvedParty>}
     */
    this.ConsCallInvolvedParty = [];
  }
}

/** Class representing a RiskRequestContext. */
// eslint-disable-next-line no-unused-vars
class RiskRequestContext {
  constructor() {
    /**
     * @type {RiskDetailsModel|{}}
     */
    this.RiskDetailsModel = {};
    /**
     * @type {RiskDetails|{}}
     */
    this.RiskDetails = {};
    /**
     * @type {Array<>RiskDetails>}
     */
    this.ScoreUpdatedRiskDetails = [];
    /**
     * @type {Array<RiskMitigation>}
     */
    this.NewRiskMitigations = [];
    /**
     * @type {Array<RiskMitigation>}
     */
    this.UpdateRiskMitigations = [];
    /**
     * @type {Array<RiskMitigation>}
     */
    this.DeleteRiskMitigations = [];
    /**
     * @type {Array<RiskMitigation>}
     */
    this.NoChangeRiskMitigations = [];
    /**
     * @type {Array<RiskLeadReview>}
     */
    this.NewRiskLeadReviews = [];
    /**
     * @type {Array<RiskLeadReview>}
     */
    this.UpdateRiskLeadReviews = [];
    /**
     * @type {Array<RiskLeadReview>}
     */
    this.DeleteRiskLeadReviews = [];
    /**
     * @type {Array<RiskLeadReview>}
     */
    this.NoChangeRiskLeadReviews = [];
    /**
     * @type {RiskConsultationCall|{}}
     */
    this.RiskConsultationCall = {};
    /**
     * @type {RiskConsultationCall|{}}
     */
    this.DeleteRiskConsultationCall = {};
    /**
     * @type {Array<RiskConsCallInvolvedParty>}
     */
    this.RiskConsCallInvolvedParties = [];
    this.DeleteRiskConsCallInvolvedParties = [];
    /**
     * @type {Array<RiskConsCallFinRevenueCCI>}
     */
    this.RiskConsCallFinRevenueCCIs = [];
    this.DeleteRiskConsCallFinRevenueCCIs = [];
    /**
     * @type {RiskContractScore|{}}
     */
    this.RiskContractScore = {};
    /**
     * @type {Array<RiskHistory>}
     */
    this.RiskHistories = [];
    this.CIPNewMitigationEvents = [];
    this.CIPUpdateMitigationEvents = [];
    this.CIPUpdateRiskRatingEvents = [];
    /**
     * @type {Spanner.Transaction}
     */
    this.transaction = null;
    /**
     * @type {Spanner.Database}
     */
    this.database = null;
    /**
     * @type {Date}
     */
    this.updateAt = null;
    this.enterpriseId = null;
  }
}

/** Class representing a RiskIDModel. */
// eslint-disable-next-line no-unused-vars
class RiskIDModel {
  constructor() {
    this.RiskID = null;
  }
}

/** Class representing a RiskIDRequestContext. */
// eslint-disable-next-line no-unused-vars
class RiskIDRequestContext {
  constructor() {
    /**
     * @type {Array<RiskIDModel>}
     */
    this.RiskID = [];
    /**
     * @type {Spanner.Transaction}
     */
    this.transaction = null;
  }
}

/** Class representing a RiskFeedbackModel. */
// eslint-disable-next-line no-unused-vars
class RiskFeedbackModel extends Entity {
  constructor() {
    super();
    this.RiskFeedbackKey = null;
    this.RiskDetailsKey = null;
    this.RiskNextBestActionKey = null;
    this.RatingLevelCd = null;
    this.RatingQuestionCdArr = null;
    this.RatingDesc = null;
  }
}

/** Class representing a RiskFeedbackRequestContext. */
// eslint-disable-next-line no-unused-vars
class RiskFeedbackRequestContext {
  constructor() {
    /**
     * @type {Array<RiskFeedbackModel>}
     */
    this.riskFeedbackList = [];
    /**
     * @type {Spanner.Transaction}
     */
    this.transaction = null;
    this.enterpriseId = null;
    this.updateAt = null;
  }
}

/** Class representing a RiskNBARecordModel. */
// eslint-disable-next-line no-unused-vars
class RiskNBARecordModel extends Entity {
  constructor() {
    super();
    this.RiskNBARecordKey = null;
    this.RiskDetailsKey = null;
    this.RiskNextBestActionKey = null;
    this.RatingLevelCd = null;
    this.RatingQuestionCdArr = null;
    this.RatingDesc = null;
    this.ModifiedNBADesc = null;
    this.ModifiedNBATitle = null;
    this.OriginalNBADesc = null;
    this.OriginalNBATitle = null;
  }
}

module.exports = {
  RiskAssessmentQuestion,
  RiskDetailsModel,
  RiskConsultationCall,
  RiskMitigation,
  RiskMitigationModel,
  RiskContractScore,
  RiskConsCallFinRevenueCCI,
  RiskConsCallInvolvedParty,
  RiskConsultationCallModel,
  RiskDetails,
  RiskHistory,
  RiskLeadReview,
  RiskQMDCallModel,
  RiskRequestContext,
  RiskIDModel,
  RiskIDRequestContext,
  RiskFeedbackModel,
  RiskFeedbackRequestContext,
  RiskNBARecordModel
};
