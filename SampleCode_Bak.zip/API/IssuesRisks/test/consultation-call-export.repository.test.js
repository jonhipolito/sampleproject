process.env.NODE_ENV = 'test';
require('dotenv').config();
const chai = require('chai');
const expect = chai.expect;
const sinon = require('sinon');
const random = require('string-random');
const uuid = require('uuidv4');

const ConsultationCallExportRepository = require('../server/consultation-call-export.repository');

describe('Testing getAllConsultationCalls', () => {
  beforeEach(function(done) {
    done();
  });

  afterEach(function(done) {
    done();
  });

  it('will call getAllConsultationCalls', async function() {
    this.timeout(0);
    const result = ConsultationCallExportRepository.getAllConsultationCalls('2019-08-27', '2019-08-28');
    expect(result).to.not.be.null;
  });

  it('will call getAllCodeDetail', async function() {
    this.timeout(0);
    const result = ConsultationCallExportRepository.getAllCodeDetail();
    expect(result).to.not.be.null;
  });

  it('will call getAllRiskConsCallFinRevenueCCI', async function() {
    this.timeout(0);
    const result = ConsultationCallExportRepository.getAllRiskConsCallFinRevenueCCI('2019-08-27', '2019-08-28');
    expect(result).to.not.be.null;
  });

  it('will call getAllLeadReview', async function() {
    this.timeout(0);
    const result = ConsultationCallExportRepository.getAllLeadReview('2019-08-27', '2019-08-28');
    expect(result).to.not.be.null;
  });

  it('will call getAllMitigation', async function() {
    this.timeout(0);
    const result = ConsultationCallExportRepository.getAllMitigation('2019-08-27', '2019-08-28');
    expect(result).to.not.be.null;
  });

  it('will call getAllInvolvedParty', async function() {
    this.timeout(0);
    const result = ConsultationCallExportRepository.getAllInvolvedParty('2019-08-27', '2019-08-28');
    expect(result).to.not.be.null;
  });

  it('will call isGlobalCM', async function() {
    this.timeout(0);
    const result = ConsultationCallExportRepository.isGlobalCM('T27354.ORION.017');
    expect(result).to.not.be.null;
  });

  it('will call getDownloadItemByEid', async function() {
    this.timeout(0);
    const result = ConsultationCallExportRepository.getDownloadItemByEid('T27354.ORION.017', 'Risks & Issues sent to CC');
    expect(result).to.not.be.null;
  });

  it('will call getDownloadItemByKey', async function() {
    this.timeout(0);
    const result = ConsultationCallExportRepository.getDownloadItemByKey('02000e8f-d08e-426f-ac50-ab2a3ab64748');
    expect(result).to.not.be.null;
  });

  it('will call insertDownloadItem', async function() {
    this.timeout(0);
    const result = ConsultationCallExportRepository.insertDownloadItem({
      DownloadKey: uuid(),
      Category: 'Category',
      FileName: 'FileName',
      FileSize: '1',
      FileUrl: 'FileUrl',
      Status: 'Status',
      CreateUserId: null,
      CreateDttm: null,
      UpdateUserId: null,
      UpdateDttm: null
    });
    expect(result).to.not.be.null;
  });

  it('will call updateDownloadItem', async function() {
    this.timeout(0);
    const result = ConsultationCallExportRepository.updateDownloadItem({
      DownloadKey: '02000e8f-d08e-426f-ac50-ab2a3ab64748',
      Category: 'Category',
      FileName: 'FileName',
      FileSize: '1',
      FileUrl: 'FileUrl',
      Status: 'Status',
      CreateUserId: null,
      CreateDttm: null,
      UpdateUserId: null,
      UpdateDttm: null
    });
    expect(result).to.not.be.null;
  });

  it('will call updateDownloadStatus', async function() {
    this.timeout(0);
    const result = ConsultationCallExportRepository.updateDownloadStatus('02000e8f-d08e-426f-ac50-ab2a3ab64748', 'TEST');
    expect(result).to.not.be.null;
  });

  it('will call getExampleData', async function() {
    this.timeout(0);
    const result = ConsultationCallExportRepository.getExampleData();
    expect(result).to.not.be.null;
  });
});
