process.env.NODE_ENV = 'test';
require('dotenv').config();
const chai = require('chai');
const expect = chai.expect;
const sinon = require('sinon');
const sinonChai = require('sinon-chai');
chai.use(sinonChai);
const random = require('string-random');
const {describe, beforeEach, afterEach, after, it} = require('mocha');

const IssuesRisksRepository = require('../server/issues-risks.repository');
const {RiskDetailsModel} = require('../server/models/issues-risks.model');

function getRandomNbr() {
  return (Math.random() * 1000000).toFixed(0);
}

describe('Testing IssuesRisksRepository', () => {
  let UTPrefix = 'UT';
  let ContractNbr = 'UT';
  let CustomerNbr = 'UT';
  let MasterClientNbr = '1800002';

  const RiskStatusDraft = '100702';
  const RiskStatusPendingReview = '100703';
  const RiskSourceCM = '101201';
  const RiskSourceCIP = '101202';
  const RiskLeadReviewStatusPendingReview = '101301';
  const RiskLeadReviewStatusReviewed = '101302';
  const RiskMitigationStatusInProgress = '101401';
  const RiskNextBestActionKey = '00b86b0b-9603-457d-b3a6-b8d808fa9e3a';
  const RiskAssessmentQuestionKey = '80380623-47cd-484f-8273-3d466659f425';
  const MitigationNBATypeCd = '102801';
  const MitigationNbr = '1234567890';
  const RiskConsultationCallStatusNotRequested = '100902';
  const RiskConsultationCallStatusPending = '100901';
  // eslint-disable-next-line no-unused-vars
  // const RiskConsultationCallStatusReviewed = '100903';
  const RiskRatingHigh = '100801';
  const RiskRatingAboveNormal = '100802';
  const RiskRatingNormal = '100803';
  // eslint-disable-next-line no-unused-vars
  // const RiskContractScoreRatingHigh = '101901';
  const RiskContractScoreRatingAboveNormal = '101902';
  const RiskContractScoreRatingNormal = '101903';
  // eslint-disable-next-line no-unused-vars
  // const RiskContractScoreRatingNA = '101904';
  const RiskConsultationCallStatusNotRequest = '100902';
  const RiskQuestionCE01 = 'd8e7feee-8e41-44b5-804a-453c576b9d99';
  const RiskQuestionCE03 = '8565935b-97c8-4278-beb7-1255e9da2c9b';
  // eslint-disable-next-line no-unused-vars
  // const RiskQuestionCE07 = '3365d391-c584-43e6-9b56-c58d83bca1a6';
  // eslint-disable-next-line no-unused-vars
  // const RiskQuestionCE08 = 'e4c9619c-bc13-4210-9eb8-a0d5dd4e4e06';
  const RiskQuestionAL01 = '5de1d297-db20-4793-9f44-d5e9d6a2c727';
  // eslint-disable-next-line no-unused-vars
  // const RiskQuestionCD01 = '80380623-47cd-484f-8273-3d466659f425';
  const RiskQuestionCM02 = 'fb336c2b-c840-41b5-beb8-889323c36f9e';
  const RiskQuestionCD03 = 'fadf5544-a1f3-413c-9e1e-b75a07ec6090'; // N

  const model = {
    CIPOpportunityId: null,
    CIPReasonforChangeTxt: null,
    CIPRiskId: null,
    CIPId: null,
    CIPType: null,
    CIPRiskTitleNm: null,
    CIPRatingNm: null,
    CIPRiskURI: null,
    CIPCategoryNm: null,
    CIPSubCategoryNm: null,
    ContractNbr,
    ContractNm: ContractNbr,
    CustomerNbr,
    CustomerNm: CustomerNbr,
    RiskTypeCd: '100602',
    MasterClientNbr,
    MasterClientNm: MasterClientNbr,
    RiskAssessmentQuestionKey: RiskQuestionCE01,
    RiskDesc: 'ut-test',
    RiskRatingCd: RiskRatingAboveNormal,
    RiskSourceCd: RiskSourceCM,
    StatementArr: ['100211'],
    RiskStatusCd: RiskStatusDraft,
    RiskLeadReviewDttm: null,
    RiskLeadReviewStatusCd: null,
    CIPRiskStatementNm: null,
    Mitigations: [
      {
        AssigneeUserId: 'ut-test',
        DueDttm: '2019-06-30T00:00:00.000Z',
        MitigationDesc: 'ut-test',
        MitigationStatusCd: RiskMitigationStatusInProgress,
        MitigationSourceCd: RiskSourceCM,
        RiskNextBestActionKey: RiskNextBestActionKey,
        MitigationTitle: 'ut-test-title',
        MitigationTypeCd: MitigationNBATypeCd,
        MitigationNbr: MitigationNbr,
        OriginalNBATitle: 'OriginalNBATitle',
        OriginalNBADesc: 'OriginalNBADesc'
      }
    ],
    LeadReviews: [
      {
        LeadReviewStatusCd: RiskLeadReviewStatusPendingReview,
        RecordedUserId: 'ut-test',
        DesignatedReviewerUserId: null,
        LeadReviewDttm: null,
        DesignatedReviewerUserIdArr: ['ut-test']
      }
    ],
    ConsultationCall: {
      ConsultationCallStatusCd: RiskConsultationCallStatusPending,
      CMActionsDesc: null,
      ExposureContractDesc: null,
      ExposureFinancialDesc: null,
      FinancialsBillingTermsNm: null,
      FinancialsBillMechanismCd: null,
      FinancialsCurrentFYRevenueNbr: null,
      FinancialsFYRevenueNbr: null,
      FinancialsTotalContractNbr: null,
      ResolutionTimeFrameDesc: null,
      ReviewerCompletedDt: null,
      ReviewerFollowupDt: null,
      ReviewerNoteDesc: null,
      ReviewerShareInd: null,
      CCSlotRequestUserId: null,
      DateRequested: null,
      BookaPreferredSlot: null,
      CMUsersArr: null,
      RequestConfidentialInd: null,
      OnHriListInd: null,
      CMOgLead: null,
      CMGeoLead: null,
      ConsCallFinRevenueCCI: [{TypeCd: '101701', EACNbr: 100, ODENbr: 100, VarianceNbr: 100}],
      ConsCallInvolvedParty: [{PartyArr: ['101005'], PartyCategoryCd: '101001'}]
    },
    QMDCall: {
      RiskQMDReviewDttm: null,
      RiskQMDReviewInd: 'N'
    }
  };

  describe('Testing addRisk', () => {
    beforeEach(function(done) {
      const Nbr = getRandomNbr();
      ContractNbr = `${UTPrefix}${Nbr}`;
      CustomerNbr = `${UTPrefix}${Nbr}`;
      done();
    });

    afterEach(function(done) {
      done();
    });
    it('addRiskID should return if successfully', async function() {
      this.timeout(0);
      const date = new Date();
      const basicNumber =
        date
          .getFullYear()
          .toString()
          .substring(3, 4) +
        (date.getMonth() + 1).toString() +
        date.getDate().toString();
      const repository = new IssuesRisksRepository();
      const result = await repository.addRiskID([{RiskID: random(10 - basicNumber.length, {letters: false}) + basicNumber}]);
      expect(result).to.be.eq(true);
    });

    it('addFeedback should return riskFeedbackList', async function() {
      this.timeout(0);
      const repository = new IssuesRisksRepository();
      const result = await repository.addFeedback([
        {
          RiskDetailsKey: null,
          RiskNextBestActionKey: RiskNextBestActionKey,
          RatingLevelCd: '102905',
          RatingQuestionCdArr: ['103022'],
          RatingDesc: null
        }
      ]);
      expect(result).to.not.be.null;
    });

    it('addRisk should return RiskDetailsKey', async function() {
      this.timeout(0);
      const repository = new IssuesRisksRepository();
      const {RiskDetailsKey: key} = await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr,
          CMRiskRatingUpdated: true
        })
      );
      expect(key).to.not.be.null;
    });

    it(`addRisk should save ConsultationCall if RiskConsultationCallStatusCd is presented 'Pending'`, async function() {
      this.timeout(0);
      const repository = new IssuesRisksRepository();
      const cc = Object.assign({}, model.ConsultationCall, {
        CMActionsDesc: 'UT',
        ExposureContractDesc: 'UT',
        ExposureFinancialDesc: 'UT',
        FinancialsBillingTermsNm: 'UT',
        FinancialsCurrentFYRevenueNbr: 1,
        FinancialsFYRevenueNbr: 1,
        FinancialsTotalContractNbr: 1,
        ResolutionTimeFrameDesc: 'UT'
      });

      const {RiskDetailsKey: key} = await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr,
          CMRiskRatingUpdated: true,
          ConsultationCall: cc
        })
      );
      const result = await repository.get(key);
      expect(result.ConsultationCall).not.to.be.deep.eq({});
      expect(result.ConsultationCall.CMActionsDesc).to.be.eq('UT');
      expect(result.ConsultationCall.FinancialsTotalContractNbr).to.be.eq(1);
    });

    it(`addRisk should save QMDCall if RiskQMDReviewInd is presented 'Y'`, async function() {
      this.timeout(0);
      const reviewAt = new Date().toISOString();
      const repository = new IssuesRisksRepository();
      const {RiskDetailsKey: key} = await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr,
          CMRiskRatingUpdated: true,
          QMDCall: {
            RiskQMDReviewInd: 'Y',
            RiskQMDReviewDttm: reviewAt
          }
        })
      );
      const result = await repository.get(key);
      expect(result.QMDCall.RiskQMDReviewDttm.valueOf()).to.be.eq(new Date(reviewAt).valueOf());
      expect(result.QMDCall.RiskQMDReviewInd).to.be.eq('Y');
    });
  });

  describe('Testing get', () => {
    const repository = new IssuesRisksRepository();
    const getDetailsStub = sinon.stub(repository, 'getDetails');
    beforeEach(function(done) {
      const Nbr = getRandomNbr();
      ContractNbr = `${UTPrefix}${Nbr}`;
      CustomerNbr = `${UTPrefix}${Nbr}`;
      done();
    });

    after(function(done) {
      getDetailsStub.restore();
      done();
    });

    it(`get should return RiskDetails which should include QMDCall and ConsultationCall and LeadReviews and Mitigations`, async function() {
      this.timeout(0);
      const repository = new IssuesRisksRepository();
      const {RiskDetailsKey: key} = await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr
        })
      );
      const result = await repository.get(key);
      expect(result.RiskDetailsKey).to.be.eq(key);
      expect(result.QMDCall).not.to.be.null;
      expect(result.ConsultationCall).not.to.be.null;
      expect(result.LeadReviews).not.to.be.null;
      expect(result.Mitigations).not.to.be.null;
    });

    it(`get should return Mitigations which should include MitigationSourceCd`, async function() {
      this.timeout(0);
      const repository = new IssuesRisksRepository();
      const {RiskDetailsKey: key} = await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr,
          Mitigations: [
            {
              AssigneeUserId: 'ut-test',
              DueDttm: '2019-06-30T00:00:00.000Z',
              MitigationDesc: 'ut-test',
              MitigationStatusCd: RiskMitigationStatusInProgress,
              MitigationSourceCd: RiskSourceCM
            }
          ]
        })
      );
      const result = await repository.get(key);
      expect(result.Mitigations[0].MitigationSourceCd).to.be.eq(RiskSourceCM);
    });

    it(`get should return NBA`, async function() {
      this.timeout(0);
      const repository = new IssuesRisksRepository();
      const result = await repository.getNba(RiskAssessmentQuestionKey);
      expect(result[0].RiskNextBestActionKey).to.be.eq(RiskNextBestActionKey);
    });

    it(`get should return empty object if riskDetailsKey not exists`, async function() {
      this.timeout(0);
      getDetailsStub.resolves(null);
      const result = await repository.get('not exists');
      expect(result).to.be.deep.eq({});
    });
  });

  describe('Testing updateRisk', () => {
    beforeEach(function(done) {
      const Nbr = getRandomNbr();
      ContractNbr = `${UTPrefix}${Nbr}`;
      CustomerNbr = `${UTPrefix}${Nbr}`;
      done();
    });

    afterEach(function(done) {
      done();
    });

    it('updateRisk should not update RiskDetailsKey', async function() {
      this.timeout(0);
      const repository = new IssuesRisksRepository();
      const {RiskDetailsKey: key} = await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr,
          QMDCall: {RiskQMDReviewDttm: new Date(), RiskQMDReviewInd: false},
          CIPRiskRatingUpdated: true
        })
      );
      const riskDetails = await repository.get(key);
      const {RiskDetailsKey: actual} = await repository.updateRisk(
        Object.assign({}, riskDetails, {
          RiskDesc: 'ut-test-updated'
        })
      );
      const result = await repository.get(actual);
      expect(actual).to.be.eq(key);
      expect(result.RiskDesc).to.be.eq('ut-test-updated');
    });

    it(`updateRisk should remove ConsultationCall if ConsultationCallStatusCd is presented NotRequest`, async function() {
      this.timeout(0);
      const repository = new IssuesRisksRepository();
      const {RiskDetailsKey: key} = await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr
        })
      );
      const riskDetails = await repository.get(key);
      riskDetails.ConsultationCall.ConsultationCallStatusCd = RiskConsultationCallStatusNotRequest;
      await repository.updateRisk(riskDetails);
      const actual = await repository.get(key);
      expect(actual.ConsultationCall).to.be.deep.eq({});
    });

    it(`updateRisk should add ConsultationCall if ConsultationCallStatusCd is presented Pending`, async function() {
      this.timeout(0);
      const repository = new IssuesRisksRepository();
      const {RiskDetailsKey: key} = await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr,
          ConsultationCall: {}
        })
      );
      let riskDetails = await repository.get(key);
      await repository.updateRisk(
        Object.assign({}, riskDetails, {
          RiskDesc: 'ut-test-updated',
          ConsultationCall: {
            ConsultationCallStatusCd: RiskConsultationCallStatusPending,
            CMActionsDesc: null,
            ExposureContractDesc: null,
            ExposureFinancialDesc: null,
            FinancialsBillingTermsNm: null,
            FinancialsBillMechanismCd: null,
            FinancialsCurrentFYRevenueNbr: null,
            FinancialsFYRevenueNbr: null,
            FinancialsTotalContractNbr: null,
            ResolutionTimeFrameDesc: null,
            ReviewerCompletedDt: null,
            ReviewerFollowupDt: null,
            ReviewerNoteDesc: null,
            ReviewerShareInd: null,
            CCSlotRequestUserId: null,
            DateRequested: null,
            BookaPreferredSlot: null,
            CMUsersArr: null,
            RequestConfidentialInd: null,
            OnHriListInd: null,
            CMOgLead: null,
            CMGeoLead: null,
            ConsCallFinRevenueCCI: [{TypeCd: '101701', EACNbr: 100, ODENbr: 100, VarianceNbr: 100}],
            ConsCallInvolvedParty: [{PartyArr: ['101005'], PartyCategoryCd: '101001'}]
          }
        })
      );
      const actual = await repository.get(key);
      expect(actual.ConsultationCall.ConsultationCallStatusCd).to.be.eq(RiskConsultationCallStatusPending);
    });

    it(`updateRisk should save QMDCall if RiskQMDReviewInd is presented 'Y'`, async function() {
      this.timeout(0);
      const reviewAt = new Date().toISOString();
      const repository = new IssuesRisksRepository();
      const {RiskDetailsKey: key} = await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr
        })
      );
      const riskDetails = await repository.get(key);
      riskDetails.QMDCall.RiskQMDReviewDttm = reviewAt;
      riskDetails.QMDCall.RiskQMDReviewInd = 'Y';
      await repository.updateRisk(riskDetails);
      const result = await repository.get(key);
      expect(result.QMDCall.RiskQMDReviewDttm.valueOf()).to.be.eq(new Date(reviewAt).valueOf());
      expect(result.QMDCall.RiskQMDReviewInd).to.be.eq('Y');
    });

    it(`updateRisk should add new Mitigations if RiskMitigationKey is null`, async function() {
      this.timeout(0);
      const repository = new IssuesRisksRepository();
      const {RiskDetailsKey: key} = await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr
        })
      );
      const riskDetails = await repository.get(key);
      riskDetails.Mitigations = riskDetails.Mitigations.map(o => {
        o.MitigationUpdated = true;
        return o;
      });
      riskDetails.Mitigations.push({
        AssigneeUserId: 'ut-test',
        DueDttm: '2019-06-30T00:00:00.000Z',
        MitigationDesc: 'ut-test',
        MitigationStatusCd: RiskMitigationStatusInProgress,
        MitigationSourceCd: RiskSourceCM,
        RiskNextBestActionKey: RiskNextBestActionKey,
        MitigationTitle: 'ut-test-title',
        MitigationTypeCd: MitigationNBATypeCd,
        MitigationNbr: MitigationNbr,
        OriginalNBATitle: 'OriginalNBATitle',
        OriginalNBADesc: 'OriginalNBADesc'
      });
      await repository.updateRisk(riskDetails);
      const result = await repository.get(key);
      expect(result.Mitigations.length).to.be.eq(2);
    });

    it(`updateRisk should delete Mitigations if IsDelete is presented true`, async function() {
      this.timeout(0);
      const repository = new IssuesRisksRepository();
      const {RiskDetailsKey: key} = await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr
        })
      );
      const riskDetails = await repository.get(key);
      riskDetails.Mitigations = riskDetails.Mitigations.map(o => {
        o.IsDelete = true;
        return o;
      });
      await repository.updateRisk(riskDetails);
      const result = await repository.get(key);
      expect(result.Mitigations.length).to.be.eq(0);
    });

    it(`updateRisk should delete LeadReviews if IsDelete is presented true`, async function() {
      this.timeout(0);
      const repository = new IssuesRisksRepository();
      const {RiskDetailsKey: key} = await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr
        })
      );
      const riskDetails = await repository.get(key);
      riskDetails.LeadReviews = [
        {
          LeadReviewStatusCd: RiskLeadReviewStatusPendingReview,
          RecordedUserId: 'ut-test',
          DesignatedReviewerUserId: null,
          LeadReviewDttm: null,
          DesignatedReviewerUserIdArr: ['ut-test']
        },
        ...riskDetails.LeadReviews.map(o => {
          o.IsDelete = true;
          return o;
        })
      ];
      await repository.updateRisk(riskDetails);
      const result = await repository.get(key);
      expect(result.LeadReviews.length).to.be.eq(1);
    });
  });

  describe('Testing getCodesByCategory', () => {
    beforeEach(function(done) {
      done();
    });

    afterEach(function(done) {
      done();
    });

    it('getCodesByCategory', async function() {
      this.timeout(0);
      const categoryDesc = 'RiskType';
      const expected = [
        {
          CodeDetailId: 100601,
          CodeTxt: '100601',
          PrimaryDecodeTxt: 'Risk',
          SecondaryDecodeTxt: '',
          ParentId: 0
        },
        {
          CodeDetailId: 100602,
          CodeTxt: '100602',
          PrimaryDecodeTxt: 'Issue',
          SecondaryDecodeTxt: '',
          ParentId: 0
        }
      ];
      const repository = new IssuesRisksRepository();
      const result = await repository.getCodesByCategory(categoryDesc);
      expect(result).to.be.deep.eq(expected);
    });
  });

  describe('Testing getCodesByParentCategory', () => {
    beforeEach(function(done) {
      done();
    });

    afterEach(function(done) {
      done();
    });

    it('getCodesByParentCategory', async function() {
      this.timeout(0);
      const parentCategory = 'RiskConsultationCallInvolvedParty';
      const repository = new IssuesRisksRepository();
      const result = await repository.getCodesByParentCategory(parentCategory);
      expect(result.length).to.be.eq(19);
    });
  });

  describe('Testing getCodesByCategories', () => {
    beforeEach(function(done) {
      done();
    });

    afterEach(function(done) {
      done();
    });

    it('getCodesByCategories', async function() {
      this.timeout(0);
      const categoryArray = ['RiskStatus', 'RiskRating'];
      const expected = [
        {
          CodeDetailId: 100701,
          CodeTxt: '100701',
          PrimaryDecodeTxt: 'Unrated',
          SecondaryDecodeTxt: '',
          ParentId: 0
        },
        {
          CodeDetailId: 100702,
          CodeTxt: '100702',
          PrimaryDecodeTxt: 'Draft',
          SecondaryDecodeTxt: '',
          ParentId: 0
        },
        {
          CodeDetailId: 100703,
          CodeTxt: '100703',
          PrimaryDecodeTxt: 'Pending Review',
          SecondaryDecodeTxt: '',
          ParentId: 0
        },
        {
          CodeDetailId: 100704,
          CodeTxt: '100704',
          PrimaryDecodeTxt: 'Reviewed',
          SecondaryDecodeTxt: '',
          ParentId: 0
        },
        {
          CodeDetailId: 100705,
          CodeTxt: '100705',
          PrimaryDecodeTxt: 'CIP Final',
          SecondaryDecodeTxt: '',
          ParentId: 0
        },
        {
          CodeDetailId: 100801,
          CodeTxt: '100801',
          PrimaryDecodeTxt: 'High',
          SecondaryDecodeTxt: '1',
          ParentId: 0
        },
        {
          CodeDetailId: 100802,
          CodeTxt: '100802',
          PrimaryDecodeTxt: 'Above Normal',
          SecondaryDecodeTxt: '2',
          ParentId: 0
        },
        {
          CodeDetailId: 100803,
          CodeTxt: '100803',
          PrimaryDecodeTxt: 'Normal',
          SecondaryDecodeTxt: '3',
          ParentId: 0
        }
      ];
      const repository = new IssuesRisksRepository();
      const result = await repository.getCodesByCategories(categoryArray);
      expect(result).to.be.deep.eq(expected);
    });
  });

  describe('Testing getQuestion', () => {
    beforeEach(function(done) {
      done();
    });

    afterEach(function(done) {
      done();
    });

    it('getQuestion', async function() {
      this.timeout(0);
      const riskAssessmentQuestionKey = '3365d391-c584-43e6-9b56-c58d83bca1a6';
      const expected = {
        RiskAssessmentQuestionKey: '3365d391-c584-43e6-9b56-c58d83bca1a6',
        CategoryCd: '100301',
        SubCategoryCd: '100403',
        StatementArr: ['100203'],
        RiskQuestionCd: '100103',
        WeightNbr: 3,
        QuestionQARefArr: ['102001', '102002']
      };
      const repository = new IssuesRisksRepository();
      const result = await repository.getQuestion(riskAssessmentQuestionKey);
      expect(result).to.be.deep.eq(expected);
    });
  });

  describe('Testing getQuestions', () => {
    beforeEach(function(done) {
      done();
    });

    afterEach(function(done) {
      done();
    });

    it('getQuestions', async function() {
      this.timeout(0);
      const contractNbr = '2000006';
      const repository = new IssuesRisksRepository();
      const result = await repository.getQuestions(contractNbr);
      expect(result.length).to.be.eq(29);
    });
  });

  describe('Testing getCode', () => {
    beforeEach(function(done) {
      done();
    });

    afterEach(function(done) {
      done();
    });

    it('getCode', async function() {
      this.timeout(0);
      const codeTxt = '100101';
      const expected = {
        CodeDetailId: 100101,
        CodeTxt: '100101',
        PrimaryDecodeTxt: 'CE.01',
        SecondaryDecodeTxt: `What is the risk of the work resulting in public controversy, such as negative media coverage? (All Service Groups)`,
        ParentId: 0
      };
      const repository = new IssuesRisksRepository();
      const result = await repository.getCode(codeTxt);
      expect(result).to.be.deep.eq(expected);
    });
  });

  describe('Testing getCodes', () => {
    it('getCodes', async function() {
      this.timeout(0);
      const codeTxtArray = ['100101', '100102'];
      const expected = [
        {
          CodeDetailId: 100101,
          CodeTxt: '100101',
          PrimaryDecodeTxt: 'CE.01',
          SecondaryDecodeTxt: `What is the risk of the work resulting in public controversy, such as negative media coverage? (All Service Groups)`,
          ParentId: 0
        },
        {
          CodeDetailId: 100102,
          CodeTxt: '100102',
          PrimaryDecodeTxt: 'CE.03',
          SecondaryDecodeTxt: `How is our experience and relationship with the overall client and our relationship with the executive sponsor? Does the relationship impact our ability to deliver to our contractual commitments?`,
          ParentId: 0
        }
      ];
      const repository = new IssuesRisksRepository();
      const result = await repository.getCodes(codeTxtArray);
      expect(result).to.be.deep.eq(expected);
    });
  });

  describe('Testing getHistory', () => {
    beforeEach(function(done) {
      const Nbr = getRandomNbr();
      ContractNbr = `${UTPrefix}${Nbr}`;
      CustomerNbr = `${UTPrefix}${Nbr}`;
      // console.log(ContractNbr);
      done();
    });

    afterEach(function(done) {
      done();
    });

    it(`add should create history if ReadyForReview is presented 'true'`, async function() {
      this.timeout(0);
      const repository = new IssuesRisksRepository();
      const {RiskDetailsKey: key} = await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr,
          RiskStatusCd: RiskStatusPendingReview,
          RiskLeadReviewStatusCd: null,
          RiskLeadReviewDttm: null,
          LeadReviews: [],
          ReadyForReview: true
        })
      );
      const historyList = await repository.getHistories(key);
      const {RiskHistoryKey, HistoryNm} = historyList[0];
      expect(HistoryNm).to.be.eq('Iteration 1 - Ready for Review');
      let result = await repository.getHistory(RiskHistoryKey, key);
      expect(result).to.not.be.null;
      expect(result.RiskDetailsKey).to.be.eq(key);
      expect(result.RiskNbr).to.not.be.null;
      result = JSON.parse(result.ContentTxt);
      expect(result.RiskStatusCd).to.be.eq(RiskStatusPendingReview);
    });

    it(`add should create history if LeadReviewCompleted is presented 'true'`, async function() {
      this.timeout(0);
      const reviewAt = new Date().toISOString();
      const repository = new IssuesRisksRepository();
      const {RiskDetailsKey: key} = await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr,
          RiskStatusCd: RiskStatusPendingReview,
          RiskLeadReviewStatusCd: RiskLeadReviewStatusReviewed,
          RiskLeadReviewDttm: reviewAt,
          LeadReviews: [
            {
              LeadReviewStatusCd: RiskLeadReviewStatusReviewed,
              RecordedUserId: 'ut-test',
              DesignatedReviewerUserId: 'ut-test-reviewer',
              LeadReviewDttm: reviewAt,
              DesignatedReviewerUserIdArr: ['ut-test']
            }
          ],
          LeadReviewCompleted: true
        })
      );
      const historyList = await repository.getHistories(key);
      const {RiskHistoryKey, HistoryNm} = historyList[0];
      expect(HistoryNm).to.be.eq('Iteration 1 - Lead Review Completed');
      let result = await repository.getHistory(RiskHistoryKey, key);
      expect(result).to.not.be.null;
      expect(result.RiskDetailsKey).to.be.eq(key);
      result = JSON.parse(result.ContentTxt);
      expect(result.RiskStatusCd).to.be.eq(RiskStatusPendingReview);
    });

    it(`update should create history if ConsultationCallFlagged/ConsultationCallCompleted is presented 'true'`, async function() {
      this.timeout(0);
      const reviewAt = new Date().toISOString();
      const repository = new IssuesRisksRepository();
      const {RiskDetailsKey: key} = await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr,
          RiskStatusCd: RiskStatusPendingReview,
          RiskLeadReviewStatusCd: RiskLeadReviewStatusReviewed,
          RiskLeadReviewDttm: reviewAt,
          LeadReviews: [
            {
              LeadReviewStatusCd: RiskLeadReviewStatusReviewed,
              RecordedUserId: 'ut-test',
              DesignatedReviewerUserId: 'ut-test-reviewer',
              LeadReviewDttm: reviewAt,
              DesignatedReviewerUserIdArr: ['ut-test']
            }
          ],
          LeadReviewCompleted: true
        })
      );
      let riskDetails = await repository.get(key);
      let historyList = await repository.getHistories(key);
      let result = historyList[0];
      expect(result.HistoryNm).to.be.eq('Iteration 1 - Lead Review Completed');
      riskDetails.ConsultationCallFlagged = true;
      await repository.updateRisk(riskDetails);
      riskDetails = await repository.get(key);
      historyList = await repository.getHistories(key);
      result = historyList[0];
      expect(result.HistoryNm).to.be.eq('Iteration 2 - Consultation Call Flagged');
      riskDetails.ConsultationCallCompleted = true;
      riskDetails.ConsultationCall.ReviewerCompletedDt = new Date().toISOString();
      await repository.updateRisk(riskDetails);
      await repository.get(key);
      historyList = await repository.getHistories(key);
      result = historyList[0];
      expect(result.HistoryNm).to.be.eq('Iteration 3 - Consultation Call Completed');
    });

    it(`update should create history if CMIssueToRisk/CMRiskToIssue is presented 'true'`, async function() {
      this.timeout(0);
      const reviewAt = new Date().toISOString();
      const repository = new IssuesRisksRepository();
      const {RiskDetailsKey: key} = await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr,
          RiskStatusCd: RiskStatusPendingReview,
          RiskLeadReviewStatusCd: RiskLeadReviewStatusReviewed,
          RiskLeadReviewDttm: reviewAt,
          LeadReviews: [
            {
              LeadReviewStatusCd: RiskLeadReviewStatusReviewed,
              RecordedUserId: 'ut-test',
              DesignatedReviewerUserId: 'ut-test-reviewer',
              LeadReviewDttm: reviewAt,
              DesignatedReviewerUserIdArr: ['ut-test']
            }
          ],
          CMRiskToIssue: true
        })
      );
      let riskDetails = await repository.get(key);
      let historyList = await repository.getHistories(key);
      let result = historyList[0];
      expect(result.HistoryNm).to.be.eq('Iteration 1 - Risk Converted to Issue');
      riskDetails.CMIssueToRisk = true;
      await repository.updateRisk(riskDetails);
      historyList = await repository.getHistories(key);
      result = historyList[0];
      expect(result.HistoryNm).to.be.eq('Iteration 2 - Issue Converted to Risk');
    });

    it(`update should create 5 histories if CMIssueToRisk/ReadyForReview/LeadReviewCompleted/ConsultationCallFlagged/ConsultationCallCompleted are presented 'true' at same time`, async function() {
      this.timeout(0);
      const reviewAt = new Date().toISOString();
      const repository = new IssuesRisksRepository();
      const {RiskDetailsKey: key} = await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr,
          RiskStatusCd: RiskStatusPendingReview,
          RiskLeadReviewStatusCd: RiskLeadReviewStatusReviewed,
          RiskLeadReviewDttm: reviewAt,
          LeadReviews: [
            {
              LeadReviewStatusCd: RiskLeadReviewStatusReviewed,
              RecordedUserId: 'ut-test',
              DesignatedReviewerUserId: 'ut-test-reviewer',
              LeadReviewDttm: reviewAt,
              DesignatedReviewerUserIdArr: ['ut-test']
            }
          ],
          CMIssueToRisk: true,
          ReadyForReview: true,
          LeadReviewCompleted: true,
          ConsultationCallFlagged: true,
          ConsultationCallCompleted: true
        })
      );
      let historyList = await repository.getHistories(key);
      expect(historyList.length).to.be.eq(5);
      let result = historyList[0];
      expect(result.HistoryNm).to.be.eq('Iteration 5 - Consultation Call Completed');
      result = historyList[1];
      expect(result.HistoryNm).to.be.eq('Iteration 4 - Consultation Call Flagged');
      result = historyList[2];
      expect(result.HistoryNm).to.be.eq('Iteration 3 - Lead Review Completed');
      result = historyList[3];
      expect(result.HistoryNm).to.be.eq('Iteration 2 - Ready for Review');
      result = historyList[4];
      expect(result.HistoryNm).to.be.eq('Iteration 1 - Issue Converted to Risk');
    });
  });

  describe('Testing getContractScores', () => {
    beforeEach(function(done) {
      const Nbr = getRandomNbr();
      ContractNbr = `${UTPrefix}${Nbr}`;
      CustomerNbr = `${UTPrefix}${Nbr}`;
      // console.log(`Testing ContractNbr: ${ContractNbr}`);
      done();
    });

    afterEach(function(done) {
      done();
    });

    it(`add Risk with specified rating should calculate ContractScore as expected`, async function() {
      this.timeout(0);
      const repository = new IssuesRisksRepository();
      const {RiskDetailsKey: key} = await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr,
          RiskRatingCd: RiskRatingHigh,
          RiskAssessmentQuestionKey: RiskQuestionCE01,
          CMRiskRatingUpdated: true
        })
      );
      let result = await repository.get(key);
      expect(result.RiskScore).to.be.eq(10);
      result = await repository.getContractScores(ContractNbr);
      expect(result).to.not.be.null;
      expect(result.length).to.be.eq(1);
      result = result[0];
      expect(result.ContractNbr).to.be.eq(ContractNbr);
      expect(result.ContractScore).to.be.eq(1.5);
      expect(result.ContractScoreRatingCd).to.be.eq(RiskContractScoreRatingAboveNormal);
    });

    it(`update Risk with specified rating should recalculate ContractScore as expected`, async function() {
      this.timeout(0);
      const repository = new IssuesRisksRepository();
      const {RiskDetailsKey: key} = await repository.addRisk(
        Object.assign({}, model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr,
          RiskNbr: 1234567890,
          RiskRatingCd: RiskRatingHigh,
          RiskAssessmentQuestionKey: RiskQuestionCE01,
          CMRiskRatingUpdated: true
        })
      );
      await repository.addRisk(
        Object.assign({}, model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr,
          RiskNbr: 1234567890,
          RiskRatingCd: RiskRatingHigh,
          RiskAssessmentQuestionKey: RiskQuestionCE03,
          CMRiskRatingUpdated: true
        })
      );
      let result = await repository.get(key);
      await repository.updateRisk(
        Object.assign(result, {
          RiskRatingCd: RiskRatingAboveNormal,
          CMRiskRatingUpdated: true
        })
      );
      result = await repository.get(key);
      expect(result.RiskScore).to.be.eq(1);
      result = await repository.getContractScores(ContractNbr);
      expect(result).to.not.be.null;
      expect(result.length).to.be.eq(1);
      result = result[0];
      expect(result.ContractNbr).to.be.eq(ContractNbr);
      expect(result.ContractScore).to.be.eq(1.27);
      expect(result.ContractScoreRatingCd).to.be.eq(RiskContractScoreRatingNormal);
    });

    it(`add two Risks with specified rating should recalculate ContractScore as expected`, async function() {
      this.timeout(0);
      const repository = new IssuesRisksRepository();
      await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr,
          RiskRatingCd: RiskRatingHigh,
          RiskAssessmentQuestionKey: RiskQuestionCE01,
          CMRiskRatingUpdated: true
        })
      );
      await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr,
          RiskRatingCd: RiskRatingHigh,
          RiskAssessmentQuestionKey: RiskQuestionCE03,
          CMRiskRatingUpdated: true
        })
      );
      let result = await repository.getContractScores(ContractNbr);
      expect(result.length).to.be.eq(1);
      result = result[0];
      expect(result.ContractNbr).to.be.eq(ContractNbr);
      expect(result.ContractScore).to.be.eq(1.5);
      expect(result.ContractScoreRatingCd).to.be.eq(RiskContractScoreRatingAboveNormal);
    });

    it(`add two Risks with specified rating should recalculate ContractScore/ContractScoreNoCM as expected`, async function() {
      this.timeout(0);
      const repository = new IssuesRisksRepository();
      await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr,
          RiskRatingCd: RiskRatingHigh,
          RiskAssessmentQuestionKey: RiskQuestionCE01,
          CMRiskRatingUpdated: true
        })
      );
      await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr,
          RiskRatingCd: RiskRatingAboveNormal,
          RiskAssessmentQuestionKey: RiskQuestionCM02,
          CMRiskRatingUpdated: true
        })
      );
      let result = await repository.getContractScores(ContractNbr);
      expect(result.length).to.be.eq(1);
      result = result[0];
      expect(result.ContractNbr).to.be.eq(ContractNbr);
      expect(result.ContractScore).to.be.eq(1.9);
      expect(result.ContractScoreRatingCd).to.be.eq(RiskContractScoreRatingAboveNormal);
      expect(result.ContractScoreNoCM).to.be.eq(1.5);
      expect(result.ContractScoreNoCMRatingCd).to.be.eq(RiskContractScoreRatingAboveNormal);
    });

    it(`add four Risks with specified rating should recalculate ContractScore/ContractScoreNoCM as expected`, async function() {
      this.timeout(0);
      const repository = new IssuesRisksRepository();
      await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr,
          RiskRatingCd: RiskRatingHigh,
          RiskAssessmentQuestionKey: RiskQuestionCE01,
          CMRiskRatingUpdated: true
        })
      );
      await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr,
          RiskRatingCd: RiskRatingAboveNormal,
          RiskAssessmentQuestionKey: RiskQuestionCM02,
          CMRiskRatingUpdated: true
        })
      );
      await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr,
          RiskRatingCd: RiskRatingAboveNormal,
          RiskAssessmentQuestionKey: RiskQuestionAL01,
          CMRiskRatingUpdated: true
        })
      );
      await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          CustomerNbr,
          MasterClientNbr,
          RiskRatingCd: RiskRatingNormal,
          RiskAssessmentQuestionKey: RiskQuestionCD03,
          CMRiskRatingUpdated: true
        })
      );
      let result = await repository.getContractScores(ContractNbr);
      expect(result.length).to.be.eq(1);
      result = result[0];
      expect(result.ContractNbr).to.be.eq(ContractNbr);
      expect(result.ContractScore).to.be.eq(2.48);
      expect(result.ContractScoreRatingCd).to.be.eq(RiskContractScoreRatingAboveNormal);
      expect(result.ContractScoreNoCM).to.be.eq(2.4);
      expect(result.ContractScoreNoCMRatingCd).to.be.eq(RiskContractScoreRatingAboveNormal);
    });

    it(`getContractScores should get all contract scores if ContractNbr is not specified`, async function() {
      this.timeout(0);
      const repository = new IssuesRisksRepository();
      const contractScores = await repository.getContractScores(null);
      expect(contractScores.length).to.gt(1);
    });
  });

  describe('Testing publishCIPComments', () => {
    it(`publishCIPComments`, async function() {
      this.timeout(0);
      const repository = new IssuesRisksRepository();
      const result = await repository.publishCIPComments(
        [
          {
            EventName: 'new_mitigation',
            RiskRatingCd: '100801',
            RiskDetailsKey: '7fb6fa6b-26c8-4cfe-a6cd-7334e214ed70',
            RiskMitigationKey: '6562a2f4-df7d-4a3e-9e74-7c8fe824a258',
            MMCLinkToRiskDetails: 'MMC URL that points to Risk Details page',
            CIPId: 12345,
            CIPType: 'OPP',
            Level3RiskId: 123,
            MitigationCreateUserId: 'test.id.001',
            MitigationCreateDttm: '2019-07-04T05:16:28.476559Z',
            MitigationUpdateUserId: 'test.id.001',
            MitigationUpdateDttm: '2019-07-04T05:16:28.476559Z',
            MitigationStatus: 'In Progress (Due)',
            MitigationDueDate: '2019-10-04T07:00:00.000000000Z',
            MitigationOwner: 'test.id.002',
            MitigationDescription: 'description'
          },
          {
            EventName: 'update_mitigation',
            RiskRatingCd: '100801',
            RiskDetailsKey: '7fb6fa6b-26c8-4cfe-a6cd-7334e214ed70',
            RiskMitigationKey: '6562a2f4-df7d-4a3e-9e74-7c8fe824a258',
            MMCLinkToRiskDetails: 'MMC URL that points to Risk Details page',
            CIPId: 12345,
            CIPType: 'OPP',
            Level3RiskId: 123,
            MitigationCreateUserId: 'test.id.001',
            MitigationCreateDttm: '2019-07-04T05:16:28.476559Z',
            MitigationUpdateUserId: 'test.id.001',
            MitigationUpdateDttm: '2019-07-04T05:16:28.476559Z',
            MitigationStatus: 'In Progress (Due)',
            MitigationDueDate: '2019-10-04T07:00:00.000000000Z',
            MitigationOwner: 'test.id.002',
            MitigationDescription: 'description'
          },
          {
            EventName: 'update_risk_rating',
            CreateUserId: 'test.id.001',
            CreateDttm: '2019-05-30T07:00:00.000000000Z',
            UpdateUserId: 'test.id.001',
            UpdateDttm: '2019-06-28T00:17:51.579000000Z',
            RiskRatingCd: '100801',
            RiskDetailsKey: '7fb6fa6b-26c8-4cfe-a6cd-7334e214ed70',
            MMCLinkToRiskDetails: 'MMC URL that points to Risk Details page',
            CIPId: 12345,
            CIPType: 'OPP',
            Level3RiskId: 123
          }
        ],
        'token'
      );
      expect(result).to.be.eq('OK');
    });
  });

  describe('Testing CIP', () => {
    beforeEach(function(done) {
      const Nbr = getRandomNbr();
      ContractNbr = `${UTPrefix}${Nbr}`;
      CustomerNbr = `${UTPrefix}${Nbr}`;
      done();
    });

    it('updateRisk should updateRisk CIP related properties', async function() {
      this.timeout(0);
      const repository = new IssuesRisksRepository();
      const {RiskDetailsKey: key} = await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          ContractNm: 'CIP UT',
          CustomerNbr,
          MasterClientNbr,
          RiskSourceCd: RiskSourceCIP,
          CIPOpportunityId: 1,
          CIPReasonforChangeTxt: 'CIP UT',
          CIPRiskId: 1,
          CIPId: 1,
          CIPType: 'MSA',
          CIPRiskTitleNm: 'CIP UT',
          CIPRatingNm: 'High',
          CIPRiskURI: 'http://example.com',
          CIPCategoryNm: 'CIP UT',
          CIPSubCategoryNm: 'CIP UT',
          Mitigations: [],
          LeadReviews: [],
          ConsultationCall: {},
          QMDCall: {}
        })
      );
      let result = await repository.get(key);
      expect(result.RiskDetailsKey).to.be.eq(key);
      expect(result.RiskSourceCd).to.be.eq(RiskSourceCIP);

      result.CIPReasonforChangeTxt = 'CIP UT UPDATE';
      result.ContractNm = 'CIP UT UPDATE';
      await repository.updateRisk(result);

      result = await repository.get(key);
      expect(result.CIPReasonforChangeTxt).to.be.eq('CIP UT UPDATE');
      expect(result.ContractNm).to.be.eq('CIP UT UPDATE');
    });

    it(`update should publish comment if new mitigation is added/update exist mitigation/change risk rating`, async function() {
      this.timeout(0);
      const repository = new IssuesRisksRepository();
      const {RiskDetailsKey: key} = await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          ContractNm: 'CIP UT',
          CustomerNbr,
          MasterClientNbr,
          RiskSourceCd: RiskSourceCIP,
          CIPOpportunityId: 1,
          CIPReasonforChangeTxt: 'CIP UT',
          CIPRiskId: 1,
          CIPId: 1,
          CIPType: 'MSA',
          CIPRiskTitleNm: 'CIP UT',
          CIPRatingNm: 'High',
          CIPRiskURI: 'http://example.com',
          CIPCategoryNm: 'CIP UT',
          CIPSubCategoryNm: 'CIP UT',
          RiskRatingCd: RiskRatingHigh,
          Mitigations: [
            {
              AssigneeUserId: 'ut-test1',
              DueDttm: '2019-06-30T00:00:00.000Z',
              MitigationDesc: 'ut-test1',
              MitigationStatusCd: RiskMitigationStatusInProgress,
              MitigationSourceCd: RiskSourceCM,
              RiskNextBestActionKey: RiskNextBestActionKey,
              MitigationTitle: 'ut-test-title1',
              MitigationTypeCd: MitigationNBATypeCd,
              MitigationNbr: MitigationNbr,
              OriginalNBATitle: 'OriginalNBATitle1',
              OriginalNBADesc: 'OriginalNBADesc1'
            }
          ],
          LeadReviews: [],
          ConsultationCall: {},
          QMDCall: {}
        })
      );
      console.log(key);
      let result = await repository.get(key);
      result.CIPReasonforChangeTxt = 'CIP UT UPDATE';
      result.RiskRatingCd = RiskRatingAboveNormal;
      result.CIPRiskRatingUpdated = true;
      result.Mitigations = [
        {
          AssigneeUserId: 'ut-test2',
          DueDttm: '2019-06-30T00:00:00.000Z',
          MitigationDesc: 'ut-test2',
          MitigationStatusCd: RiskMitigationStatusInProgress,
          MitigationSourceCd: RiskSourceCM,
          RiskNextBestActionKey: RiskNextBestActionKey,
          MitigationTitle: 'ut-test-title2',
          MitigationTypeCd: MitigationNBATypeCd,
          MitigationNbr: MitigationNbr,
          OriginalNBATitle: 'OriginalNBATitle2',
          OriginalNBADesc: 'OriginalNBADesc2'
        },
        ...result.Mitigations
      ];
      result.Mitigations[1].MitigationUpdated = true;
      await repository.updateRisk(result);

      result = await repository.get(key);
      expect(result.CIPReasonforChangeTxt).to.be.eq('CIP UT UPDATE');
    });

    it(`update should publish comment if update exist mitigation`, async function() {
      this.timeout(0);
      const repository = new IssuesRisksRepository();
      const {RiskDetailsKey: key} = await repository.addRisk(
        Object.assign(new RiskDetailsModel(), model, {
          ContractNbr,
          ContractNm: 'CIP UT',
          CustomerNbr,
          MasterClientNbr,
          RiskSourceCd: RiskSourceCIP,
          CIPOpportunityId: 1,
          CIPReasonforChangeTxt: 'CIP UT',
          CIPRiskId: 1,
          CIPId: 1,
          CIPType: 'MSA',
          CIPRiskTitleNm: 'CIP UT',
          CIPRatingNm: 'High',
          CIPRiskURI: 'http://example.com',
          CIPCategoryNm: 'CIP UT',
          CIPSubCategoryNm: 'CIP UT',
          RiskRatingCd: RiskRatingHigh,
          Mitigations: [
            {
              AssigneeUserId: 'ut-test',
              DueDttm: '2019-06-30T00:00:00.000Z',
              MitigationDesc: 'ut-test',
              MitigationStatusCd: RiskMitigationStatusInProgress,
              MitigationSourceCd: RiskSourceCIP
            }
          ],
          LeadReviews: [],
          ConsultationCall: {},
          QMDCall: {}
        })
      );
      let result = await repository.get(key);
      result.CIPReasonforChangeTxt = 'CIP UT UPDATE';
      result.RiskRatingCd = RiskRatingAboveNormal;
      result.CIPRiskRatingUpdated = true;
      result.Mitigations[0].MitigationUpdated = true;
      await repository.updateRisk(result);

      result = await repository.get(key);
      expect(result.CIPReasonforChangeTxt).to.be.eq('CIP UT UPDATE');
    });
  });

  describe('Testing createRiskDetails', () => {
    it(`createRiskDetails should init QMDCall with default value`, async function() {
      const repository = new IssuesRisksRepository();
      const updateAt = new Date().toISOString();
      const enterpriseId = 'dummy';
      const context = {
        RiskDetailsModel: {},
        updateAt: updateAt,
        enterpriseId: enterpriseId
      };
      await repository.createRiskDetails(context);
      expect(context.RiskDetails.RiskQMDReviewDttm).to.be.null;
      expect(context.RiskDetails.RiskQMDReviewInd).to.eq('N');
    });
  });

  describe('Testing createRiskMitigations', () => {
    it(`createRiskMitigations should init MitigationSourceCd with default value`, async function() {
      const repository = new IssuesRisksRepository();
      const updateAt = new Date().toISOString();
      const enterpriseId = 'dummy';
      const context = {
        RiskDetailsModel: {
          Mitigations: [{}]
        },
        RiskDetails: {
          RiskDetailsKey: 'dummy'
        },
        updateAt: updateAt,
        enterpriseId: enterpriseId
      };
      await repository.createRiskMitigations(context);
      expect(context.NewRiskMitigations[0].MitigationSourceCd).to.eq(RiskSourceCM);
    });
  });

  describe('Testing createRiskLeadReviews', () => {
    it(`createRiskLeadReviews should not process lead reviews if risk is not create from CM`, async function() {
      const repository = new IssuesRisksRepository();
      const updateAt = new Date().toISOString();
      const enterpriseId = 'dummy';
      const context = {
        RiskDetailsModel: {
          LeadReviews: []
        },
        RiskDetails: {
          RiskDetailsKey: 'dummy',
          RiskSourceCd: RiskSourceCIP
        },
        updateAt: updateAt,
        enterpriseId: enterpriseId
      };
      await repository.createRiskLeadReviews(context);
      expect(context.NewRiskLeadReviews).to.be.undefined;
    });
  });

  describe('Testing createRiskConsultationCall', () => {
    it(`createRiskConsultationCall should not process cc if risk is not create from CM`, async function() {
      const repository = new IssuesRisksRepository();
      const updateAt = new Date().toISOString();
      const enterpriseId = 'dummy';
      const context = {
        RiskDetailsModel: {
          ConsultationCall: {}
        },
        RiskDetails: {
          RiskDetailsKey: 'dummy',
          RiskSourceCd: RiskSourceCIP
        },
        updateAt: updateAt,
        enterpriseId: enterpriseId
      };
      await repository.createRiskConsultationCall(context);
      expect(context.RiskConsultationCall).to.be.undefined;
    });

    it(`createRiskConsultationCall should not create party and CCIs`, async function() {
      const repository = new IssuesRisksRepository();
      const updateAt = new Date().toISOString();
      const enterpriseId = 'dummy';
      const context = {
        RiskDetailsModel: {
          ConsultationCall: {ConsultationCallStatusCd: RiskConsultationCallStatusNotRequested}
        },
        RiskDetails: {
          RiskDetailsKey: 'dummy',
          RiskSourceCd: RiskSourceCM
        },
        updateAt: updateAt,
        enterpriseId: enterpriseId
      };
      await repository.createRiskConsultationCall(context);
      expect(context.RiskConsCallInvolvedParties).to.be.undefined;
      expect(context.RiskConsCallFinRevenueCCIs).to.be.undefined;
    });
  });

  describe('Testing updateRiskScore', () => {
    it(`updateRiskScore should not process ContractScore if risk is not create from CM`, async function() {
      const repository = new IssuesRisksRepository();
      const updateAt = new Date().toISOString();
      const enterpriseId = 'dummy';
      const context = {
        RiskDetailsModel: {},
        RiskDetails: {
          RiskDetailsKey: 'dummy',
          RiskSourceCd: RiskSourceCIP
        },
        updateAt: updateAt,
        enterpriseId: enterpriseId
      };
      await repository.updateRiskScore(context);
      expect(context.RiskContractScore).to.be.undefined;
    });
  });

  describe('Testing updateRiskDetails', () => {
    it(`updateRiskDetails should init QMDCall with default value`, async function() {
      const repository = new IssuesRisksRepository();
      const updateAt = new Date().toISOString();
      const enterpriseId = 'dummy';
      const context = {
        RiskDetailsModel: {QMDCall: {}},
        updateAt: updateAt,
        enterpriseId: enterpriseId
      };
      await repository.updateRiskDetails(context);
      expect(context.RiskDetails.RiskQMDReviewDttm).to.be.null;
      expect(context.RiskDetails.RiskQMDReviewInd).to.eq('N');
    });
    it(`updateRiskDetails should init QMDCall with default value if QMD not provided`, async function() {
      const repository = new IssuesRisksRepository();
      const updateAt = new Date().toISOString();
      const enterpriseId = 'dummy';
      const context = {
        RiskDetailsModel: {},
        updateAt: updateAt,
        enterpriseId: enterpriseId
      };
      await repository.updateRiskDetails(context);
      expect(context.RiskDetails.RiskQMDReviewDttm).to.be.null;
      expect(context.RiskDetails.RiskQMDReviewInd).to.eq('N');
    });
  });

  describe('Testing updateRiskMitigations', () => {
    const repository = new IssuesRisksRepository();
    const getCodesByCategoryStub = sinon.stub(repository, 'getCodesByCategory');
    after(function(done) {
      getCodesByCategoryStub.restore();
      done();
    });
    it(`updateRiskMitigations should create CIP events`, async function() {
      getCodesByCategoryStub.resolves([{CodeTxt: 'dummyStatus', PrimaryDecodeTxt: 'dummyPrimaryDecodeTxt'}]);
      const updateAt = new Date().toISOString();
      const enterpriseId = 'dummy';
      const context = {
        RiskDetailsModel: {
          RiskSourceCd: RiskSourceCIP,
          Mitigations: [
            {
              RiskMitigationKey: 'dummy',
              MitigationStatusCd: 'dummyStatus',
              MitigationUpdated: true,
              CIPMitigationUpdated: true
            }
          ]
        },
        RiskDetails: {
          RiskDetailsKey: 'dummy'
        },
        updateAt: updateAt,
        enterpriseId: enterpriseId
      };
      await repository.updateRiskMitigations(context);
      expect(context.CIPUpdateMitigationEvents.length).to.eq(1);
    });
  });

  describe('Testing updateRiskLeadReviews', () => {
    it(`updateRiskLeadReviews should not process lead reviews`, async function() {
      const repository = new IssuesRisksRepository();
      const updateAt = new Date().toISOString();
      const enterpriseId = 'dummy';
      const context = {
        RiskDetailsModel: {},
        RiskDetails: {
          RiskDetailsKey: 'dummy',
          RiskSourceCd: RiskSourceCM
        },
        updateAt: updateAt,
        enterpriseId: enterpriseId
      };
      await repository.updateRiskLeadReviews(context);
      expect(context.NewRiskLeadReviews).to.be.undefined;
      expect(context.UpdateRiskLeadReviews).to.be.undefined;
    });
    it(`updateRiskLeadReviews should process new lead reviews`, async function() {
      const repository = new IssuesRisksRepository();
      const updateAt = new Date().toISOString();
      const enterpriseId = 'dummy';
      const context = {
        RiskDetailsModel: {
          LeadReviews: [{}, {RiskLeadReviewKey: 'dummy'}]
        },
        RiskDetails: {
          RiskDetailsKey: 'dummy',
          RiskSourceCd: RiskSourceCM
        },
        updateAt: updateAt,
        enterpriseId: enterpriseId
      };
      await repository.updateRiskLeadReviews(context);
      expect(context.NewRiskLeadReviews.length).to.eq(1);
      expect(context.UpdateRiskLeadReviews.length).to.eq(1);
    });
  });

  describe('Testing updateRiskConsultationCall', () => {
    it(`updateRiskConsultationCall should process CC`, async function() {
      const repository = new IssuesRisksRepository();
      const updateAt = new Date().toISOString();
      const enterpriseId = 'dummy';
      const context = {
        RiskDetailsModel: {
          ConsultationCall: {
            RiskConsultationCallKey: 'dummy',
            ConsultationCallStatusCd: RiskConsultationCallStatusPending,
            ConsCallInvolvedParty: [{}],
            ConsCallFinRevenueCCI: [{}]
          }
        },
        RiskDetails: {
          RiskDetailsKey: 'dummy',
          RiskSourceCd: RiskSourceCM
        },
        updateAt: updateAt,
        enterpriseId: enterpriseId
      };
      await repository.updateRiskConsultationCall(context);
      expect(context.RiskConsultationCall).to.be.not.undefined;
      expect(context.RiskConsCallInvolvedParties).to.be.not.undefined;
      expect(context.RiskConsCallFinRevenueCCIs).to.be.not.undefined;
    });
    it(`updateRiskConsultationCall should not process CC`, async function() {
      const repository = new IssuesRisksRepository();
      const updateAt = new Date().toISOString();
      const enterpriseId = 'dummy';
      const context = {
        RiskDetailsModel: {
          ConsultationCall: {}
        },
        RiskDetails: {
          RiskDetailsKey: 'dummy',
          RiskSourceCd: RiskSourceCM
        },
        updateAt: updateAt,
        enterpriseId: enterpriseId
      };
      await repository.updateRiskConsultationCall(context);
      expect(context.RiskConsultationCall).to.be.undefined;
    });
    it(`updateRiskConsultationCall should not process Party and CCIs`, async function() {
      const repository = new IssuesRisksRepository();
      const updateAt = new Date().toISOString();
      const enterpriseId = 'dummy';
      const context = {
        RiskDetailsModel: {
          ConsultationCall: {
            RiskConsultationCallKey: 'dummy',
            ConsultationCallStatusCd: RiskConsultationCallStatusPending
          }
        },
        RiskDetails: {
          RiskDetailsKey: 'dummy',
          RiskSourceCd: RiskSourceCM
        },
        updateAt: updateAt,
        enterpriseId: enterpriseId
      };
      await repository.updateRiskConsultationCall(context);
      expect(context.RiskConsultationCall).to.be.not.undefined;
      expect(context.RiskConsCallInvolvedParties).to.be.undefined;
      expect(context.RiskConsCallFinRevenueCCIs).to.be.undefined;
    });
  });

  describe('Testing deleteRiskConsultationCall', () => {
    it(`deleteRiskConsultationCall should process CC`, async function() {
      const repository = new IssuesRisksRepository();
      const updateAt = new Date().toISOString();
      const enterpriseId = 'dummy';
      const context = {
        RiskDetailsModel: {
          ConsultationCall: {
            RiskConsultationCallKey: 'dummy',
            ConsultationCallStatusCd: RiskConsultationCallStatusPending,
            ConsCallInvolvedParty: [{}],
            ConsCallFinRevenueCCI: [{}]
          }
        },
        RiskDetails: {
          RiskDetailsKey: 'dummy',
          RiskSourceCd: RiskSourceCM
        },
        updateAt: updateAt,
        enterpriseId: enterpriseId
      };
      await repository.deleteRiskConsultationCall(context);
      expect(context.DeleteRiskConsultationCall).to.be.not.undefined;
      expect(context.DeleteRiskConsCallInvolvedParties).to.be.not.undefined;
      expect(context.DeleteRiskConsCallFinRevenueCCIs).to.be.not.undefined;
    });
    it(`deleteRiskConsultationCall should not process Party and CCIs`, async function() {
      const repository = new IssuesRisksRepository();
      const updateAt = new Date().toISOString();
      const enterpriseId = 'dummy';
      const context = {
        RiskDetailsModel: {
          ConsultationCall: {
            RiskConsultationCallKey: 'dummy',
            ConsultationCallStatusCd: RiskConsultationCallStatusPending
          }
        },
        RiskDetails: {
          RiskDetailsKey: 'dummy',
          RiskSourceCd: RiskSourceCM
        },
        updateAt: updateAt,
        enterpriseId: enterpriseId
      };
      await repository.deleteRiskConsultationCall(context);
      expect(context.DeleteRiskConsultationCall).to.be.not.undefined;
      expect(context.DeleteRiskConsCallInvolvedParties).to.be.undefined;
      expect(context.DeleteRiskConsCallFinRevenueCCIs).to.be.undefined;
    });
  });

  describe('Testing addIDToDb', () => {
    it(`addIDToDb should not insert RiskID`, async function() {
      const repository = new IssuesRisksRepository();
      const transactionSpy = sinon.spy();
      const context = {
        RiskID: null,
        transaction: transactionSpy
      };
      await repository.addIDToDb(context);
      expect(transactionSpy).have.not.been.called;
    });
  });

  describe('Testing addFeedbackToDb', () => {
    it(`addFeedbackToDb should not insert RiskNBARecord`, async function() {
      const repository = new IssuesRisksRepository();
      const transactionSpy = sinon.spy();
      const context = {
        riskFeedbackList: null,
        transaction: transactionSpy
      };
      await repository.addFeedbackToDb(context);
      expect(transactionSpy).have.not.been.called;
    });
    it(`addFeedbackToDb should save RiskDetailsKey`, async function() {
      const repository = new IssuesRisksRepository();
      const insertSpy = sinon.spy();
      const context = {
        riskFeedbackList: [{RiskDetailsKey: 'stub'}],
        transaction: {
          insert: insertSpy
        },
        updateAt: 'stub',
        enterpriseId: 'stub'
      };
      await repository.addFeedbackToDb(context);
      expect(insertSpy).have.been.called;
    });
  });

  describe('Testing addToDb', () => {
    it(`addToDb should not insert`, async function() {
      const repository = new IssuesRisksRepository();
      const transactionSpy = sinon.spy();
      const context = {
        RiskDetails: null,
        NewRiskMitigations: null,
        NewRiskLeadReviews: null,
        RiskConsultationCall: null,
        RiskContractScore: null,
        RiskHistories: null,
        transaction: transactionSpy
      };
      await repository.addToDb(context);
      expect(transactionSpy).have.not.been.called;
    });
    it(`addToDb should not insert Party and CCIs`, async function() {
      const repository = new IssuesRisksRepository();
      const insertSpy = sinon.spy();
      const context = {
        RiskDetails: null,
        NewRiskMitigations: null,
        NewRiskLeadReviews: null,
        RiskConsultationCall: {
          RiskConsCallInvolvedParties: null,
          RiskConsCallFinRevenueCCIs: null
        },
        RiskContractScore: null,
        RiskHistories: null,
        transaction: {
          insert: insertSpy
        }
      };
      await repository.addToDb(context);
      expect(insertSpy).have.been.calledOnce;
    });
  });

  describe('Testing updateToDb', () => {
    it(`updateToDb should not update`, async function() {
      const repository = new IssuesRisksRepository();
      const transactionSpy = sinon.spy();
      const context = {
        RiskDetails: null,
        DeleteRiskMitigations: null,
        UpdateRiskMitigations: null,
        DeleteRiskLeadReviews: null,
        UpdateRiskLeadReviews: null,
        NewRiskMitigations: null,
        NewRiskLeadReviews: null,
        DeleteRiskConsultationCall: null,
        RiskConsultationCall: null,
        RiskContractScore: null,
        RiskHistories: null,
        transaction: transactionSpy
      };
      await repository.updateToDb(context);
      expect(transactionSpy).have.not.been.called;
    });
    it(`updateToDb should not delete Party and CCIs`, async function() {
      const repository = new IssuesRisksRepository();
      const deleteRowsSpy = sinon.spy();
      const context = {
        RiskDetails: null,
        DeleteRiskMitigations: null,
        UpdateRiskMitigations: null,
        DeleteRiskLeadReviews: null,
        UpdateRiskLeadReviews: null,
        NewRiskMitigations: null,
        NewRiskLeadReviews: null,
        DeleteRiskConsultationCall: {
          DeleteRiskConsCallInvolvedParties: null,
          DeleteRiskConsCallFinRevenueCCIs: null
        },
        RiskConsultationCall: null,
        RiskContractScore: null,
        RiskHistories: null,
        transaction: {
          deleteRows: deleteRowsSpy
        }
      };
      await repository.updateToDb(context);
      expect(deleteRowsSpy).have.been.calledOnce;
    });
    it(`updateToDb should not upsert Party and CCIs`, async function() {
      const repository = new IssuesRisksRepository();
      const upsertSpy = sinon.spy();
      const context = {
        RiskDetails: null,
        DeleteRiskMitigations: null,
        UpdateRiskMitigations: null,
        DeleteRiskLeadReviews: null,
        UpdateRiskLeadReviews: null,
        NewRiskMitigations: null,
        NewRiskLeadReviews: null,
        DeleteRiskConsultationCall: null,
        RiskConsultationCall: {
          RiskConsCallInvolvedParties: null,
          RiskConsCallFinRevenueCCIs: null
        },
        RiskContractScore: null,
        RiskHistories: null,
        transaction: {
          upsert: upsertSpy
        }
      };
      await repository.updateToDb(context);
      expect(upsertSpy).have.been.calledOnce;
    });
    it(`updateToDb should not update ScoreUpdatedRiskDetails`, async function() {
      const repository = new IssuesRisksRepository();
      const upsertSpy = sinon.spy();
      const updateSpy = sinon.spy();
      const context = {
        RiskDetails: null,
        DeleteRiskMitigations: null,
        UpdateRiskMitigations: null,
        DeleteRiskLeadReviews: null,
        UpdateRiskLeadReviews: null,
        NewRiskMitigations: null,
        NewRiskLeadReviews: null,
        DeleteRiskConsultationCall: null,
        RiskConsultationCall: null,
        RiskContractScore: {},
        ScoreUpdatedRiskDetails: [],
        RiskHistories: null,
        transaction: {
          upsert: upsertSpy,
          update: updateSpy
        }
      };
      await repository.updateToDb(context);
      expect(upsertSpy).have.been.calledOnce;
      expect(updateSpy).have.not.been.called;
    });
  });

  describe('Testing calcContractScoreRating', () => {
    it(`calcContractScoreRating should return rating`, async function() {
      const repository = new IssuesRisksRepository();
      const ratingScoreEqZero = repository.calcContractScoreRating(0);
      expect(ratingScoreEqZero[0]).to.eq('101904');
      expect(ratingScoreEqZero[1]).to.eq(0);
      const ratingScoreLtOnePointFive = repository.calcContractScoreRating(1.3);
      expect(ratingScoreLtOnePointFive[0]).to.eq('101903');
      expect(ratingScoreLtOnePointFive[1]).to.eq(1.3);
      const ratingScoreLtThree = repository.calcContractScoreRating(2.8);
      expect(ratingScoreLtThree[0]).to.eq('101902');
      expect(ratingScoreLtThree[1]).to.eq(2.8);
      const ratingScoreGtThree = repository.calcContractScoreRating(3.1);
      expect(ratingScoreGtThree[0]).to.eq('101901');
      expect(ratingScoreGtThree[1]).to.eq(3.1);
      const ratingScoreNegative = repository.calcContractScoreRating(-1);
      expect(ratingScoreNegative[0]).to.eq('101904');
      expect(ratingScoreNegative[1]).to.eq(0);
    });
  });

  describe('Testing determineRiskRatingMultiplier', () => {
    it(`determineRiskRatingMultiplier should throw error if rating not matched`, async function() {
      const repository = new IssuesRisksRepository();
      try {
        repository.determineRiskRatingMultiplier('err');
      } catch (err) {
        expect(err.message).to.eq('Rating of Risk is not valid.');
      }
    });
  });

  describe('Testing runQuery', () => {
    const repository = new IssuesRisksRepository();
    const stub = sinon.stub(repository, 'getDatabase');
    beforeEach(function(done) {
      stub.returns({
        run() {
          throw new Error('err');
        },
        close() {
          console.log('close');
        }
      });
      done();
    });
    afterEach(function(done) {
      stub.reset();
      done();
    });
    after(function(done) {
      stub.restore();
      done();
    });
    it(`runQuery should throw error if database throw exception`, async function() {
      try {
        await repository.runQuery({});
      } catch (err) {
        expect(err.message).to.eq('err');
      }
    });
  });

  describe('Testing runUpdate', () => {
    const repository = new IssuesRisksRepository();
    const stub = sinon.stub(repository, 'getDatabase');
    beforeEach(function(done) {
      done();
    });
    afterEach(function(done) {
      stub.reset();
      done();
    });
    after(function(done) {
      stub.restore();
      done();
    });
    it(`runUpdate`, async function() {
      stub.returns({
        async runTransactionAsync(action) {
          await action({
            runUpdate() {
              return [1];
            },
            commit() {
              console.log('commit');
            },
            ended: false,
            end() {
              console.log('end');
            }
          });
        },
        async close() {
          console.log('close');
        }
      });
      await repository.runUpdate({});
      stub.returns({
        async runTransactionAsync(action) {
          await action({
            runUpdate() {
              return [1];
            },
            commit() {
              console.log('commit');
            },
            ended: true,
            end() {
              console.log('end');
            }
          });
        },
        async close() {
          console.log('close');
        }
      });
      await repository.runUpdate({});
    });
    it(`runQuery should throw error if database throw exception`, async function() {
      stub.returns({
        runTransactionAsync() {
          throw new Error('err');
        },
        close() {
          console.log('close');
        }
      });
      try {
        await repository.runUpdate({});
      } catch (err) {
        expect(err.message).to.eq('err');
      }
    });
    it(`runQuery should throw error if transaction throw exception`, async function() {
      stub.returns({
        async runTransactionAsync(action) {
          await action({
            async runUpdate() {
              throw new Error('runUpdate err');
            },
            ended: false,
            end() {
              console.log('end');
            }
          });
        },
        async close() {
          console.log('close');
        }
      });
      try {
        await repository.runUpdate({});
      } catch (err) {
        expect(err.message).to.eq('runUpdate err');
      }
    });
  });

  describe('Testing runQueryGetSingle', () => {
    const repository = new IssuesRisksRepository();
    const stub = sinon.stub(repository, 'getDatabase');
    beforeEach(function(done) {
      stub.returns({
        run() {
          throw new Error('err');
        },
        close() {
          console.log('close');
        }
      });
      done();
    });
    afterEach(function(done) {
      stub.reset();
      done();
    });
    after(function(done) {
      stub.restore();
      done();
    });
    it(`runQueryGetSingle should throw error if database throw exception`, async function() {
      try {
        await repository.runQueryGetSingle({});
      } catch (err) {
        expect(err.message).to.eq('err');
      }
    });
  });

  describe('Testing private functions', () => {
    const repository = new IssuesRisksRepository();
    it(`_divide should return 0 if params is invalid`, async function() {
      const actual = await repository._divide(1, 'a');
      expect(actual).to.eq(0);
    });
    it(`_multiply should return 0 if params is invalid`, async function() {
      const actual = await repository._multiply(1, 'a');
      expect(actual).to.eq(0);
    });
  });

  describe('Testing errorHandling', () => {
    const repository = new IssuesRisksRepository();
    it(`errorHandling should print err to screen`, async function() {
      const err = new Error('errorHandling');
      await repository.errorHandling(err, {
        errorKey: 'key'
      });
    });
  });

  describe('Testing addRisk error', () => {
    const repository = new IssuesRisksRepository();
    const stubDb = sinon.stub(repository, 'getDatabase');
    const stub = sinon.stub(repository, 'createRiskDetails');
    afterEach(function(done) {
      stubDb.reset();
      stub.reset();
      done();
    });
    after(function(done) {
      stubDb.restore();
      stub.restore();
      done();
    });
    it(`addRisk should throw error if database throw exception`, async function() {
      try {
        stubDb.returns({
          runTransactionAsync(action) {
            action({
              ended: false,
              end() {
                console.log('end');
              }
            });
          },
          close() {
            console.log('close');
          }
        });
        stub.throws(new Error('err'));
        await repository.addRisk({});
      } catch (err) {
        expect(err.message).to.eq('ADD_RISK_ERROR');
      }
    });
    it(`addRisk should throw error if getTransaction throw exception`, async function() {
      try {
        stubDb.returns({
          runTransactionAsync() {
            throw new Error('err');
          },
          close() {
            console.log('close');
          }
        });
        await repository.addRisk({});
      } catch (err) {
        expect(err.message).to.eq('ADD_RISK_ERROR');
      }
    });
    it(`addRisk should throw error if  question is being rated by others`, async function() {
      try {
        stubDb.returns({
          runTransactionAsync() {
            throw new Error('ISSUES_RISKS_ERROR: question is being rated by others');
          },
          close() {
            console.log('close');
          }
        });
        await repository.addRisk({});
      } catch (err) {
        expect(err.message).to.eq('ISSUES_RISKS_ERROR: question is being rated by others');
      }
    });
  });

  describe('Testing updateRisk error', () => {
    const repository = new IssuesRisksRepository();
    const stubDb = sinon.stub(repository, 'getDatabase');
    const stub = sinon.stub(repository, 'updateRiskDetails');
    afterEach(function(done) {
      stubDb.reset();
      stub.reset();
      done();
    });
    after(function(done) {
      stubDb.restore();
      stub.restore();
      done();
    });
    it(`updateRisk should throw error if database throw exception`, async function() {
      try {
        stubDb.returns({
          runTransactionAsync(action) {
            action({
              ended: false,
              end() {
                console.log('end');
              }
            });
          },
          close() {
            console.log('close');
          }
        });
        stub.throws(new Error('err'));
        await repository.updateRisk({});
      } catch (err) {
        expect(err.message).to.eq('UPDATE_RISK_ERROR');
      }
    });
    it(`updateRisk should throw error if getTransaction throw exception`, async function() {
      try {
        stubDb.returns({
          runTransactionAsync() {
            throw new Error('err');
          },
          close() {
            console.log('close');
          }
        });
        await repository.updateRisk({});
      } catch (err) {
        expect(err.message).to.eq('UPDATE_RISK_ERROR');
      }
    });
  });

  describe('Testing closeDatabase error', () => {
    const repository = new IssuesRisksRepository();
    beforeEach(function(done) {
      done();
    });

    afterEach(function(done) {
      done();
    });
    it(`closeDatabase should handle session error`, async function() {
      const database = {
        async close(action) {
          const err = new Error('Error: 1 session leak(s) detected.');
          action(err);
        }
      };
      await repository.closeDatabase(database);
    });

    it(`closeDatabase should handle other error`, async function() {
      const database = {
        async close(action) {
          const err = new Error('Error: other');
          action(err);
        }
      };
      await repository.closeDatabase(database);
    });
  });

  describe('Testing addFeedback error', () => {
    const repository = new IssuesRisksRepository();
    const stubDb = sinon.stub(repository, 'getDatabase');
    afterEach(function(done) {
      stubDb.reset();
      done();
    });
    after(function(done) {
      stubDb.restore();
      done();
    });
    it(`addFeedback should throw error if getTransaction throw exception`, async function() {
      try {
        stubDb.returns({
          runTransactionAsync() {
            throw new Error('err');
          },
          close() {
            console.log('close');
          }
        });
        await repository.addFeedback([]);
      } catch (err) {
        expect(err.message).to.eq('err');
      }
    });

    it(`addRiskID should throw error if getTransaction throw exception`, async function() {
      try {
        stubDb.returns({
          runTransactionAsync() {
            throw new Error('err');
          },
          close() {
            console.log('close');
          }
        });
        await repository.addRiskID([]);
      } catch (err) {
        expect(err.message).to.eq('err');
      }
    });
  });

  describe('Testing runQueryGetSingleWithTransaction error', () => {
    const repository = new IssuesRisksRepository();
    const stub = sinon.stub(repository, 'runQueryGetSingleWithTransaction');
    beforeEach(function(done) {
      done();
    });
    afterEach(function(done) {
      stub.reset();
      done();
    });
    after(function(done) {
      stub.restore();
      done();
    });
    it(`addToDb should handle session error`, async function() {
      const requestContext = {
        RiskDetails: model
      };
      try {
        stub.returns({Count: 1});
        await repository.addToDb(requestContext);
      } catch (err) {
        expect(err.message).to.eq('ISSUES_RISKS_ERROR: question is being rated by others');
      }
    });
  });

  describe('Testing getInstance', () => {
    it('getInstance', async function() {
      const result = IssuesRisksRepository.getInstance();
      expect(result).to.not.be.null;
    });
  });
});
