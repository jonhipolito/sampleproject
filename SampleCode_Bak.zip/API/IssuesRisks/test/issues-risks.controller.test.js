process.env.NODE_ENV = 'test';

const sinon = require('sinon');
const chai = require('chai');
const sinonChai = require('sinon-chai');
chai.use(sinonChai);
const expect = chai.expect;
const {describe, before, beforeEach, afterEach, after, it} = require('mocha');

const IssuesRisksController = require('../server/issues-risks.controller');
const IssuesRisksService = require('../server/issues-risks.service');
const consultationCallExportService = require('../server/consultation-call-export.service');

describe('Testing IssuesRisksController', () => {
  beforeEach(function(done) {
    statusStub.returns({json: jsonSpy});
    done();
  });

  afterEach(function(done) {
    statusStub.reset();
    jsonSpy.resetHistory();
    nextSpy.resetHistory();
    done();
  });

  after(function(done) {
    getServiceMock.restore();
    done();
  });

  const riskDetailsKey = 'b1eeeec5-5797-4997-894d-8329531b4183';
  const questionKey = '4ddb59a7-7739-45a4-8b1d-20823a705871	';
  const contractNbr = '000000';
  const historyKey = 'test';
  const Question = {};
  const Category = 'Underlying Capability';
  const SubCategory = 'Delivery Location | Industry | Geography';

  const result = {riskDetailsKey, Mitigations: [], LeadReviews: []};
  const codes = [];
  const question = {Question, Statements: [], Category, SubCategory};
  const err = 'err';
  const getDetailsMock = sinon.stub();
  const getCodesMock = sinon.stub();
  const getQuestionsMock = sinon.stub();
  const getQuestionMock = sinon.stub();
  const getHistoryMock = sinon.stub();
  const getHistoryListMock = sinon.stub();
  const getContractScoresMock = sinon.stub();
  const createDetailsMock = sinon.stub();
  const updateDetailsMock = sinon.stub();
  const createFeedbackMock = sinon.stub();
  const getFeedbackRatingMock = sinon.stub();
  const getServiceMock = sinon.stub(IssuesRisksController, 'getService');
  const statusStub = sinon.stub();
  const jsonSpy = sinon.spy();
  const nextSpy = sinon.spy();

  describe('Testing getRiskDetails', () => {
    beforeEach(function(done) {
      getServiceMock.returns({
        getDetails: getDetailsMock
      });
      done();
    });

    afterEach(function(done) {
      getServiceMock.reset();
      getDetailsMock.reset();
      done();
    });

    it('getRiskDetails should call service', async () => {
      getDetailsMock.resolves(result);

      const req = {params: {riskDetailsKey}};
      const res = {status: statusStub};
      await IssuesRisksController.getRiskDetails(req, res, nextSpy);

      expect(getDetailsMock).to.have.been.calledWith(riskDetailsKey);
      expect(statusStub).to.have.been.calledWith(200);
      expect(jsonSpy).to.have.been.calledWith(result);
    });

    it('getRiskDetails should call next if error occurred', async () => {
      getDetailsMock.throws(err);

      const req = {params: {riskDetailsKey}};
      const res = {};
      await IssuesRisksController.getRiskDetails(req, res, nextSpy);

      expect(nextSpy.calledOnce).to.be.true;
      const error = nextSpy.firstCall.args[0];
      expect(error).to.be.instanceOf(Error);
      expect(error.message).to.eq(err);
    });
  });

  describe('Testing getRiskCodes', () => {
    beforeEach(function(done) {
      getServiceMock.returns({
        getCodes: getCodesMock
      });
      done();
    });

    afterEach(function(done) {
      getServiceMock.reset();
      getCodesMock.reset();
      done();
    });

    it('getRiskCodes should call service', async () => {
      getCodesMock.resolves(codes);
      const req = {query: {category: 'stub'}};
      const res = {status: statusStub};
      await IssuesRisksController.getRiskCodes(req, res, nextSpy);

      expect(statusStub).to.have.been.calledWith(200);
      expect(jsonSpy).to.have.been.calledWith(codes);
    });

    it('getRiskCodes should call next if error occurred', async () => {
      getCodesMock.throws(err);
      const req = {query: {category: 'stub'}};
      const res = {};
      await IssuesRisksController.getRiskCodes(req, res, nextSpy);

      expect(nextSpy.calledOnce).to.be.true;
      const error = nextSpy.firstCall.args[0];
      expect(error).to.be.instanceOf(Error);
      expect(error.message).to.eq(err);
    });
  });

  describe('Testing getQuestion', () => {
    beforeEach(function(done) {
      getServiceMock.returns({
        getQuestion: getQuestionMock
      });
      done();
    });

    afterEach(function(done) {
      getServiceMock.reset();
      getQuestionMock.reset();
      done();
    });

    it('getQuestion should call service', async () => {
      getQuestionMock.resolves(question);
      const req = {params: {questionKey}};
      const res = {status: statusStub};
      await IssuesRisksController.getRiskQuestion(req, res, nextSpy);

      expect(getQuestionMock).to.have.been.calledWith(questionKey);
      expect(statusStub).to.have.been.calledWith(200);
      expect(jsonSpy).to.have.been.calledWith(question);
    });

    it('getQuestion should call next if error occurred', async () => {
      getQuestionMock.throws(err);

      const req = {params: {questionKey}};
      const res = {};
      await IssuesRisksController.getRiskQuestion(req, res, nextSpy);

      expect(nextSpy.calledOnce).to.be.true;
      const error = nextSpy.firstCall.args[0];
      expect(error).to.be.instanceOf(Error);
      expect(error.message).to.eq(err);
    });
  });

  describe('Testing getQuestions', () => {
    beforeEach(function(done) {
      getServiceMock.returns({
        getQuestions: getQuestionsMock
      });
      done();
    });

    afterEach(function(done) {
      getServiceMock.reset();
      getQuestionsMock.reset();
      done();
    });

    it('getQuestions should call service', async () => {
      getQuestionsMock.resolves(result);

      const req = {query: {contractNbr}};
      const res = {status: statusStub};
      await IssuesRisksController.getRiskQuestions(req, res, nextSpy);

      expect(getQuestionsMock).to.have.been.calledWith(contractNbr);
      expect(statusStub).to.have.been.calledWith(200);
      expect(jsonSpy).to.have.been.calledWith(result);
    });

    it('getQuestions should call next if error occurred', async () => {
      getQuestionsMock.throws(err);
      nextSpy.resetHistory();

      const req = {query: {contractNbr}};
      const res = {};
      await IssuesRisksController.getRiskQuestions(req, res, nextSpy);

      expect(nextSpy.calledOnce).to.be.true;
      const error = nextSpy.firstCall.args[0];
      expect(error).to.be.instanceOf(Error);
      expect(error.message).to.eq(err);
    });
  });

  describe('Testing getRiskNba', () => {
    const getNbaMock = sinon.stub();
    beforeEach(function(done) {
      getServiceMock.returns({
        getNba: getNbaMock
      });
      done();
    });

    afterEach(function(done) {
      getServiceMock.reset();
      getNbaMock.reset();
      done();
    });

    it('getRiskNba should call service', async () => {
      getNbaMock.resolves([]);

      const req = {params: {questionKey}};
      const res = {status: statusStub};
      await IssuesRisksController.getRiskNba(req, res, nextSpy);

      expect(getNbaMock).to.have.been.calledWith(questionKey);
      expect(statusStub).to.have.been.calledWith(200);
      expect(jsonSpy).to.have.been.calledWith([]);
    });

    it('getRiskNba should call next if error occurred', async () => {
      getNbaMock.throws(err);
      nextSpy.resetHistory();

      const req = {params: {questionKey}};
      const res = {};
      await IssuesRisksController.getRiskNba(req, res, nextSpy);

      expect(nextSpy.calledOnce).to.be.true;
      const error = nextSpy.firstCall.args[0];
      expect(error).to.be.instanceOf(Error);
      expect(error.message).to.eq(err);
    });
  });

  describe('Testing getRiskHistory', () => {
    beforeEach(function(done) {
      getServiceMock.returns({
        getHistory: getHistoryMock
      });
      done();
    });

    afterEach(function(done) {
      getServiceMock.reset();
      getHistoryMock.reset();
      done();
    });

    it('getRiskHistory should call service', async () => {
      getHistoryMock.resolves(result);

      const req = {params: {historyKey, riskDetailsKey}};
      const res = {status: statusStub};
      await IssuesRisksController.getRiskHistory(req, res, nextSpy);

      expect(getHistoryMock).to.have.been.calledWith(historyKey, riskDetailsKey);
      expect(statusStub).to.have.been.calledWith(200);
      expect(jsonSpy).to.have.been.calledWith(result);
    });

    it('getRiskHistory should call next if error occurred', async () => {
      getHistoryMock.throws(err);
      nextSpy.resetHistory();

      const req = {params: {historyKey, riskDetailsKey}};
      const res = {};
      await IssuesRisksController.getRiskHistory(req, res, nextSpy);

      expect(nextSpy.calledOnce).to.be.true;
      const error = nextSpy.firstCall.args[0];
      expect(error).to.be.instanceOf(Error);
      expect(error.message).to.eq(err);
    });
  });

  describe('Testing getHistoryList', () => {
    beforeEach(function(done) {
      getServiceMock.returns({
        getHistoryList: getHistoryListMock
      });
      done();
    });

    afterEach(function(done) {
      getServiceMock.reset();
      getHistoryListMock.reset();
      done();
    });

    it('getRiskHistoryList should call service', async () => {
      getHistoryListMock.resolves(result);
      const req = {params: {riskDetailsKey}};
      const res = {status: statusStub};
      await IssuesRisksController.getRiskHistoryList(req, res, nextSpy);

      expect(getHistoryListMock).to.have.been.calledWith(riskDetailsKey);
      expect(statusStub).to.have.been.calledWith(200);
      expect(jsonSpy).to.have.been.calledWith(result);
    });

    it('getRiskHistoryList should call next if error occurred', async () => {
      getHistoryListMock.throws(err);

      const req = {params: {riskDetailsKey}};
      const res = {};
      await IssuesRisksController.getRiskHistoryList(req, res, nextSpy);

      expect(nextSpy.calledOnce).to.be.true;
      const error = nextSpy.firstCall.args[0];
      expect(error).to.be.instanceOf(Error);
      expect(error.message).to.eq(err);
    });
  });

  describe('Testing getContractScores', () => {
    beforeEach(function(done) {
      getServiceMock.returns({
        getContractScores: getContractScoresMock
      });
      done();
    });

    afterEach(function(done) {
      getServiceMock.reset();
      getContractScoresMock.reset();
      done();
    });

    it('getContractScores should call service', async () => {
      getContractScoresMock.resolves(result);
      const req = {query: {contractNbr}};
      const res = {status: statusStub};
      await IssuesRisksController.getContractScores(req, res, nextSpy);

      expect(statusStub).to.have.been.calledWith(200);
      expect(jsonSpy).to.have.been.calledWith(result);

      req.query.contractNbr = null;
      await IssuesRisksController.getContractScores(req, res, nextSpy);

      expect(statusStub).to.have.been.calledWith(200);
      expect(jsonSpy).to.have.been.calledWith(result);
    });

    it('getContractScores should call next if error occurred', async () => {
      getContractScoresMock.throws(err);
      nextSpy.resetHistory();

      const req = {query: {contractNbr}};
      const res = {};
      await IssuesRisksController.getContractScores(req, res, nextSpy);

      expect(nextSpy.calledOnce).to.be.true;
      const error = nextSpy.firstCall.args[0];
      expect(error).to.be.instanceOf(Error);
      expect(error.message).to.eq(err);
    });
  });

  describe('Testing createRiskDetails', () => {
    beforeEach(function(done) {
      getServiceMock.returns({
        createDetails: createDetailsMock
      });
      done();
    });

    afterEach(function(done) {
      createDetailsMock.reset();
      getDetailsMock.reset();
      done();
    });

    it('createRiskDetails should call service', async () => {
      createDetailsMock.resolves({
        RiskDetailsKey: 'stub'
      });
      const req = {body: {}};
      const res = {status: statusStub};
      await IssuesRisksController.createRiskDetails(req, res, nextSpy);

      expect(statusStub).to.have.been.calledWith(200);
      expect(jsonSpy).to.have.been.calledWith({
        RiskDetailsKey: 'stub'
      });
    });

    it('createRiskDetails should have message', async () => {
      createDetailsMock.resolves({
        RiskDetailsKey: 'stub',
        message: 'message'
      });
      const req = {body: {}};
      const res = {status: statusStub};
      await IssuesRisksController.createRiskDetails(req, res, nextSpy);

      expect(statusStub).to.have.been.calledWith(200);
      expect(jsonSpy).to.have.been.calledWith({
        RiskDetailsKey: 'stub',
        message: 'message'
      });
    });

    it('createRiskDetails return RiskDetailsKey with null', async () => {
      createDetailsMock.resolves({});
      const req = {body: {}};
      const res = {status: statusStub};
      await IssuesRisksController.createRiskDetails(req, res, nextSpy);

      expect(statusStub).to.have.been.calledWith(200);
      expect(jsonSpy).to.have.been.calledWith({
        RiskDetailsKey: null
      });
    });

    it('createRiskDetails should call next if error occurred', async () => {
      createDetailsMock.throws(err);
      nextSpy.resetHistory();

      const req = {body: {}};
      const res = {};
      await IssuesRisksController.createRiskDetails(req, res, nextSpy);

      expect(nextSpy.calledOnce).to.be.true;
      const error = nextSpy.firstCall.args[0];
      expect(error).to.be.instanceOf(Error);
      expect(error.message).to.eq(err);
    });
  });

  describe('Testing updateRiskDetails', () => {
    beforeEach(function(done) {
      getServiceMock.returns({
        updateDetails: updateDetailsMock,
        getDetails: getDetailsMock
      });
      done();
    });

    afterEach(function(done) {
      getServiceMock.reset();
      updateDetailsMock.reset();
      done();
    });

    it('updateRiskDetails should call service', async () => {
      updateDetailsMock.resolves({
        RiskDetailsKey: 'stub'
      });
      const req = {
        params: {RiskDetailsKey: 'stub'},
        body: {},
        headers: {authorization: ''}
      };
      const res = {status: statusStub};
      await IssuesRisksController.updateRiskDetails(req, res, nextSpy);

      expect(statusStub).to.have.been.calledWith(200);
      expect(jsonSpy).to.have.been.calledWith({
        RiskDetailsKey: 'stub'
      });
    });

    it('updateRiskDetails return RiskDetailsKey with null', async () => {
      updateDetailsMock.resolves({});
      const req = {
        params: {RiskDetailsKey: 'stub'},
        body: {},
        headers: {authorization: ''}
      };
      const res = {status: statusStub};
      await IssuesRisksController.updateRiskDetails(req, res, nextSpy);

      expect(statusStub).to.have.been.calledWith(200);
      expect(jsonSpy).to.have.been.calledWith({
        RiskDetailsKey: null
      });
    });

    it('updateRiskDetails should call next if error occurred', async () => {
      updateDetailsMock.throws(err);
      nextSpy.resetHistory();

      const req = {
        params: {riskDetailsKey},
        body: {},
        headers: {authorization: ''}
      };
      const res = {};
      await IssuesRisksController.updateRiskDetails(req, res, nextSpy);

      expect(nextSpy.calledOnce).to.be.true;
      const error = nextSpy.firstCall.args[0];
      expect(error).to.be.instanceOf(Error);
      expect(error.message).to.eq(err);
    });
  });

  describe('Testing createRiskFeedback', () => {
    beforeEach(function(done) {
      getServiceMock.returns({
        createFeedback: createFeedbackMock,
        getFeedbackRating: getFeedbackRatingMock
      });
      done();
    });

    afterEach(function(done) {
      createFeedbackMock.reset();
      done();
    });

    it('createFeedback should call service', async () => {
      createFeedbackMock.resolves({
        RiskFeedbackKey: 'stub'
      });
      const req = {body: {}};
      const res = {status: statusStub};
      await IssuesRisksController.createRiskFeedback(req, res, nextSpy);

      expect(statusStub).to.have.been.calledWith(200);
      expect(jsonSpy).to.have.been.calledWith({
        RiskFeedbackKey: 'stub'
      });
    });

    it('createRiskFeedback should call next if error occurred', async () => {
      createFeedbackMock.throws(err);

      const req = {body: {}};
      const res = {};
      await IssuesRisksController.createRiskFeedback(req, res, nextSpy);

      expect(nextSpy.calledOnce).to.be.true;
      const error = nextSpy.firstCall.args[0];
      expect(error).to.be.instanceOf(Error);
      expect(error.message).to.eq(err);
    });
  });

  describe('Testing getCCDownload', () => {
    let getDownloadItemByEidStub;

    before(function(done) {
      getDownloadItemByEidStub = sinon.stub(consultationCallExportService, 'getDownloadItemByEid');
      done();
    });

    afterEach(function(done) {
      getDownloadItemByEidStub.reset();
      done();
    });

    after(function(done) {
      getDownloadItemByEidStub.restore();
      done();
    });

    it('getCCDownload should call service', async () => {
      getDownloadItemByEidStub.resolves({});
      const req = {};
      const res = {status: statusStub};
      await IssuesRisksController.getCCDownload(req, res, nextSpy);

      expect(getDownloadItemByEidStub).to.have.been.called;
      expect(statusStub).to.have.been.calledWith(200);
      expect(jsonSpy).to.have.been.calledWith({data: {}});
    });

    it('getCCDownload should call next if error occurred', async () => {
      getDownloadItemByEidStub.throws(err);

      const req = {};
      const res = {};
      await IssuesRisksController.getCCDownload(req, res, nextSpy);

      expect(nextSpy.calledOnce).to.be.true;
      const error = nextSpy.firstCall.args[0];
      expect(error).to.be.instanceOf(Error);
      expect(error.message).to.eq(err);
    });
  });

  describe('Testing updateCCDownloadStatus', () => {
    let updateDownloadStatusStub;

    before(function(done) {
      updateDownloadStatusStub = sinon.stub(consultationCallExportService, 'updateDownloadStatus');
      done();
    });

    afterEach(function(done) {
      updateDownloadStatusStub.reset();
      done();
    });

    after(function(done) {
      updateDownloadStatusStub.restore();
      done();
    });

    it('updateCCDownloadStatus should call service', async () => {
      updateDownloadStatusStub.resolves({});
      const req = {query: {downloadKey: 'stub', status: 'stub'}};
      const res = {status: statusStub};
      await IssuesRisksController.updateCCDownloadStatus(req, res, nextSpy);

      expect(updateDownloadStatusStub).to.have.been.called;
      expect(statusStub).to.have.been.calledWith(200);
      expect(jsonSpy).to.have.been.calledWith({data: {}});
    });

    it('updateCCDownloadStatus should call next if error occurred', async () => {
      updateDownloadStatusStub.throws(err);
      const req = {query: {downloadKey: 'stub', status: 'stub'}};
      const res = {};
      await IssuesRisksController.updateCCDownloadStatus(req, res, nextSpy);

      expect(nextSpy.calledOnce).to.be.true;
      const error = nextSpy.firstCall.args[0];
      expect(error).to.be.instanceOf(Error);
      expect(error.message).to.eq(err);
    });
  });

  describe('Testing postCCDownload', () => {
    let insertDownloadItemStub;
    let exportConsultationCallStub;

    before(function(done) {
      insertDownloadItemStub = sinon.stub(consultationCallExportService, 'insertDownloadItem');
      exportConsultationCallStub = sinon.stub(consultationCallExportService, 'exportConsultationCall');
      done();
    });

    afterEach(function(done) {
      insertDownloadItemStub.reset();
      exportConsultationCallStub.reset();
      done();
    });

    after(function(done) {
      insertDownloadItemStub.restore();
      exportConsultationCallStub.restore();
      done();
    });

    it('postCCDownload should call service insertDownloadItem', async () => {
      insertDownloadItemStub.resolves(true);
      exportConsultationCallStub.resolves({});
      const req = {query: {startdate: 'stub', enddate: 'stub'}};
      const res = {status: statusStub};
      await IssuesRisksController.postCCDownload(req, res, nextSpy);

      expect(insertDownloadItemStub).to.have.been.called;
      expect(exportConsultationCallStub).to.have.been.called;
      expect(statusStub).to.have.been.calledWith(200);
      expect(jsonSpy).to.have.been.calledWith({data: 'ok'});
    });

    it('postCCDownload should not call service insertDownloadItem', async () => {
      insertDownloadItemStub.resolves(false);
      exportConsultationCallStub.resolves({});
      const req = {query: {startdate: 'stub', enddate: 'stub'}};
      const res = {};
      await IssuesRisksController.postCCDownload(req, res, nextSpy);

      expect(insertDownloadItemStub).to.have.been.called;
      expect(exportConsultationCallStub).to.not.have.been.called;
    });

    it('postCCDownload should call next if error occurred', async () => {
      insertDownloadItemStub.throws(err);
      const req = {query: {startdate: 'stub', enddate: 'stub'}};
      const res = {};
      await IssuesRisksController.postCCDownload(req, res, nextSpy);

      expect(nextSpy.calledOnce).to.be.true;
      const error = nextSpy.firstCall.args[0];
      expect(error).to.be.instanceOf(Error);
      expect(error.message).to.eq(err);
    });
  });

  describe('Testing isGlobalCM', () => {
    let isGlobalCMStub;

    before(function(done) {
      isGlobalCMStub = sinon.stub(consultationCallExportService, 'isGlobalCM');
      done();
    });

    afterEach(function(done) {
      isGlobalCMStub.reset();
      done();
    });

    after(function(done) {
      isGlobalCMStub.restore();
      done();
    });

    it('isGlobalCM should call service', async () => {
      isGlobalCMStub.resolves({});
      const req = {};
      const res = {status: statusStub};
      await IssuesRisksController.isGlobalCM(req, res, nextSpy);

      expect(isGlobalCMStub).to.have.been.called;
      expect(statusStub).to.have.been.calledWith(200);
      expect(jsonSpy).to.have.been.calledWith({data: {}});
    });

    it('isGlobalCM should call next if error occurred', async () => {
      isGlobalCMStub.throws(err);
      const req = {};
      const res = {};
      await IssuesRisksController.isGlobalCM(req, res, nextSpy);

      expect(nextSpy.calledOnce).to.be.true;
      const error = nextSpy.firstCall.args[0];
      expect(error).to.be.instanceOf(Error);
      expect(error.message).to.eq(err);
    });
  });

  describe('Testing getService', () => {
    const getInstanceSpy = sinon.spy(IssuesRisksService, 'getInstance');
    beforeEach(function(done) {
      getServiceMock.restore();
      done();
    });

    afterEach(function(done) {
      getInstanceSpy.resetHistory();
      done();
    });

    after(function(done) {
      getInstanceSpy.restore();
      done();
    });

    it('getService should call getInstance of IssuesRisksService', async () => {
      IssuesRisksController.getService();

      expect(getInstanceSpy).to.have.been.called;
    });
  });
});
