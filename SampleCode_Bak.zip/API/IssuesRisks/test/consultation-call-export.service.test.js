process.env.NODE_ENV = 'test';
process.env.ORION_APPSPOT_BUCKET_NAME = 'test';
process.env.TEMPLATE_BASE_PATH = './';
// const should = require('chai').should();
const expect = require('chai').expect;
// const assert = require('chai').assert;
const sinon = require('sinon');
const moment = require('moment');
const fs = require('fs');
const ejsExcel = require('ejsexcel');

const ConsultationCallExportRepository = require('../server/consultation-call-export.repository');
const ConsultationCallExportService = require('../server/consultation-call-export.service');
const TestDataConsulatationCall = require('./test-data-consulatation-call');

describe('Testing ConsultationCallExportService', () => {
  describe('Testing isGlobalCM', () => {
    let isGlobalCMStub = null;
    beforeEach(function(done) {
      isGlobalCMStub = sinon.stub(ConsultationCallExportRepository, 'isGlobalCM');
      done();
    });

    afterEach(function(done) {
      isGlobalCMStub.restore();
      done();
    });

    it('should call isGlobalCM', async () => {
      isGlobalCMStub.returns([{count: 2}]);
      const result = await ConsultationCallExportService.isGlobalCM('cong.wu');
      expect(ConsultationCallExportRepository.isGlobalCM.calledWith('cong.wu'));
      expect(result).to.be.eq(true);
    });

    it('should call isGlobalCM return false', async () => {
      isGlobalCMStub.returns([{count: undefined}]);
      const result = await ConsultationCallExportService.isGlobalCM('cong.wu');
      expect(ConsultationCallExportRepository.isGlobalCM.calledWith('cong.wu'));
      expect(result).to.be.eq(false);
    });
  });

  describe('Testing getDownloadItemByEid', () => {
    let getDownloadItemByEidStub = null;
    let updateDownloadStatusStub = null;
    beforeEach(function(done) {
      getDownloadItemByEidStub = sinon.stub(ConsultationCallExportRepository, 'getDownloadItemByEid');
      updateDownloadStatusStub = sinon.stub(ConsultationCallExportRepository, 'updateDownloadStatus');
      done();
    });

    afterEach(function(done) {
      getDownloadItemByEidStub.restore();
      updateDownloadStatusStub.restore();
      done();
    });
    it('should call getDownloadItemByEid with empty content', async () => {
      getDownloadItemByEidStub.returns([]);

      const result = await ConsultationCallExportService.getDownloadItemByEid('cong.wu');
      expect(ConsultationCallExportRepository.getDownloadItemByEid.calledWith('cong.wu'));
      expect(result).to.be.eq(undefined);
    });

    it('should call getDownloadItemByEid', async () => {
      getDownloadItemByEidStub.returns([
        {
          UpdateDttm: new Date(),
          Status: 'Success',
          DownloadKey: '12345'
        }
      ]);

      const result = await ConsultationCallExportService.getDownloadItemByEid('cong.wu');
      expect(ConsultationCallExportRepository.getDownloadItemByEid.calledWith('cong.wu'));
      expect(result.Status).to.be.eq('Success');
    });

    it('should call repository and update status', async () => {
      getDownloadItemByEidStub.returns([
        {
          UpdateDttm: moment(new Date())
            .add(-10, 'm')
            .toDate(),
          Status: 'In Progress',
          DownloadKey: '12345'
        }
      ]);

      updateDownloadStatusStub.returns([{}]);

      const result = await ConsultationCallExportService.getDownloadItemByEid('cong.wu');
      expect(ConsultationCallExportRepository.getDownloadItemByEid.calledWith('cong.wu'));
      expect(result.Status).to.be.eq('Failed');
    });
  });

  describe('Testing insertDownloadItem', () => {
    let insertDownloadItemStub = null;
    beforeEach(function(done) {
      insertDownloadItemStub = sinon.stub(ConsultationCallExportRepository, 'insertDownloadItem');
      done();
    });

    afterEach(function(done) {
      insertDownloadItemStub.restore();
      done();
    });

    it('should call insertDownloadItem', async () => {
      insertDownloadItemStub.returns([{}]);
      await ConsultationCallExportService.insertDownloadItem('cong.wu', '123');
      expect(ConsultationCallExportRepository.insertDownloadItem.call());
    });
  });

  describe('Testing updateDownloadStatus', () => {
    let updateDownloadStatusStub = null;
    beforeEach(function(done) {
      updateDownloadStatusStub = sinon.stub(ConsultationCallExportRepository, 'updateDownloadStatus');
      done();
    });

    afterEach(function(done) {
      updateDownloadStatusStub.restore();
      done();
    });
    it('should call updateDownloadStatus', async () => {
      updateDownloadStatusStub.returns([{}]);
      await ConsultationCallExportService.updateDownloadStatus('123', '123');
      expect(ConsultationCallExportRepository.updateDownloadStatus.call());
    });
  });

  describe('Testing renderExcel', () => {
    let readFileSyncStub = null;
    let renderExcelStub = null;
    let writeFileSyncStub = null;
    beforeEach(function(done) {
      readFileSyncStub = sinon.stub(fs, 'readFileSync');
      renderExcelStub = sinon.stub(ejsExcel, 'renderExcel');
      writeFileSyncStub = sinon.stub(fs, 'writeFileSync');
      done();
    });

    afterEach(function(done) {
      readFileSyncStub.restore();
      renderExcelStub.restore();
      writeFileSyncStub.restore();
      done();
    });

    it('should call renderExcel', async () => {
      readFileSyncStub.returns({});
      renderExcelStub.returns({});
      writeFileSyncStub.returns({});
      await ConsultationCallExportService.renderExcel('123', '123', '123');
      expect(fs.writeFileSync.call());
    });
  });

  describe('Testing uploadExcelToGCPStorage', () => {
    const bucket = {upload: function() {}};
    let storageStub = null;
    let uploadStub = null;
    beforeEach(function(done) {
      storageStub = sinon.stub(ConsultationCallExportService.storage, 'bucket').returns(bucket);
      uploadStub = sinon.stub(bucket, 'upload').returns({});
      done();
    });

    afterEach(function(done) {
      storageStub.restore();
      uploadStub.restore();
      done();
    });

    it('should call uploadExcelToGCPStorage', async () => {
      const bucket = {upload: function() {}};
      storageStub.returns(bucket);
      uploadStub.returns({});
      await ConsultationCallExportService.uploadExcelToGCPStorage('123', 'server/templates/Risks & Issues sent to CC Template.xlsx');
      expect(ConsultationCallExportService.storage.bucket.call());
    });
  });

  describe('Testing getSignedUrl', () => {
    const bucket = {
      file: function() {
        return {
          getSignedUrl: function() {
            return new Promise(function(resolve) {
              resolve('');
            });
          }
        };
      }
    };
    let storageStub = null;
    beforeEach(function(done) {
      storageStub = sinon.stub(ConsultationCallExportService.storage, 'bucket').returns(bucket);
      done();
    });

    afterEach(function(done) {
      storageStub.restore();
      done();
    });

    it('should call getSignedUrl', async () => {
      storageStub.returns(bucket);
      await ConsultationCallExportService.getSignedUrl('123', '123');
      expect(ConsultationCallExportService.storage.bucket.call());
    });
  });

  describe('Testing getFileMetadata', () => {
    const bucket = {
      file: function() {
        return {
          getMetadata: function() {
            return new Promise(function(resolve) {
              resolve('');
            });
          }
        };
      }
    };
    let storageStub = null;
    beforeEach(function(done) {
      storageStub = sinon.stub(ConsultationCallExportService.storage, 'bucket').returns(bucket);
      done();
    });

    afterEach(function(done) {
      storageStub.restore();
      done();
    });

    it('should call getFileMetadata', async () => {
      storageStub.returns(bucket);
      await ConsultationCallExportService.getFileMetadata('123', '123');
      expect(ConsultationCallExportService.storage.bucket.call());
    });
  });

  describe('Testing fsExistsSync', () => {
    let accessSyncStub = null;
    beforeEach(function(done) {
      accessSyncStub = sinon.stub(fs, 'accessSync');
      done();
    });
    afterEach(function(done) {
      accessSyncStub.restore();
      done();
    });

    it('should call fsExistsSync return true', () => {
      accessSyncStub.returns({});
      const result = ConsultationCallExportService.fsExistsSync('123');
      expect(fs.accessSync.call());
      expect(result).to.be.true;
    });

    it('should call fsExistsSync return false', () => {
      accessSyncStub.throws(new Error('err'));
      const result = ConsultationCallExportService.fsExistsSync('123');
      expect(result).to.be.false;
    });
  });

  describe('Testing removefileForLocal', () => {
    let unlinkSyncStub = null;
    beforeEach(function(done) {
      unlinkSyncStub = sinon.stub(fs, 'unlinkSync');
      done();
    });
    afterEach(function(done) {
      unlinkSyncStub.restore();
      done();
    });

    it('should call removefileForLocal', () => {
      unlinkSyncStub.returns(function() {});
      ConsultationCallExportService.removefileForLocal('123');
      expect(fs.unlinkSync.call());
    });

    it('should call removefileForLocal throw error', () => {
      unlinkSyncStub.throws(new Error('Err'));
      try {
        ConsultationCallExportService.removefileForLocal('123');
      } catch (err) {
        expect(err.message).to.contains('Err');
      }
    });
  });

  describe('Testing exportConsultationCall', () => {
    let accessSyncStub = null;
    let mkdirSyncStub = null;

    let getAllConsultationCallsStub = null;
    let getAllRiskConsCallFinRevenueCCIStub = null;
    let getAllInvolvedPartyStub = null;
    let getAllLeadReviewStub = null;
    let getAllMitigationStub = null;
    let getAllCodeDetailStub = null;

    let readFileSyncStub = null;
    let renderExcelStub = null;
    let writeFileSyncStub = null;

    const bucket = {
      upload: function() {},
      file: function() {
        return {
          getSignedUrl: function() {
            return new Promise(function(resolve) {
              resolve('');
            });
          },
          getMetadata: function() {
            return new Promise(function(resolve) {
              resolve([{size: 1}]);
            });
          }
        };
      }
    };
    let storageStub = null;
    let uploadStub = null;

    let getDownloadItemByKeyStub = null;
    let updateDownloadItemStub = null;

    let unlinkSyncStub = null;
    let updateDownloadStatusStub = null;

    beforeEach(function(done) {
      accessSyncStub = sinon.stub(fs, 'accessSync');
      mkdirSyncStub = sinon.stub(fs, 'mkdirSync');

      getAllConsultationCallsStub = sinon.stub(ConsultationCallExportRepository, 'getAllConsultationCalls');
      getAllRiskConsCallFinRevenueCCIStub = sinon.stub(ConsultationCallExportRepository, 'getAllRiskConsCallFinRevenueCCI');
      getAllInvolvedPartyStub = sinon.stub(ConsultationCallExportRepository, 'getAllInvolvedParty');
      getAllLeadReviewStub = sinon.stub(ConsultationCallExportRepository, 'getAllLeadReview');
      getAllMitigationStub = sinon.stub(ConsultationCallExportRepository, 'getAllMitigation');
      getAllCodeDetailStub = sinon.stub(ConsultationCallExportRepository, 'getAllCodeDetail');

      readFileSyncStub = sinon.stub(fs, 'readFileSync');
      renderExcelStub = sinon.stub(ejsExcel, 'renderExcel');
      writeFileSyncStub = sinon.stub(fs, 'writeFileSync');

      storageStub = sinon.stub(ConsultationCallExportService.storage, 'bucket').returns(bucket);
      uploadStub = sinon.stub(bucket, 'upload').returns({});

      getDownloadItemByKeyStub = sinon.stub(ConsultationCallExportRepository, 'getDownloadItemByKey');

      updateDownloadItemStub = sinon.stub(ConsultationCallExportRepository, 'updateDownloadItem');

      unlinkSyncStub = sinon.stub(fs, 'unlinkSync');
      updateDownloadStatusStub = sinon.stub(ConsultationCallExportRepository, 'updateDownloadStatus');

      done();
    });
    afterEach(function(done) {
      accessSyncStub.restore();
      mkdirSyncStub.restore();

      getAllConsultationCallsStub.restore();
      getAllRiskConsCallFinRevenueCCIStub.restore();
      getAllInvolvedPartyStub.restore();
      getAllLeadReviewStub.restore();
      getAllMitigationStub.restore();
      getAllCodeDetailStub.restore();

      readFileSyncStub.restore();
      renderExcelStub.restore();
      writeFileSyncStub.restore();

      storageStub.restore();
      uploadStub.restore();

      getDownloadItemByKeyStub.restore();
      updateDownloadItemStub.restore();
      unlinkSyncStub.restore();
      updateDownloadStatusStub.restore();
      done();
    });

    it('should call exportConsultationCall', async () => {
      let eid = 'cong.wu';
      let downloadKey = '123';
      let startdate = '2019-10-10';
      let enddate = '2019-10-11';
      getAllConsultationCallsStub.returns(TestDataConsulatationCall.consultationCalls);
      getAllRiskConsCallFinRevenueCCIStub.returns(TestDataConsulatationCall.consCallFinRevenueCCIs);
      getAllInvolvedPartyStub.returns(TestDataConsulatationCall.involvedParties);
      getAllLeadReviewStub.returns(TestDataConsulatationCall.leadReviews);
      getAllMitigationStub.returns(TestDataConsulatationCall.mitigations);
      getAllCodeDetailStub.returns(TestDataConsulatationCall.codeDetails);

      getDownloadItemByKeyStub.returns(TestDataConsulatationCall.downloadItems);

      await ConsultationCallExportService.exportConsultationCall(eid, downloadKey, startdate, enddate);

      expect(ConsultationCallExportRepository.getDownloadItemByKey.call());
    });

    it('should call exportConsultationCall without start date and end date', async () => {
      let eid = 'cong.wu';
      let downloadKey = '123';
      let startdate = '';
      let enddate = '';
      getAllConsultationCallsStub.returns(TestDataConsulatationCall.consultationCalls);
      getAllRiskConsCallFinRevenueCCIStub.returns(TestDataConsulatationCall.consCallFinRevenueCCIs);
      getAllInvolvedPartyStub.returns(TestDataConsulatationCall.involvedParties);
      getAllLeadReviewStub.returns(TestDataConsulatationCall.leadReviews);
      getAllMitigationStub.returns(TestDataConsulatationCall.mitigations);
      getAllCodeDetailStub.returns(TestDataConsulatationCall.codeDetails);

      getDownloadItemByKeyStub.returns(TestDataConsulatationCall.downloadItems);

      await ConsultationCallExportService.exportConsultationCall(eid, downloadKey, startdate, enddate);

      expect(ConsultationCallExportRepository.getDownloadItemByKey.call());
    });

    it('should call exportConsultationCall include creating a temp folder', async () => {
      let eid = 'cong.wu';
      let downloadKey = '123';
      let startdate = '2019-10-10';
      let enddate = '2019-10-11';
      try {
        accessSyncStub.throws(new Error('err'));
      } catch (error) {
        expect(fs.mkdirSync.call());
      }

      getAllConsultationCallsStub.returns(TestDataConsulatationCall.consultationCalls);
      getAllRiskConsCallFinRevenueCCIStub.returns(TestDataConsulatationCall.consCallFinRevenueCCIs);
      getAllInvolvedPartyStub.returns(TestDataConsulatationCall.involvedParties);
      getAllLeadReviewStub.returns(TestDataConsulatationCall.leadReviews);
      getAllMitigationStub.returns(TestDataConsulatationCall.mitigations);
      getAllCodeDetailStub.returns(TestDataConsulatationCall.codeDetails);

      getDownloadItemByKeyStub.returns(TestDataConsulatationCall.downloadItems);

      try {
        await ConsultationCallExportService.exportConsultationCall(eid, downloadKey, startdate, enddate);
      } catch (error) {
        expect(fs.accessSync.call());
        expect(ConsultationCallExportRepository.getDownloadItemByKey.call());
      }
    });

    it('should call exportConsultationCall exclude creating a temp folder', async () => {
      let eid = 'cong.wu';
      let downloadKey = '123';
      let startdate = '2019-10-10';
      let enddate = '2019-10-11';

      accessSyncStub.returns({});
      getAllConsultationCallsStub.returns(TestDataConsulatationCall.consultationCalls);
      getAllRiskConsCallFinRevenueCCIStub.returns(TestDataConsulatationCall.consCallFinRevenueCCIs);
      getAllInvolvedPartyStub.returns(TestDataConsulatationCall.involvedParties);
      getAllLeadReviewStub.returns(TestDataConsulatationCall.leadReviews);
      getAllMitigationStub.returns(TestDataConsulatationCall.mitigations);
      getAllCodeDetailStub.returns(TestDataConsulatationCall.codeDetails);

      getDownloadItemByKeyStub.returns(TestDataConsulatationCall.downloadItems);

      await ConsultationCallExportService.exportConsultationCall(eid, downloadKey, startdate, enddate);
      expect(fs.accessSync.call());
      expect(ConsultationCallExportRepository.getDownloadItemByKey.call());
    });

    it('should call exportConsultationCall without changing download record', async () => {
      let eid = 'cong.wu';
      let downloadKey = '123';
      let startdate = '2019-10-10';
      let enddate = '2019-10-11';

      accessSyncStub.returns({});
      getAllConsultationCallsStub.returns(TestDataConsulatationCall.consultationCalls);
      getAllRiskConsCallFinRevenueCCIStub.returns(TestDataConsulatationCall.consCallFinRevenueCCIs);
      getAllInvolvedPartyStub.returns(TestDataConsulatationCall.involvedParties);
      getAllLeadReviewStub.returns(TestDataConsulatationCall.leadReviews);
      getAllMitigationStub.returns(TestDataConsulatationCall.mitigations);
      getAllCodeDetailStub.returns(TestDataConsulatationCall.codeDetails);

      getDownloadItemByKeyStub.returns([]);

      await ConsultationCallExportService.exportConsultationCall(eid, downloadKey, startdate, enddate);
      expect(fs.accessSync.call());
    });

    it('should call exportConsultationCall throw error', async () => {
      let eid = 'cong.wu';
      let downloadKey = '123';
      let startdate = '2019-10-10';
      let enddate = '2019-10-11';
      getAllConsultationCallsStub.returns(TestDataConsulatationCall.consultationCalls);
      getAllRiskConsCallFinRevenueCCIStub.returns(TestDataConsulatationCall.consCallFinRevenueCCIs);
      getAllInvolvedPartyStub.returns(TestDataConsulatationCall.involvedParties);
      getAllLeadReviewStub.returns(TestDataConsulatationCall.leadReviews);
      getAllMitigationStub.returns(TestDataConsulatationCall.mitigations);
      getAllCodeDetailStub.returns(TestDataConsulatationCall.codeDetails);

      getDownloadItemByKeyStub.throws(new Error('Err'));
      try {
        await ConsultationCallExportService.exportConsultationCall(eid, downloadKey, startdate, enddate);
      } catch (error) {
        expect(ConsultationCallExportRepository.updateDownloadStatus.call());
        expect(error.message).to.eq('Err');
      }
    });
  });
});
