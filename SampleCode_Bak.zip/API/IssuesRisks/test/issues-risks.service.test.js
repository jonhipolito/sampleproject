process.env.NODE_ENV = 'test';

const expect = require('chai').expect;
const sinon = require('sinon');
const {describe, beforeEach, afterEach, after, it} = require('mocha');

const IssuesRisksService = require('../server/issues-risks.service');
const IssuesRisksRepository = require('../server/issues-risks.repository');

describe('Testing IssuesRisksService', () => {
  describe('Testing getService', () => {
    let getInstanceStub;
    after(function(done) {
      getInstanceStub.restore();
      done();
    });

    it('getService should call getInstance of IssuesRisksRepository', async () => {
      getInstanceStub = sinon.stub(IssuesRisksRepository, 'getInstance');
      const instance = new IssuesRisksRepository();
      getInstanceStub.returns(instance);
      IssuesRisksService.getInstance();
      expect(getInstanceStub).to.be.have.been.called;
    });
  });

  describe('Testing getDetails', () => {
    const riskDetailsKey = 'b1eeeec5-5797-4997-894d-8329531b4183';
    const RiskSourceCd = '101201';

    const getStub = sinon.stub().resolves({
      RiskDetailsKey: riskDetailsKey,
      RiskSourceCd: RiskSourceCd,
      Mitigations: [{}],
      LeadReviews: [{}],
      ConsultationCall: [{}] || {},
      ConsultationCallParties: [{}],
      ConsultationCallFinRevenueCCI: [{}]
    });

    const service = new IssuesRisksService({
      get: getStub
    });

    it('getDetails should call repository', async () => {
      const result = await service.getDetails(riskDetailsKey);
      expect(getStub.calledWith(riskDetailsKey));
      expect(result).to.deep.eq({
        RiskDetailsKey: riskDetailsKey,
        RiskSourceCd,
        Mitigations: [{}],
        LeadReviews: [{}],
        ConsultationCall: [{}] || {},
        ConsultationCallParties: [{}],
        ConsultationCallFinRevenueCCI: [{}]
      });
    });
  });

  describe('Testing createDetails', () => {
    const riskDetailsKey = 'b1eeeec5-5797-4997-894d-8329531b4183';

    const addStub = sinon.stub();
    const addRiskIDStub = sinon.stub();

    const service = new IssuesRisksService({
      addRisk: addStub,
      addRiskID: addRiskIDStub
    });

    beforeEach(function(done) {
      addStub.resolves(riskDetailsKey);
      addRiskIDStub.resolves(true);
      done();
    });

    afterEach(function(done) {
      addStub.reset();
      addRiskIDStub.reset();
      done();
    });

    it('createDetails should call repository', async () => {
      const result = await service.createDetails({Mitigations: [{AssigneeUserId: 'stub'}, {AssigneeUserId: null}]});

      expect(addStub.calledWith(riskDetailsKey));

      expect(result).to.eq(riskDetailsKey);
    });

    it('createDetails without Mitigations  should call repository', async () => {
      const result = await service.createDetails({Mitigations: null});

      expect(addStub.calledWith(riskDetailsKey));

      expect(result).to.eq(riskDetailsKey);
    });

    it('createDetails should retry', async () => {
      addStub.throws(new Error('err'));
      try {
        await service.createDetails({Mitigations: [{AssigneeUserId: 'eid'}]});
      } catch (err) {
        expect(err.message).to.eq('RETRY_FAILED: Exceeded max retry attempts');
      }
    });

    it('createDetails should throw ex', async () => {
      addStub.throws(new Error('ISSUES_RISKS_ERROR: question is being rated by others'));
      try {
        await service.createDetails({Mitigations: [{AssigneeUserId: 'eid'}]});
      } catch (err) {
        expect(err.message).to.eq('ISSUES_RISKS_ERROR: question is being rated by others');
      }
    });
  });

  describe('Testing updateDetails', () => {
    const riskDetailsKey = 'b1eeeec5-5797-4997-894d-8329531b4183';
    const updateStub = sinon.stub().resolves(riskDetailsKey);
    const addRiskIDStub = sinon.stub().resolves(true);
    const service = new IssuesRisksService({
      updateRisk: updateStub,
      addRiskID: addRiskIDStub
    });

    it('updateDetails should call repository', async () => {
      const result = await service.updateDetails(riskDetailsKey, {
        Mitigations: [{AssigneeUserId: 'stub'}, {AssigneeUserId: null, MitigationNbr: null}, {AssigneeUserId: 'stub', MitigationNbr: ''}]
      });

      expect(updateStub.calledWith(riskDetailsKey));

      expect(result).to.eq(riskDetailsKey);
    });

    it('updateDetails should retry', async () => {
      updateStub.throws('err');
      try {
        await service.updateDetails(riskDetailsKey, {});
      } catch (err) {
        expect(err.message).to.eq('RETRY_FAILED: Exceeded max retry attempts');
      }
    });

    it('updateDetails should throw ex', async () => {
      updateStub.throws(new Error('ISSUES_RISKS_ERROR: question is being rated by others'));
      try {
        await service.updateDetails(riskDetailsKey, {Mitigations: [{AssigneeUserId: 'eid'}]});
      } catch (err) {
        expect(err.message).to.eq('ISSUES_RISKS_ERROR: question is being rated by others');
      }
    });
  });

  describe('Testing getCodes', () => {
    const getCodesByCategorySub = sinon.stub();
    getCodesByCategorySub.resolves([{CodeDetailId: 1}]);
    getCodesByCategorySub.withArgs('RiskConsultationCallInvolvedParty').resolves([{CodeDetailId: 2}]);
    const getCodesByParentCategorySub = sinon.stub().resolves([{CodeDetailId: 3, ParentId: 2}]);
    const service = new IssuesRisksService({
      getCodesByCategory: getCodesByCategorySub,
      getCodesByParentCategory: getCodesByParentCategorySub
    });

    it('getCodes should call repository', async () => {
      const result = await service.getCodes('');
      expect(result).to.deep.eq([]);

      const result2 = await service.getCodes('Types');
      expect(result2).to.deep.eq([{CodeDetailId: 1}]);

      const result3 = await service.getCodes('Parties');
      expect(result3).to.deep.eq([{CodeDetailId: 2, Children: [{CodeDetailId: 3, ParentId: 2}]}]);

      expect(getCodesByCategorySub.calledWith('RiskType'));
      expect(getCodesByCategorySub.calledWith('RiskConsultationCallInvolvedParty'));
      expect(getCodesByParentCategorySub.calledWith('RiskConsultationCallInvolvedParty'));
    });
  });

  describe('Testing getHistoryList', () => {
    const riskDetailsKey = 'b1eeeec5-5797-4997-894d-8329531b4183';
    const getHistoriesSub = sinon.stub().resolves(riskDetailsKey);
    const service = new IssuesRisksService({
      getHistories: getHistoriesSub
    });

    it('getHistoryList should call repository', async () => {
      const result = await service.getHistoryList({});

      expect(getHistoriesSub.calledWith(riskDetailsKey));
      expect(result).to.eq(riskDetailsKey);
    });
  });

  describe('Testing getQuestion', () => {
    const riskAssessmentQuestionKey = '4a4934c2-97e3-4935-85ad-b6ffa789195b';
    const question = {
      CategoryCd: 'CCD',
      SubCategoryCd: 'SCCD',
      RiskQuestionCd: 'RQCD',
      StatementArr: []
    };
    const getQuestionSub = sinon.stub().resolves(question);
    const getCodeSub = sinon.stub().resolves({PrimaryDecodeTxt: 'PDT', SecondaryDecodeTxt: 'SDT'});
    const getCodesSub = sinon.stub().resolves([{}]);

    const service = new IssuesRisksService({
      getQuestion: getQuestionSub,
      getCode: getCodeSub,
      getCodes: getCodesSub
    });

    it('getQuestion should call repository', async () => {
      const result = await service.getQuestion(riskAssessmentQuestionKey);

      expect(getQuestionSub.calledWith(riskAssessmentQuestionKey));
      expect(getCodeSub.calledWith(question.CategoryCd));
      expect(getCodeSub.calledWith(question.SubCategoryCd));
      expect(getCodeSub.calledWith(question.RiskQuestionCd));
      expect(getCodesSub.calledWith(result.StatementArr));

      expect(result).to.deep.eq({
        Question: {PrimaryDecodeTxt: 'PDT', SecondaryDecodeTxt: 'SDT'},
        Statements: [{}],
        Category: 'PDT',
        CategoryMaterialLink: 'SDT',
        SubCategory: 'PDT'
      });
    });
  });

  describe('Testing getQuestions', () => {
    const riskDetailsKey = 'b1eeeec5-5797-4997-894d-8329531b4183';
    const masterClientNbr = '0';
    const customerNbr = '0';
    const contractNbr = '0';
    const getQuestionsSub = sinon.stub().resolves(riskDetailsKey);
    const service = new IssuesRisksService({
      getQuestions: getQuestionsSub
    });

    it('getQuestions should call repository', async () => {
      const result = await service.getQuestions({});

      expect(getQuestionsSub.calledWith(masterClientNbr, customerNbr, contractNbr));

      expect(result).to.eq(riskDetailsKey);
    });
  });

  describe('Testing getHistory', () => {
    const riskDetailsKey = 'b1eeeec5-5797-4997-894d-8329531b4183';
    const historyKey = '';
    const getHistorySub = sinon.stub().resolves({ContentTxt: `{ "key": 1 }`});
    const service = new IssuesRisksService({
      getHistory: getHistorySub
    });

    it('getHistory should call repository', async () => {
      const result = await service.getHistory(historyKey, riskDetailsKey);
      expect(getHistorySub.calledWith(historyKey, riskDetailsKey));
      expect(result).to.deep.eq({key: 1});
    });
  });

  describe('Testing getContractScores', () => {
    const ContractNbr = '000000';
    const getContractScoresSub = sinon.stub().resolves([
      {
        ContractScoreRating: 'N',
        ContractScoreNoCMRating: 'H',
        ContractScore: 1,
        ContractScoreNoCM: 3,
        ContractNbr
      }
    ]);

    const service = new IssuesRisksService({
      getContractScores: getContractScoresSub
    });

    it('getContractScores should call repository', async () => {
      const result = await service.getContractScores(ContractNbr);
      expect(getContractScoresSub.calledWith(ContractNbr));
      expect(result).to.deep.eq([
        {
          Score: ['N', 1],
          ScoreNoCM: ['H', 3],
          ContractNbr
        }
      ]);
    });
  });

  describe('Testing getNba', () => {
    const questionKey = '4ddb59a7-7739-45a4-8b1d-20823a705871	';

    const getNbaStub = sinon.stub().resolves([]);

    const service = new IssuesRisksService({
      getNba: getNbaStub
    });

    it('getNba should call repository', async () => {
      const result = await service.getNba(questionKey);
      expect(getNbaStub.calledWith(questionKey));
      expect(result).to.deep.eq([]);
    });
  });

  describe('Testing createFeedback', () => {
    const addFeedbackStub = sinon.stub().resolves([]);

    const service = new IssuesRisksService({
      addFeedback: addFeedbackStub
    });

    it('getNba should call repository', async () => {
      const result = await service.createFeedback([]);
      expect(addFeedbackStub.calledWith([]));
      expect(result).to.deep.eq([]);
    });
  });

  describe('Testing generateRandomID', () => {
    const addRiskIDStub = sinon.stub();

    const service = new IssuesRisksService({
      addRiskID: addRiskIDStub
    });

    beforeEach(function(done) {
      done();
    });

    afterEach(function(done) {
      addRiskIDStub.reset();
      done();
    });

    it('generateRandomID should call repository', async () => {
      addRiskIDStub.onCall(0).resolves(false);
      addRiskIDStub.onCall(1).resolves(true);
      await service.generateRandomID(1);
      expect(addRiskIDStub.called).to.be.true;
    });
  });
});
