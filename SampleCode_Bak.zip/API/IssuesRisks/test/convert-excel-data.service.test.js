process.env.NODE_ENV = 'test';

const sinon = require('sinon');
const chai = require('chai');
var sinonChai = require('sinon-chai');
chai.use(sinonChai);
const expect = chai.expect;

const convertExcelDataService = require('../server/convert-excel-data.service');

describe('Testing convert excel data service', () => {
  const sendSpy = sinon.spy();
  const nextSpy = sinon.spy();

  describe('Testing allLinkColumns', () => {
    it('should return all Link Columns', () => {
      const result = convertExcelDataService.allLinkColumns;

      expect(result).to.be.contains('CustomerNm');
    });
  });

  describe('Testing allColumnsPrefix', () => {
    it('should return all Columns Prefix', () => {
      const result = convertExcelDataService.allColumnsPrefix;

      expect(result).to.be.contains('A');
    });
  });

  describe('Testing formatDate', () => {
    afterEach(function(done) {
      sendSpy.resetHistory();
      nextSpy.resetHistory();
      done();
    });

    it('should return a format string', () => {
      const oneDay = new Date(2019, 10, 10);
      const oneDayFormat = '2019-11-10';

      const result = convertExcelDataService.formatDate(oneDay);

      expect(result).to.eq(oneDayFormat);
    });

    it('should return null', () => {
      const oneDay = null;
      const oneDayFormat = null;

      const result = convertExcelDataService.formatDate(oneDay);

      expect(result).to.eq(oneDayFormat);
    });
  });

  describe('Testing formatDateToNum', () => {
    it('should return a string', () => {
      const oneDay = new Date(2019, 10, 10);
      const result = convertExcelDataService.formatDateToNum(oneDay);
      expect(typeof result).to.eq('string');
    });

    it('should return null', () => {
      const oneDay = null;
      const result = convertExcelDataService.formatDateToNum(oneDay);
      expect(result == null).to.eq(true);
    });
  });

  describe('Testing convertStrArr2Json', () => {
    it('should return a json object', () => {
      const strArr = '[{"name":"Jim"}]';

      const result = convertExcelDataService.convertStrArr2Json(strArr);
      expect(result[0].name).to.eq('Jim');
    });

    it('should return an empy array', () => {
      const strArr = '[{"name';

      const result = convertExcelDataService.convertStrArr2Json(strArr);
      expect(result.length).to.eq(0);
    });
  });

  describe('Testing removeHTMLTag', () => {
    it('should return string without html', () => {
      const html = '<h1>Hello world</h1>';

      const result = convertExcelDataService.removeHTMLTag(html);
      expect(result).to.eq('Hello world');
    });
  });

  describe('Testing escape2Html', () => {
    it('should return string without special char', () => {
      const html = '&lt;|&gt;|&nbsp;|&amp;|&quot;';

      const result = convertExcelDataService.escape2Html(html);
      expect(result).to.eq('<|>| |&|"');
    });
  });

  describe('Testing getCodeDetail', () => {
    it('should return matched code detail object', () => {
      const codeDetails = [{CodeTxt: 'A', PrimaryDecodeTxt: 'AA'}, {CodeTxt: 'B', PrimaryDecodeTxt: 'BB'}];
      const result = convertExcelDataService.getCodeDetail('A', codeDetails);
      expect(result.PrimaryDecodeTxt).to.eq('AA');
    });

    it('should return a empty object', () => {
      const codeDetails = [{CodeTxt: 'A', PrimaryDecodeTxt: 'AA'}, {CodeTxt: 'B', PrimaryDecodeTxt: 'BB'}];
      const result = convertExcelDataService.getCodeDetail('C', codeDetails);
      expect(result.PrimaryDecodeTxt).to.eq(undefined);
    });

    it('should return a empty object when code detail list is empty', () => {
      const codeDetails = null;
      const result = convertExcelDataService.getCodeDetail('C', codeDetails);
      expect(result.PrimaryDecodeTxt).to.eq(undefined);
    });
  });

  describe('Testing getConsCallFinRevenueCCI', () => {
    const consCallFinRevenueCCIs = [
      {RiskConsultationCallKey: '0011a3b6-aeda-4329-8528-bc9e167cf479', TypeCd: '101701', EACNbr: '1', ODENbr: '11', VarianceNbr: '111'},
      {RiskConsultationCallKey: '0011a3b6-aeda-4329-8528-bc9e167cf479', TypeCd: '101702', EACNbr: '2', ODENbr: '22', VarianceNbr: '222'},
      {RiskConsultationCallKey: '0011a3b6-aeda-4329-8528-bc9e167cf479', TypeCd: '101703', EACNbr: '3', ODENbr: '33', VarianceNbr: '333'}
    ];
    const riskConsultationCallKey = '0011a3b6-aeda-4329-8528-bc9e167cf479';

    it('should return matched ConsCallFinRevenueCCI for revenue', () => {
      const typeCode = '101701';
      const result = convertExcelDataService.getConsCallFinRevenueCCI(riskConsultationCallKey, typeCode, consCallFinRevenueCCIs);
      expect(result.EACNbr).to.eq('1');
      expect(result.ODENbr).to.eq('11');
      expect(result.VarianceNbr).to.eq('111');
    });

    it('should return matched ConsCallFinRevenueCCI for CCI', () => {
      const typeCode = '101702';
      const result = convertExcelDataService.getConsCallFinRevenueCCI(riskConsultationCallKey, typeCode, consCallFinRevenueCCIs);
      expect(result.EACNbr).to.eq('2');
      expect(result.ODENbr).to.eq('22');
      expect(result.VarianceNbr).to.eq('222');
    });

    it('should return matched ConsCallFinRevenueCCI for CCIPercent', () => {
      const typeCode = '101703';
      const result = convertExcelDataService.getConsCallFinRevenueCCI(riskConsultationCallKey, typeCode, consCallFinRevenueCCIs);
      expect(result.EACNbr).to.eq('3');
      expect(result.ODENbr).to.eq('33');
      expect(result.VarianceNbr).to.eq('333');
    });

    it('should return unmatched ConsCallFinRevenueCCI for CCIPercent with empty source', () => {
      const consCallFinRevenueCCIs = null;
      const typeCode = '101703';
      const result = convertExcelDataService.getConsCallFinRevenueCCI(riskConsultationCallKey, typeCode, consCallFinRevenueCCIs);
      expect(result.EACNbr).to.eq(undefined);
      expect(result.ODENbr).to.eq(undefined);
      expect(result.VarianceNbr).to.eq(undefined);
    });
  });

  describe('Testing getInvolvedParty', () => {
    const involvedParties = [
      {RiskConsultationCallKey: '0011a3b6-aeda-4329-8528-bc9e167cf479', PartyCategoryCd: '101001', PartyArr: '["A","B"]'},
      {RiskConsultationCallKey: '0011a3b6-aeda-4329-8528-bc9e167cf479', PartyCategoryCd: '101002', PartyArr: '["A"]'}
    ];

    const codeDetails = [{CodeTxt: 'A', PrimaryDecodeTxt: 'AA'}, {CodeTxt: 'B', PrimaryDecodeTxt: 'BB'}];

    const riskConsultationCallKey = '0011a3b6-aeda-4329-8528-bc9e167cf479';

    it('should return involved party for business', () => {
      const partyCategoryCd = '101001';
      const result = convertExcelDataService.getInvolvedParty(riskConsultationCallKey, partyCategoryCd, involvedParties, codeDetails);
      expect(result).to.eq('AA, BB');
    });

    it('should return involved party for finance', () => {
      const partyCategoryCd = '101002';
      const result = convertExcelDataService.getInvolvedParty(riskConsultationCallKey, partyCategoryCd, involvedParties, codeDetails);
      expect(result).to.eq('AA');
    });

    it('should return involved party for finance with non-existing code', () => {
      const partyCategoryCd = '101003';
      const result = convertExcelDataService.getInvolvedParty(riskConsultationCallKey, partyCategoryCd, involvedParties, codeDetails);
      expect(result).to.eq('');
    });

    it('should return involved party for finance with empty source', () => {
      const involvedParties = null;
      const partyCategoryCd = '101002';
      const result = convertExcelDataService.getInvolvedParty(riskConsultationCallKey, partyCategoryCd, involvedParties, codeDetails);
      expect(result).to.eq('');
    });
  });

  describe('Testing getStatements', () => {
    const codeDetails = [{CodeTxt: 'A', PrimaryDecodeTxt: 'AA'}, {CodeTxt: 'B', PrimaryDecodeTxt: 'BB'}];

    it('should return statements', () => {
      const statementArr = ['A', 'B'];
      const result = convertExcelDataService.getStatements(statementArr, codeDetails);
      expect(result[0].PrimaryDecodeTxt).to.eq('AA');
      expect(result[1].PrimaryDecodeTxt).to.eq('BB');
    });

    it('should return maximum 6 statements', () => {
      const statementArr = ['A', 'B', 'A', 'B', 'A', 'B', 'A', 'B'];
      const result = convertExcelDataService.getStatements(statementArr, codeDetails);
      expect(result[0].PrimaryDecodeTxt).to.eq('AA');
      expect(result[1].PrimaryDecodeTxt).to.eq('BB');
      expect(result.length).to.eq(6);
    });
  });

  describe('Testing getCMUsers', () => {
    it('should return cm users list', () => {
      const cmusers = '["cong.wu", "bob.liu"]';
      const result = convertExcelDataService.getCMUsers(cmusers);
      expect(result[0]).to.eq('cong.wu');
      expect(result[1]).to.eq('bob.liu');
    });

    it('should return maxinum 10 cm users list', () => {
      const cmusers =
        '["cong.wu", "bob.liu","cong.wu", "bob.liu","cong.wu", "bob.liu","cong.wu", "bob.liu","cong.wu", "bob.liu","cong.wu"]';
      const result = convertExcelDataService.getCMUsers(cmusers);
      expect(result[0]).to.eq('cong.wu');
      expect(result[1]).to.eq('bob.liu');
      expect(result.length).to.eq(10);
    });
  });

  describe('Testing getLeadReviews', () => {
    const riskDetailsKey = '0011a3b6-aeda-4329-8528-bc9e167cf479';

    it('should return LeadReviews list', () => {
      const leadReviews = [
        {
          RiskDetailsKey: '0011a3b6-aeda-4329-8528-bc9e167cf479',
          DesignatedReviewerUserIdArr: 'cong.wu',
          LeadReviewDttm: new Date(2019, 9, 10),
          LeadReviewStatusCd: 'A'
        },
        {
          RiskDetailsKey: '0011a3b6-aeda-4329-8528-bc9e167cf479',
          DesignatedReviewerUserIdArr: 'cong.wu',
          LeadReviewDttm: new Date(2019, 9, 10),
          LeadReviewStatusCd: 'A'
        }
      ];

      const result = convertExcelDataService.getLeadReviews(riskDetailsKey, leadReviews);
      expect(result[0].RiskDetailsKey).to.eq('0011a3b6-aeda-4329-8528-bc9e167cf479');
      expect(result[0].DesignatedReviewerUserIdArr).to.eq('cong.wu');
      expect(result[0].LeadReviewStatusCd).to.eq('A');
    });

    it('should return maximum 3 LeadReviews list', () => {
      const leadReviews = [
        {
          RiskDetailsKey: '0011a3b6-aeda-4329-8528-bc9e167cf479',
          DesignatedReviewerUserIdArr: 'cong.wu',
          LeadReviewDttm: new Date(2019, 9, 10),
          LeadReviewStatusCd: 'A'
        },
        {
          RiskDetailsKey: '0011a3b6-aeda-4329-8528-bc9e167cf479',
          DesignatedReviewerUserIdArr: 'cong.wu',
          LeadReviewDttm: new Date(2019, 9, 10),
          LeadReviewStatusCd: 'A'
        },
        {
          RiskDetailsKey: '0011a3b6-aeda-4329-8528-bc9e167cf479',
          DesignatedReviewerUserIdArr: 'cong.wu',
          LeadReviewDttm: new Date(2019, 9, 10),
          LeadReviewStatusCd: 'A'
        },
        {
          RiskDetailsKey: '0011a3b6-aeda-4329-8528-bc9e167cf479',
          DesignatedReviewerUserIdArr: 'cong.wu',
          LeadReviewDttm: new Date(2019, 9, 10),
          LeadReviewStatusCd: 'A'
        }
      ];

      const result = convertExcelDataService.getLeadReviews(riskDetailsKey, leadReviews);
      expect(result[0].RiskDetailsKey).to.eq('0011a3b6-aeda-4329-8528-bc9e167cf479');
      expect(result[0].DesignatedReviewerUserIdArr).to.eq('cong.wu');
      expect(result[0].LeadReviewStatusCd).to.eq('A');
      expect(result.length).to.eq(3);
    });
  });

  describe('Testing getMitigations', () => {
    const riskDetailsKey = '0011a3b6-aeda-4329-8528-bc9e167cf479';

    it('should return mitigations list', () => {
      const mitigations = [
        {
          RiskDetailsKey: '0011a3b6-aeda-4329-8528-bc9e167cf479',
          AssigneeUserId: 'cong.wu',
          MitigationDesc: 'this is a mitigation description',
          DueDttm: new Date(2019, 9, 10),
          MitigationStatusCd: 'A'
        }
      ];
      const result = convertExcelDataService.getMitigations(riskDetailsKey, mitigations);
      expect(result[0].RiskDetailsKey).to.eq('0011a3b6-aeda-4329-8528-bc9e167cf479');
      expect(result[0].AssigneeUserId).to.eq('cong.wu');
      expect(result[0].MitigationDesc).to.eq('this is a mitigation description');
      expect(result[0].MitigationStatusCd).to.eq('A');
    });

    it('should return maximum 20 mitigations list', () => {
      const mitigation = {
        RiskDetailsKey: '0011a3b6-aeda-4329-8528-bc9e167cf479',
        AssigneeUserId: 'cong.wu',
        MitigationDesc: 'this is a mitigation description',
        DueDttm: new Date(2019, 9, 10),
        MitigationStatusCd: 'A'
      };
      const mitigations = [];
      for (let index = 0; index < 21; index++) {
        mitigations.push(mitigation);
      }
      const result = convertExcelDataService.getMitigations(riskDetailsKey, mitigations);
      expect(result[0].RiskDetailsKey).to.eq('0011a3b6-aeda-4329-8528-bc9e167cf479');
      expect(result[0].AssigneeUserId).to.eq('cong.wu');
      expect(result[0].MitigationDesc).to.eq('this is a mitigation description');
      expect(result[0].MitigationStatusCd).to.eq('A');
      expect(result.length).to.eq(20);
    });
  });

  describe('Testing getlinkText', () => {
    const column = 1;
    const row = 2;

    it('should return lik text', () => {
      const result = convertExcelDataService.getlinkText(column, row);
      expect(result).to.eq("='Dump Table'!$B$4");
    });
  });

  describe('Testing convertDataToExcelDto', () => {
    it('should return excel dto list with Ind value is Y', () => {
      const consultationCalls = [
        {
          RiskConsultationCallKey: '0011a3b6-aeda-4329-8528-bc9e167cf479',
          CustomerNbr: '12345',
          CustomerNm: 'customerNm - 00',
          ContractNm: 'contractNm - 00',
          ContractNbr: 'contractNbr - 00',
          MasterClientNm: 'MasterClientNm',
          MasterClientNbr: 'MasterClientNbr',
          CountryNm: 'CountryNm',
          GeographicUnitDesc: 'geographicUnitDesc - 00',
          GeographicRegionDesc: 'geographicRegionDesc - 00',
          CategoryCd: 'CategoryCd',
          SubCategoryCd: 'SubCategoryCd',
          RiCategory: 'riCategory - 00',
          RiSubCategory: 'riSubCategory - 00',
          RiskTypeDesc: 'riskTypeDesc - 00',
          ConfidentialSlotRequested: 'Yes',
          UpdateUserId: 'updateUserId - 00',
          CMUserId1: 'cMUserId1 - 00',
          CMUserId2: 'cMUserId2 - 00',
          CMUserId3: 'cMUserId3 - 00',
          CMUserId4: 'cMUserId4 - 00',
          CMUserId5: 'cMUserId5 - 00',
          RiskQMDReviewInd: 'Y',
          OnHriListInd: 'Y',
          RequestConfidentialInd: 'Y',
          ReviewerShareInd: 'Y'
        }
      ];

      const consCallFinRevenueCCIs = [
        {RiskConsultationCallKey: '0011a3b6-aeda-4329-8528-bc9e167cf479', TypeCd: '101701', EACNbr: '1', ODENbr: '11', VarianceNbr: '111'},
        {RiskConsultationCallKey: '0011a3b6-aeda-4329-8528-bc9e167cf479', TypeCd: '101702', EACNbr: '2', ODENbr: '22', VarianceNbr: '222'},
        {RiskConsultationCallKey: '0011a3b6-aeda-4329-8528-bc9e167cf479', TypeCd: '101703', EACNbr: '3', ODENbr: '33', VarianceNbr: '333'}
      ];

      const involvedParties = [
        {RiskConsultationCallKey: '0011a3b6-aeda-4329-8528-bc9e167cf479', PartyCategoryCd: '101001', PartyArr: '["A","B"]'},
        {RiskConsultationCallKey: '0011a3b6-aeda-4329-8528-bc9e167cf479', PartyCategoryCd: '101002', PartyArr: '["A"]'}
      ];

      const leadReviews = [
        {
          RiskDetailsKey: '0011a3b6-aeda-4329-8528-bc9e167cf479',
          DesignatedReviewerUserIdArr: 'cong.wu',
          LeadReviewDttm: new Date(2019, 9, 10),
          LeadReviewStatusCd: 'A'
        },
        {
          RiskDetailsKey: '0011a3b6-aeda-4329-8528-bc9e167cf479',
          DesignatedReviewerUserIdArr: 'cong.wu',
          LeadReviewDttm: new Date(2019, 9, 10),
          LeadReviewStatusCd: 'A'
        }
      ];

      const mitigations = [
        {
          RiskDetailsKey: '0011a3b6-aeda-4329-8528-bc9e167cf479',
          AssigneeUserId: 'cong.wu',
          MitigationDesc: 'this is a mitigation description',
          DueDttm: new Date(2019, 9, 10),
          MitigationStatusCd: 'A'
        }
      ];
      const codeDetails = [{CodeTxt: 'A', PrimaryDecodeTxt: 'AA'}, {CodeTxt: 'B', PrimaryDecodeTxt: 'BB'}];

      const result = convertExcelDataService.convertDataToExcelDto(
        consultationCalls,
        consCallFinRevenueCCIs,
        involvedParties,
        leadReviews,
        mitigations,
        codeDetails
      );

      expect(result[0].CustomerNbr).to.eq('12345');
      expect(result[0].DateRequested_LINK).to.eq("='Dump Table'!$AI$2");
      expect(result[0].RevenueVarianceNbr).to.eq('111');
      expect(result[0].CCIPercentVarianceNbr).to.eq('333');
    });

    it('should return excel dto list with Ind value is Y', () => {
      const consultationCalls = [
        {
          RiskConsultationCallKey: '0011a3b6-aeda-4329-8528-bc9e167cf479',
          CustomerNbr: '12345',
          CustomerNm: 'customerNm - 00',
          ContractNm: 'contractNm - 00',
          ContractNbr: 'contractNbr - 00',
          MasterClientNm: 'MasterClientNm',
          MasterClientNbr: 'MasterClientNbr',
          CountryNm: 'CountryNm',
          GeographicUnitDesc: 'geographicUnitDesc - 00',
          GeographicRegionDesc: 'geographicRegionDesc - 00',
          CategoryCd: 'CategoryCd',
          SubCategoryCd: 'SubCategoryCd',
          RiCategory: 'riCategory - 00',
          RiSubCategory: 'riSubCategory - 00',
          RiskTypeDesc: 'riskTypeDesc - 00',
          ConfidentialSlotRequested: 'Yes',
          UpdateUserId: 'updateUserId - 00',
          CMUserId1: 'cMUserId1 - 00',
          CMUserId2: 'cMUserId2 - 00',
          CMUserId3: 'cMUserId3 - 00',
          CMUserId4: 'cMUserId4 - 00',
          CMUserId5: 'cMUserId5 - 00',
          RiskQMDReviewInd: 'N',
          OnHriListInd: 'N',
          RequestConfidentialInd: 'N',
          ReviewerShareInd: 'N'
        }
      ];

      const consCallFinRevenueCCIs = [
        {RiskConsultationCallKey: '0011a3b6-aeda-4329-8528-bc9e167cf479', TypeCd: '101701', EACNbr: '1', ODENbr: '11', VarianceNbr: '111'},
        {RiskConsultationCallKey: '0011a3b6-aeda-4329-8528-bc9e167cf479', TypeCd: '101702', EACNbr: '2', ODENbr: '22', VarianceNbr: '222'},
        {RiskConsultationCallKey: '0011a3b6-aeda-4329-8528-bc9e167cf479', TypeCd: '101703', EACNbr: '3', ODENbr: '33', VarianceNbr: '333'}
      ];

      const involvedParties = [
        {RiskConsultationCallKey: '0011a3b6-aeda-4329-8528-bc9e167cf479', PartyCategoryCd: '101001', PartyArr: '["A","B"]'},
        {RiskConsultationCallKey: '0011a3b6-aeda-4329-8528-bc9e167cf479', PartyCategoryCd: '101002', PartyArr: '["A"]'}
      ];

      const leadReviews = [
        {
          RiskDetailsKey: '0011a3b6-aeda-4329-8528-bc9e167cf479',
          DesignatedReviewerUserIdArr: 'cong.wu',
          LeadReviewDttm: new Date(2019, 9, 10),
          LeadReviewStatusCd: 'A'
        },
        {
          RiskDetailsKey: '0011a3b6-aeda-4329-8528-bc9e167cf479',
          DesignatedReviewerUserIdArr: 'cong.wu',
          LeadReviewDttm: new Date(2019, 9, 10),
          LeadReviewStatusCd: 'A'
        }
      ];

      const mitigations = [
        {
          RiskDetailsKey: '0011a3b6-aeda-4329-8528-bc9e167cf479',
          AssigneeUserId: 'cong.wu',
          MitigationDesc: 'this is a mitigation description',
          DueDttm: new Date(2019, 9, 10),
          MitigationStatusCd: 'A'
        }
      ];
      const codeDetails = [{CodeTxt: 'A', PrimaryDecodeTxt: 'AA'}, {CodeTxt: 'B', PrimaryDecodeTxt: 'BB'}];

      const result = convertExcelDataService.convertDataToExcelDto(
        consultationCalls,
        consCallFinRevenueCCIs,
        involvedParties,
        leadReviews,
        mitigations,
        codeDetails
      );

      expect(result[0].CustomerNbr).to.eq('12345');
      expect(result[0].DateRequested_LINK).to.eq("='Dump Table'!$AI$2");
      expect(result[0].RevenueVarianceNbr).to.eq('111');
      expect(result[0].CCIPercentVarianceNbr).to.eq('333');
    });

    it('should return excel dto list with empty properties', () => {
      const consultationCalls = [
        {
          RiskConsultationCallKey: '0011a3b6-aeda-4329-8528-bc9e167cf479',
          CustomerNbr: '',
          CustomerNm: '',
          ContractNm: '',
          ContractNbr: '',
          MasterClientNm: '',
          MasterClientNbr: '',
          CountryNm: '',
          GeographicUnitDesc: '',
          GeographicRegionDesc: '',
          CategoryCd: '',
          SubCategoryCd: '',
          RiCategory: '',
          RiSubCategory: '',
          RiskTypeDesc: '',
          ConfidentialSlotRequested: 'Y',
          UpdateUserId: ''
        }
      ];

      const consCallFinRevenueCCIs = [
        {RiskConsultationCallKey: '0011a3b6-aeda-4329-8528-bc9e167cf479', TypeCd: '101701', EACNbr: '1', ODENbr: '11', VarianceNbr: '111'},
        {RiskConsultationCallKey: '0011a3b6-aeda-4329-8528-bc9e167cf479', TypeCd: '101702', EACNbr: '2', ODENbr: '22', VarianceNbr: '222'},
        {RiskConsultationCallKey: '0011a3b6-aeda-4329-8528-bc9e167cf479', TypeCd: '101703', EACNbr: '3', ODENbr: '33', VarianceNbr: '333'}
      ];

      const involvedParties = [
        {RiskConsultationCallKey: '0011a3b6-aeda-4329-8528-bc9e167cf479', PartyCategoryCd: '101001', PartyArr: '["A","B"]'},
        {RiskConsultationCallKey: '0011a3b6-aeda-4329-8528-bc9e167cf479', PartyCategoryCd: '101002', PartyArr: '["A"]'}
      ];

      const leadReviews = [
        {
          RiskDetailsKey: '0011a3b6-aeda-4329-8528-bc9e167cf479',
          DesignatedReviewerUserIdArr: 'cong.wu',
          LeadReviewDttm: new Date(2019, 9, 10),
          LeadReviewStatusCd: 'A'
        },
        {
          RiskDetailsKey: '0011a3b6-aeda-4329-8528-bc9e167cf479',
          DesignatedReviewerUserIdArr: 'cong.wu',
          LeadReviewDttm: new Date(2019, 9, 10),
          LeadReviewStatusCd: 'A'
        }
      ];

      const mitigations = [
        {
          RiskDetailsKey: '0011a3b6-aeda-4329-8528-bc9e167cf479',
          AssigneeUserId: 'cong.wu',
          MitigationDesc: 'this is a mitigation description',
          DueDttm: new Date(2019, 9, 10),
          MitigationStatusCd: 'A'
        }
      ];
      const codeDetails = [{CodeTxt: 'A', PrimaryDecodeTxt: 'AA'}, {CodeTxt: 'B', PrimaryDecodeTxt: 'BB'}];

      const result = convertExcelDataService.convertDataToExcelDto(
        consultationCalls,
        consCallFinRevenueCCIs,
        involvedParties,
        leadReviews,
        mitigations,
        codeDetails
      );

      expect(result[0].CustomerNbr).to.eq('');
      expect(result[0].DateRequested_LINK).to.eq("='Dump Table'!$AI$2");
      expect(result[0].RevenueVarianceNbr).to.eq('111');
      expect(result[0].CCIPercentVarianceNbr).to.eq('333');
    });

    it('should return an empty object', () => {
      const consultationCalls = [];

      const consCallFinRevenueCCIs = [];

      const involvedParties = [];

      const leadReviews = [];

      const mitigations = [];
      const codeDetails = [];

      const result = convertExcelDataService.convertDataToExcelDto(
        consultationCalls,
        consCallFinRevenueCCIs,
        involvedParties,
        leadReviews,
        mitigations,
        codeDetails
      );
      expect(result.length).to.eq(0);
    });

    it('should return an empty object with consultationCalls is null', () => {
      const consultationCalls = null;

      const consCallFinRevenueCCIs = [];

      const involvedParties = [];

      const leadReviews = [];

      const mitigations = [];
      const codeDetails = [];

      const result = convertExcelDataService.convertDataToExcelDto(
        consultationCalls,
        consCallFinRevenueCCIs,
        involvedParties,
        leadReviews,
        mitigations,
        codeDetails
      );
      expect(result.length).to.eq(0);
    });
  });
});
