'use strict';

const { Spanner } = require('@google-cloud/spanner');

/**
 * Return the instance of Database
 * @returns {Database} A instance of Database
 */
const DB = function() {
  const spanner = new Spanner({
    projectId: process.env.PROJECT_ID
  });

  const instance = spanner.instance(process.env.INSTANCE_ID);
  return instance.database(
    process.env.NODE_ENV === 'test'
      ? process.env.UNIT_TEST_DATABASE_ID
      : process.env.DATABASE_ID
  );
};

module.exports = DB;
