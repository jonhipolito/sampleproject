'use strict';

let gaeConfig = {
  hostname: process.env.PROJECT_URL,
  port: process.env.PORT
};

module.exports = gaeConfig;
