'use strict';

let localConfig = {
  hostname: process.env.PROJECT_URL,
  port: 8080
};

module.exports = localConfig;
