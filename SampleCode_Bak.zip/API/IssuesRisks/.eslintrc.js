module.exports = {
  extends: ['eslint:recommended', 'prettier', 'plugin:prettier/recommended'],
  parser: 'babel-eslint',
  parserOptions: {
    ecmaVersion: 7,
    sourceType: 'module'
  },
  rules: {
    'prettier/prettier': 'error',
    'strict': 'off',
    'max-len': ['error', { 'code': 140, 'ignoreUrls': true, 'ignoreTemplateLiterals': true, 'ignoreComments': true }],
    'no-console': 'off',
    'import/no-dynamic-require': 'off',
    'global-require': 'off',
    'require-yield': 'off',
    'object-curly-spacing': ['error', 'never'],
    'array-bracket-spacing': ['error', 'never']
  },
  env: {
    node: true,
    es6: true,
    mocha: true
  },
  plugins: ['prettier'],
  globals: {}
};
