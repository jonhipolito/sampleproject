'use strict';

const _ = require('lodash');
const dateformat = require('dateformat');
const Excel = require('exceljs');
const he = require('he');
const moment = require('moment');
const momentTZ = require('moment-timezone');
const { Storage } = require('@google-cloud/storage');
const risksIssuesRepository = require('./risksissues.repository');

const _getRisksIssuesViews = (mc, fc, con, view) => {
  return new Promise(async function (resolve, reject) {
    var defaultView = '';
    // let userAccess;
    var views = await risksIssuesRepository.getRisksIssuesViews();
    if (views && views.length > 0) {
      let jsonValue = JSON.parse(JSON.stringify(views));
      let res = view ? jsonValue.find(x => x.primaryTxt.toLowerCase().replace(" ", "") === view.toLowerCase()) : null;

      if (res) {
        defaultView = res.id;
      }
      else {
        defaultView = jsonValue[0].id;
      }
    }

    var grid = await risksIssuesRepository.getRisksAndIssues(mc, fc, con, defaultView);

    let initialGrid = {
      defaultView: defaultView,
      grid: grid
    }

    let res = {
      views: views,
      initialGrid: initialGrid
    };

    try {
      // Read #1, using SQL
      let rows = [];
      if (res.initialGrid.grid) {
        res.initialGrid.grid.forEach(row => {
          row.forEach(col => {
            if (col.name == 'qmdreview' && col.value && col.value.includes('Requested on')) {
              var date = col.value.substr(13);
              var qmdreview = date ? 'Requested on ' + moment(date).format('DD-MMM-YYYY') : 'Requested on ';
              col.value = qmdreview;
            }
            else if ((col.name == 'status' || col.name == 'consulcall') && col.value && col.value.includes('Reviewed on')) {
              var date = col.value.substr(12);
              var colValue = date ? 'Reviewed on ' + moment(date).format('DD-MMM-YYYY') : 'Reviewed on ';
              col.value = colValue;
            }
          })
          rows.push(row);
        })
      }
      rows = replaceQuotes(rows);
      res.initialGrid.grid = rows;
      resolve(res);
      res.catch(err);

    } catch (err) {

      return reject(err);

    }
  })
}

const _getRisksAndIssues = (mc, fc, con, view) => {
  return new Promise(async function (resolve, reject) {
    var res = await risksIssuesRepository.getRisksAndIssues(mc, fc, con, view);
    try {
      let rows = [];
      if (res && (view == '136004' || view == '136003')) {
        res.forEach(row => {
          row.forEach(col => {
            if ((col.name == 'duedate' || col.name == 'followupdate') && col.value) {
              var dateValue = moment(col.value).format('DD-MMM-YYYY');
              col.value = dateValue;
            }
            if (view == '136003' && col.name == 'consulcall' && col.value && col.value.includes('Reviewed on')) {
              var date = col.value.substr(12);
              var colValue = date ? 'Reviewed on ' + moment(date).format('DD-MMM-YYYY') : 'Reviewed on ';
              col.value = colValue;
            }
          })
          rows.push(row);
        })
      }
      else if (res && (view == '136001')) {
        res.forEach(row => {
          row.forEach(col => {
            if (col.name == 'qmdreview' && col.value && col.value.includes('Requested on')) {
              var date = col.value.substr(13);
              var qmdreview = date ? 'Requested on ' + moment(date).format('DD-MMM-YYYY') : 'Requested on ';
              col.value = qmdreview;
            }
            else if ((col.name == 'status' || col.name == 'consulcall') && col.value && col.value.includes('Reviewed on')) {
              var date = col.value.substr(12);
              var colValue = date ? 'Reviewed on ' + moment(date).format('DD-MMM-YYYY') : 'Reviewed on ';
              col.value = colValue;
            }
          })
          rows.push(row);
        })
      } else {
        rows = res;
      }
      rows = replaceQuotes(rows);
      // Read #1, using SQL
      resolve(rows);
      rows.catch(err);

    } catch (err) {

      return reject(err);

    }
  })
}

const _exportAssessmentView = (body) => {
  return new Promise(async (resolve) => {

    let details = {};
    details['MasterClientNbr'] = body.MasterClientNbr;
    details['FinancialClientNbr'] = body.CustomerNbr;
    details['ContractNbr'] = body.ContractNbr;

    let clientDetails = await getClientDetails(body.ContractNbr);

    details['MasterClientNm'] = clientDetails['MasterClientNm'];
    details['FinancialClientNm'] = clientDetails['CustomerNm'];
    details['ContractNm'] = clientDetails['ContractNm'];
    details['Region'] = clientDetails['region'];
    details['Geography'] = clientDetails['geography'];
    details['Country'] = clientDetails['country'];

    let riskScore = await getCMRiskScore(body.ContractNbr);

    details['CMRiskScore'] = riskScore['CMRiskScore'];
    details['CMRiskScoreRating'] = riskScore['CMRiskScoreRating'];

    details['StatusSummary'] = await getStatusSummary(body.ContractNbr);
    details['Mitigations'] = await getMitigations(body.ContractNbr)
    details['Questions'] = await getAssesstmentAndMitigation(body.ContractNbr, body.UserTimeZone);

    try {
      let result = await generateTemplate(details);
      resolve(result);
    } catch (error) {
      console.log("_exportAssessmentView", error);
    } finally {
    }
  });
}

async function getMitigations(con) {
  let mitigationDetails = await risksIssuesRepository.getMitDueOverdueCount(con);
  let response = {};
  try {
    if (mitigationDetails && mitigationDetails.length > 0) {
      response['Summary'] = mitigationDetails[0].total;
      response['Overdue'] = mitigationDetails[0].overdue;
      response['Due'] = mitigationDetails[0].due;
    }
  } catch (err) {
    console.log(err);
  }
  return response;
}
async function getStatusSummary(con) {
  let statusSummary = await risksIssuesRepository.getRisksAssmtStatSummary(con);
  let response = {};
  try {
    if (statusSummary && statusSummary.length > 0) {
      response['High'] = statusSummary[0].high;
      response['AboveNormal'] = statusSummary[0].abovenormal;
      response['Normal'] = statusSummary[0].normal;
      response['NotStarted'] = statusSummary[0].notstarted;
    }
  } catch (err) {
    console.log(err);
  }
  return response;
}

async function getCMRiskScore(con) {
  let contractScores = await risksIssuesRepository.getContractScores(con);
  let contractScore = {};
  try {
    if (contractScores.length > 0) {
      contractScore['CMRiskScore'] = contractScores[0]['ContractScore'];
      contractScore['CMRiskScoreRating'] = contractScores[0]['ContractScoreRating'];
    }
  } catch (err) {
    console.log(err);
  }
  return contractScore;
}

async function getClientDetails(con) {
  let clientDetails = await risksIssuesRepository.getClientDetails(con);
  let response = {};
  try {
    if (clientDetails && clientDetails.length > 0) {
      response['region'] = clientDetails[0].region;
      response['geography'] = clientDetails[0].geography;
      response['country'] = clientDetails[0].country;
      response['MasterClientNm'] = clientDetails[0].MasterClientNm;
      response['CustomerNm'] = clientDetails[0].CustomerNm;
      response['ContractNm'] = clientDetails[0].ContractNm;
    }
  } catch (err) {
    console.log(err);
  }
  return response;
}

async function getAssesstmentAndMitigation(con, usertz) {
  let data = await risksIssuesRepository.getRisksAssmtAndMitigation(con);
  let response = [];
  try {
    if (data && data.length > 0) {
      for (let row of data) {
        let assesstmentRow = {};
        let mitigationRow = {};
        let mitigationArray = [];
        let newRaDesc = '';

        let existingRow = response.find(i => i.QARef === row.qaref);

        if (existingRow === undefined) {
          assesstmentRow['QARef'] = row.qaref;
          assesstmentRow['Category'] = row.category;
          assesstmentRow['Question'] = row.question;
          assesstmentRow['Statements'] = row.statementall;
          assesstmentRow['SubCategory'] = row.subcategory;
          assesstmentRow['Rating'] = row.rating;

          if (row.radescription != null) {
            newRaDesc = row.radescription.replace(/(<([^>]+)>)/g, '');

            newRaDesc = he.decode(newRaDesc).trim();

            assesstmentRow['Description'] = newRaDesc;
          } else {
            assesstmentRow['Description'] = row.radescription;
          }

          assesstmentRow['Type'] = row.type;
          assesstmentRow['Status'] = row.rastatus;
          assesstmentRow['LeadReviewStatus'] = row.leadreviewstatus;
          assesstmentRow['DesignatedReviewer'] = row.designatedreviewer;
          assesstmentRow['CCRequested'] = row.ccrequested;
          assesstmentRow['QMDCallRequested'] = row.qmdcallrequested;
        }

        mitigationRow['Title'] = row.mitigationtitle;
        mitigationRow['Description'] = row.mitdescription;
        mitigationRow['CreatedBy'] = row.createdby;
        mitigationRow['AssignedTo'] = row.assignedto;
        mitigationRow['Status'] = row.mitstatus;
        mitigationRow['CreatedOn'] = (row.createdon != null) ? momentTZ(row.createdon).tz(usertz).format('DD-MMM-YYYY') : row.createdon;
        mitigationRow['DueDate'] = (row.duedate != null) ? dateformat(new Date(row.duedate), 'dd-mmm-yyyy').toString() : row.duedate;

        if (existingRow === undefined) {
          mitigationArray.push(mitigationRow);
          assesstmentRow['Mitigations'] = mitigationArray;
          response.push(assesstmentRow);
        } else {
          existingRow['Mitigations'].push(mitigationRow);
        }
      }
    }
  } catch (err) {
    console.log(err);
  }
  return response;
}

function generateTemplate(details) {
  return new Promise(async (resolve, reject) => {
    try {
      const storage = new Storage();
      if (details) {
        let readstream = await storage.bucket(process.env.STORAGEBUCKET).file("excel-templates/Risk Assessment View Export Template v4.xlsx").createReadStream();
        var workbook = new Excel.Workbook();
        let writeStream = workbook.xlsx.createInputStream();
        readstream.pipe(writeStream);
        writeStream.on('done', () => {
          let ws = workbook.getWorksheet("R & I Assessment");
          let colHeaders = ws.getRow(16)._cells; //16 is fixed: based on template
          let colMitiHeaders = ws.getRow(15)._cells; //15 is fixed: based on template
          let mitigationHeaders = ws.getRow(16)._cells; //16 is fixed: based on template
          let maxMitigationCount = 0;
          let questions = details.Questions;
          let qaRefRowCtr = 17; //17 is fixed: based on template
          let borderRight = { right: { style: 'medium', color: { argb: 'A6A6A6' } } };
          let borderTopRight = { top: { style: 'medium', color: { argb: 'A6A6A6' } }, right: { style: 'medium', color: { argb: 'A6A6A6' } } };
          /*let fillHigh = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFF0000' }, bgColor: { argb: 'FFFF0000' } };
          let fillAboveNormal = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFC000' }, bgColor: { argb: 'FFFFC000' } };
          let fillNormal = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF92D050' }, bgColor: { argb: 'FF92D050' } };
          let fillUnrated = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFA6A6A6' }, bgColor: { argb: 'FFA6A6A6' } };*/

          ws.getCell('M7').border = borderRight;
          ws.getCell('L5').border = borderRight;
          ws.getCell('M5').border = borderTopRight;

          ws.getCell('D7').value = details.MasterClientNm + ' - ' + details.MasterClientNbr;
          ws.getCell('D8').value = details.FinancialClientNm + ' - ' + details.FinancialClientNbr;
          ws.getCell('D9').value = details.ContractNm + ' - ' + details.ContractNbr;
          ws.getCell('G7').value = details.Region;
          ws.getCell('G8').value = details.Geography;
          ws.getCell('G9').value = details.Country;
          ws.getCell('I7').value = details.CMRiskScore;
          ws.getCell('I10').value = details.CMRiskScoreRating;
          ws.getCell('K7').value = details.StatusSummary.High;
          ws.getCell('K8').value = details.StatusSummary.AboveNormal;
          ws.getCell('K9').value = details.StatusSummary.Normal;
          ws.getCell('K10').value = details.StatusSummary.NotStarted;
          ws.getCell('L7').value = details.Mitigations.Summary;
          ws.getCell('M9').value = details.Mitigations.Overdue;
          ws.getCell('M10').value = details.Mitigations.Due;

          if (!_.isEmpty(questions)) {
            for (let y = 0; y < questions.length; y++) {
              if (_.isEqual(ws.getCell('D' + qaRefRowCtr).value.trim(), questions[y].QARef)) {
                ws.getCell(qaRefRowCtr, ArrayFind(colHeaders, 'value', 'Category', 'col')).value = questions[y].Category;
                ws.getCell(qaRefRowCtr, ArrayFind(colHeaders, 'value', 'Statement (s)', 'col')).value = questions[y].Statements;
                ws.getCell(qaRefRowCtr, ArrayFind(colHeaders, 'value', 'Rating', 'col')).value = questions[y].Rating;
                ws.getCell(qaRefRowCtr, ArrayFind(colHeaders, 'value', 'Description', 'col')).value = questions[y].Description;
                ws.getCell(qaRefRowCtr, ArrayFind(colHeaders, 'value', 'Type', 'col')).value = questions[y].Type;
                ws.getCell(qaRefRowCtr, ArrayFind(colHeaders, 'value', 'Status', 'col')).value = questions[y].Status;
                ws.getCell(qaRefRowCtr, ArrayFind(colHeaders, 'value', 'Lead Review Status', 'col')).value = questions[y].LeadReviewStatus;
                ws.getCell(qaRefRowCtr, ArrayFind(colHeaders, 'value', 'Designated Reviewer', 'col')).value = questions[y].DesignatedReviewer;
                ws.getCell(qaRefRowCtr, ArrayFind(colHeaders, 'value', 'CC Requested', 'col')).value = questions[y].CCRequested;
                ws.getCell(qaRefRowCtr, ArrayFind(colHeaders, 'value', 'QMD Call Requested', 'col')).value = questions[y].QMDCallRequested;

                // Pick List to column ‘Type’
                // ws.getCell(qaRefRowCtr, ArrayFind(colHeaders, 'value', 'Type', 'col')).dataValidation = { type: 'list', allowBlank: true, formulae: ['"Risk,Issue"'] };

                // let ratingCell = ws.getCell(qaRefRowCtr, ArrayFind(colHeaders, 'value', 'Rating', 'col'));
                // ratingCell.style = _.cloneDeep(ratingCell.style);
                // ratingCell.font = { color: { argb: '00000000' } };
                // switch (questions[y].Rating) {
                //   case 'High':
                //     ratingCell.fill = fillHigh;
                //     break;
                //   case 'Above Normal':
                //     ratingCell.fill = fillAboveNormal;
                //     break;
                //   case 'Normal':
                //     ratingCell.fill = fillNormal;
                //     break;
                //   case 'Unrated':
                //     ratingCell.fill = fillUnrated;
                //     break;
                //   default:
                //     console.log('undefined');
                // }

                if (!_.isEmpty(questions[y].Mitigations)) {
                  let mitigationCount = 1;
                  let addtlMitiCtr = 58; //fixed: based on template
                  let mitigationHeaderStyleCount = 1;
                  let oddColumn = true;
                  for (let x = 0; x < questions[y].Mitigations.length; x++) {
                    let mitigationCol = "";
                    if (mitigationCount < 7) { mitigationCol = ArrayFind(colMitiHeaders, 'value', 'MITIGATION ' + mitigationCount, 'col'); }
                    if (mitigationCol != "") {
                      ws.getCell(qaRefRowCtr, mitigationCol).value = questions[y].Mitigations[x].Title;
                      ws.getCell(qaRefRowCtr, mitigationCol + 1).value = questions[y].Mitigations[x].Description;
                      ws.getCell(qaRefRowCtr, mitigationCol + 2).value = questions[y].Mitigations[x].CreatedBy;
                      ws.getCell(qaRefRowCtr, mitigationCol + 3).value = questions[y].Mitigations[x].AssignedTo;
                      ws.getCell(qaRefRowCtr, mitigationCol + 4).value = questions[y].Mitigations[x].Status;
                      ws.getCell(qaRefRowCtr, mitigationCol + 5).value = questions[y].Mitigations[x].CreatedOn;
                      ws.getCell(qaRefRowCtr, mitigationCol + 6).value = questions[y].Mitigations[x].DueDate;
                    } else {
                      if (mitigationHeaderStyleCount > 3) {
                        mitigationHeaderStyleCount = 1;
                      }
                      let mitRef = ws.getCell(15, ArrayFind(colMitiHeaders, 'value', 'MITIGATION ' + mitigationHeaderStyleCount, 'col'));
                      let headerRef = ws.getCell(16, ArrayFind(colMitiHeaders, 'value', 'MITIGATION ' + mitigationHeaderStyleCount, 'col'));
                      let noStripeStyle = ws.getCell(17, ArrayFind(colMitiHeaders, 'value', 'MITIGATION ' + mitigationHeaderStyleCount, 'col'));
                      let stripeStyle = ws.getCell(18, ArrayFind(colMitiHeaders, 'value', 'MITIGATION ' + mitigationHeaderStyleCount, 'col'));

                      ws.getCell(15, addtlMitiCtr).value = "MITIGATION " + mitigationCount;
                      ws.getCell(16, addtlMitiCtr).value = "Title";
                      ws.getCell(16, addtlMitiCtr + 1).value = "Description";
                      ws.getCell(16, addtlMitiCtr + 2).value = "Created by";
                      ws.getCell(16, addtlMitiCtr + 3).value = "Assigned To";
                      ws.getCell(16, addtlMitiCtr + 4).value = "Status";
                      ws.getCell(16, addtlMitiCtr + 5).value = "Created On";
                      ws.getCell(16, addtlMitiCtr + 6).value = "Due Date";

                      ws.getColumn(addtlMitiCtr).width = ws.getColumn(ArrayFind(mitigationHeaders, 'value', 'Title', 'col')).width;
                      ws.getColumn(addtlMitiCtr + 1).width = ws.getColumn(25).width; // gets description from mitigation columns directly
                      ws.getColumn(addtlMitiCtr + 2).width = ws.getColumn(ArrayFind(mitigationHeaders, 'value', 'Created by', 'col')).width;
                      ws.getColumn(addtlMitiCtr + 3).width = ws.getColumn(ArrayFind(mitigationHeaders, 'value', 'Assigned To', 'col')).width;
                      ws.getColumn(addtlMitiCtr + 4).width = ws.getColumn(ArrayFind(mitigationHeaders, 'value', 'Status', 'col')).width;
                      ws.getColumn(addtlMitiCtr + 5).width = ws.getColumn(ArrayFind(mitigationHeaders, 'value', 'Created on', 'col')).width;
                      ws.getColumn(addtlMitiCtr + 6).width = ws.getColumn(ArrayFind(mitigationHeaders, 'value', 'Due Date', 'col')).width;

                      // mitigation header style
                      ws.getCell(15, addtlMitiCtr).style = mitRef.style;
                      ws.getCell(15, addtlMitiCtr + 1).style = mitRef.style;
                      ws.getCell(15, addtlMitiCtr + 2).style = mitRef.style;
                      ws.getCell(15, addtlMitiCtr + 3).style = mitRef.style;
                      ws.getCell(15, addtlMitiCtr + 4).style = mitRef.style;
                      ws.getCell(15, addtlMitiCtr + 5).style = mitRef.style;
                      ws.getCell(15, addtlMitiCtr + 6).style = mitRef.style;

                      // title header style
                      ws.getCell(16, addtlMitiCtr).style = headerRef.style;
                      ws.getCell(16, addtlMitiCtr + 1).style = headerRef.style;
                      ws.getCell(16, addtlMitiCtr + 2).style = headerRef.style;
                      ws.getCell(16, addtlMitiCtr + 3).style = headerRef.style;
                      ws.getCell(16, addtlMitiCtr + 4).style = headerRef.style;
                      ws.getCell(16, addtlMitiCtr + 5).style = headerRef.style;
                      ws.getCell(16, addtlMitiCtr + 6).style = headerRef.style;

                      //insert new data
                      ws.getCell(qaRefRowCtr, addtlMitiCtr).value = questions[y].Mitigations[x].Title;
                      ws.getCell(qaRefRowCtr, addtlMitiCtr + 1).value = questions[y].Mitigations[x].Description;
                      ws.getCell(qaRefRowCtr, addtlMitiCtr + 2).value = questions[y].Mitigations[x].CreatedBy;
                      ws.getCell(qaRefRowCtr, addtlMitiCtr + 3).value = questions[y].Mitigations[x].AssignedTo;
                      ws.getCell(qaRefRowCtr, addtlMitiCtr + 4).value = questions[y].Mitigations[x].Status;
                      ws.getCell(qaRefRowCtr, addtlMitiCtr + 5).value = questions[y].Mitigations[x].CreatedOn;
                      ws.getCell(qaRefRowCtr, addtlMitiCtr + 6).value = questions[y].Mitigations[x].DueDate;

                      // styling for all cells in a column of new data
                      for (let row = 17; row < 45; row++) {
                        if (oddColumn) {
                          ws.getCell(row, addtlMitiCtr).style = noStripeStyle.style;
                          ws.getCell(row, addtlMitiCtr + 1).style = noStripeStyle.style;
                          ws.getCell(row, addtlMitiCtr + 2).style = noStripeStyle.style;
                          ws.getCell(row, addtlMitiCtr + 3).style = noStripeStyle.style;
                          ws.getCell(row, addtlMitiCtr + 4).style = noStripeStyle.style;
                          ws.getCell(row, addtlMitiCtr + 5).style = noStripeStyle.style;
                          ws.getCell(row, addtlMitiCtr + 6).style = noStripeStyle.style;
                          oddColumn = false;
                        } else {
                          ws.getCell(row, addtlMitiCtr).style = stripeStyle.style;
                          ws.getCell(row, addtlMitiCtr + 1).style = stripeStyle.style;
                          ws.getCell(row, addtlMitiCtr + 2).style = stripeStyle.style;
                          ws.getCell(row, addtlMitiCtr + 3).style = stripeStyle.style;
                          ws.getCell(row, addtlMitiCtr + 4).style = stripeStyle.style;
                          ws.getCell(row, addtlMitiCtr + 5).style = stripeStyle.style;
                          ws.getCell(row, addtlMitiCtr + 6).style = stripeStyle.style;
                          oddColumn = true;
                        }
                      }

                      try {
                        ws.mergeCells(ws.getCell(15, addtlMitiCtr).address + ':' + ws.getCell(15, addtlMitiCtr + 6).address);
                      } catch (err) { }

                      addtlMitiCtr = addtlMitiCtr + 7;
                      mitigationHeaderStyleCount++;
                      maxMitigationCount = addtlMitiCtr;
                    }
                    mitigationCount++;
                  }
                }
              }
              qaRefRowCtr++;
            }
          }
          if (maxMitigationCount >= 58) {
            let lastCell = maxMitigationCount - 1;
            ws.autoFilter = { from: { row: 16, column: 3 }, to: { row: 44, column: lastCell } };
            ws.getCell('BF14').border = { right: { style: 'none' } };
            ws.getCell('BF45').border = { right: { style: 'none' } };

            let bg14Cell = ws.getCell('BG14');
            bg14Cell.style = _.cloneDeep(bg14Cell.style);
            bg14Cell.fill = { type: 'pattern', pattern: 'none' };

            let bg45Cell = ws.getCell('BG45');
            bg45Cell.style = _.cloneDeep(bg45Cell.style);
            bg45Cell.fill = { type: 'pattern', pattern: 'none' };

            let bgGrayCell = maxMitigationCount + 2;
            for (let x = 58; x < bgGrayCell; x++) {
              if (x < bgGrayCell - 1) {
                let riHeaderCell = ws.getCell(13, x);
                riHeaderCell.style = _.cloneDeep(riHeaderCell.style);
                riHeaderCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'A6A6A6' }, bgColor: { argb: 'A6A6A6' } };

                let riFooterCell = ws.getCell(46, x);
                riFooterCell.style = _.cloneDeep(riFooterCell.style);
                riFooterCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'F2F2F2' }, bgColor: { argb: 'F2F2F2' } };

                ws.getCell(46, x).border = { top: { style: 'medium', color: { argb: 'A6A6A6' } } };
              }

              for (let y = 0; y < 13; y++) {
                let lightGrayHeaderCell = ws.getCell(y, x);
                lightGrayHeaderCell.style = _.cloneDeep(lightGrayHeaderCell.style);
                lightGrayHeaderCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'F2F2F2' }, bgColor: { argb: 'F2F2F2' } };
              }
            }

            let lastCol = ws.getColumn(maxMitigationCount);
            lastCol.width = 2;

            // Right
            for (let h = 13; h < 47; h++) {
              if (h < 46) {
                ws.getCell(h, maxMitigationCount).border = { right: { style: 'medium', color: { argb: 'A6A6A6' } } };
              }

              let riRightCell = ws.getCell(h, maxMitigationCount + 1);
              riRightCell.style = _.cloneDeep(riRightCell.style);
              riRightCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'F2F2F2' }, bgColor: { argb: 'F2F2F2' } };
            }
          }
          workbook.xlsx.writeBuffer()
            .then(function (buffer) {
              resolve(buffer);
            });
        });
      }
      else {
        let file = storage.bucket(process.env.STORAGEBUCKET).file(`excel-templates/Risk Assessment View Export Template v4.xlsx`)
        file.download(function (err, contents) {
          resolve(contents);
        });
      }
    } catch (error) {
      return reject(error);
    }
  });
}

function ArrayFind(arr, prop, value, ret) {
  let val = arr.find(x => x[prop] == value);
  if (val) {
    return val[ret];
  }
  return '';
}

const _searchRiskIssuesID = (id, view) => {
  return new Promise(async function (resolve, reject) {
    var res = await risksIssuesRepository.searchRiskIssuesID(id, view);
    try {
      let rows = [];
      if (res && (view == '136004' || view == '136003')) {
        res.forEach(row => {
          row.forEach(col => {
            if ((col.name == 'duedate' || col.name == 'followupdate') && col.value) {
              var dateValue = moment(col.value).format('DD-MMM-YYYY');
              col.value = dateValue;
            }
            if (view == '136003' && col.name == 'consulcall' && col.value && col.value.includes('Reviewed on')) {
              var date = col.value.substr(12);
              var colValue = date ? 'Reviewed on ' + moment(date).format('DD-MMM-YYYY') : 'Reviewed on ';
              col.value = colValue;
            }
          })
          rows.push(row);
        })
      }
      else if (res && (view == '136001')) {
        res.forEach(row => {
          row.forEach(col => {
            if (col.name == 'qmdreview' && col.value && col.value.includes('Requested on')) {
              var date = col.value.substr(13);
              var qmdreview = date ? 'Requested on ' + moment(date).format('DD-MMM-YYYY') : 'Requested on ';
              col.value = qmdreview;
            }
            else if ((col.name == 'status' || col.name == 'consulcall') && col.value && col.value.includes('Reviewed on')) {
              var date = col.value.substr(12);
              var colValue = date ? 'Reviewed on ' + moment(date).format('DD-MMM-YYYY') : 'Reviewed on ';
              col.value = colValue;
            }
          })
          rows.push(row);
        })
      } else {
        rows = res;
      }
      rows = replaceQuotes(rows);
      // Read #1, using SQL
      resolve(rows);
      rows.catch(err);

    } catch (err) {

      return reject(err);

    }
  })
}

function replaceQuotes(res) {
  let rows = [];
  if (res.length > 0) {
    res.forEach(row => {
      row.forEach(col => {
        let value = col.value;
        if (value) {
          if (typeof value === 'string' || value instanceof String) {
            col.value = value.replace("’", "'");
          } else if (Array.isArray(value) && value.length > 0) {
            for (var i = 0; i < value.length; i++) {
              if (value[i]) {
                value[i] = value[i].replace("’", "'");
              }
            }
            col.value = value;
          }
        } else {
          col.value = value;
        }
      })
      rows.push(row);
    })
  }
  return rows;
}

module.exports = {
  _getRisksIssuesViews,
  _getRisksAndIssues,
  _exportAssessmentView,
  _searchRiskIssuesID
}
