'use strict';

const express = require('express');
const router = express.Router();
const risksIssuesController = require('./risksissues.controller');
const { hasAccess } = require('./middlewares/accesscontrol');


router.get('/getRisksIssuesViews/:mc/:fc/:con/:view?', hasAccess, risksIssuesController.getRisksIssuesViews);
router.get('/getRisksAndIssues/:mc/:fc/:con/:view', hasAccess, risksIssuesController.getRisksAndIssues);
router.post('/exportAssessmentView', hasAccess, risksIssuesController.exportAssessmentView);
router.get('/searchRiskIssuesID/:id/:view', risksIssuesController.searchRiskIssuesID);
module.exports = router;