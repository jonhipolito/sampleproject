'use strict';

const risksIssuesService = require('./risksissues.service');

const getRisksIssuesViews = (req, res, next) => {
    risksIssuesService._getRisksIssuesViews(req.params.mc, req.params.fc, req.params.con, req.params.view)
        .then(data => {
            res.status(200).json({
                data: data
            });
        })
        .catch(error => {
            const err = new Error(error);
            next(err);
        })
}

const getRisksAndIssues = (req, res, next) => {
    risksIssuesService._getRisksAndIssues(req.params.mc, req.params.fc, req.params.con, req.params.view)
        .then(data => {
            res.status(200).json({
                data: data
            });
        })
        .catch(error => {
            const err = new Error(error);
            next(err);
        })
}

const exportAssessmentView = (req, res, next) => {
    risksIssuesService._exportAssessmentView(req.body)
    .then(data => {
        res.set('Response-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        res.status(200).send(data);
    })
    .catch(error => {
        const err = new Error(error);
        next(err);
    })
}

const searchRiskIssuesID = (req, res, next) => {
    risksIssuesService._searchRiskIssuesID(req.params.id, req.params.view)
        .then(data => {
            res.status(200).json({
                data: data
            });
        })
        .catch(error => {
            const err = new Error(error);
            next(err);
        })
}

module.exports = {
    getRisksIssuesViews,
    getRisksAndIssues,
    exportAssessmentView,
    searchRiskIssuesID
}