'use strict';

const SpannerDB = require('../configs/db.connection');

const getRisksIssuesViews = async () => {
    const database = new SpannerDB();

    const risksIssuesViewsquery = `SELECT CodeTxt AS id
                                        ,PrimaryDecodeTxt AS primaryTxt
                                        ,SecondaryDecodeTxt AS secondaryTxt
                                        ,'false' AS disabled
                                    FROM CodeDetail cd
                                    INNER JOIN CodeHeader ch
                                        ON cd.CodeHeaderId = ch.CodeHeaderId
                                    WHERE ch.CategoryDesc = 'RisksAndIssuesViews'`;

    try {
        let [risksIssuesViewsRows] = await database.run(risksIssuesViewsquery);
        return risksIssuesViewsRows;
    } catch (err) {
        // return new Error(err);
    } finally {
        // Close the database when finished.
        await database.close();
    }
}

const getRisksAndIssues = async (mc, fc, con, view) => {
    const database = new SpannerDB();

    var risksIssuesquery = await getQuery(mc, fc, con, view);

    try {
        let [risksIssuesRows] = await database.run(risksIssuesquery);
        if (risksIssuesRows.length > 0) {
            return risksIssuesRows;
        } else {
            return null;
        }
    } catch (err) {
        return new Error(err);
    } finally {
        // Close the database when finished.
        await database.close();
    }
}

const getQuery = async (mc, fc, con, view) => {

    var query = ``;

    if (con != 'null') {
        switch (view) {
            case '136001': //RisksIssuesLogs
                query = `SELECT rating
                            ,category
                            ,subcategory
                            ,CASE
                            	WHEN source = 'CM' 
                                	THEN
										CASE
                                        	WHEN (statementcount - 1) = 0 THEN cd.PrimaryDecodeTxt
                                            ELSE concat(concat(concat(cd.PrimaryDecodeTxt, ', + '), CAST((statementcount - 1) AS STRING)), ' more')
                                        END
                                ELSE res.statement
                            END AS statement
                            ,statementall
                            ,type
                            ,status
                            ,consulcall
                            ,qmdreview
                            ,source
                            ,contractname
                            ,riskdetailskey
                            ,riskassessmentquestionkey
                            ,contractnbr
                            ,contractnm
                            ,customernbr
                            ,customernm
                            ,masterclientnbr
                            ,masterclientnm
                            ,riskid
                            ,mitigationid
                        FROM (
                            SELECT IFNULL(cd1.PrimaryDecodeTxt,'Unrated') AS rating
                                ,IFNULL(cd1.SecondaryDecodeTxt,'4') AS ratingorder
                                ,CASE
                                    WHEN cd7.PrimaryDecodeTxt = 'CM' THEN cd2.PrimaryDecodeTxt
                                    ELSE rd.CIPCategoryNm
                                END AS category
                                ,CASE
                                    WHEN cd7.PrimaryDecodeTxt = 'CM' THEN cd3.PrimaryDecodeTxt
                                    ELSE rd.CIPSubCategoryNm
                                END AS subcategory
                                ,CASE
                                    WHEN cd7.PrimaryDecodeTxt = 'CM' THEN (SELECT * FROM UNNEST(rd.StatementArr) LIMIT 1)
                                    ELSE 
                                        CASE
                                            WHEN rd.CIPRiskStatementNm IS NULL OR rd.CIPRiskStatementNm = '' THEN 'CIP Risk'
                                            ELSE rd.CIPRiskStatementNm
                                        END
                                END AS statement
                                ,CASE
                                    WHEN cd7.PrimaryDecodeTxt = 'CM' THEN (SELECT ARRAY_LENGTH(rd.StatementArr))
                                    ELSE 0
                                END AS statementcount
                                ,CASE
                                    WHEN cd7.PrimaryDecodeTxt = 'CM' THEN concat('• ',(SELECT ARRAY_TO_STRING((SELECT ARRAY_AGG(PrimaryDecodeTxt) FROM CodeDetail WHERE CodeTxt IN UNNEST(rd.StatementArr)), '\\n• ')))
                                    ELSE 
                                      CASE
                                          WHEN rd.CIPRiskStatementNm IS NULL OR rd.CIPRiskStatementNm = '' THEN '• CIP Risk'
                                          ELSE concat('• ', rd.CIPRiskStatementNm)
                                      END
                                END AS statementall
                                ,cd4.PrimaryDecodeTxt AS type
                                ,CASE
                                    WHEN LOWER(cd5.PrimaryDecodeTxt) = 'reviewed' THEN concat(concat(cd5.PrimaryDecodeTxt, ' on '), CAST(rd.RiskLeadReviewDttm AS STRING))
                                    ELSE cd5.PrimaryDecodeTxt
                                END AS status
                                ,CASE
                                    WHEN cd7.PrimaryDecodeTxt = 'CIP' THEN ''
                                    ELSE 
                                        CASE
                                            WHEN LOWER(cd6.PrimaryDecodeTxt) = 'reviewed' THEN concat(concat(cd6.PrimaryDecodeTxt, ' on '), CAST(cc.ReviewerCompletedDt AS STRING))
                                            ELSE IFNULL(cd6.PrimaryDecodeTxt,'Not Requested')
                                        END
                                END AS consulcall
                                ,CASE
                                    WHEN cd7.PrimaryDecodeTxt = 'CIP' THEN ''
                                    ELSE 
                                        CASE
                                            WHEN rd.RiskQMDReviewInd = 'N' OR rd.RiskQMDReviewInd IS NULL THEN 'Not Requested'
                                            WHEN rd.RiskQMDReviewInd = 'Y' THEN concat('Requested on ',CAST(rd.RiskQMDReviewDttm AS STRING))
                                            ELSE ''
                                        END
                                END AS qmdreview
                                ,cd7.PrimaryDecodeTxt AS source
                                ,CASE
                                    WHEN rd.ContractNbr = '' AND cd7.PrimaryDecodeTxt = 'CM' THEN 'No Contracts Available'
                                    WHEN rd.ContractNbr = '' AND cd7.PrimaryDecodeTxt = 'CIP' THEN ''
                                    ELSE concat(concat(rd.ContractNm, ' - '), rd.ContractNbr)
                                END AS contractname
                                ,rd.RiskDetailsKey AS riskdetailskey
                                ,raq.RiskAssessmentQuestionKey AS riskassessmentquestionkey
                                ,rd.ContractNbr AS contractnbr
                                ,rd.ContractNm AS contractnm
                                ,rd.CustomerNbr AS customernbr
                                ,rd.CustomerNm AS customernm
                                ,rd.MasterClientNbr AS masterclientnbr
                                ,rd.MasterClientNm AS masterclientnm
                                ,rd.RiskNbr AS riskid
                                ,ARRAY(SELECT CAST(MitigationNbr AS STRING) FROM RiskMitigation rm WHERE rm.RiskDetailsKey = rd.RiskDetailsKey) AS mitigationid
                            FROM RiskDetails rd
                            LEFT JOIN RiskAssessmentQuestion raq
                                ON rd.RiskAssessmentQuestionKey = raq.RiskAssessmentQuestionKey
                            LEFT JOIN RiskConsultationCall cc
                                ON rd.RiskDetailsKey = cc.RiskDetailsKey
                            LEFT JOIN CodeDetail cd1
                                ON rd.RiskRatingCd = cd1.CodeTxt
                            LEFT JOIN CodeDetail cd2
                                ON raq.CategoryCd = cd2.CodeTxt
                            LEFT JOIN CodeDetail cd3
                                ON raq.SubCategoryCd = cd3.CodeTxt
                            LEFT JOIN CodeDetail cd4
                                ON rd.RiskTypeCd = cd4.CodeTxt
                            LEFT JOIN CodeDetail cd5
                                ON rd.RiskStatusCd = cd5.CodeTxt
                            LEFT JOIN CodeDetail cd6
                                ON cc.ConsultationCallStatusCd = cd6.CodeTxt
                            LEFT JOIN CodeDetail cd7
                                ON rd.RiskSourceCd = cd7.CodeTxt
                            WHERE (cd7.PrimaryDecodeTxt = 'CIP' OR
                                (cd7.PrimaryDecodeTxt = 'CM' AND (cd1.PrimaryDecodeTxt IN ('High', 'Above Normal'))))
                                AND rd.ContractNbr = '${con}'
                        ) res
                        LEFT JOIN CodeDetail cd
                            ON cd.CodeTxt = res.statement
                        ORDER BY ratingorder ASC`;
                break;
            case '136002': //Assessment
                query = `SELECT category, subcategory, question, rating, type, source, riskdetailskey, riskassessmentquestionkey, contractnbr, contractnm, customernbr, customernm, masterclientnbr, masterclientnm,riskid,mitigationid
                        FROM (
                            SELECT cd1.PrimaryDecodeTxt AS category
                                ,cd2.PrimaryDecodeTxt AS subcategory
                                ,cd3.SecondaryDecodeTxt AS question
                                ,raq.QuestionOrderNbr AS questionorder
                                ,IFNULL(rating,'Unrated') AS rating
                                ,IFNULL(ratingorder,'4') AS ratingorder
                                ,type
                                ,source
                                ,riskdetailskey
                                ,raq.RiskAssessmentQuestionKey AS riskassessmentquestionkey
                                ,contractnbr
                                ,contractnm
                                ,customernbr
                                ,customernm
                                ,masterclientnbr
                                ,masterclientnm
                                ,riskid
                                ,mitigationid
                            FROM RiskAssessmentQuestion raq
                            LEFT JOIN
                            (
                                SELECT cd4.PrimaryDecodeTxt AS rating
                                    ,cd4.SecondaryDecodeTxt AS ratingorder
                                    ,cd5.PrimaryDecodeTxt AS type
                                    ,cd6.PrimaryDecodeTxt AS source
                                    ,rd.RiskDetailsKey AS riskdetailskey
                                    ,rd.ContractNbr AS contractnbr
                                    ,rd.ContractNm AS contractnm
                                    ,rd.CustomerNbr AS customernbr
                                    ,rd.CustomerNm AS customernm
                                    ,rd.MasterClientNbr AS masterclientnbr
                                    ,rd.MasterClientNm AS masterclientnm
                                    ,rd.RiskAssessmentQuestionKey
                                    ,rd.RiskNbr AS riskid
                                    ,ARRAY(SELECT CAST(MitigationNbr AS STRING) FROM RiskMitigation rm WHERE rm.RiskDetailsKey = rd.RiskDetailsKey) AS mitigationid
                                FROM RiskDetails rd
                                LEFT JOIN CodeDetail cd4
                                    ON rd.RiskRatingCd = cd4.CodeTxt
                                LEFT JOIN CodeDetail cd5
                                    ON rd.RiskTypeCd = cd5.CodeTxt
                                LEFT JOIN CodeDetail cd6
                                    ON rd.RiskSourceCd = cd6.CodeTxt
                                WHERE cd6.PrimaryDecodeTxt != 'CIP'
                                    AND rd.ContractNbr = '${con}'
                            ) res
                                ON raq.RiskAssessmentQuestionKey = res.RiskAssessmentQuestionKey
                            LEFT JOIN CodeDetail cd1
                                ON raq.CategoryCd = cd1.CodeTxt
                            LEFT JOIN CodeDetail cd2
                                ON raq.SubCategoryCd = cd2.CodeTxt
                            LEFT JOIN CodeDetail cd3
                                ON raq.RiskQuestionCd = cd3.CodeTxt
                        )
                        ORDER BY questionorder ASC`;
                break;
            case '136003': //Consultation
                query = `SELECT rating
                            ,category
                            ,subcategory
                            ,CASE
                                WHEN (statementcount - 1) = 0 THEN cd.PrimaryDecodeTxt
                                ELSE concat(concat(concat(cd.PrimaryDecodeTxt, ', + '), CAST((statementcount - 1) AS STRING)), ' more')
                            END AS statement
                            ,concat('• ',(SELECT ARRAY_TO_STRING(statementarray, '\\n• '))) as statementall
                            ,type
                            ,consulcall
                            ,followupdate
                            ,contractname
                            ,source
                            ,riskdetailskey
                            ,riskassessmentquestionkey
                            ,contractnbr
                            ,contractnm
                            ,customernbr
                            ,customernm
                            ,masterclientnbr
                            ,masterclientnm
                            ,riskid
                            ,mitigationid
                        FROM (
                            SELECT IFNULL(cd1.PrimaryDecodeTxt,'Unrated') AS rating
                                ,IFNULL(cd1.SecondaryDecodeTxt,'4') AS ratingorder
                                ,cd2.PrimaryDecodeTxt AS category
                                ,cd3.PrimaryDecodeTxt AS subcategory
                                ,(SELECT * FROM UNNEST(rd.StatementArr)LIMIT 1) AS statement
                                ,(SELECT ARRAY_LENGTH(rd.StatementArr)) AS statementcount
                                ,(SELECT ARRAY_AGG(PrimaryDecodeTxt) FROM CodeDetail WHERE CodeTxt IN UNNEST(rd.StatementArr)) AS statementarray
                                ,cd4.PrimaryDecodeTxt AS type
                                ,CASE
                                    WHEN LOWER(cd5.PrimaryDecodeTxt) = 'reviewed' THEN concat(concat(cd5.PrimaryDecodeTxt, ' on '), CAST(cc.ReviewerCompletedDt AS STRING))
                                    ELSE cd5.PrimaryDecodeTxt
                                END AS consulcall
                                ,cc.ReviewerFollowupDt AS followupdate
                                ,CASE
                                    WHEN rd.ContractNbr = '' THEN 'No Contracts Available'
                                    ELSE concat(concat(rd.ContractNm, ' - '), rd.ContractNbr)
                                END AS contractname
                                ,cd6.PrimaryDecodeTxt AS source
                                ,rd.RiskDetailsKey AS riskdetailskey
                                ,raq.RiskAssessmentQuestionKey AS riskassessmentquestionkey
                                ,rd.ContractNbr AS contractnbr
                                ,rd.ContractNm AS contractnm
                                ,rd.CustomerNbr AS customernbr
                                ,rd.CustomerNm AS customernm
                                ,rd.MasterClientNbr AS masterclientnbr
                                ,rd.MasterClientNm AS masterclientnm
                                ,rd.RiskNbr AS riskid
                                ,ARRAY(SELECT CAST(MitigationNbr AS STRING) FROM RiskMitigation rm WHERE rm.RiskDetailsKey = rd.RiskDetailsKey) AS mitigationid
                            FROM RiskDetails rd
                            LEFT JOIN RiskAssessmentQuestion raq
                                ON rd.RiskAssessmentQuestionKey = raq.RiskAssessmentQuestionKey
                            LEFT JOIN RiskConsultationCall cc
                                ON rd.RiskDetailsKey = cc.RiskDetailsKey
                            LEFT JOIN CodeDetail cd1
                                ON rd.RiskRatingCd = cd1.CodeTxt
                            LEFT JOIN CodeDetail cd2
                                ON raq.CategoryCd = cd2.CodeTxt
                            LEFT JOIN CodeDetail cd3
                                ON raq.SubCategoryCd = cd3.CodeTxt
                            LEFT JOIN CodeDetail cd4
                                ON rd.RiskTypeCd = cd4.CodeTxt
                            LEFT JOIN CodeDetail cd5
                                ON cc.ConsultationCallStatusCd = cd5.CodeTxt
                            LEFT JOIN CodeDetail cd6
                                ON rd.RiskSourceCd = cd6.CodeTxt
                            WHERE cd6.PrimaryDecodeTxt != 'CIP'
                                AND cc.ConsultationCallStatusCd IS NOT NULL
                                AND LOWER(cd5.PrimaryDecodeTxt) IN ('pending', 'reviewed')
                                AND rd.ContractNbr = '${con}'
                        ) res
                        LEFT JOIN CodeDetail cd
                            ON cd.CodeTxt = res.statement
                        ORDER BY ratingorder ASC`;
                break;
            case '136004': //MyMitigations
                query = `SELECT rating 
                            ,CASE
                            	WHEN source = 'CM' 
                                	THEN
                                    	CASE
                                        	WHEN (statementcount - 1) = 0 THEN cd.PrimaryDecodeTxt
                                            ELSE concat(concat(concat(cd.PrimaryDecodeTxt, ', + '), CAST((statementcount - 1) AS STRING)), ' more')
                                        END
                                ELSE res.statement
                            END AS statement
                            ,statementall
                            ,description 
                            ,status 
                            ,duedate 
                            ,source 
                            ,contractname
                            ,riskdetailskey
                            ,riskassessmentquestionkey
                            ,contractnbr
                            ,contractnm
                            ,customernbr
                            ,customernm
                            ,masterclientnbr
                            ,masterclientnm
                            ,riskid
                            ,mitigationid
                        FROM (
                            SELECT IFNULL(cd1.PrimaryDecodeTxt,'Unrated') AS rating
                                ,IFNULL(cd1.SecondaryDecodeTxt,'4') AS ratingorder
                                ,CASE
                                    WHEN cd3.PrimaryDecodeTxt = 'CM' THEN (SELECT * FROM UNNEST(rd.StatementArr) LIMIT 1)
                                    ELSE 
                                        CASE
                                            WHEN rd.CIPRiskStatementNm IS NULL OR rd.CIPRiskStatementNm = '' THEN 'CIP Risk'
                                            ELSE rd.CIPRiskStatementNm
                                        END
                                END AS statement
                                ,CASE
                                    WHEN cd3.PrimaryDecodeTxt = 'CM' THEN (SELECT ARRAY_LENGTH(rd.StatementArr))
                                    ELSE 0
                                END AS statementcount
                                ,CASE
                                    WHEN cd3.PrimaryDecodeTxt = 'CM' THEN concat('• ',(SELECT ARRAY_TO_STRING((SELECT ARRAY_AGG(PrimaryDecodeTxt) FROM CodeDetail WHERE CodeTxt IN UNNEST(rd.StatementArr)), '\\n• ')))
                                    ELSE 
                                        CASE
                                            WHEN rd.CIPRiskStatementNm IS NULL OR rd.CIPRiskStatementNm = '' THEN '• CIP Risk'
                                            ELSE concat('• ', rd.CIPRiskStatementNm)
                                        END
                                END AS statementall
                                ,rm.MitigationDesc AS description
                                ,cd2.PrimaryDecodeTxt AS status
                                ,rm.DueDttm AS duedate
                                ,cd3.PrimaryDecodeTxt AS source
                                ,CASE
                                    WHEN rd.ContractNbr = '' THEN 'No Contracts Available'
                                    ELSE concat(concat(rd.ContractNm, ' - '), rd.ContractNbr)
                                END AS contractname
                                ,rd.RiskDetailsKey AS riskdetailskey
                                ,raq.RiskAssessmentQuestionKey AS riskassessmentquestionkey
                                ,rd.ContractNbr AS contractnbr
                                ,rd.ContractNm AS contractnm
                                ,rd.CustomerNbr AS customernbr
                                ,rd.CustomerNm AS customernm
                                ,rd.MasterClientNbr AS masterclientnbr
                                ,rd.MasterClientNm AS masterclientnm
                                ,rd.RiskNbr AS riskid
                                ,CAST(rm.MitigationNbr AS STRING) AS mitigationid
                            FROM RiskDetails rd
                            LEFT JOIN RiskAssessmentQuestion raq
                                ON rd.RiskAssessmentQuestionKey = raq.RiskAssessmentQuestionKey
                            LEFT JOIN RiskMitigation rm
                                ON rd.RiskDetailsKey = rm.RiskDetailsKey
                            LEFT JOIN CodeDetail cd1
                                ON rd.RiskRatingCd = cd1.CodeTxt
                            LEFT JOIN CodeDetail cd2
                                ON rm.MitigationStatusCd = cd2.CodeTxt
                            LEFT JOIN CodeDetail cd3
                                ON rd.RiskSourceCd = cd3.CodeTxt
                            WHERE rm.AssigneeUserId = '${process.env.ENTERPRISEID}'
                                AND rd.ContractNbr = '${con}'
                        ) res
                        LEFT JOIN CodeDetail cd
                            ON cd.CodeTxt = res.statement
                        ORDER BY ratingorder ASC`;
                break;
        }
    } else if (fc != 'null') {
        switch (view) {
            case '136001': //RisksIssuesLogs
                query = `SELECT rating
                            ,category
                            ,subcategory
                            ,CASE
                            	WHEN source = 'CM' 
                                	THEN
										CASE
                                        	WHEN (statementcount - 1) = 0 THEN cd.PrimaryDecodeTxt
                                            ELSE concat(concat(concat(cd.PrimaryDecodeTxt, ', + '), CAST((statementcount - 1) AS STRING)), ' more')
                                        END
                                ELSE res.statement
                            END AS statement
                            ,statementall
                            ,type
                            ,status
                            ,consulcall
                            ,qmdreview
                            ,source
                            ,contractname
                            ,riskdetailskey
                            ,riskassessmentquestionkey
                            ,contractnbr
                            ,contractnm
                            ,customernbr
                            ,customernm
                            ,masterclientnbr
                            ,masterclientnm
                            ,riskid
                            ,mitigationid
                        FROM (
                            SELECT IFNULL(cd1.PrimaryDecodeTxt,'Unrated') AS rating
                                ,IFNULL(cd1.SecondaryDecodeTxt,'4') AS ratingorder
                                ,CASE
                                    WHEN cd7.PrimaryDecodeTxt = 'CM' THEN cd2.PrimaryDecodeTxt
                                    ELSE rd.CIPCategoryNm
                                END AS category
                                ,CASE
                                    WHEN cd7.PrimaryDecodeTxt = 'CM' THEN cd3.PrimaryDecodeTxt
                                    ELSE rd.CIPSubCategoryNm
                                END AS subcategory
                                ,CASE
                                    WHEN cd7.PrimaryDecodeTxt = 'CM' THEN (SELECT * FROM UNNEST(rd.StatementArr) LIMIT 1)
                                    ELSE 
                                        CASE
                                            WHEN rd.CIPRiskStatementNm IS NULL OR rd.CIPRiskStatementNm = '' THEN 'CIP Risk'
                                            ELSE rd.CIPRiskStatementNm
                                        END
                                END AS statement
                                ,CASE
                                    WHEN cd7.PrimaryDecodeTxt = 'CM' THEN (SELECT ARRAY_LENGTH(rd.StatementArr))
                                    ELSE 0
                                END AS statementcount
                                ,CASE
                                    WHEN cd7.PrimaryDecodeTxt = 'CM' THEN concat('• ',(SELECT ARRAY_TO_STRING((SELECT ARRAY_AGG(PrimaryDecodeTxt) FROM CodeDetail WHERE CodeTxt IN UNNEST(rd.StatementArr)), '\\n• ')))
                                    ELSE 
                                      CASE
                                          WHEN rd.CIPRiskStatementNm IS NULL OR rd.CIPRiskStatementNm = '' THEN '• CIP Risk'
                                          ELSE concat('• ', rd.CIPRiskStatementNm)
                                      END
                                END AS statementall
                                ,cd4.PrimaryDecodeTxt AS type
                                ,CASE
                                    WHEN LOWER(cd5.PrimaryDecodeTxt) = 'reviewed' THEN concat(concat(cd5.PrimaryDecodeTxt, ' on '), CAST(rd.RiskLeadReviewDttm AS STRING))
                                    ELSE cd5.PrimaryDecodeTxt
                                END AS status
                                ,CASE
                                    WHEN cd7.PrimaryDecodeTxt = 'CIP' THEN ''
                                    ELSE 
                                        CASE
                                            WHEN LOWER(cd6.PrimaryDecodeTxt) = 'reviewed' THEN concat(concat(cd6.PrimaryDecodeTxt, ' on '), CAST(cc.ReviewerCompletedDt AS STRING))
                                            ELSE IFNULL(cd6.PrimaryDecodeTxt,'Not Requested')
                                        END
                                END AS consulcall
                                ,CASE
                                    WHEN cd7.PrimaryDecodeTxt = 'CIP' THEN ''
                                    ELSE 
                                        CASE
                                            WHEN rd.RiskQMDReviewInd = 'N' OR rd.RiskQMDReviewInd IS NULL THEN 'Not Requested'
                                            WHEN rd.RiskQMDReviewInd = 'Y' THEN concat('Requested on ',CAST(rd.RiskQMDReviewDttm AS STRING))
                                            ELSE ''
                                        END
                                END AS qmdreview
                                ,cd7.PrimaryDecodeTxt AS source
                                ,CASE
                                    WHEN rd.ContractNbr = '' AND cd7.PrimaryDecodeTxt = 'CM' THEN 'No Contracts Available'
                                    WHEN rd.ContractNbr = '' AND cd7.PrimaryDecodeTxt = 'CIP' THEN ''
                                    ELSE concat(concat(rd.ContractNm, ' - '), rd.ContractNbr)
                                END AS contractname
                                ,rd.RiskDetailsKey AS riskdetailskey
                                ,raq.RiskAssessmentQuestionKey AS riskassessmentquestionkey
                                ,rd.ContractNbr AS contractnbr
                                ,rd.ContractNm AS contractnm
                                ,rd.CustomerNbr AS customernbr
                                ,rd.CustomerNm AS customernm
                                ,rd.MasterClientNbr AS masterclientnbr
                                ,rd.MasterClientNm AS masterclientnm
                                ,rd.RiskNbr AS riskid
                                ,ARRAY(SELECT CAST(MitigationNbr AS STRING) FROM RiskMitigation rm WHERE rm.RiskDetailsKey = rd.RiskDetailsKey) AS mitigationid
                            FROM RiskDetails rd
                            LEFT JOIN RiskAssessmentQuestion raq
                                ON rd.RiskAssessmentQuestionKey = raq.RiskAssessmentQuestionKey
                            LEFT JOIN RiskConsultationCall cc
                                ON rd.RiskDetailsKey = cc.RiskDetailsKey
                            LEFT JOIN CodeDetail cd1
                                ON rd.RiskRatingCd = cd1.CodeTxt
                            LEFT JOIN CodeDetail cd2
                                ON raq.CategoryCd = cd2.CodeTxt
                            LEFT JOIN CodeDetail cd3
                                ON raq.SubCategoryCd = cd3.CodeTxt
                            LEFT JOIN CodeDetail cd4
                                ON rd.RiskTypeCd = cd4.CodeTxt
                            LEFT JOIN CodeDetail cd5
                                ON rd.RiskStatusCd = cd5.CodeTxt
                            LEFT JOIN CodeDetail cd6
                                ON cc.ConsultationCallStatusCd = cd6.CodeTxt
                            LEFT JOIN CodeDetail cd7
                                ON rd.RiskSourceCd = cd7.CodeTxt
                            WHERE (cd7.PrimaryDecodeTxt = 'CIP' OR
                                (cd7.PrimaryDecodeTxt = 'CM' AND (cd1.PrimaryDecodeTxt IN ('High', 'Above Normal'))))
                                AND rd.CustomerNbr = '${fc}'
                        ) res
                        LEFT JOIN CodeDetail cd
                            ON cd.CodeTxt = res.statement
                        ORDER BY ratingorder ASC`;
                break;
            case '136002': //Assessment
                query = ``;
                break;
            case '136003': //Consultation
                query = `SELECT rating
                            ,category
                            ,subcategory
                            ,CASE
                                WHEN (statementcount - 1) = 0 THEN cd.PrimaryDecodeTxt
                                ELSE concat(concat(concat(cd.PrimaryDecodeTxt, ', + '), CAST((statementcount - 1) AS STRING)), ' more')
                            END AS statement
                            ,concat('• ',(SELECT ARRAY_TO_STRING(statementarray, '\\n• '))) as statementall
                            ,type
                            ,consulcall
                            ,followupdate
                            ,contractname
                            ,source
                            ,riskdetailskey
                            ,riskassessmentquestionkey
                            ,contractnbr
                            ,contractnm
                            ,customernbr
                            ,customernm
                            ,masterclientnbr
                            ,masterclientnm
                            ,riskid
                            ,mitigationid
                        FROM (
                            SELECT IFNULL(cd1.PrimaryDecodeTxt,'Unrated') AS rating
                                ,IFNULL(cd1.SecondaryDecodeTxt,'4') AS ratingorder
                                ,cd2.PrimaryDecodeTxt AS category
                                ,cd3.PrimaryDecodeTxt AS subcategory
                                ,(SELECT * FROM UNNEST(rd.StatementArr)LIMIT 1) AS statement
                                ,(SELECT ARRAY_LENGTH(rd.StatementArr)) AS statementcount
                                ,(SELECT ARRAY_AGG(PrimaryDecodeTxt) FROM CodeDetail WHERE CodeTxt IN UNNEST(rd.StatementArr)) AS statementarray
                                ,cd4.PrimaryDecodeTxt AS type
                                ,CASE
                                    WHEN LOWER(cd5.PrimaryDecodeTxt) = 'reviewed' THEN concat(concat(cd5.PrimaryDecodeTxt, ' on '), CAST(cc.ReviewerCompletedDt AS STRING))
                                    ELSE cd5.PrimaryDecodeTxt
                                END AS consulcall
                                ,cc.ReviewerFollowupDt AS followupdate
                                ,CASE
                                    WHEN rd.ContractNbr = '' THEN 'No Contracts Available'
                                    ELSE concat(concat(rd.ContractNm, ' - '), rd.ContractNbr)
                                END AS contractname
                                ,cd6.PrimaryDecodeTxt AS source
                                ,rd.RiskDetailsKey AS riskdetailskey
                                ,raq.RiskAssessmentQuestionKey AS riskassessmentquestionkey
                                ,rd.ContractNbr AS contractnbr
                                ,rd.ContractNm AS contractnm
                                ,rd.CustomerNbr AS customernbr
                                ,rd.CustomerNm AS customernm
                                ,rd.MasterClientNbr AS masterclientnbr
                                ,rd.MasterClientNm AS masterclientnm
                                ,rd.RiskNbr AS riskid
                                ,ARRAY(SELECT CAST(MitigationNbr AS STRING) FROM RiskMitigation rm WHERE rm.RiskDetailsKey = rd.RiskDetailsKey) AS mitigationid
                            FROM RiskDetails rd
                            LEFT JOIN RiskAssessmentQuestion raq
                                ON rd.RiskAssessmentQuestionKey = raq.RiskAssessmentQuestionKey
                            LEFT JOIN RiskConsultationCall cc
                                ON rd.RiskDetailsKey = cc.RiskDetailsKey
                            LEFT JOIN CodeDetail cd1
                                ON rd.RiskRatingCd = cd1.CodeTxt
                            LEFT JOIN CodeDetail cd2
                                ON raq.CategoryCd = cd2.CodeTxt
                            LEFT JOIN CodeDetail cd3
                                ON raq.SubCategoryCd = cd3.CodeTxt
                            LEFT JOIN CodeDetail cd4
                                ON rd.RiskTypeCd = cd4.CodeTxt
                            LEFT JOIN CodeDetail cd5
                                ON cc.ConsultationCallStatusCd = cd5.CodeTxt
                            LEFT JOIN CodeDetail cd6
                                ON rd.RiskSourceCd = cd6.CodeTxt
                            WHERE cd6.PrimaryDecodeTxt != 'CIP'
                                AND cc.ConsultationCallStatusCd IS NOT NULL
                                AND LOWER(cd5.PrimaryDecodeTxt) IN ('pending', 'reviewed')
                                AND rd.CustomerNbr = '${fc}'
                        ) res
                        LEFT JOIN CodeDetail cd
                            ON cd.CodeTxt = res.statement
                        ORDER BY ratingorder ASC`;
                break;
            case '136004': //MyMitigations
                query = `SELECT rating 
                            ,CASE
                            	WHEN source = 'CM' 
                                	THEN
                                    	CASE
                                        	WHEN (statementcount - 1) = 0 THEN cd.PrimaryDecodeTxt
                                            ELSE concat(concat(concat(cd.PrimaryDecodeTxt, ', + '), CAST((statementcount - 1) AS STRING)), ' more')
                                        END
                                ELSE res.statement
                            END AS statement
                            ,statementall
                            ,description 
                            ,status 
                            ,duedate 
                            ,source 
                            ,contractname
                            ,riskdetailskey
                            ,riskassessmentquestionkey
                            ,contractnbr
                            ,contractnm
                            ,customernbr
                            ,customernm
                            ,masterclientnbr
                            ,masterclientnm
                            ,riskid
                            ,mitigationid
                        FROM (
                            SELECT IFNULL(cd1.PrimaryDecodeTxt,'Unrated') AS rating
                                ,IFNULL(cd1.SecondaryDecodeTxt,'4') AS ratingorder
                                ,CASE
                                    WHEN cd3.PrimaryDecodeTxt = 'CM' THEN (SELECT * FROM UNNEST(rd.StatementArr) LIMIT 1)
                                    ELSE 
                                        CASE
                                            WHEN rd.CIPRiskStatementNm IS NULL OR rd.CIPRiskStatementNm = '' THEN 'CIP Risk'
                                            ELSE rd.CIPRiskStatementNm
                                        END
                                END AS statement
                                ,CASE
                                    WHEN cd3.PrimaryDecodeTxt = 'CM' THEN (SELECT ARRAY_LENGTH(rd.StatementArr))
                                    ELSE 0
                                END AS statementcount
                                ,CASE
                                    WHEN cd3.PrimaryDecodeTxt = 'CM' THEN concat('• ',(SELECT ARRAY_TO_STRING((SELECT ARRAY_AGG(PrimaryDecodeTxt) FROM CodeDetail WHERE CodeTxt IN UNNEST(rd.StatementArr)), '\\n• ')))
                                    ELSE 
                                      CASE
                                          WHEN rd.CIPRiskStatementNm IS NULL OR rd.CIPRiskStatementNm = '' THEN '• CIP Risk'
                                          ELSE concat('• ', rd.CIPRiskStatementNm)
                                      END
                                END AS statementall
                                ,rm.MitigationDesc AS description
                                ,cd2.PrimaryDecodeTxt AS status
                                ,rm.DueDttm AS duedate
                                ,cd3.PrimaryDecodeTxt AS source
                                ,CASE
                                    WHEN rd.ContractNbr = '' THEN 'No Contracts Available'
                                    ELSE concat(concat(rd.ContractNm, ' - '), rd.ContractNbr)
                                END AS contractname
                                ,rd.RiskDetailsKey AS riskdetailskey
                                ,raq.RiskAssessmentQuestionKey AS riskassessmentquestionkey
                                ,rd.ContractNbr AS contractnbr
                                ,rd.ContractNm AS contractnm
                                ,rd.CustomerNbr AS customernbr
                                ,rd.CustomerNm AS customernm
                                ,rd.MasterClientNbr AS masterclientnbr
                                ,rd.MasterClientNm AS masterclientnm
                                ,rd.RiskNbr AS riskid
                                ,CAST(rm.MitigationNbr AS STRING) AS mitigationid
                            FROM RiskDetails rd
                            LEFT JOIN RiskAssessmentQuestion raq
                                ON rd.RiskAssessmentQuestionKey = raq.RiskAssessmentQuestionKey
                            LEFT JOIN RiskMitigation rm
                                ON rd.RiskDetailsKey = rm.RiskDetailsKey
                            LEFT JOIN CodeDetail cd1
                                ON rd.RiskRatingCd = cd1.CodeTxt
                            LEFT JOIN CodeDetail cd2
                                ON rm.MitigationStatusCd = cd2.CodeTxt
                            LEFT JOIN CodeDetail cd3
                                ON rd.RiskSourceCd = cd3.CodeTxt
                            WHERE rm.AssigneeUserId = '${process.env.ENTERPRISEID}'
                                AND rd.CustomerNbr = '${fc}'
                        ) res
                        LEFT JOIN CodeDetail cd
                            ON cd.CodeTxt = res.statement
                        ORDER BY ratingorder ASC`;
                break;
        }
    } else if (mc != 'null') {
        switch (view) {
            case '136001': //RisksIssuesLogs
                query = `SELECT rating
                            ,category
                            ,subcategory
                            ,CASE
                            	WHEN source = 'CM' 
                                	THEN
										CASE
                                        	WHEN (statementcount - 1) = 0 THEN cd.PrimaryDecodeTxt
                                            ELSE concat(concat(concat(cd.PrimaryDecodeTxt, ', + '), CAST((statementcount - 1) AS STRING)), ' more')
                                        END
                                ELSE res.statement
                            END AS statement
                            ,statementall
                            ,type
                            ,status
                            ,consulcall
                            ,qmdreview
                            ,source
                            ,contractname
                            ,riskdetailskey
                            ,riskassessmentquestionkey
                            ,contractnbr
                            ,contractnm
                            ,customernbr
                            ,customernm
                            ,masterclientnbr
                            ,masterclientnm
                            ,riskid
                            ,mitigationid
                        FROM (
                            SELECT IFNULL(cd1.PrimaryDecodeTxt,'Unrated') AS rating
                                ,IFNULL(cd1.SecondaryDecodeTxt,'4') AS ratingorder
                                ,CASE
                                    WHEN cd7.PrimaryDecodeTxt = 'CM' THEN cd2.PrimaryDecodeTxt
                                    ELSE rd.CIPCategoryNm
                                END AS category
                                ,CASE
                                    WHEN cd7.PrimaryDecodeTxt = 'CM' THEN cd3.PrimaryDecodeTxt
                                    ELSE rd.CIPSubCategoryNm
                                END AS subcategory
                                ,CASE
                                    WHEN cd7.PrimaryDecodeTxt = 'CM' THEN (SELECT * FROM UNNEST(rd.StatementArr) LIMIT 1)
                                    ELSE 
                                        CASE
                                            WHEN rd.CIPRiskStatementNm IS NULL OR rd.CIPRiskStatementNm = '' THEN 'CIP Risk'
                                            ELSE rd.CIPRiskStatementNm
                                        END
                                END AS statement
                                ,CASE
                                    WHEN cd7.PrimaryDecodeTxt = 'CM' THEN (SELECT ARRAY_LENGTH(rd.StatementArr))
                                    ELSE 0
                                END AS statementcount
                                ,CASE
                                    WHEN cd7.PrimaryDecodeTxt = 'CM' THEN concat('• ',(SELECT ARRAY_TO_STRING((SELECT ARRAY_AGG(PrimaryDecodeTxt) FROM CodeDetail WHERE CodeTxt IN UNNEST(rd.StatementArr)), '\\n• ')))
                                    ELSE 
                                      CASE
                                          WHEN rd.CIPRiskStatementNm IS NULL OR rd.CIPRiskStatementNm = '' THEN '• CIP Risk'
                                          ELSE concat('• ', rd.CIPRiskStatementNm)
                                      END
                                END AS statementall
                                ,cd4.PrimaryDecodeTxt AS type
                                ,CASE
                                    WHEN LOWER(cd5.PrimaryDecodeTxt) = 'reviewed' THEN concat(concat(cd5.PrimaryDecodeTxt, ' on '), CAST(rd.RiskLeadReviewDttm AS STRING))
                                    ELSE cd5.PrimaryDecodeTxt
                                END AS status
                                ,CASE
                                    WHEN cd7.PrimaryDecodeTxt = 'CIP' THEN ''
                                    ELSE 
                                        CASE
                                            WHEN LOWER(cd6.PrimaryDecodeTxt) = 'reviewed' THEN concat(concat(cd6.PrimaryDecodeTxt, ' on '), CAST(cc.ReviewerCompletedDt AS STRING))
                                            ELSE IFNULL(cd6.PrimaryDecodeTxt,'Not Requested')
                                        END
                                END AS consulcall
                                ,CASE
                                    WHEN cd7.PrimaryDecodeTxt = 'CIP' THEN ''
                                    ELSE 
                                        CASE
                                            WHEN rd.RiskQMDReviewInd = 'N' OR rd.RiskQMDReviewInd IS NULL THEN 'Not Requested'
                                            WHEN rd.RiskQMDReviewInd = 'Y' THEN concat('Requested on ',CAST(rd.RiskQMDReviewDttm AS STRING))
                                            ELSE ''
                                        END
                                END AS qmdreview
                                ,cd7.PrimaryDecodeTxt AS source
                                ,CASE
                                    WHEN rd.ContractNbr = '' AND cd7.PrimaryDecodeTxt = 'CM' THEN 'No Contracts Available'
                                    WHEN rd.ContractNbr = '' AND cd7.PrimaryDecodeTxt = 'CIP' THEN ''
                                    ELSE concat(concat(rd.ContractNm, ' - '), rd.ContractNbr)
                                END AS contractname
                                ,rd.RiskDetailsKey AS riskdetailskey
                                ,raq.RiskAssessmentQuestionKey AS riskassessmentquestionkey
                                ,rd.ContractNbr AS contractnbr
                                ,rd.ContractNm AS contractnm
                                ,rd.CustomerNbr AS customernbr
                                ,rd.CustomerNm AS customernm
                                ,rd.MasterClientNbr AS masterclientnbr
                                ,rd.MasterClientNm AS masterclientnm
                                ,rd.RiskNbr AS riskid
                                ,ARRAY(SELECT CAST(MitigationNbr AS STRING) FROM RiskMitigation rm WHERE rm.RiskDetailsKey = rd.RiskDetailsKey) AS mitigationid
                            FROM RiskDetails rd
                            LEFT JOIN RiskAssessmentQuestion raq
                                ON rd.RiskAssessmentQuestionKey = raq.RiskAssessmentQuestionKey
                            LEFT JOIN RiskConsultationCall cc
                                ON rd.RiskDetailsKey = cc.RiskDetailsKey
                            LEFT JOIN CodeDetail cd1
                                ON rd.RiskRatingCd = cd1.CodeTxt
                            LEFT JOIN CodeDetail cd2
                                ON raq.CategoryCd = cd2.CodeTxt
                            LEFT JOIN CodeDetail cd3
                                ON raq.SubCategoryCd = cd3.CodeTxt
                            LEFT JOIN CodeDetail cd4
                                ON rd.RiskTypeCd = cd4.CodeTxt
                            LEFT JOIN CodeDetail cd5
                                ON rd.RiskStatusCd = cd5.CodeTxt
                            LEFT JOIN CodeDetail cd6
                                ON cc.ConsultationCallStatusCd = cd6.CodeTxt
                            LEFT JOIN CodeDetail cd7
                                ON rd.RiskSourceCd = cd7.CodeTxt
                            WHERE (cd7.PrimaryDecodeTxt = 'CIP' OR
                                    (cd7.PrimaryDecodeTxt = 'CM' AND (cd1.PrimaryDecodeTxt IN ('High', 'Above Normal'))))
                                AND rd.MasterClientNbr = '${mc}'
                        ) res
                        LEFT JOIN CodeDetail cd
                            ON cd.CodeTxt = res.statement
                        ORDER BY ratingorder ASC`;
                break;
            case '136002': //Assessment
                query = ``;
                break;
            case '136003': //Consultation
                query = `SELECT rating
                            ,category
                            ,subcategory
                            ,CASE
                                WHEN (statementcount - 1) = 0 THEN cd.PrimaryDecodeTxt
                                ELSE concat(concat(concat(cd.PrimaryDecodeTxt, ', + '), CAST((statementcount - 1) AS STRING)), ' more')
                            END AS statement
                            ,concat('• ',(SELECT ARRAY_TO_STRING(statementarray, '\\n• '))) as statementall
                            ,type
                            ,consulcall
                            ,followupdate
                            ,contractname
                            ,source
                            ,riskdetailskey
                            ,riskassessmentquestionkey
                            ,contractnbr
                            ,contractnm
                            ,customernbr
                            ,customernm
                            ,masterclientnbr
                            ,masterclientnm
                            ,riskid
                            ,mitigationid
                        FROM (
                            SELECT IFNULL(cd1.PrimaryDecodeTxt,'Unrated') AS rating
                                ,IFNULL(cd1.SecondaryDecodeTxt,'4') AS ratingorder
                                ,cd2.PrimaryDecodeTxt AS category
                                ,cd3.PrimaryDecodeTxt AS subcategory
                                ,(SELECT * FROM UNNEST(rd.StatementArr)LIMIT 1) AS statement
                                ,(SELECT ARRAY_LENGTH(rd.StatementArr)) AS statementcount
                                ,(SELECT ARRAY_AGG(PrimaryDecodeTxt) FROM CodeDetail WHERE CodeTxt IN UNNEST(rd.StatementArr)) AS statementarray
                                ,cd4.PrimaryDecodeTxt AS type
                                ,CASE
                                    WHEN LOWER(cd5.PrimaryDecodeTxt) = 'reviewed' THEN concat(concat(cd5.PrimaryDecodeTxt, ' on '), CAST(cc.ReviewerCompletedDt AS STRING))
                                    ELSE cd5.PrimaryDecodeTxt
                                END AS consulcall
                                ,cc.ReviewerFollowupDt AS followupdate
                                ,CASE
                                    WHEN rd.ContractNbr = '' THEN 'No Contracts Available'
                                    ELSE concat(concat(rd.ContractNm, ' - '), rd.ContractNbr)
                                END AS contractname
                                ,cd6.PrimaryDecodeTxt AS source
                                ,rd.RiskDetailsKey AS riskdetailskey
                                ,raq.RiskAssessmentQuestionKey AS riskassessmentquestionkey
                                ,rd.ContractNbr AS contractnbr
                                ,rd.ContractNm AS contractnm
                                ,rd.CustomerNbr AS customernbr
                                ,rd.CustomerNm AS customernm
                                ,rd.MasterClientNbr AS masterclientnbr
                                ,rd.MasterClientNm AS masterclientnm
                                ,rd.RiskNbr AS riskid
                                ,ARRAY(SELECT CAST(MitigationNbr AS STRING) FROM RiskMitigation rm WHERE rm.RiskDetailsKey = rd.RiskDetailsKey) AS mitigationid
                            FROM RiskDetails rd
                            LEFT JOIN RiskAssessmentQuestion raq
                                ON rd.RiskAssessmentQuestionKey = raq.RiskAssessmentQuestionKey
                            LEFT JOIN RiskConsultationCall cc
                                ON rd.RiskDetailsKey = cc.RiskDetailsKey
                            LEFT JOIN CodeDetail cd1
                                ON rd.RiskRatingCd = cd1.CodeTxt
                            LEFT JOIN CodeDetail cd2
                                ON raq.CategoryCd = cd2.CodeTxt
                            LEFT JOIN CodeDetail cd3
                                ON raq.SubCategoryCd = cd3.CodeTxt
                            LEFT JOIN CodeDetail cd4
                                ON rd.RiskTypeCd = cd4.CodeTxt
                            LEFT JOIN CodeDetail cd5
                                ON cc.ConsultationCallStatusCd = cd5.CodeTxt
                            LEFT JOIN CodeDetail cd6
                                ON rd.RiskSourceCd = cd6.CodeTxt
                            WHERE cd6.PrimaryDecodeTxt != 'CIP'
                                AND cc.ConsultationCallStatusCd IS NOT NULL
                                AND LOWER(cd5.PrimaryDecodeTxt) IN ('pending', 'reviewed')
                                AND rd.MasterClientNbr = '${mc}'
                        ) res
                        LEFT JOIN CodeDetail cd
                            ON cd.CodeTxt = res.statement
                        ORDER BY ratingorder ASC`;
                break;
            case '136004': //MyMitigations
                query = `SELECT rating 
                            ,CASE
                            	WHEN source = 'CM' 
                                	THEN
                                    	CASE
                                        	WHEN (statementcount - 1) = 0 THEN cd.PrimaryDecodeTxt
                                            ELSE concat(concat(concat(cd.PrimaryDecodeTxt, ', + '), CAST((statementcount - 1) AS STRING)), ' more')
                                        END
                                ELSE res.statement
                            END AS statement
                            ,statementall
                            ,description 
                            ,status 
                            ,duedate 
                            ,source 
                            ,contractname
                            ,riskdetailskey
                            ,riskassessmentquestionkey
                            ,contractnbr
                            ,contractnm
                            ,customernbr
                            ,customernm
                            ,masterclientnbr
                            ,masterclientnm
                            ,riskid
                            ,mitigationid
                        FROM (
                            SELECT IFNULL(cd1.PrimaryDecodeTxt,'Unrated') AS rating
                                ,IFNULL(cd1.SecondaryDecodeTxt,'4') AS ratingorder
                                ,CASE
                                    WHEN cd3.PrimaryDecodeTxt = 'CM' THEN (SELECT * FROM UNNEST(rd.StatementArr) LIMIT 1)
                                    ELSE 
                                        CASE
                                            WHEN rd.CIPRiskStatementNm IS NULL OR rd.CIPRiskStatementNm = '' THEN 'CIP Risk'
                                            ELSE rd.CIPRiskStatementNm
                                        END
                                END AS statement
                                ,CASE
                                    WHEN cd3.PrimaryDecodeTxt = 'CM' THEN (SELECT ARRAY_LENGTH(rd.StatementArr))
                                    ELSE 0
                                END AS statementcount
                                ,CASE
                                    WHEN cd3.PrimaryDecodeTxt = 'CM' THEN concat('• ',(SELECT ARRAY_TO_STRING((SELECT ARRAY_AGG(PrimaryDecodeTxt) FROM CodeDetail WHERE CodeTxt IN UNNEST(rd.StatementArr)), '\\n• ')))
                                    ELSE 
                                      CASE
                                          WHEN rd.CIPRiskStatementNm IS NULL OR rd.CIPRiskStatementNm = '' THEN '• CIP Risk'
                                          ELSE concat('• ', rd.CIPRiskStatementNm)
                                      END
                                END AS statementall
                                ,rm.MitigationDesc AS description
                                ,cd2.PrimaryDecodeTxt AS status
                                ,rm.DueDttm AS duedate
                                ,cd3.PrimaryDecodeTxt AS source
                                ,CASE
                                    WHEN rd.ContractNbr = '' THEN 'No Contracts Available'
                                    ELSE concat(concat(rd.ContractNm, ' - '), rd.ContractNbr)
                                END AS contractname
                                ,rd.RiskDetailsKey AS riskdetailskey
                                ,raq.RiskAssessmentQuestionKey AS riskassessmentquestionkey
                                ,rd.ContractNbr AS contractnbr
                                ,rd.ContractNm AS contractnm
                                ,rd.CustomerNbr AS customernbr
                                ,rd.CustomerNm AS customernm
                                ,rd.MasterClientNbr AS masterclientnbr
                                ,rd.MasterClientNm AS masterclientnm
                                ,rd.RiskNbr AS riskid
                                ,CAST(rm.MitigationNbr AS STRING) AS mitigationid
                            FROM RiskDetails rd
                            LEFT JOIN RiskAssessmentQuestion raq
                                ON rd.RiskAssessmentQuestionKey = raq.RiskAssessmentQuestionKey
                            LEFT JOIN RiskMitigation rm
                                ON rd.RiskDetailsKey = rm.RiskDetailsKey
                            LEFT JOIN CodeDetail cd1
                                ON rd.RiskRatingCd = cd1.CodeTxt
                            LEFT JOIN CodeDetail cd2
                                ON rm.MitigationStatusCd = cd2.CodeTxt
                            LEFT JOIN CodeDetail cd3
                                ON rd.RiskSourceCd = cd3.CodeTxt
                            WHERE rm.AssigneeUserId = '${process.env.ENTERPRISEID}'
                                AND rd.MasterClientNbr = '${mc}'
                        ) res
                        LEFT JOIN CodeDetail cd
                            ON cd.CodeTxt = res.statement
                        ORDER BY ratingorder ASC`;
                break;
        }
    }

    return query;
}

const getRisksAssmtAndMitigation = async (con) => {
    const database = new SpannerDB();

    const risksAssmtAndMitigationQry = `SELECT ra.questionorder, ra.category, ra.qaref, ra.question, ra.statementall,
                        ra.subcategory, ra.rating, ra.description radescription, ra.type, ra.status rastatus,
                        ra.leadreviewstatus, ra.designatedreviewer, ra.ccrequested, ra.qmdcallrequested,
                        mit.mitigationtitle, mit.description mitdescription, mit.createdby, mit.assignedto,
                        mit.status mitstatus, mit.createdon, mit.duedate
                        FROM
                        (SELECT
                        category, qaref, question, statementall, subcategory, rating, type, status,
                        leadreviewstatus, designatedreviewer, ccrequested, qmdcallrequested, riskdetailskey,
                        riskassessmentquestionkey, questionorder, description
                        FROM
                        (SELECT DISTINCT
                        cd1.PrimaryDecodeTxt AS category,
                        cd2.PrimaryDecodeTxt AS subcategory,
                        cd3.SecondaryDecodeTxt AS question,
                        cd3.PrimaryDecodeTxt AS qaref,
                        raq.QuestionOrderNbr AS questionorder,
                        IFNULL(rating,'Unrated') AS rating,
                        IFNULL(ratingorder,'4') AS ratingorder,
                        statementall as statementall,
                        status as status,
                        type,
                        source,
                        leadreviewstatus,
                        designatedreviewer,
                        ccrequested,
                        qmdcallrequested,
                        riskdetailskey,
                        raq.RiskAssessmentQuestionKey AS riskassessmentquestionkey,
                        contractnbr,
                        contractnm,
                        customernbr,
                        customernm,
                        masterclientnbr,
                        masterclientnm,
                        riskdesc as description
                        FROM
                        RiskAssessmentQuestion raq
                        LEFT JOIN
                        (SELECT
                        cd4.PrimaryDecodeTxt AS rating,
                        cd4.SecondaryDecodeTxt AS ratingorder,
                        cd5.PrimaryDecodeTxt AS type,
                        cd6.PrimaryDecodeTxt AS source,
                        CASE WHEN
                        LOWER(cd4.PrimaryDecodeTxt) = 'not started'
                        THEN ''
                        ELSE
                        CASE WHEN
                        rd.RiskLeadReviewDttm IS NOT NULL
                        THEN
                        CONCAT('last review on ', CAST(FORMAT_DATE("%d-%b-%Y", DATE(rd.RiskLeadReviewDttm,'+00:00')) AS STRING))
                        ELSE
                        'no review completed'
                        END
                        END AS
                        leadreviewstatus,
                        rd.RiskDetailsKey AS riskdetailskey,
                        rd.ContractNbr AS contractnbr,
                        rd.ContractNm AS contractnm,
                        rd.CustomerNbr AS customernbr,
                        rd.CustomerNm AS customernm,
                        rd.MasterClientNbr AS masterclientnbr,
                        rd.MasterClientNm AS masterclientnm,
                        rd.RiskAssessmentQuestionKey,
                        rd.RiskDesc riskdesc,
                        CASE WHEN
                        cd6.PrimaryDecodeTxt = 'CM' 
                        THEN
                        concat('• ',(SELECT ARRAY_TO_STRING((SELECT ARRAY_AGG(PrimaryDecodeTxt) FROM CodeDetail WHERE CodeTxt IN UNNEST(rd.StatementArr)), '\\n• ')))
                        ELSE 
                        CASE WHEN
                        rd.CIPRiskStatementNm IS NULL OR rd.CIPRiskStatementNm = '' 
                        THEN
                        '• CIP Risk'
                        ELSE
                        concat('• ', rd.CIPRiskStatementNm)
                        END
                        END AS statementall,
                        CASE WHEN 
                        LOWER(cd7.PrimaryDecodeTxt) = 'reviewed'
                        THEN concat(concat(cd7.PrimaryDecodeTxt, ' on '), CAST(FORMAT_DATE("%d-%b-%Y", DATE(rd.RiskLeadReviewDttm,'+00:00')) AS STRING))
                        ELSE
                        cd7.PrimaryDecodeTxt
                        END AS status,
                        ARRAY_TO_STRING(rlr.DesignatedReviewerUserIdArr, ', ') as designatedreviewer,
                        CASE WHEN cd6.PrimaryDecodeTxt = 'CIP'
                        THEN ''
                        ELSE cd9.PrimaryDecodeTxt
                        END AS ccrequested,
                        CASE WHEN cd6.PrimaryDecodeTxt = 'CIP' 
                        THEN ''
                        ELSE 
                        CASE WHEN rd.RiskQMDReviewInd = 'N'
                        THEN 'not requested'
                        WHEN rd.RiskQMDReviewInd = 'Y' 
                        THEN
                        CONCAT('requested on ', CAST(FORMAT_DATE("%d-%b-%Y", DATE(rd.RiskQMDReviewDttm,'+00:00')) AS STRING))
                        ELSE ''
                        END
                        END AS qmdcallrequested
                        FROM 
                        RiskDetails rd
                        LEFT JOIN RiskConsultationCall cc
                        ON rd.RiskDetailsKey = cc.RiskDetailsKey
                        LEFT JOIN CodeDetail cd4
                        ON rd.RiskRatingCd = cd4.CodeTxt
                        LEFT JOIN CodeDetail cd5
                        ON rd.RiskTypeCd = cd5.CodeTxt
                        LEFT JOIN CodeDetail cd6
                        ON rd.RiskSourceCd = cd6.CodeTxt
                        LEFT JOIN CodeDetail cd7
                        ON rd.RiskStatusCd = cd7.CodeTxt
                        LEFT JOIN CodeDetail cd9
                        ON cc.ConsultationCallStatusCd = cd9.CodeTxt
                        LEFT JOIN RiskLeadReview rlr
                        ON rd.RiskDetailsKey = rlr.RiskDetailsKey
                        WHERE cd6.PrimaryDecodeTxt != 'CIP'
                        AND rd.ContractNbr = '${con}'
                        ) res
                        ON raq.RiskAssessmentQuestionKey = res.RiskAssessmentQuestionKey
                        LEFT JOIN CodeDetail cd1
                        ON raq.CategoryCd = cd1.CodeTxt
                        LEFT JOIN CodeDetail cd2
                        ON raq.SubCategoryCd = cd2.CodeTxt
                        LEFT JOIN CodeDetail cd3
                        ON raq.RiskQuestionCd = cd3.CodeTxt
                        )) ra
                        LEFT JOIN
                        (SELECT rm.RiskDetailsKey riskdetailskey, rm.MitigationTitle mitigationtitle, rm.MitigationDesc description, rm.CreateUserId createdby, rm.AssigneeUserId assignedto,
                        cd10.PrimaryDecodeTxt status, rm.CreateDttm createdon,
                        rm.DueDttm duedate
                        FROM RiskMitigation rm
                        LEFT JOIN CodeDetail cd10
                        ON rm.MitigationStatusCd = cd10.CodeTxt
                        WHERE cd10.PrimaryDecodeTxt != 'Not Applied') mit
                        ON ra.riskdetailskey = mit.riskdetailskey
                        ORDER BY ra.questionorder ASC`;

    try {
        let [risksAssmtAndMitigationRows] = await database.run(risksAssmtAndMitigationQry);
        if (risksAssmtAndMitigationRows.length > 0) {
            return risksAssmtAndMitigationRows.map(o => o.toJSON());
        } else {
            return null;
        }
    } catch (err) {
        return new Error(err);
    } finally {
        // Close the database when finished.
        await database.close();
    }
}

const getRisksAssmtStatSummary = async (con) => {
    const database = new SpannerDB();

    const risksAssmtStatSummaryQry = `SELECT SUM(high) high, SUM(abovenormal) abovenormal, SUM(normal) normal, SUM(notstarted) notstarted
                    FROM
                    (SELECT
                    category, qaref, question, statementall, subcategory, rating, type, status,
                    leadreviewstatus, designatedreviewer, ccrequested, qmdcallrequested, riskdetailskey,
                    riskassessmentquestionkey, questionorder, description,
                    CASE WHEN LOWER(rating) = 'high'
                    THEN 1
                    ELSE 0
                    END AS high,
                    CASE WHEN LOWER(rating) = 'above normal'
                    THEN 1
                    ELSE 0
                    END AS abovenormal,
                    CASE WHEN LOWER(rating) = 'normal'
                    THEN 1
                    ELSE 0
                    END AS normal,
                    CASE WHEN LOWER(rating) = 'not started'
                    THEN 1
                    ELSE 0
                    END AS notstarted
                    FROM
                    (SELECT DISTINCT
                    cd1.PrimaryDecodeTxt AS category,
                    cd2.PrimaryDecodeTxt AS subcategory,
                    cd3.SecondaryDecodeTxt AS question,
                    cd3.PrimaryDecodeTxt AS qaref,
                    raq.QuestionOrderNbr AS questionorder,
                    IFNULL(rating,'Not Started') AS rating,
                    IFNULL(ratingorder,'4') AS ratingorder,
                    statementall as statementall,
                    status as status,
                    type,
                    source,
                    leadreviewstatus,
                    designatedreviewer,
                    ccrequested,
                    qmdcallrequested,
                    riskdetailskey,
                    raq.RiskAssessmentQuestionKey AS riskassessmentquestionkey,
                    contractnbr,
                    contractnm,
                    customernbr,
                    customernm,
                    masterclientnbr,
                    masterclientnm,
                    riskdesc as description
                    FROM
                    RiskAssessmentQuestion raq
                    LEFT JOIN
                    (SELECT
                    cd4.PrimaryDecodeTxt AS rating,
                    cd4.SecondaryDecodeTxt AS ratingorder,
                    cd5.PrimaryDecodeTxt AS type,
                    cd6.PrimaryDecodeTxt AS source,
                    cd8.PrimaryDecodeTxt AS leadreviewstatus,
                    rd.RiskDetailsKey AS riskdetailskey,
                    rd.ContractNbr AS contractnbr,
                    rd.ContractNm AS contractnm,
                    rd.CustomerNbr AS customernbr,
                    rd.CustomerNm AS customernm,
                    rd.MasterClientNbr AS masterclientnbr,
                    rd.MasterClientNm AS masterclientnm,
                    rd.RiskAssessmentQuestionKey,
                    rd.RiskDesc riskdesc,
                    CASE WHEN
                    cd6.PrimaryDecodeTxt = 'CM' 
                    THEN
                    concat('• ',(SELECT ARRAY_TO_STRING((SELECT ARRAY_AGG(PrimaryDecodeTxt) FROM CodeDetail WHERE CodeTxt IN UNNEST(rd.StatementArr)), '\\n• ')))
                    ELSE 
                    CASE WHEN
                    rd.CIPRiskStatementNm IS NULL OR rd.CIPRiskStatementNm = '' 
                    THEN
                    '• CIP Risk'
                    ELSE
                    concat('• ', rd.CIPRiskStatementNm)
                    END
                    END AS statementall,
                    CASE WHEN 
                    LOWER(cd7.PrimaryDecodeTxt) = 'reviewed'
                    THEN concat(concat(cd7.PrimaryDecodeTxt, ' on '), CAST(rd.RiskLeadReviewDttm AS STRING))
                    ELSE
                    cd7.PrimaryDecodeTxt
                    END AS status,
                    ARRAY_TO_STRING(rlr.DesignatedReviewerUserIdArr, ', ') as designatedreviewer,
                    CASE WHEN cd6.PrimaryDecodeTxt = 'CIP'
                    THEN ''
                    ELSE 
                    CASE WHEN LOWER(cd9.PrimaryDecodeTxt) = 'reviewed' 
                    THEN 'Yes'
                    WHEN LOWER(cd9.PrimaryDecodeTxt) = 'not requested'
                    THEN 'No'
                    ELSE IFNULL(cd9.PrimaryDecodeTxt,'No')
                    END
                    END AS ccrequested,
                    CASE WHEN cd6.PrimaryDecodeTxt = 'CIP' 
                    THEN ''
                    ELSE 
                    CASE WHEN rd.RiskQMDReviewInd = 'N' OR rd.RiskQMDReviewInd IS NULL 
                    THEN 'No'
                    WHEN rd.RiskQMDReviewInd = 'Y' 
                    THEN 'Yes'
                    ELSE ''
                    END
                    END AS qmdcallrequested
                    FROM 
                    RiskDetails rd
                    LEFT JOIN RiskConsultationCall cc
                    ON rd.RiskDetailsKey = cc.RiskDetailsKey
                    LEFT JOIN CodeDetail cd4
                    ON rd.RiskRatingCd = cd4.CodeTxt
                    LEFT JOIN CodeDetail cd5
                    ON rd.RiskTypeCd = cd5.CodeTxt
                    LEFT JOIN CodeDetail cd6
                    ON rd.RiskSourceCd = cd6.CodeTxt
                    LEFT JOIN CodeDetail cd7
                    ON rd.RiskStatusCd = cd7.CodeTxt
                    LEFT JOIN CodeDetail cd8
                    ON rd.RiskLeadReviewStatusCd = cd8.CodeTxt
                    LEFT JOIN CodeDetail cd9
                    ON cc.ConsultationCallStatusCd = cd9.CodeTxt
                    LEFT JOIN RiskLeadReview rlr
                    ON rd.RiskDetailsKey = rlr.RiskDetailsKey
                    WHERE cd6.PrimaryDecodeTxt != 'CIP'
                    AND rd.ContractNbr = '${con}'
                    ) res
                    ON raq.RiskAssessmentQuestionKey = res.RiskAssessmentQuestionKey
                    LEFT JOIN CodeDetail cd1
                    ON raq.CategoryCd = cd1.CodeTxt
                    LEFT JOIN CodeDetail cd2
                    ON raq.SubCategoryCd = cd2.CodeTxt
                    LEFT JOIN CodeDetail cd3
                    ON raq.RiskQuestionCd = cd3.CodeTxt
                    ))`;

    try {
        let [risksAssmtStatSummaryRows] = await database.run(risksAssmtStatSummaryQry);
        if (risksAssmtStatSummaryRows.length > 0) {
            return risksAssmtStatSummaryRows.map(o => o.toJSON());
        } else {
            return null;
        }
    } catch (err) {
        return new Error(err);
    } finally {
        // Close the database when finished.
        await database.close();
    }
}

const getClientDetails = async (con) => {
    const database = new SpannerDB();

    const clientDetailsQry = `SELECT mc.MasterClientNbr, mc.MasterClientNm, c.CustomerNbr, c.CustomerNm, con.ContractNbr, con.ContractNm,
                    gr.GeographicRegionDesc region, gu.GeographicUnitDesc geography,
                    ct.CountryNm country
                    FROM
                    MasterClient mc
                    LEFT JOIN Customer c
                    ON mc.MasterClientNbr = c.MasterClientNbr
                    LEFT JOIN Contract con
                    ON c.CustomerNbr = con.CustomerNbr
                    LEFT JOIN Country ct 
                    ON ct.CountryCd = con.CountryCd 
                    LEFT JOIN GeographicUnit gu 
                    ON gu.GeographicUnitCd = ct.GeographicUnitCd
                    LEFT JOIN GeographicRegion gr 
                    ON gu.GeographicRegionCd = gr.GeographicRegionCd
                    WHERE con.ContractNbr = '${con}'`;

    try {
        let [clientDetails] = await database.run(clientDetailsQry);
        if (clientDetails.length > 0) {
            return clientDetails.map(o => o.toJSON());;
        } else {
            return null;
        }
    } catch (err) {
        return new Error(err);
    } finally {
        // Close the database when finished.
        await database.close();
    }
}

const getMitDueOverdueCount = async (con) => {
    const database = new SpannerDB();

    const mitDueOverdueCountQry = `SELECT SUM(overdue) overdue, SUM(due) due, SUM(overdue + due) total
                        FROM
                        (SELECT ra.questionorder, ra.category, ra.qaref, ra.question, ra.statementall,
                        ra.subcategory, ra.rating, ra.description, ra.type, ra.status,
                        ra.leadreviewstatus, ra.designatedreviewer, ra.ccrequested, ra.qmdcallrequested,
                        mit.mitigationtitle, mit.description, mit.createdby, mit.assignedto,
                        mit.status, mit.createdon, mit.duedate,
                        CASE WHEN LOWER(mit.status) LIKE '%overdue%'
                        THEN 1
                        ELSE 0
                        END AS overdue,
                        CASE WHEN mit.status LIKE '%Due%'
                        THEN 1
                        ELSE 0
                        END AS due
                        FROM
                        (SELECT
                        category, qaref, question, statementall, subcategory, rating, type, status,
                        leadreviewstatus, designatedreviewer, ccrequested, qmdcallrequested, riskdetailskey,
                        riskassessmentquestionkey, questionorder, description
                        FROM
                        (SELECT DISTINCT
                        cd1.PrimaryDecodeTxt AS category,
                        cd2.PrimaryDecodeTxt AS subcategory,
                        cd3.SecondaryDecodeTxt AS question,
                        cd3.PrimaryDecodeTxt AS qaref,
                        raq.QuestionOrderNbr AS questionorder,
                        IFNULL(rating,'Not Started') AS rating,
                        IFNULL(ratingorder,'4') AS ratingorder,
                        statementall as statementall,
                        status as status,
                        type,
                        source,
                        leadreviewstatus,
                        designatedreviewer,
                        ccrequested,
                        qmdcallrequested,
                        riskdetailskey,
                        raq.RiskAssessmentQuestionKey AS riskassessmentquestionkey,
                        contractnbr,
                        contractnm,
                        customernbr,
                        customernm,
                        masterclientnbr,
                        masterclientnm,
                        riskdesc as description
                        FROM
                        RiskAssessmentQuestion raq
                        LEFT JOIN
                        (SELECT
                        cd4.PrimaryDecodeTxt AS rating,
                        cd4.SecondaryDecodeTxt AS ratingorder,
                        cd5.PrimaryDecodeTxt AS type,
                        cd6.PrimaryDecodeTxt AS source,
                        cd8.PrimaryDecodeTxt AS leadreviewstatus,
                        rd.RiskDetailsKey AS riskdetailskey,
                        rd.ContractNbr AS contractnbr,
                        rd.ContractNm AS contractnm,
                        rd.CustomerNbr AS customernbr,
                        rd.CustomerNm AS customernm,
                        rd.MasterClientNbr AS masterclientnbr,
                        rd.MasterClientNm AS masterclientnm,
                        rd.RiskAssessmentQuestionKey,
                        rd.RiskDesc riskdesc,
                        CASE WHEN
                        cd6.PrimaryDecodeTxt = 'CM' 
                        THEN
                        concat('• ',(SELECT ARRAY_TO_STRING((SELECT ARRAY_AGG(PrimaryDecodeTxt) FROM CodeDetail WHERE CodeTxt IN UNNEST(rd.StatementArr)), '\\n• ')))
                        ELSE 
                        CASE WHEN
                        rd.CIPRiskStatementNm IS NULL OR rd.CIPRiskStatementNm = '' 
                        THEN
                        '• CIP Risk'
                        ELSE
                        concat('• ', rd.CIPRiskStatementNm)
                        END
                        END AS statementall,
                        CASE WHEN 
                        LOWER(cd7.PrimaryDecodeTxt) = 'reviewed'
                        THEN concat(concat(cd7.PrimaryDecodeTxt, ' on '), CAST(rd.RiskLeadReviewDttm AS STRING))
                        ELSE
                        cd7.PrimaryDecodeTxt
                        END AS status,
                        ARRAY_TO_STRING(rlr.DesignatedReviewerUserIdArr, ', ') as designatedreviewer,
                        CASE WHEN cd6.PrimaryDecodeTxt = 'CIP'
                        THEN ''
                        ELSE 
                        CASE WHEN LOWER(cd9.PrimaryDecodeTxt) = 'reviewed' 
                        THEN 'Yes'
                        WHEN LOWER(cd9.PrimaryDecodeTxt) = 'not requested'
                        THEN 'No'
                        ELSE IFNULL(cd9.PrimaryDecodeTxt,'No')
                        END
                        END AS ccrequested,
                        CASE WHEN cd6.PrimaryDecodeTxt = 'CIP' 
                        THEN ''
                        ELSE 
                        CASE WHEN rd.RiskQMDReviewInd = 'N' OR rd.RiskQMDReviewInd IS NULL 
                        THEN 'No'
                        WHEN rd.RiskQMDReviewInd = 'Y' 
                        THEN 'Yes'
                        ELSE ''
                        END
                        END AS qmdcallrequested
                        FROM 
                        RiskDetails rd
                        LEFT JOIN RiskConsultationCall cc
                        ON rd.RiskDetailsKey = cc.RiskDetailsKey
                        LEFT JOIN CodeDetail cd4
                        ON rd.RiskRatingCd = cd4.CodeTxt
                        LEFT JOIN CodeDetail cd5
                        ON rd.RiskTypeCd = cd5.CodeTxt
                        LEFT JOIN CodeDetail cd6
                        ON rd.RiskSourceCd = cd6.CodeTxt
                        LEFT JOIN CodeDetail cd7
                        ON rd.RiskStatusCd = cd7.CodeTxt
                        LEFT JOIN CodeDetail cd8
                        ON rd.RiskLeadReviewStatusCd = cd8.CodeTxt
                        LEFT JOIN CodeDetail cd9
                        ON cc.ConsultationCallStatusCd = cd9.CodeTxt
                        LEFT JOIN RiskLeadReview rlr
                        ON rd.RiskDetailsKey = rlr.RiskDetailsKey
                        WHERE cd6.PrimaryDecodeTxt != 'CIP'
                        AND rd.ContractNbr = '${con}'
                        ) res
                        ON raq.RiskAssessmentQuestionKey = res.RiskAssessmentQuestionKey
                        LEFT JOIN CodeDetail cd1
                        ON raq.CategoryCd = cd1.CodeTxt
                        LEFT JOIN CodeDetail cd2
                        ON raq.SubCategoryCd = cd2.CodeTxt
                        LEFT JOIN CodeDetail cd3
                        ON raq.RiskQuestionCd = cd3.CodeTxt
                        )) ra
                        LEFT JOIN
                        (SELECT rm.RiskDetailsKey riskdetailskey, rm.MitigationTitle mitigationtitle, rm.MitigationDesc description, rm.CreateUserId createdby, rm.AssigneeUserId assignedto,
                        cd10.PrimaryDecodeTxt status, rm.CreateDttm createdon, rm.DueDttm duedate
                        FROM RiskMitigation rm
                        LEFT JOIN CodeDetail cd10
                        ON rm.MitigationStatusCd = cd10.CodeTxt
                        WHERE cd10.PrimaryDecodeTxt != 'Not Applied') mit
                        ON ra.riskdetailskey = mit.riskdetailskey)`;

    try {
        let [mitDueOverdueCountRows] = await database.run(mitDueOverdueCountQry);
        if (mitDueOverdueCountRows.length > 0) {
            return mitDueOverdueCountRows.map(o => o.toJSON());;
        } else {
            return null;
        }
    } catch (err) {
        return new Error(err);
    } finally {
        // Close the database when finished.
        await database.close();
    }
}

const getContractScores = async (contractNbr) => {
    const database = new SpannerDB();
    let query = {};
    const queryWithParams = {
        sql: `SELECT rcs.*, cd.PrimaryDecodeTxt ContractScoreRating, cd2.PrimaryDecodeTxt ContractScoreNoCMRating
                FROM RiskContractScore rcs 
                LEFT JOIN@{JOIN_TYPE=APPLY_JOIN} CodeDetail cd ON cd.CodeTxt = rcs.ContractScoreRatingCd
                LEFT JOIN@{JOIN_TYPE=APPLY_JOIN} CodeDetail cd2 ON cd2.CodeTxt = rcs.ContractScoreNoCMRatingCd
                WHERE rcs.ContractNbr=@contractNbr`,
        params: {
            contractNbr
        }
    };
    const queryNoParams = {
        sql: `SELECT * FROM RiskContractScore`
    };

    if (contractNbr) {
        query = queryWithParams;
    } else {
        query = queryNoParams;
    }

    try {
        let [contractScoreRows] = await database.run(query);
        if (contractScoreRows.length > 0) {
            return contractScoreRows.map(o => o.toJSON());
        } else {
            return null;
        }
    } catch (err) {
        return new Error(err);
    } finally {
        await database.close();
    }
}

const searchRiskIssuesID = async (id, view) => {
    const database = new SpannerDB();

    var risksIssuesquery = await getSearchRiskIssuesIDQuery(id, view);

    try {
        let [risksIssuesRows] = await database.run(risksIssuesquery);
        if (risksIssuesRows.length > 0) {
            return risksIssuesRows;
        } else {
            return [];
        }
    } catch (err) {
        return new Error(err);
    } finally {
        // Close the database when finished.
        await database.close();
    }
}

const getSearchRiskIssuesIDQuery = async (id, view) => {
    var query = ``;
    switch (view) {
        case '136001': //RisksIssuesLogs
            query = `SELECT rating
                        ,category
                        ,subcategory
                        ,CASE
                            WHEN source = 'CM' 
                                THEN
                                    CASE
                                        WHEN (statementcount - 1) = 0 THEN cd.PrimaryDecodeTxt
                                        ELSE concat(concat(concat(cd.PrimaryDecodeTxt, ', + '), CAST((statementcount - 1) AS STRING)), ' more')
                                    END
                            ELSE res.statement
                        END AS statement
                        ,statementall
                        ,type
                        ,status
                        ,consulcall
                        ,qmdreview
                        ,source
                        ,contractname
                        ,riskdetailskey
                        ,riskassessmentquestionkey
                        ,contractnbr
                        ,contractnm
                        ,customernbr
                        ,customernm
                        ,masterclientnbr
                        ,masterclientnm
                        ,riskid
                        ,mitigationid
                    FROM (
                        SELECT IFNULL(cd1.PrimaryDecodeTxt,'Unrated') AS rating
                            ,IFNULL(cd1.SecondaryDecodeTxt,'4') AS ratingorder
                            ,CASE
                                WHEN cd7.PrimaryDecodeTxt = 'CM' THEN cd2.PrimaryDecodeTxt
                                ELSE rd.CIPCategoryNm
                            END AS category
                            ,CASE
                                WHEN cd7.PrimaryDecodeTxt = 'CM' THEN cd3.PrimaryDecodeTxt
                                ELSE rd.CIPSubCategoryNm
                            END AS subcategory
                            ,CASE
                                WHEN cd7.PrimaryDecodeTxt = 'CM' THEN (SELECT * FROM UNNEST(rd.StatementArr) LIMIT 1)
                                ELSE 
                                    CASE
                                        WHEN rd.CIPRiskStatementNm IS NULL OR rd.CIPRiskStatementNm = '' THEN 'CIP Risk'
                                        ELSE rd.CIPRiskStatementNm
                                    END
                            END AS statement
                            ,CASE
                                WHEN cd7.PrimaryDecodeTxt = 'CM' THEN (SELECT ARRAY_LENGTH(rd.StatementArr))
                                ELSE 0
                            END AS statementcount
                            ,CASE
                                WHEN cd7.PrimaryDecodeTxt = 'CM' THEN concat('• ',(SELECT ARRAY_TO_STRING((SELECT ARRAY_AGG(PrimaryDecodeTxt) FROM CodeDetail WHERE CodeTxt IN UNNEST(rd.StatementArr)), '\\n• ')))
                                ELSE 
                                  CASE
                                      WHEN rd.CIPRiskStatementNm IS NULL OR rd.CIPRiskStatementNm = '' THEN '• CIP Risk'
                                      ELSE concat('• ', rd.CIPRiskStatementNm)
                                  END
                            END AS statementall
                            ,cd4.PrimaryDecodeTxt AS type
                            ,CASE
                                WHEN LOWER(cd5.PrimaryDecodeTxt) = 'reviewed' THEN concat(concat(cd5.PrimaryDecodeTxt, ' on '), CAST(rd.RiskLeadReviewDttm AS STRING))
                                ELSE cd5.PrimaryDecodeTxt
                            END AS status
                            ,CASE
                                WHEN cd7.PrimaryDecodeTxt = 'CIP' THEN ''
                                ELSE 
                                    CASE
                                        WHEN LOWER(cd6.PrimaryDecodeTxt) = 'reviewed' THEN concat(concat(cd6.PrimaryDecodeTxt, ' on '), CAST(cc.ReviewerCompletedDt AS STRING))
                                        ELSE IFNULL(cd6.PrimaryDecodeTxt,'Not Requested')
                                    END
                            END AS consulcall
                            ,CASE
                                WHEN cd7.PrimaryDecodeTxt = 'CIP' THEN ''
                                ELSE 
                                    CASE
                                        WHEN rd.RiskQMDReviewInd = 'N' OR rd.RiskQMDReviewInd IS NULL THEN 'Not Requested'
                                        WHEN rd.RiskQMDReviewInd = 'Y' THEN concat('Requested on ',CAST(rd.RiskQMDReviewDttm AS STRING))
                                        ELSE ''
                                    END
                            END AS qmdreview
                            ,cd7.PrimaryDecodeTxt AS source
                            ,CASE
                                WHEN rd.ContractNbr = '' AND cd7.PrimaryDecodeTxt = 'CM' THEN 'No Contracts Available'
                                WHEN rd.ContractNbr = '' AND cd7.PrimaryDecodeTxt = 'CIP' THEN ''
                                ELSE concat(concat(rd.ContractNm, ' - '), rd.ContractNbr)
                            END AS contractname
                            ,rd.RiskDetailsKey AS riskdetailskey
                            ,raq.RiskAssessmentQuestionKey AS riskassessmentquestionkey
                            ,rd.ContractNbr AS contractnbr
                            ,rd.ContractNm AS contractnm
                            ,rd.CustomerNbr AS customernbr
                            ,rd.CustomerNm AS customernm
                            ,rd.MasterClientNbr AS masterclientnbr
                            ,rd.MasterClientNm AS masterclientnm
                            ,rd.RiskNbr AS riskid
                            ,ARRAY(SELECT CAST(MitigationNbr AS STRING) FROM RiskMitigation rm WHERE rm.RiskDetailsKey = rd.RiskDetailsKey) AS mitigationid
                            ,sd.EnterpriseID AS eid
                        FROM RiskDetails rd
                        LEFT JOIN RiskAssessmentQuestion raq
                            ON rd.RiskAssessmentQuestionKey = raq.RiskAssessmentQuestionKey
                        LEFT JOIN RiskConsultationCall cc
                            ON rd.RiskDetailsKey = cc.RiskDetailsKey
                        LEFT JOIN CodeDetail cd1
                            ON rd.RiskRatingCd = cd1.CodeTxt
                        LEFT JOIN CodeDetail cd2
                            ON raq.CategoryCd = cd2.CodeTxt
                        LEFT JOIN CodeDetail cd3
                            ON raq.SubCategoryCd = cd3.CodeTxt
                        LEFT JOIN CodeDetail cd4
                            ON rd.RiskTypeCd = cd4.CodeTxt
                        LEFT JOIN CodeDetail cd5
                            ON rd.RiskStatusCd = cd5.CodeTxt
                        LEFT JOIN CodeDetail cd6
                            ON cc.ConsultationCallStatusCd = cd6.CodeTxt
                        LEFT JOIN CodeDetail cd7
                            ON rd.RiskSourceCd = cd7.CodeTxt
                        LEFT JOIN MMCSecurityData sd
                            ON rd.MasterClientNbr = sd.MasterClientNbr
                        WHERE (cd7.PrimaryDecodeTxt = 'CIP' OR
                                (cd7.PrimaryDecodeTxt = 'CM' AND (cd1.PrimaryDecodeTxt IN ('High', 'Above Normal'))))
                    ) res
                    LEFT JOIN CodeDetail cd
                        ON cd.CodeTxt = res.statement
                    WHERE res.eid = '${process.env.ENTERPRISEID}' AND (CAST(res.riskid AS STRING) LIKE '%${id}%' OR  ARRAY_TO_STRING(res.mitigationid, " ") LIKE '%${id}%')
                    ORDER BY ratingorder ASC`;
            break;
        case '136002': //Assessment
            query = `SELECT category, subcategory, question, rating, type, source, riskdetailskey, riskassessmentquestionkey, contractnbr, contractnm, customernbr, customernm, masterclientnbr, masterclientnm,riskid,mitigationid
            FROM (
                SELECT cd1.PrimaryDecodeTxt AS category
                    ,cd2.PrimaryDecodeTxt AS subcategory
                    ,cd3.SecondaryDecodeTxt AS question
                    ,raq.QuestionOrderNbr AS questionorder
                    ,IFNULL(rating,'Unrated') AS rating
                    ,IFNULL(ratingorder,'4') AS ratingorder
                    ,type
                    ,source
                    ,riskdetailskey
                    ,raq.RiskAssessmentQuestionKey AS riskassessmentquestionkey
                    ,contractnbr
                    ,contractnm
                    ,customernbr
                    ,customernm
                    ,masterclientnbr
                    ,masterclientnm
                    ,riskid
                    ,mitigationid
                FROM RiskAssessmentQuestion raq
                LEFT JOIN
                (
                    SELECT cd4.PrimaryDecodeTxt AS rating
                        ,cd4.SecondaryDecodeTxt AS ratingorder
                        ,cd5.PrimaryDecodeTxt AS type
                        ,cd6.PrimaryDecodeTxt AS source
                        ,rd.RiskDetailsKey AS riskdetailskey
                        ,rd.ContractNbr AS contractnbr
                        ,rd.ContractNm AS contractnm
                        ,rd.CustomerNbr AS customernbr
                        ,rd.CustomerNm AS customernm
                        ,rd.MasterClientNbr AS masterclientnbr
                        ,rd.MasterClientNm AS masterclientnm
                        ,rd.RiskAssessmentQuestionKey
                        ,rd.RiskNbr AS riskid
                        ,ARRAY(SELECT CAST(MitigationNbr AS STRING) FROM RiskMitigation rm WHERE rm.RiskDetailsKey = rd.RiskDetailsKey) AS mitigationid
                        ,sd.EnterpriseID AS eid
                    FROM RiskDetails rd
                    LEFT JOIN CodeDetail cd4
                        ON rd.RiskRatingCd = cd4.CodeTxt
                    LEFT JOIN CodeDetail cd5
                        ON rd.RiskTypeCd = cd5.CodeTxt
                    LEFT JOIN CodeDetail cd6
                        ON rd.RiskSourceCd = cd6.CodeTxt
                    LEFT JOIN MMCSecurityData sd
                        ON rd.MasterClientNbr = sd.MasterClientNbr
                    WHERE cd6.PrimaryDecodeTxt != 'CIP'
                ) res
                    ON raq.RiskAssessmentQuestionKey = res.RiskAssessmentQuestionKey
                LEFT JOIN CodeDetail cd1
                    ON raq.CategoryCd = cd1.CodeTxt
                LEFT JOIN CodeDetail cd2
                    ON raq.SubCategoryCd = cd2.CodeTxt
                LEFT JOIN CodeDetail cd3
                    ON raq.RiskQuestionCd = cd3.CodeTxt
                WHERE res.eid = '${process.env.ENTERPRISEID}' AND (CAST(res.riskid AS STRING) LIKE '%${id}%' OR  ARRAY_TO_STRING(res.mitigationid, " ") LIKE '%${id}%')
            )
            ORDER BY questionorder ASC`;
            break;
        case '136003': //Consultation
            query = `SELECT rating
                        ,category
                        ,subcategory
                        ,CASE
                            WHEN (statementcount - 1) = 0 THEN cd.PrimaryDecodeTxt
                            ELSE concat(concat(concat(cd.PrimaryDecodeTxt, ', + '), CAST((statementcount - 1) AS STRING)), ' more')
                        END AS statement
                        ,concat('• ',(SELECT ARRAY_TO_STRING(statementarray, '\\n• '))) as statementall
                        ,type
                        ,consulcall
                        ,followupdate
                        ,contractname
                        ,source
                        ,riskdetailskey
                        ,riskassessmentquestionkey
                        ,contractnbr
                        ,contractnm
                        ,customernbr
                        ,customernm
                        ,masterclientnbr
                        ,masterclientnm
                        ,riskid
                        ,mitigationid
                    FROM (
                        SELECT IFNULL(cd1.PrimaryDecodeTxt,'Unrated') AS rating
                            ,IFNULL(cd1.SecondaryDecodeTxt,'4') AS ratingorder
                            ,cd2.PrimaryDecodeTxt AS category
                            ,cd3.PrimaryDecodeTxt AS subcategory
                            ,(SELECT * FROM UNNEST(rd.StatementArr)LIMIT 1) AS statement
                            ,(SELECT ARRAY_LENGTH(rd.StatementArr)) AS statementcount
                            ,(SELECT ARRAY_AGG(PrimaryDecodeTxt) FROM CodeDetail WHERE CodeTxt IN UNNEST(rd.StatementArr)) AS statementarray
                            ,cd4.PrimaryDecodeTxt AS type
                            ,CASE
                                WHEN LOWER(cd5.PrimaryDecodeTxt) = 'reviewed' THEN concat(concat(cd5.PrimaryDecodeTxt, ' on '), CAST(cc.ReviewerCompletedDt AS STRING))
                                ELSE cd5.PrimaryDecodeTxt
                            END AS consulcall
                            ,cc.ReviewerFollowupDt AS followupdate
                            ,CASE
                                WHEN rd.ContractNbr = '' THEN 'No Contracts Available'
                                ELSE concat(concat(rd.ContractNm, ' - '), rd.ContractNbr)
                            END AS contractname
                            ,cd6.PrimaryDecodeTxt AS source
                            ,rd.RiskDetailsKey AS riskdetailskey
                            ,raq.RiskAssessmentQuestionKey AS riskassessmentquestionkey
                            ,rd.ContractNbr AS contractnbr
                            ,rd.ContractNm AS contractnm
                            ,rd.CustomerNbr AS customernbr
                            ,rd.CustomerNm AS customernm
                            ,rd.MasterClientNbr AS masterclientnbr
                            ,rd.MasterClientNm AS masterclientnm
                            ,rd.RiskNbr AS riskid
                            ,ARRAY(SELECT CAST(MitigationNbr AS STRING) FROM RiskMitigation rm WHERE rm.RiskDetailsKey = rd.RiskDetailsKey) AS mitigationid
                            ,sd.EnterpriseID AS eid
                        FROM RiskDetails rd
                        LEFT JOIN RiskAssessmentQuestion raq
                            ON rd.RiskAssessmentQuestionKey = raq.RiskAssessmentQuestionKey
                        LEFT JOIN RiskConsultationCall cc
                            ON rd.RiskDetailsKey = cc.RiskDetailsKey
                        LEFT JOIN CodeDetail cd1
                            ON rd.RiskRatingCd = cd1.CodeTxt
                        LEFT JOIN CodeDetail cd2
                            ON raq.CategoryCd = cd2.CodeTxt
                        LEFT JOIN CodeDetail cd3
                            ON raq.SubCategoryCd = cd3.CodeTxt
                        LEFT JOIN CodeDetail cd4
                            ON rd.RiskTypeCd = cd4.CodeTxt
                        LEFT JOIN CodeDetail cd5
                            ON cc.ConsultationCallStatusCd = cd5.CodeTxt
                        LEFT JOIN CodeDetail cd6
                            ON rd.RiskSourceCd = cd6.CodeTxt
                        LEFT JOIN MMCSecurityData sd
                            ON rd.MasterClientNbr = sd.MasterClientNbr
                        WHERE cd6.PrimaryDecodeTxt != 'CIP'
                            AND cc.ConsultationCallStatusCd IS NOT NULL
                            AND LOWER(cd5.PrimaryDecodeTxt) IN ('pending', 'reviewed')
                    ) res
                    LEFT JOIN CodeDetail cd
                        ON cd.CodeTxt = res.statement
                    WHERE res.eid = '${process.env.ENTERPRISEID}' AND (CAST(res.riskid AS STRING) LIKE '%${id}%' OR  ARRAY_TO_STRING(res.mitigationid, " ") LIKE '%${id}%')
                    ORDER BY ratingorder ASC`;
            break;
        case '136004': //MyMitigations
            query = `SELECT rating 
                        ,CASE
                            WHEN source = 'CM' 
                                THEN
                                    CASE
                                        WHEN (statementcount - 1) = 0 THEN cd.PrimaryDecodeTxt
                                        ELSE concat(concat(concat(cd.PrimaryDecodeTxt, ', + '), CAST((statementcount - 1) AS STRING)), ' more')
                                    END
                            ELSE res.statement
                        END AS statement
                        ,statementall
                        ,description 
                        ,status 
                        ,duedate 
                        ,source 
                        ,contractname
                        ,riskdetailskey
                        ,riskassessmentquestionkey
                        ,contractnbr
                        ,contractnm
                        ,customernbr
                        ,customernm
                        ,masterclientnbr
                        ,masterclientnm
                        ,riskid
                        ,mitigationid
                    FROM (
                        SELECT IFNULL(cd1.PrimaryDecodeTxt,'Unrated') AS rating
                            ,IFNULL(cd1.SecondaryDecodeTxt,'4') AS ratingorder
                            ,CASE
                                WHEN cd3.PrimaryDecodeTxt = 'CM' THEN (SELECT * FROM UNNEST(rd.StatementArr) LIMIT 1)
                                ELSE 
                                    CASE
                                        WHEN rd.CIPRiskStatementNm IS NULL OR rd.CIPRiskStatementNm = '' THEN 'CIP Risk'
                                        ELSE rd.CIPRiskStatementNm
                                    END
                            END AS statement
                            ,CASE
                                WHEN cd3.PrimaryDecodeTxt = 'CM' THEN (SELECT ARRAY_LENGTH(rd.StatementArr))
                                ELSE 0
                            END AS statementcount
                            ,CASE
                                WHEN cd3.PrimaryDecodeTxt = 'CM' THEN concat('• ',(SELECT ARRAY_TO_STRING((SELECT ARRAY_AGG(PrimaryDecodeTxt) FROM CodeDetail WHERE CodeTxt IN UNNEST(rd.StatementArr)), '\\n• ')))
                                ELSE 
                                  CASE
                                      WHEN rd.CIPRiskStatementNm IS NULL OR rd.CIPRiskStatementNm = '' THEN '• CIP Risk'
                                      ELSE concat('• ', rd.CIPRiskStatementNm)
                                  END
                            END AS statementall
                            ,rm.MitigationDesc AS description
                            ,cd2.PrimaryDecodeTxt AS status
                            ,rm.DueDttm AS duedate
                            ,cd3.PrimaryDecodeTxt AS source
                            ,CASE
                                WHEN rd.ContractNbr = '' THEN 'No Contracts Available'
                                ELSE concat(concat(rd.ContractNm, ' - '), rd.ContractNbr)
                            END AS contractname
                            ,rd.RiskDetailsKey AS riskdetailskey
                            ,raq.RiskAssessmentQuestionKey AS riskassessmentquestionkey
                            ,rd.ContractNbr AS contractnbr
                            ,rd.ContractNm AS contractnm
                            ,rd.CustomerNbr AS customernbr
                            ,rd.CustomerNm AS customernm
                            ,rd.MasterClientNbr AS masterclientnbr
                            ,rd.MasterClientNm AS masterclientnm
                            ,rd.RiskNbr AS riskid
                            ,CAST(rm.MitigationNbr AS STRING) AS mitigationid
                            ,sd.EnterpriseID AS eid
                        FROM RiskDetails rd
                        LEFT JOIN RiskAssessmentQuestion raq
                            ON rd.RiskAssessmentQuestionKey = raq.RiskAssessmentQuestionKey
                        LEFT JOIN RiskMitigation rm
                            ON rd.RiskDetailsKey = rm.RiskDetailsKey
                        LEFT JOIN CodeDetail cd1
                            ON rd.RiskRatingCd = cd1.CodeTxt
                        LEFT JOIN CodeDetail cd2
                            ON rm.MitigationStatusCd = cd2.CodeTxt
                        LEFT JOIN CodeDetail cd3
                            ON rd.RiskSourceCd = cd3.CodeTxt
                        LEFT JOIN MMCSecurityData sd
                            ON rd.MasterClientNbr = sd.MasterClientNbr
                        WHERE rm.AssigneeUserId = '${process.env.ENTERPRISEID}'
                    ) res
                    LEFT JOIN CodeDetail cd
                        ON cd.CodeTxt = res.statement
                    WHERE res.eid = '${process.env.ENTERPRISEID}' AND (CAST(res.riskid AS STRING) LIKE '%${id}%' OR res.mitigationid LIKE '%${id}%')
                    ORDER BY ratingorder ASC`;
            break;
    }

    return query;
}

module.exports = {
    getRisksIssuesViews,
    getRisksAndIssues,
    getRisksAssmtAndMitigation,
    getRisksAssmtStatSummary,
    getClientDetails,
    getMitDueOverdueCount,
    getContractScores,
    searchRiskIssuesID
}