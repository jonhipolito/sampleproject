'use strict';

const
    express = require('express'),
    middlewares = require('./middlewares'),
    logRequest = require('morgan'); // use to log every request
require('dotenv').config(); // Loads .env (for local)                                                                                


module.exports = function () {
    let server = express(),
        create,
        start;

    create = function (config) {
        
        // Server settings
        server.set('env', config.env);
        server.set('port', config.port);
        server.set('hostname', config.hostname);

        // parse the url
        server.use(express.urlencoded({ extended: false }))
        server.use(express.json());

        middlewares.init(server);

        // log all request
        if (process.env.NODE_ENV !== 'test') {
            server.use(logRequest('dev'));
        }

        // init route
        let risksIssuesRoute = require('./risksissues.route');
        server.use('/risksissues/api/risksissues', risksIssuesRoute);
    };

    start = function () {
        let hostname = server.get('hostname'),
            port = server.get('port');

        server.listen(port, function () {
            console.log('Express server listening on - http://' + hostname + ':' + port);
        });

        return server;
    };

    return {
        create: create,
        start: start
    };
};
