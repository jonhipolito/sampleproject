process.env.NODE_ENV = 'test';

require('dotenv').config(); // Loads .env (for local)
const should = require('chai').should();
const expect = require('chai').expect;
const assert = require('chai').assert;
const risksIssuesRepository = require('../server/risksissues.repository');

describe('Testing RiskIssues Repository', () => {
    describe('getRisksIssuesViews', () => {
        describe('getRisksIssuesViews - success', () => {
            it('should return risk and issues views as json', async function () {
                var result = await risksIssuesRepository.getRisksIssuesViews();
                
                try{
                    assert.notEqual(result, null);
                } catch(err) {
                    // console.log(err);
                }
            });
            
            it('should return the length of risk and issues views not zero', async function () {
                var result = await risksIssuesRepository.getRisksIssuesViews();

                try{
                    assert.notEqual(result.length, 0);
                } catch(err) {
                    // console.log(err);
                }
            });
        });

        describe('getRisksIssuesViews - error', () => {
            let env;
            before(() => {
                env = Object.assign({}, process.env);
            });
    
            after(() => {
                process.env = env;
            });

            it("should throw an error", async function () {
                process.env.DATABASE_ID = 'unittest'; // alter the database config to throw an error

                try {
                    await risksIssuesRepository.getRisksIssuesViews();
                } catch (err) {
                    expect(err).to.have.string('Database not found');
                }
            });
        });
    });

    describe('getRisksAndIssues', () => {
        describe('getRisksAndIssues - success', () => {
            it('should return risk and issues as json with view = 136001 and con != null', async function () {
                let mc = '1800002'; 
                let fc = '10000112';
                let con = '1';
                let view = '136001';

                var result = await risksIssuesRepository.getRisksAndIssues(mc, fc, con, view);

                result.should.not.equal(null);
            });

            it('should return risk and issues as json with view = 136002 and con != null', async function () {
                let mc = 'null'; 
                let fc = 'null';
                let con = '1800002';
                let view = '136002';

                var result = await risksIssuesRepository.getRisksAndIssues(mc, fc, con, view);

                result.should.not.equal(null);
            });

            it('should return risk and issues as json with view = 136003 and con != null', async function () {
                let mc = '1800002'; 
                let fc = '10000112';
                let con = '1';
                let view = '136003';

                var result = await risksIssuesRepository.getRisksAndIssues(mc, fc, con, view);

                result.should.not.equal(null);
            });

            it('should return risk and issues as json with view = 136004 and con != null', async function () {
                let mc = '1800002'; 
                let fc = '10000112';
                let con = '9940299105';
                let view = '136004';

                var result = await risksIssuesRepository.getRisksAndIssues(mc, fc, con, view);

                result.should.not.equal(null);
            });

            it('should return risk and issues as json with view = 136001 and fc != null', async function () {
                let mc = '1800002'; 
                let fc = '10000112';
                let con = 'null';
                let view = '136001';

                var result = await risksIssuesRepository.getRisksAndIssues(mc, fc, con, view);

                result.should.not.equal(null);
            });

            it('should return risk and issues as json with view = 136002 and fc != null', async function () {
                let mc = 'null'; 
                let fc = '1800002';
                let con = 'null';
                let view = '136002';

                var result = await risksIssuesRepository.getRisksAndIssues(mc, fc, con, view);

                result.should.not.equal(null);
            });

            it('should return risk and issues as json with view = 136003 and fc != null', async function () {
                let mc = '1800002'; 
                let fc = '10000112';
                let con = 'null';
                let view = '136003';

                var result = await risksIssuesRepository.getRisksAndIssues(mc, fc, con, view);

                result.should.not.equal(null);
            });

            it('should return risk and issues as json with view = 136004 and fc != null', async function () {
                let mc = '1800002'; 
                let fc = '10000112';
                let con = 'null';
                let view = '136004';

                var result = await risksIssuesRepository.getRisksAndIssues(mc, fc, con, view);

                result.should.not.equal(null);
            });

            it('should return risk and issues as json with view = 136001 and mc != null', async function () {
                let mc = '1800002'; 
                let fc = 'null';
                let con = 'null';
                let view = '136001';

                var result = await risksIssuesRepository.getRisksAndIssues(mc, fc, con, view);

                result.should.not.equal(null);
            });

            it('should return risk and issues as json with view = 136002 and mc != null', async function () {
                let mc = '1800002'; 
                let fc = 'null';
                let con = 'null';
                let view = '136002';

                var result = await risksIssuesRepository.getRisksAndIssues(mc, fc, con, view);

                result.should.not.equal(null);
            });

            it('should return risk and issues as json with view = 136003 and mc != null', async function () {
                let mc = '1800002'; 
                let fc = 'null';
                let con = 'null';
                let view = '136003';

                var result = await risksIssuesRepository.getRisksAndIssues(mc, fc, con, view);

                result.should.not.equal(null);
            });

            it('should return risk and issues as json with view = 136004 and mc != null', async function () {
                let mc = '1800002'; 
                let fc = 'null';
                let con = 'null';
                let view = '136004';

                var result = await risksIssuesRepository.getRisksAndIssues(mc, fc, con, view);

                result.should.not.equal(null);
            });
        });

        describe('getRisksIssuesViews - error', () => {
            let env;
            before(() => {
                env = Object.assign({}, process.env);
            });
    
            after(() => {
                process.env = env;
            });

            it("should throw an error", async function () {
                let mc = '1800002'; 
                let fc = '1800002';
                let con = '1800002';
                let view = '136001';

                process.env.DATABASE_ID = 'unittest'; // alter the database config to throw an error

                try {
                    await risksIssuesRepository.getRisksAndIssues(mc, fc, con, view);
                } catch (err) {
                    expect(err).to.have.string('Database not found');
                }
            });
        });
    });

    describe('getRisksAssmtAndMitigation', () => {
        describe('getRisksAssmtAndMitigation - success', () => {
            it('should return risk assessment and mitigation as json', async function () {
                var result = await risksIssuesRepository.getRisksAssmtAndMitigation();
                
                try{
                    assert.notEqual(result, null);
                } catch(err) {
                    // console.log(err);
                }
            });
            
            it('should return the length of risk assessment and mitigation not zero', async function () {
                var result = await risksIssuesRepository.getRisksAssmtAndMitigation();

                try{
                    assert.notEqual(result.length, 0);
                } catch(err) {
                    // console.log(err);
                }
            });
        });

        describe('getRisksAssmtAndMitigation - error', () => {
            let env;
            before(() => {
                env = Object.assign({}, process.env);
            });
    
            after(() => {
                process.env = env;
            });

            it("should throw an error", async function () {
                process.env.DATABASE_ID = 'unittest'; // alter the database config to throw an error

                try {
                    await risksIssuesRepository.getRisksAssmtAndMitigation();
                } catch (err) {
                    expect(err).to.have.string('Database not found');
                }
            });
        });
    });

    describe('getRisksAssmtStatSummary', () => {
        describe('getRisksAssmtStatSummary - success', () => {
            it('should return risk assessment status summary as json', async function () {
                var result = await risksIssuesRepository.getRisksAssmtStatSummary();
                
                try{
                    assert.notEqual(result, null);
                } catch(err) {
                    // console.log(err);
                }
            });
            
            it('should return the length of risk assessment status summary not zero', async function () {
                var result = await risksIssuesRepository.getRisksAssmtStatSummary();

                try{
                    assert.notEqual(result.length, 0);
                } catch(err) {
                    // console.log(err);
                }
            });
        });

        describe('getRisksAssmtStatSummary - error', () => {
            let env;
            before(() => {
                env = Object.assign({}, process.env);
            });
    
            after(() => {
                process.env = env;
            });

            it("should throw an error", async function () {
                process.env.DATABASE_ID = 'unittest'; // alter the database config to throw an error

                try {
                    await risksIssuesRepository.getRisksAssmtStatSummary();
                } catch (err) {
                    expect(err).to.have.string('Database not found');
                }
            });
        });
    });

    describe('getGeoRegionCountry', () => {
        describe('getGeoRegionCountry - success', () => {
            it('should return geography, region and country as json', async function () {
                var result = await risksIssuesRepository.getGeoRegionCountry();
                
                try{
                    assert.notEqual(result, null);
                } catch(err) {
                    // console.log(err);
                }
            });
            
            it('should return the length of geography, region and country not zero', async function () {
                var result = await risksIssuesRepository.getGeoRegionCountry();

                try{
                    assert.notEqual(result.length, 0);
                } catch(err) {
                    // console.log(err);
                }
            });
        });

        describe('getGeoRegionCountry - error', () => {
            let env;
            before(() => {
                env = Object.assign({}, process.env);
            });
    
            after(() => {
                process.env = env;
            });

            it("should throw an error", async function () {
                process.env.DATABASE_ID = 'unittest'; // alter the database config to throw an error

                try {
                    await risksIssuesRepository.getGeoRegionCountry();
                } catch (err) {
                    expect(err).to.have.string('Database not found');
                }
            });
        });
    });

    describe('getMitDueOverdueCount', () => {
        describe('getGeoRegionCountry - success', () => {
            it('should return mitigation due and overdue count as json', async function () {
                var result = await risksIssuesRepository.getMitDueOverdueCount();
                
                try{
                    assert.notEqual(result, null);
                } catch(err) {
                    // console.log(err);
                }
            });
            
            it('should return the length of mitigation due and overdue count not zero', async function () {
                var result = await risksIssuesRepository.getMitDueOverdueCount();

                try{
                    assert.notEqual(result.length, 0);
                } catch(err) {
                    // console.log(err);
                }
            });
        });

        describe('getMitDueOverdueCount - error', () => {
            let env;
            before(() => {
                env = Object.assign({}, process.env);
            });
    
            after(() => {
                process.env = env;
            });

            it("should throw an error", async function () {
                process.env.DATABASE_ID = 'unittest'; // alter the database config to throw an error

                try {
                    await risksIssuesRepository.getMitDueOverdueCount();
                } catch (err) {
                    expect(err).to.have.string('Database not found');
                }
            });
        });
    });

    describe('getContractScores', () => {
        describe('getContractScores - success', () => {
            it('should return CM Risk Score as json', async function () {
                let con = '0000130001';

                var result = await risksIssuesRepository.getContractScores(con);
                
                try{
                    assert.notEqual(result, null);
                } catch(err) {
                    // console.log(err);
                }
            });
            
            it('should return the length of CM Risk Score not zero', async function () {
                let con = '0000130001';

                var result = await risksIssuesRepository.getContractScores(con);

                try{
                    assert.notEqual(result.length, 0);
                } catch(err) {
                    // console.log(err);
                }
            });
        });

        describe('getContractScores - error', () => {
            let env;
            before(() => {
                env = Object.assign({}, process.env);
            });
    
            after(() => {
                process.env = env;
            });

            it("should throw an error", async function () {
                process.env.DATABASE_ID = 'unittest'; // alter the database config to throw an error

                try {
                    await risksIssuesRepository.getContractScores();
                } catch (err) {
                    expect(err).to.have.string('Database not found');
                }
            });
        });
    });

    describe('searchRiskIssuesID', () => {
        describe('searchRiskIssuesID - success', () => {
            it('should return risk and issues as json with view = 136001 and con != null', async function () {
                let id = '12345';
                let view = '136001';

                var result = await risksIssuesRepository.searchRiskIssuesID(id, view);

                result.should.not.equal(null);
            });

            it('should return risk and issues as json with view = 136002 and con != null', async function () {
                let id = '12345';
                let view = '136002';

                var result = await risksIssuesRepository.searchRiskIssuesID(id, view);

                result.should.not.equal(null);
            });

            it('should return risk and issues as json with view = 136003 and con != null', async function () {
                let id = '12345';
                let view = '136003';

                var result = await risksIssuesRepository.searchRiskIssuesID(id, view);

                result.should.not.equal(null);
            });

            it('should return risk and issues as json with view = 136004 and con != null', async function () {
                let id = '12345';
                let view = '136004';

                var result = await risksIssuesRepository.searchRiskIssuesID(id, view);

                result.should.not.equal(null);
            });

            it('should return risk and issues as json with view = 136001 and fc != null', async function () {
                let id = '12345';
                let view = '136001';

                var result = await risksIssuesRepository.searchRiskIssuesID(id, view);

                result.should.not.equal(null);
            });

            it('should return risk and issues as json with view = 136002 and fc != null', async function () {
                let id = '12345';
                let view = '136002';

                var result = await risksIssuesRepository.searchRiskIssuesID(id, view);

                result.should.not.equal(null);
            });

            it('should return risk and issues as json with view = 136003 and fc != null', async function () {
                let id = '12345';
                let view = '136003';

                var result = await risksIssuesRepository.searchRiskIssuesID(id, view);

                result.should.not.equal(null);
            });

            it('should return risk and issues as json with view = 136004 and fc != null', async function () {
                let id = '12345';
                let view = '136004';

                var result = await risksIssuesRepository.searchRiskIssuesID(id, view);

                result.should.not.equal(null);
            });

            it('should return risk and issues as json with view = 136001 and mc != null', async function () {
                let id = '12345';
                let view = '136001';

                var result = await risksIssuesRepository.searchRiskIssuesID(id, view);

                result.should.not.equal(null);
            });

            it('should return risk and issues as json with view = 136002 and mc != null', async function () {
                let id = '12345';
                let view = '136002';

                var result = await risksIssuesRepository.searchRiskIssuesID(id, view);

                result.should.not.equal(null);
            });

            it('should return risk and issues as json with view = 136003 and mc != null', async function () {
                let id = '12345';
                let view = '136003';

                var result = await risksIssuesRepository.searchRiskIssuesID(id, view);

                result.should.not.equal(null);
            });

            it('should return risk and issues as json with view = 136004 and mc != null', async function () {
                let id = '12345';
                let view = '136004';

                var result = await risksIssuesRepository.searchRiskIssuesID(id, view);

                result.should.not.equal(null);
            });
        });

        describe('getRisksIssuesViews - error', () => {
            let env;
            before(() => {
                env = Object.assign({}, process.env);
            });
    
            after(() => {
                process.env = env;
            });

            it("should throw an error", async function () {
                let id = '12345';
                let view = '136001';

                process.env.DATABASE_ID = 'unittest'; // alter the database config to throw an error

                try {
                    await risksIssuesRepository.searchRiskIssuesID(id, view);
                } catch (err) {
                    expect(err).to.have.string('Database not found');
                }
            });
        });
    });
    
});