process.env.NODE_ENV = 'test';

const risksIssuesController = require('../server/risksissues.controller');
const risksIssuesService = require('../server/risksissues.service');
const sinon = require('sinon');
const chai = require('chai');
const should = chai.should();
const expect = require('chai').expect;

describe('Testing RisksIssues Controller', () => {
    describe('getRisksIssuesViews', () => {
        describe('getRisksIssuesViews - success', () => {
            before(() => {
                sinon.stub(risksIssuesService, '_getRisksIssuesViews').returns(new Promise((resolve, reject) => {
                    resolve('get success');
                }));
            })

            after(() => {
                risksIssuesService._getRisksIssuesViews.restore();
            })

            it("should send a message after get risks issues views", function () {
                var req = ({
                    params: {mc: '1800002',
                             fc: '10000112',
                             con: '9940299105',
                             view: null}
                });
                var res = new Object();

                res.send = function (val) {
                    val.should.have.property('data');
                    val.should.have.property('data').eql('get success');
                }

                risksIssuesController.getRisksIssuesViews(req, res, {});
            });
        });

        describe('getRisksIssuesViews - error', () => {
            before(() => {
                sinon.stub(risksIssuesService, '_getRisksIssuesViews').rejects(new Error('Fake Service Error'));
            })

            after(() => {
                risksIssuesService._getRisksIssuesViews.restore();
            })

            it("should return an error", function () {
                var req = ({
                    params: {mc: '1800002',
                             fc: '10000112',
                             con: '9940299105',
                             view: null}
                });
                var res = new Object();
                var callback = sinon.spy();

                risksIssuesController.getRisksIssuesViews(req, res, callback);

                try {
                    new ErrorThrowingObject();
                    // Force the test to fail since error wasn't thrown
                    should.fail('no error was thrown when it should have been')
                }
                catch (error) {
                    // console.log(error);
                    // done();
                }
            });

        });
    });

    describe('getRisksAndIssues', () => {
        describe('getRisksAndIssues - success', () => {
            before(() => {
                sinon.stub(risksIssuesService, '_getRisksAndIssues').returns(new Promise((resolve, reject) => {
                    resolve('get success');
                }));
            })

            after(() => {
                risksIssuesService._getRisksAndIssues.restore();
            })

            it("should send a message after get risks issues views", function () {
                var req = ({
                    params: {mc: '1800002',
                             fc: '10000112',
                             con: '9940299105',
                             view: '136001'}
                });
                var res = new Object();

                res.send = function (val) {
                    val.should.have.property('data');
                    val.should.have.property('data').eql('get success');
                }

                risksIssuesController.getRisksAndIssues(req, res, {});
            });
        });

        describe('getRisksIssuesViews - error', () => {
            before(() => {
                sinon.stub(risksIssuesService, '_getRisksAndIssues').rejects(new Error('Fake Service Error'));
            })

            after(() => {
                risksIssuesService._getRisksAndIssues.restore();
            })

            it("should return an error", function () {
                var req = ({
                    params: {mc: '1800002',
                             fc: '10000112',
                             con: '9940299105',
                             view: '136001'}
                });
                var res = new Object();
                var callback = sinon.spy();

                risksIssuesController.getRisksAndIssues(req, res, callback);

                try {
                    new ErrorThrowingObject();
                    // Force the test to fail since error wasn't thrown
                    should.fail('no error was thrown when it should have been')
                }
                catch (error) {
                    // console.log(error);
                    // done();
                }
            });
        });
    });

    describe('exportAssessmentView', () => {
        describe('exportAssessmentView - success', () => {
            before(() => {
                sinon.stub(risksIssuesService, '_exportAssessmentView').returns(new Promise((resolve, reject) => {
                    resolve('export success');
                }));
            })

            after(() => {
                risksIssuesService._exportAssessmentView.restore();
            })

            it("should export assessment view", function () {
                var req = ({
                    body: {
                        MasterClientNbr: '0000110001',
                        CustomerNbr: '0000120001',
                        ContractNbr: '0000130001',
                    }
                });
                var res = new Object();

                res.send = function (val) {
                    val.should.have.property('message');
                    val.should.have.property('message').eql('export success');
                }

                risksIssuesController.exportAssessmentView(req, res, {});
            });
        });

        describe('exportAssessmentView - error', () => {
            before(() => {
                sinon.stub(risksIssuesService, '_exportAssessmentView').rejects(new Error('Fake Service Error'));
            })

            after(() => {
                risksIssuesService._exportAssessmentView.restore();
            })

            it("should return an error", function () {
                var req = ({
                    body: {
                        MasterClientNbr: '0000110001',
                        CustomerNbr: '0000120001',
                        ContractNbr: '0000130001',
                    }
                });
                var res = new Object();
                var callback = sinon.spy();

                risksIssuesController.exportAssessmentView(req, res, callback);

                try {
                    new ErrorThrowingObject();
                    // Force the test to fail since error wasn't thrown
                    should.fail('no error was thrown when it should have been')
                }
                catch (error) {
                    // console.log(error);
                    // done();
                }
            });
        });
    });

    describe('searchRiskIssuesID', () => {
        describe('searchRiskIssuesID - success', () => {
            before(() => {
                sinon.stub(risksIssuesService, '_searchRiskIssuesID').returns(new Promise((resolve, reject) => {
                    resolve('get success');
                }));
            })

            after(() => {
                risksIssuesService._searchRiskIssuesID.restore();
            })

            it("should send a message after get risks issues views", function () {
                var req = ({
                    params: {id: '12345',
                             view: '136001'}
                });
                var res = new Object();

                res.send = function (val) {
                    val.should.have.property('data');
                    val.should.have.property('data').eql('get success');
                }

                risksIssuesController.searchRiskIssuesID(req, res, {});
            });
        });

        describe('getRisksIssuesViews - error', () => {
            before(() => {
                sinon.stub(risksIssuesService, '_searchRiskIssuesID').rejects(new Error('Fake Service Error'));
            })

            after(() => {
                risksIssuesService._searchRiskIssuesID.restore();
            })

            it("should return an error", function () {
                var req = ({
                    params: {id: '12345',
                             view: '136001'}
                });
                var res = new Object();
                var callback = sinon.spy();

                risksIssuesController.searchRiskIssuesID(req, res, callback);

                try {
                    new ErrorThrowingObject();
                    // Force the test to fail since error wasn't thrown
                    should.fail('no error was thrown when it should have been')
                }
                catch (error) {
                    // console.log(error);
                    // done();
                }
            });
        });
    });
});