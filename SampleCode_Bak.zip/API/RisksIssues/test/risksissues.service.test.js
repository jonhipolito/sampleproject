process.env.NODE_ENV = 'test';

const should = require('chai').should();
const expect = require('chai').expect;
const assert = require('chai').assert;
const sinon = require('sinon');
// const Excel = require('exceljs');
// var mock = sinon.mock(Excel);
var mock = require('mock-require');

mock('exceljs', 'Workbook()');

var Excel = require('exceljs');
const risksIssuesRepository = require('../server/risksissues.repository');
const risksIssuesService = require('../server/risksissues.service');

describe('Testing RisksIssues Service', () => {
    describe('_getRisksIssuesViews', () => {
        describe('_getRisksIssuesViews - success', () => {
            before(() => {
                var arryObj = (
                    [
                        {
                            id:  "136001", 
                            primaryTxt: "Risks & Issues Log",
                            secondaryTxt: "All CM items excluding normal or unrated. All CIP items.",
                            disabled: "false"
                        },
                        {
                            id:  "136002", 
                            primaryTxt: "Assessment View",
                            secondaryTxt: "Available at contract level only.",
                            disabled: "false"
                        },
                        {
                            id:  "136003", 
                            primaryTxt: "Consultation Call View",
                            secondaryTxt: "Shows only items marked for consultation call.",
                            disabled: "false"
                        },
                        {
                            id:  "136004", 
                            primaryTxt: "My Mitigations",
                            secondaryTxt: "Shows only mitigations assigned to you.",
                            disabled: "false"
                        }
                    ]
                );

                var arryObj2 = (
                    [
                        [
                            {
                                name:  "qmdreview", 
                                value: "Requested on 2019-06-27 20:37:48.442-07"
                            },
                            {
                                name:  "status", 
                                value: "Reviewed on 2019-06-27 20:37:48.442-07"
                            },
                            {
                                name:  "consulcall", 
                                value: "Reviewed on 2019-06-27 20:37:48.442-07"
                            },
                            {
                                name:  "rating", 
                                value: "High"
                            }
                        ]
                    ]
                );

                sinon.stub(risksIssuesRepository, 'getRisksIssuesViews').returns(arryObj);
                sinon.stub(risksIssuesRepository, 'getRisksAndIssues').returns(arryObj2);
            });

            after(() => {
                risksIssuesRepository.getRisksIssuesViews.restore();
                risksIssuesRepository.getRisksAndIssues.restore();
            });

            it("should get and return risks and issues views", function (done) {
                let mc = '1800002'; 
                let fc = '10000112';
                let con = '9940299105';
                let view = null;

                risksIssuesService._getRisksIssuesViews(mc, fc, con, view)
                    .then(message => {
                        message.should.have.property('views');
                    })
                    .finally(done())
            });
        });

        describe('_getRisksIssuesViews - success', () => {
            before(() => {
                var arryObj = (
                    [
                        {
                            id:  "136001", 
                            primaryTxt: "Risks & Issues Log",
                            secondaryTxt: "All CM items excluding normal or unrated. All CIP items.",
                            disabled: "false"
                        },
                        {
                            id:  "136002", 
                            primaryTxt: "Assessment View",
                            secondaryTxt: "Available at contract level only.",
                            disabled: "false"
                        },
                        {
                            id:  "136003", 
                            primaryTxt: "Consultation Call View",
                            secondaryTxt: "Shows only items marked for consultation call.",
                            disabled: "false"
                        },
                        {
                            id:  "136004", 
                            primaryTxt: "My Mitigations",
                            secondaryTxt: "Shows only mitigations assigned to you.",
                            disabled: "false"
                        }
                    ]
                );

                var arryObj2 = ([]);

                sinon.stub(risksIssuesRepository, 'getRisksIssuesViews').returns(arryObj);
                sinon.stub(risksIssuesRepository, 'getRisksAndIssues').returns(arryObj2);
            });

            after(() => {
                risksIssuesRepository.getRisksIssuesViews.restore();
                risksIssuesRepository.getRisksAndIssues.restore();
            });

            it("should get and return risks and issues views", function (done) {
                let mc = '1800002'; 
                let fc = '10000112';
                let con = '9940299105';
                let view = 'assessmentview';

                risksIssuesService._getRisksIssuesViews(mc, fc, con, view)
                    .then(message => {
                        message.should.have.property('views');
                    })
                    .finally(done())
            });
        });

        describe('_getRisksIssuesViews - error', () => {
            before(() => {
                sinon.stub(risksIssuesRepository, 'getRisksIssuesViews').rejects(new Error('Fake Repository Error'));
            })

            after(() => {
                risksIssuesRepository.getRisksIssuesViews.restore();
            })

            it("should return an error", function (done) {
                risksIssuesService._getRisksIssuesViews()
                    .catch(error => {
                        error.message.should.eql('Fake Repository Error');
                    })
                    .finally(done())
            });
        });
    });

    describe('_getRisksAndIssues', () => {
        //136004
        describe('_getRisksAndIssues - success', () => {
            before(() => {
                var arryObj = (
                    [
                        [
                            {
                                name:  "duedate", 
                                value: "2019-06-27 20:37:48.442-07"
                            }
                        ]
                    ]
                );

                sinon.stub(risksIssuesRepository, 'getRisksAndIssues').returns(arryObj);
            });

            after(() => {
                risksIssuesRepository.getRisksAndIssues.restore();
            });

            it("should get and return risks and issues with 136004 as value of view", function (done) {
                let mc = '1800002'; 
                let fc = '1800002';
                let con = '1800002';
                let view = '136004';

                risksIssuesService._getRisksAndIssues(mc, fc, con, view)
                    .then(message => {
                        message.should.not.equal(null);
                    })
                    .finally(done())
            });
        });

        //136003
        describe('_getRisksAndIssues - success', () => {
            before(() => {
                var arryObj = (
                    [
                        [
                            {
                                name:  "consulcall", 
                                value: "Reviewed on 2019-06-27 20:37:48.442-07"
                            }
                        ]
                    ]
                );

                sinon.stub(risksIssuesRepository, 'getRisksAndIssues').returns(arryObj);
            });

            after(() => {
                risksIssuesRepository.getRisksAndIssues.restore();
            });

            it("should get and return risks and issues with 136003 as value of view", function (done) {
                let mc = '1800002'; 
                let fc = '1800002';
                let con = '1800002';
                let view = '136003';

                risksIssuesService._getRisksAndIssues(mc, fc, con, view)
                    .then(message => {
                        message.should.not.equal(null);
                    })
                    .finally(done())
            });
        });

        //136001
        describe('_getRisksAndIssues - success', () => {
            before(() => {
                var arryObj = (
                    [
                        [
                            {
                                name:  "qmdreview", 
                                value: "Requested on 2019-06-27 20:37:48.442-07"
                            },
                            {
                                name:  "status", 
                                value: "Reviewed on 2019-06-27 20:37:48.442-07"
                            },
                            {
                                name:  "consulcall", 
                                value: "Reviewed on 2019-06-27 20:37:48.442-07"
                            },
                            {
                                name:  "rating", 
                                value: "High"
                            }
                        ]
                    ]
                );

                sinon.stub(risksIssuesRepository, 'getRisksAndIssues').returns(arryObj);
            });

            after(() => {
                risksIssuesRepository.getRisksAndIssues.restore();
            });

            it("should get and return risks and issues with 136003 as value of view", function (done) {
                let mc = '1800002'; 
                let fc = '1800002';
                let con = '1800002';
                let view = '136001';

                risksIssuesService._getRisksAndIssues(mc, fc, con, view)
                    .then(message => {
                        message.should.not.equal(null);
                    })
                    .finally(done())
            });
        });

        //136002
        describe('_getRisksAndIssues - success', () => {
            before(() => {
                var arryObj = (
                    [
                        [
                            {
                                name:  "rating", 
                                value: "High"
                            }
                        ]
                    ]
                );

                sinon.stub(risksIssuesRepository, 'getRisksAndIssues').returns(arryObj);
            });

            after(() => {
                risksIssuesRepository.getRisksAndIssues.restore();
            });

            it("should get and return risks and issues with 136002 as value of view", function (done) {
                let mc = '1800002'; 
                let fc = '1800002';
                let con = '1800002';
                let view = '136002';

                risksIssuesService._getRisksAndIssues(mc, fc, con, view)
                    .then(message => {
                        message.should.not.equal(null);
                    })
                    .finally(done())
            });
        });

        describe('_getRisksAndIssues - error', () => {
            before(() => {
                sinon.stub(risksIssuesRepository, 'getRisksAndIssues').rejects(new Error('Fake Repository Error'));
            })

            after(() => {
                risksIssuesRepository.getRisksAndIssues.restore();
            })

            it("should return an error", function (done) {
                risksIssuesService._getRisksAndIssues()
                    .catch(error => {
                        error.message.should.eql('Fake Repository Error');
                    })
                    .finally(done())
            });
        });
    });

    describe('_exportAssessmentView', () => {
        describe('_exportAssessmentView - success', () => {
            before(() => {
                sinon.stub(risksIssuesRepository, 'getGeoRegionCountry').returns('Test Geography, Region and Country.');
                sinon.stub(risksIssuesRepository, 'getContractScores').returns('Test CM Risk Score.');
                sinon.stub(risksIssuesRepository, 'getRisksAssmtStatSummary').returns('Test Risk Assessment Status Summary.');
                sinon.stub(risksIssuesRepository, 'getMitDueOverdueCount').returns('Test Mitigation Due and Overdue Count.');
                sinon.stub(risksIssuesRepository, 'getRisksAssmtAndMitigation').returns('Test Risk Assessment and Mitigation.');
                sinon.stub(Excel, 'Workbook').returns(Excel.Workbook);
            });

            after(() => {
                risksIssuesRepository.getGeoRegionCountry.restore();
                risksIssuesRepository.getContractScores.restore();
                risksIssuesRepository.getRisksAssmtStatSummary.restore();
                risksIssuesRepository.getMitDueOverdueCount.restore();
                risksIssuesRepository.getRisksAssmtAndMitigation.restore();
                Excel.Workbook.restore();
            });

            it("should get all data and generate Risk Assessment View Export Template.xlsx", function (done) {
                let body = {
                    MasterClientNbr: '0000110001',
                    CustomerNbr: '0000120001',
                    ContractNbr: '0000130001',
                };

                risksIssuesService._exportAssessmentView(body)
                    .then(message => {
                        message.should.eql('Test Geography, Region and Country.');
                        message.should.eql('Test CM Risk Score.');
                        message.should.eql('Test Risk Assessment Status Summary.');
                        message.should.eql('Test Mitigation Due and Overdue Count.');
                        message.should.eql('Test Risk Assessment and Mitigation.');
                    })
                    .finally(done())
            });
        });

        describe('_exportAssessmentView - error', () => {
            before(() => {
                sinon.stub(risksIssuesRepository, 'getGeoRegionCountry').rejects(new Error('Fake Repository Error'));
                sinon.stub(risksIssuesRepository, 'getContractScores').rejects(new Error('Fake Repository Error'));
                sinon.stub(risksIssuesRepository, 'getRisksAssmtStatSummary').rejects(new Error('Fake Repository Error'));
                sinon.stub(risksIssuesRepository, 'getMitDueOverdueCount').rejects(new Error('Fake Repository Error'));
                sinon.stub(risksIssuesRepository, 'getRisksAssmtAndMitigation').rejects(new Error('Fake Repository Error'));
            });

            after(() => {
                risksIssuesRepository.getGeoRegionCountry.restore();
                risksIssuesRepository.getContractScores.restore();
                risksIssuesRepository.getRisksAssmtStatSummary.restore();
                risksIssuesRepository.getMitDueOverdueCount.restore();
                risksIssuesRepository.getRisksAssmtAndMitigation.restore();
            });


            it("should return an error.", function (done) {
                let body = {};

                risksIssuesService._exportAssessmentView(body)
                    .catch(error => {
                        error.message.should.eql('Fake Repository Error.');
                    })
                    .finally(done())
            });
        });
    });

    describe('_searchRiskIssuesID', () => {
        //136004
        describe('_searchRiskIssuesID - success', () => {
            before(() => {
                var arryObj = (
                    [
                        [
                            {
                                name:  "duedate", 
                                value: "2019-06-27 20:37:48.442-07"
                            }
                        ]
                    ]
                );

                sinon.stub(risksIssuesRepository, 'searchRiskIssuesID').returns(arryObj);
            });

            after(() => {
                risksIssuesRepository.searchRiskIssuesID.restore();
            });

            it("should get and return risks and issues with 136004 as value of view", function (done) {
                let id = '12345';
                let view = '136004';

                risksIssuesService._searchRiskIssuesID(id, view)
                    .then(message => {
                        message.should.not.equal(null);
                    })
                    .finally(done())
            });
        });

        //136003
        describe('_searchRiskIssuesID - success', () => {
            before(() => {
                var arryObj = (
                    [
                        [
                            {
                                name:  "consulcall", 
                                value: "Reviewed on 2019-06-27 20:37:48.442-07"
                            }
                        ]
                    ]
                );

                sinon.stub(risksIssuesRepository, 'searchRiskIssuesID').returns(arryObj);
            });

            after(() => {
                risksIssuesRepository.searchRiskIssuesID.restore();
            });

            it("should get and return risks and issues with 136003 as value of view", function (done) {
                let id = '12345';
                let view = '136003';

                risksIssuesService._searchRiskIssuesID(id, view)
                    .then(message => {
                        message.should.not.equal(null);
                    })
                    .finally(done())
            });
        });

        describe('_searchRiskIssuesID - success', () => {
            before(() => {
                var arryObj = (
                    [
                        [
                            {
                                name:  "consulcall", 
                                value: "Reviewed on "
                            }
                        ]
                    ]
                );

                sinon.stub(risksIssuesRepository, 'searchRiskIssuesID').returns(arryObj);
            });

            after(() => {
                risksIssuesRepository.searchRiskIssuesID.restore();
            });

            it("should get and return risks and issues with 136003 as value of view", function (done) {
                let id = '12345';
                let view = '136003';

                risksIssuesService._searchRiskIssuesID(id, view)
                    .then(message => {
                        message.should.not.equal(null);
                    })
                    .finally(done())
            });
        });

        //136001
        describe('_searchRiskIssuesID - success', () => {
            before(() => {
                var arryObj = (
                    [
                        [
                            {
                                name:  "qmdreview", 
                                value: "Requested on 2019-06-27 20:37:48.442-07"
                            },
                            {
                                name:  "status", 
                                value: "Reviewed on 2019-06-27 20:37:48.442-07"
                            },
                            {
                                name:  "consulcall", 
                                value: "Reviewed on 2019-06-27 20:37:48.442-07"
                            },
                            {
                                name:  "rating", 
                                value: "High"
                            }
                        ]
                    ]
                );

                sinon.stub(risksIssuesRepository, 'searchRiskIssuesID').returns(arryObj);
            });

            after(() => {
                risksIssuesRepository.searchRiskIssuesID.restore();
            });

            it("should get and return risks and issues with 136003 as value of view", function (done) {
                let id = '12345';
                let view = '136001';

                risksIssuesService._searchRiskIssuesID(id, view)
                    .then(message => {
                        message.should.not.equal(null);
                    })
                    .finally(done())
            });
        });

        describe('_searchRiskIssuesID - success', () => {
            before(() => {
                var arryObj = (
                    [
                        [
                            {
                                name:  "qmdreview", 
                                value: "Requested on"
                            },
                            {
                                name:  "status", 
                                value: "Reviewed on"
                            },
                            {
                                name:  "consulcall", 
                                value: "Reviewed on"
                            },
                            {
                                name:  "rating", 
                                value: "High"
                            }
                        ]
                    ]
                );

                sinon.stub(risksIssuesRepository, 'searchRiskIssuesID').returns(arryObj);
            });

            after(() => {
                risksIssuesRepository.searchRiskIssuesID.restore();
            });

            it("should get and return risks and issues with 136003 as value of view", function (done) {
                let id = '12345';
                let view = '136001';

                risksIssuesService._searchRiskIssuesID(id, view)
                    .then(message => {
                        message.should.not.equal(null);
                    })
                    .finally(done())
            });
        });

        //136002
        describe('_searchRiskIssuesID - success', () => {
            before(() => {
                var arryObj = (
                    [
                        [
                            {
                                name:  "rating", 
                                value: "High"
                            }
                        ]
                    ]
                );

                sinon.stub(risksIssuesRepository, 'searchRiskIssuesID').returns(arryObj);
            });

            after(() => {
                risksIssuesRepository.searchRiskIssuesID.restore();
            });

            it("should get and return risks and issues with 136002 as value of view", function (done) {
                let id = '12345';
                let view = '136002';

                risksIssuesService._searchRiskIssuesID(id, view)
                    .then(message => {
                        message.should.not.equal(null);
                    })
                    .finally(done())
            });
        });

        describe('_searchRiskIssuesID - error', () => {
            before(() => {
                sinon.stub(risksIssuesRepository, 'searchRiskIssuesID').rejects(new Error('Fake Repository Error'));
            })

            after(() => {
                risksIssuesRepository.searchRiskIssuesID.restore();
            })

            it("should return an error", function (done) {
                risksIssuesService._searchRiskIssuesID()
                    .catch(error => {
                        error.message.should.eql('Fake Repository Error');
                    })
                    .finally(done())
            });
        });
    });
});