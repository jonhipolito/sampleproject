'use strict';

const commonService = require('./common.service');

const getLastAccessClient = (req, res, next) => {
    commonService._getLastAccessClient()
        .then(something => {
            res.send({
                message: something
            });
        })
        .catch(error => {
            res.status(500).send({ errors: error });
        })
}

const postLastAccessClient = (req, res, next) => {
    console.log(req);
    commonService._postLastAccessClient(req.body)
        .then(something => {
            res.send({
                message: something
            });
        })
        .catch(error => {
            res.status(500).send({ errors: error });
        })
}

const getMasterClientList = (req, res, next) => {
    commonService._getMasterClientList()
        .then(something => {
            res.send({
                message: something
            });
        })
        .catch(error => {
            res.status(500).send({ errors: error });
        })
}

const getCustomerList = (req, res, next) => {
    commonService._getCustomerList(req.params.id)
        .then(something => {
            res.send({
                message: something
            });
        })
        .catch(error => {
            res.status(500).send({ errors: error });
        })
}

const getContractList = (req, res, next) => {
    commonService._getContractList(req.params.id)
        .then(something => {
            res.send({
                message: something
            });
        })
        .catch(error => {
            res.status(500).send({ errors: error });
        })
}

const getContractListByMClient = (req, res, next) => {
    commonService._getContractListByMClient(req.params.id)
        .then(something => {
            res.send({
                message: something
            });
        })
        .catch(error => {
            res.status(500).send({ errors: error });
        })
}

const getURL = (req, res, next) => {
    commonService._getURL(req.params.description)
        .then(url => {
            res.send({
                message: url
            });
        })
        .catch(error => {
            res.status(500).send({ errors: error });
        })
}

// const user = async(req, res, next) => {    
//     let token;    
//     let eid;  

//     if(req.headers.authorization){
//         token = req.headers.authorization.replace("Bearer ","");  
//     }    
//     if(req.params.enterpriseId) {
//         eid = req.params.enterpriseId;
//     }
//     else {
//         eid = process.env.ENTERPRISEID;
//     }

//     let user = await commonService._user(token,eid);
//     res.send(user);
// }
const userMRDRLocation = async (req, res, next) => {
    let eid;
    if (req.params.enterpriseId) {
        eid = req.params.enterpriseId;
    }
    else {
        eid = process.env.ENTERPRISEID;
    }
    let user = await commonService._userMRDRLocation(eid);
    res.send(user);
}
const userProfile = async (req, res, next) => {
    let token;
    let eid;

    if (req.headers.authorization) {
        token = req.headers.authorization.replace("Bearer ", "");
    }

    if (req.params.enterpriseId) {
        eid = req.params.enterpriseId;
    }
    else {
        eid = process.env.ENTERPRISEID;
    }

    let user = await commonService._userProfile(token, eid);

    res.send(user);
}
// const userGroups = async(req, res, next) => {    
//     let email;  
//     if(req.params.enterpriseId) {
//         email = req.params.enterpriseId + '@' + process.env.MailDomain;
//     }
//     else {
//         email = process.env.ENTERPRISEID + '@' + process.env.MailDomain;
//     }
//     let user = await commonService._userAADGroups(email);

//     res.send(user);
// }
const getPeopleImage = (req, res, next) => {
    let eid;
    if (req.params.enterpriseId) {
        eid = req.params.enterpriseId;
    }
    commonService._getPeopleImage(eid)
        .then(data => {
            if (data) {                
                res.json(data);
            }
            else {
                res.send();
            }
        })
        .catch(error => {
            res.json(error);
        })
}
const peoplepicker = (req, res, next) => {
    let filter = req.query.filter;
    let count = req.query.count;
    commonService._getAADPeoplePicker(filter, count)
        .then(data => {
            res.send(data);
        })
        .catch(error => {
            res.status(500).send({ errors: error });
        })
}

const getMMCLinkItems = (req, res, next) => {
    commonService._getMMCLinkItems(req.params.linkCategory)
        .then(data => {
            res.send({
                data: data
            });
        })
        .catch(error => {
            res.status(500).send({ errors: error });
        })
}

const getDisabledFeatures = (req, res, next) => {
    commonService._getDisabledFeatures(req.params.featureGroup)
    .then(data => {
        res.send({
            data: data
        });
    })
    .catch(error => {
        res.status(500).send({ errors: error });
    });
}

// const getPeopleImageThumbnail = (req, res, next) => {
//     let peopleKey;
//     let eid;
//     if(req.params.peopleKey) {
//         peopleKey = req.params.peopleKey;
//     }
//     if(req.params.enterpriseId) {
//         eid = req.params.enterpriseId;
//     }
//     commonService._getPeopleImageThumbnail(peopleKey,eid)
//         .then(data => {
//             if(data) {
//                 let u8 = new Uint8Array(data);
//                 res.writeHead(200, {
//                     'Content-Type': 'image/jpeg',
//                     'Content-disposition': 'inline;filename=' + req.params.id,
//                     'Content-Length': u8.length.toString()
//                 });
//                 res.end(Buffer.from(u8, 'binary'));            
//             }
//             else {
//                 res.send();
//             }                    
//         })
//         .catch(error => {
//             const err = new Error(error);
//             next(err);
//         })
// }

const hasMasterClientAccess = (req, res, next) => {
    commonService._hasMasterClientAccess(req.params.MasterClientNbr)
        .then(data => {
            res.send(data);
        });
}

const hasCustomerAccess = (req, res, next) => {
    commonService._hasCustomerAccess(req.params.CustomerNbr)
        .then(data => {
            res.send(data);
        });
}

const hasContractAccess = (req, res, next) => {
    commonService._hasContractAccess(req.params.ContractNbr)
        .then(data => {
            res.send(data);
        });
}

module.exports = {
    getLastAccessClient,
    postLastAccessClient,
    getMasterClientList,
    getCustomerList,
    getContractList,
    getContractListByMClient,
    getURL,
    // user,
    userMRDRLocation,
    userProfile,
    // userGroups,
    getPeopleImage,
    peoplepicker,
    getMMCLinkItems,
    getDisabledFeatures
    // getPeopleImageThumbnail
}
