'use strict';

const express = require('express');

const commonController = require('./common.controller');

const { hasAccess } = require('./middlewares/accesscontrol');

const router = express.Router();

router.get('/getLastAccessClient', hasAccess, commonController.getLastAccessClient);
router.post('/postLastAccessClient', hasAccess, commonController.postLastAccessClient);
router.get('/getMasterClientList', hasAccess, commonController.getMasterClientList);
router.get('/getCustomerList/:id', hasAccess, commonController.getCustomerList);
router.get('/getContractList/:id', hasAccess, commonController.getContractList);
router.get('/getContractListByMClient/:id', hasAccess, commonController.getContractListByMClient);
router.get('/getURL/:description', hasAccess, commonController.getURL);
// router.get('/User/:enterpriseId?', hasAccess, commonController.user);
router.get('/UserMRDRLocation/:enterpriseId?/', hasAccess, commonController.userMRDRLocation);
router.get('/UserProfile/:enterpriseId?/', hasAccess, commonController.userProfile);
// router.get('/UserGroups/:enterpriseId?/', hasAccess, commonController.userGroups);
router.get('/getPeopleImage/:enterpriseId?/', hasAccess, commonController.getPeopleImage);
router.get('/peoplepicker', hasAccess, commonController.peoplepicker);
router.get('/getMMCLinkItems/:linkCategory', hasAccess, commonController.getMMCLinkItems);
router.get('/getDisabledFeatures/:featureGroup', hasAccess, commonController.getDisabledFeatures);
// router.get('/getPeopleImageThumbnail/:peopleKey?/:enterpriseId?/', hasAccess, commonController.getPeopleImageThumbnail);

module.exports = router;
