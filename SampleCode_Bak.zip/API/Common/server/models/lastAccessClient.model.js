'use strict';

const uuid = require('uuidv4');

module.exports = function (mc, fc, con) {
    this.LastAccessClientLogKey = uuid();
    this.ContractCd = con;
    this.CreateDttm = new Date();
    this.CreateUserId = process.env.ENTERPRISEID
    this.FinancialClientCd = fc
    this.MasterClientCd = mc
    this.UpdateDttm = new Date();
    this.UpdateUserId = process.env.ENTERPRISEID
    this.UserNm = process.env.ENTERPRISEID
}