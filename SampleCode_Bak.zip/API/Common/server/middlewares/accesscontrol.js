'use strict';
const NodeCache = require("node-cache");
const ttl = 60 * 60 * 1; // cache for 1 Hour
const cache = new NodeCache({ stdTTL: ttl, checkperiod: ttl * 0.2 });

const SpannerDB = require('../../configs/db.connection');

const hasMasterClientAccess = async (MasterClientNbr, EnterpriseId) => {
    let result = cache.get(`${MasterClientNbr}-${EnterpriseId}`);
    if (result && result.length > 0) {
        return result;
    }
    let database = new SpannerDB();
    const query = {
        sql: `
        SELECT MasterClientNbr 
        FROM MMCSecurityData 
        WHERE EnterpriseId = @EnterpriseId
        AND MasterClientNbr = @MasterClientNbr
        LIMIT 1
        `,
        params: {
            MasterClientNbr,
            EnterpriseId
        }
    };
    try {
        [result] = await database.run(query);
        if (result && result.length > 0) {
            cache.set(`${MasterClientNbr}-${EnterpriseId}`, result);
        }
        return result;
    } catch (err) {
        console.error('ERROR:', err);
    } finally {
        await database.close();
    }
}

const hasCustomerAccess = async (CustomerNbr, EnterpriseId) => {
    let result = cache.get(`${CustomerNbr}-${EnterpriseId}`);
    if (result && result.length > 0) {
        return result;
    }
    let database = new SpannerDB();
    const query = {
        sql: `
        SELECT mc.MasterClientNbr 
        FROM MMCSecurityData mc
        INNER JOIN CUSTOMER cus
        ON cus.MasterClientNbr = mc.MasterClientNbr        
        WHERE CustomerNbr = @CustomerNbr
        AND EnterpriseId = @EnterpriseId
        LIMIT 1
        `,
        params: {
            CustomerNbr,
            EnterpriseId
        }
    };
    try {
        const [result] = await database.run(query);
        if (result && result.length > 0) {
            cache.set(`${CustomerNbr}-${EnterpriseId}`, result);
        }
        return result;
    } catch (err) {
        console.error('ERROR:', err);
    } finally {
        await database.close();
    }
}

const hasContractAccess = async (ContractNbr, EnterpriseId) => {
    let result = cache.get(`${ContractNbr}-${EnterpriseId}`);
    if (result && result.length > 0) {
        return result;
    }
    let database = new SpannerDB();
    const query = {
        sql: `
        SELECT mc.MasterClientNbr 
        FROM MMCSecurityData mc
        INNER JOIN CUSTOMER cus
        ON cus.MasterClientNbr = mc.MasterClientNbr
        INNER JOIN Contract con
        ON con.CustomerNbr = cus.CustomerNbr
        WHERE ContractNbr = @ContractNbr
        AND EnterpriseId = @EnterpriseId
        LIMIT 1
        `,
        params: {
            ContractNbr,
            EnterpriseId
        }
    };
    try {
        const [result] = await database.run(query);
        if (result && result.length > 0) {
            cache.set(`${ContractNbr}-${EnterpriseId}`, result);
        }
        return result;
    } catch (err) {
        console.error('ERROR:', err);
    } finally {
        await database.close();
    }
}

const processParams = async (req, params, type, state) => {
    let access = [];
    for (let index = 0; index < params.length; index++) {
        const x = params[index];        
        if (req.params && req.params[x] && !isNaN(req.params[x]) && req.params[x] != 0) {
            switch (type) {
                case "mc":
                    access = await hasMasterClientAccess(req.params[x], process.env.ENTERPRISEID);
                    break;
                case "fc":
                    access = await hasCustomerAccess(req.params[x], process.env.ENTERPRISEID);
                    break;
                case "con":
                    access = await hasContractAccess(req.params[x], process.env.ENTERPRISEID);
                    break;
                default:
                    break;
            }
            if (access.length == 0) {
                state = 0;
            }
            else {
                state = 1;
            }
        }
        if (req.body && req.body[x] && !isNaN(req.body[x]) && req.body[x] != 0) {
            switch (type) {
                case "mc":
                    access = await hasMasterClientAccess(req.body[x], process.env.ENTERPRISEID);
                    break;
                case "fc":
                    access = await hasCustomerAccess(req.body[x], process.env.ENTERPRISEID);
                    break;
                case "con":
                    access = await hasContractAccess(req.body[x], process.env.ENTERPRISEID);
                    break;
                default:
                    break;
            }
            if (access.length == 0) {
                state = 0;
            }
            else {
                state = 1;
            }
        }
    }
    return state;

}
const hasAccess = async (req, res, next) => {
    let mcparams = ['MCustomerNbr', 'mcid', 'MasterClientNbr','mc']
    let fcparams = ['fcid', 'CustomerNbr','customerNbr','fc']
    let conparams = ['contractNbr','con']
    let state = -1;
    state = await processParams(req, conparams, 'con', state);
    if (state > 0) {
        next();
        return;
    }

    state = await processParams(req, fcparams, 'fc', state);
    if (state > 0) {
        next();
        return;
    }

    state = await processParams(req, mcparams, 'mc', state);
    if (state > 0) {
        next();
        return;
    }
    if (state == 0) {
        res.status(401).send('Unauthorized')
    }
    else {
        next();
    }
}

module.exports = { hasAccess }