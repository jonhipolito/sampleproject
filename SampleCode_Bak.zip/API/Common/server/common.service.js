'use strict';
const jwtDecode = require('jwt-decode');
const uuid = require('uuidv4');
const commonRepository = require('./common.repository');
const LastAccessClientModel = require('./models/lastAccessClient.model');
const request = require('request');
const axios = require('axios');
const NodeCache = require("node-cache");
var btoa = require('btoa');
const Cache = new NodeCache({
  stdTTL: 1800,
  checkperiod: 340
});
const OneDay = 86400;
const _getLastAccessClient = () => {
  return new Promise(function (resolve, reject) {
    var res = commonRepository.getLastAccessClient();
    try {
      // Read #1, using SQL
      //resolve(commonRepository.getLastAccessClient());
      resolve(res);
      res.catch(err);
      //console.log('Successfully executed read-only transaction.');       

      // resolve(qOneRows);

    } catch (err) {

      return reject(err);

    }

  })
}

const _postLastAccessClient = (body) => {
  return new Promise(async function (resolve, reject) {
    let rows;
    let message;
    try {

      rows = await commonRepository.getLastAccessClient();
      if (rows.length > 0) {
        const rowJSON = JSON.parse(JSON.stringify(rows[0]));
        rowJSON.ContractCd = body.con;
        rowJSON.FinancialClientCd = body.fc
        rowJSON.MasterClientCd = body.mc
        rowJSON.UpdateDttm = new Date();
        rowJSON.UpdateUserId = process.env.ENTERPRISEID

        commonRepository.updateLastAccessClientLog(rowJSON);
        message = 'updated last access client log';
      } else {
        let model = new LastAccessClientModel(body.mc, body.fc, body.con);

        commonRepository.insertLastAccessClientLog(model);
        message = 'inserted updated last access client log';
      }

      resolve(message);
      message.catch(err);

    } catch (err) {
      return reject(err);
    }
  })

}

const _getMasterClientList = () => {
  return new Promise(function (resolve, reject) {
    var res = commonRepository.getMasterClientList();
    try {
      // Read #1, using SQL
      //resolve(commonRepository.getMasterClientList());   
      resolve(res);
      res.catch(err);
      // resolve(qOneRows);

    } catch (err) {

      //console.error('ERROR:', err);

      return reject(err);

    }

  })
}

const _getCustomerList = (selectedMCNbr) => {
  return new Promise(function (resolve, reject) {
    var res = commonRepository.getCustomerList(selectedMCNbr);
    try {
      // Read #1, using SQL
      resolve(res);
      res.catch(err);
      // resolve(qOneRows);

    } catch (err) {

      //console.error('ERROR:', err);

      return reject(err);

    }
  })
}

const _getContractList = (selectedFCNbr) => {
  return new Promise(function (resolve, reject) {
    var res = commonRepository.getContractList(selectedFCNbr);
    try {
      // Read #1, using SQL
      resolve(res);
      res.catch(err);
      // resolve(qOneRows);

    } catch (err) {

      //console.error('ERROR:', err);

      return reject(err);
    }

  })
}

const _getContractListByMClient = (selectedMCNbr) => {
  return new Promise(function (resolve, reject) {
    var res = commonRepository.getContractListByMClient(selectedMCNbr);
    try {
      // Read #1, using SQL
      resolve(res);
      res.catch(err);
      // resolve(qOneRows);

    } catch (err) {

      //console.error('ERROR:', err);

      return reject(err);
    }

  })
}

const _getURL = (description) => {
  return new Promise(function (resolve, reject) {
    var res = commonRepository.getURL(description);
    try {
      resolve(res);
      res.catch(err);
    } catch (err) {

      //console.error('ERROR:', err);

      return reject(err);

    }

  })
}

const _profile = async (email) => {
  let profile = [];
  const groups = await CommonService._getUserRoles(email.split('@')[0]);
  return groups;
}

const _user = async (token, eid) => {
  if (eid) {
    let tokendetail = await CommonService._getAADUserDetail(eid);
    return {
      EnterpriseId: tokendetail.userPrincipalName.split("@")[0],
      Details: {
        FirstName: tokendetail.givenName,
        LastName: tokendetail.surname,
        DisplayName: tokendetail.displayName,
        Email: tokendetail.userPrincipalName
      }
    }
  } else {
    let tokendetail = CommonService._getTokenDetail(token);
    return {
      EnterpriseId: tokendetail.upn.split("@")[0],
      Details: {
        DisplayName: tokendetail.name,
        FirstName: tokendetail.given_name,
        LastName: tokendetail.family_name,
        Email: tokendetail.upn
      }
    }
  }
}

const _userMRDRLocation = async (eid) => {
  let ADFSDetail = await CommonService._getMRDRUserDetail(eid);
  if (ADFSDetail) {
    return {
      EnterpriseId: ADFSDetail.EnterpriseId,
      Details: {
        DisplayName: ADFSDetail.displayName,
        FirstName: ADFSDetail.FirstName,
        MiddleInitial: ADFSDetail.MiddleInitial,
        LastName: ADFSDetail.LastName,
        Email: ADFSDetail.InternetMail,
        CountryNm: ADFSDetail.CountryName,
        CountryCd: ADFSDetail.CountryKey,
        GeographicUnitDesc: ADFSDetail.GeographicUnitDescription,
        GeographicUnitCd: ADFSDetail.GeographicUnitCode
      }
    }
  }
  return {
    EnterpriseId: eid,
    Details: {}
  }
}
const _userProfile = async (token, eid) => {
  let user = CommonService._user(token, eid);
  let profile = CommonService._profile(eid + '@' + process.env.MAILDOMAIN);
  let userProfile = await user;
  userProfile.AccessProfile = await profile;
  return userProfile;
}

const _getAADToken = () => {
  return new Promise(function (resolve, reject) {
    const options = {
      url: `https://login.microsoftonline.com/${process.env.TENANT}/oauth2/token`,
      headers: {
        'Content-Type': 'application/json'
      },
      form: {
        'client_id': process.env.AAD_CLIENT_ID,
        'client_secret': process.env.AAD_SECRET,
        'grant_type': 'client_credentials',
        'resource': 'https://graph.microsoft.com/',
        'scope': 'User.Read.All'
      },
      time: true
    };
    let AppToken = Cache.get("AAD_access_token");
    if (AppToken) {
      resolve(AppToken)
      return;
    }
    request.post(options, function (error, response, body) {
      if (response && response.statusCode != 201) {
        const token = JSON.parse(body).access_token;
        Cache.set("AAD_access_token", token);
        resolve(token);
      }
    });
  });
}

const _getADFSToken = (scope = 'read_mrdr_people') => {
  return new Promise(function (resolve, reject) {
    const options = {
      url: process.env.ADFS_LOGINURL,
      headers: {
        'Content-Type': 'application/json'
      },
      form: {
        'client_id': process.env.ADFS_CLIENT_ID,
        'client_secret': process.env.ADFS_SECRET,
        'grant_type': 'client_credentials',
        'scope': scope
      },
      time: true
    };
    let AppToken = Cache.get("ADFS_access_token");
    if (AppToken) {
      resolve(AppToken)
      return;
    }
    request.post(options, function (error, response, body) {
      if (response && response.statusCode != 201) {
        const token = JSON.parse(body).access_token;
        Cache.set("ADFS_access_token", token);
        resolve(token);
      }
    });
  });
}

const _userAADGroups = async (email) => {
  const token = await _getAADToken();
  return new Promise(function (resolve, reject) {
    const options = {
      url: `https://graph.microsoft.com/v1.0/users/${email}/transitiveMemberOf?$select=displayName&$format=application/json;odata=nometadata`,
      method: 'GET',
      headers: {
        'Content-Type': 'application/json;',
        'Authorization': "Bearer " + token
      }
    };
    console.log("_userAADGroups - options", options)
    let cachedgroups = Cache.get(email + '-Groups');
    if (cachedgroups) {
      resolve(cachedgroups);
    } else {
      request(options, function (error, response, body) {
        if (body) {
          let res = JSON.parse(body).value;
          if (res) {
            res = res.map(g => g.displayName)
            Cache.set(email + '-Groups', res);
            resolve(res);
          }
          else {
            resolve([]);
          }
        }
      });
    }
  });
}

const _getUserRoles = async (eid) => {
  return new Promise(async function (resolve, reject) {
    var res = await commonRepository.getUserRole(eid);
    if (res && res.length) {
      res = res.map(a => a.find(b => b.name == "PrimaryDecodeTxt").value);
    }
    resolve(res);
  });
}

// const _getTokenEID = (token) => {
//   let user = jwtDecode(token)
//   return user.upn.split("@")[0];
// }
const _getTokenDetail = (token) => {
  let user = jwtDecode(token)
  return user;
}
const _getAADUserDetail = async (eid) => {
  const domain = process.env.MAILDOMAIN;
  const Apptoken = await CommonService._getAADToken();
  let email = eid + '@' + domain;
  return new Promise(function (resolve, reject) {
    const options = {
      url: `https://graph.microsoft.com/v1.0/users/${email}/?$format=application/json;odata=nometadata`,
      headers: {
        'Content-Type': 'application/json;',
        'Authorization': "Bearer " + Apptoken
      },
    };
    let cacheduser = Cache.get(email + '-Detail');
    if (cacheduser) {
      resolve(cacheduser);
    } else {
      request.get(options, function (error, response, body) {
        if (body) {
          let res = JSON.parse(body);
          Cache.set(email + '-Detail', res, OneDay);
          resolve(res);
        }
      });
    }
  });
}

const _getMRDRUserDetail = async (eid) => {
  const Apptoken = await CommonService._getADFSToken();
  return new Promise(function (resolve, reject) {
    const options = {
      url: `${process.env.MRDR_PEOPLEURL}?$select=GeographicUnitCode,GeographicUnitDescription,CountryName,CountryKey,LastName,MiddleInitial,FirstName,EnterpriseId,PersonalDisplayName,InternetMail&$top=1&$filter=EnterpriseId eq '${eid}'`,
      headers: {
        'Content-Type': 'application/json;',
        'authorizationToken': "Bearer " + Apptoken,
        'x-api-key': process.env.MRDR_APIKEY
      },
    };
    let cacheduser = Cache.get(eid + '-MRDRPeople');
    if (cacheduser) {
      resolve(cacheduser);
    } else {
      request.get(options, function (error, response, body) {
        if (body) {
          let res = JSON.parse(body).value[0];
          Cache.set(eid + '-MRDRPeople', res, OneDay);
          resolve(res);
        }
      });
    }
  });
}

// const _getMRDRPeoplePicker = async (filter, count = 10) => {
//   const Apptoken = await _getADFSToken();
//   return new Promise(function (resolve, reject) {
//     const options = {
//       url: `${process.env.MRDR_PEOPLEURL}?$select=EnterpriseId&$top=${count}&$filter=startswith(EnterpriseId, '${filter}') eq true or startswith(PersonalDisplayName,'${filter}')  eq true`,
//       method: 'GET',
//       headers: {
//         'Content-Type': 'application/json;',
//         'authorizationToken': "Bearer " + Apptoken,
//         'x-api-key': process.env.MRDR_APIKEY
//       },
//       timeout: 1200000
//     };
//     let cacheduser = Cache.get(`${filter}-${count}-MRDRPeoplePicker`);
//     if (cacheduser) {
//       resolve(cacheduser);
//     } else {
//       request(options, function (error, response, body) {
//         if (body) {
//           let res = JSON.parse(body).value;
//           if (res.length > 0) {
//             res = res.map(r => r.EnterpriseId);
//           }
//           Cache.set(`${filter}-${count}-MRDRPeoplePicker`, res);
//           resolve(res);
//         }
//       });
//     }
//   });
// }

const _getAADPeoplePicker = async (filter, count = 10) => {
  const Apptoken = await CommonService._getAADToken();
  return new Promise(function (resolve, reject) {
    const options = {
      url: `https://graph.microsoft.com/v1.0/users?$top=${count}&$filter=startswith(mail,'${filter}') or startswith(userPrincipalName,'${filter}') or startswith(displayName, '${filter}')&$select=mail&$format=application/json;odata=nometadata`,
      headers: {
        'Content-Type': 'application/json;',
        'Authorization': "Bearer " + Apptoken
      },
    };
    let cacheduser = Cache.get(`${filter}-${count}-MRDRPeoplePicker`);
    if (cacheduser) {
      resolve(cacheduser);
    } else {
      request.get(options, function (error, response, body) {
        if (body) {

          let res = JSON.parse(body).value;
          if (res.length > 0) {
            res = res.map(r => {
              if (r && r.mail) {
                return r.mail.split("@")[0];
              }
            });
          }
          res = res.filter(function (el) {
            return el != null;
          });
          Cache.set(`${filter}-${count}-MRDRPeoplePicker`, res);
          resolve(res);
        }
      });
    }
  });
}

const _getPeopleImage = (eid) => {
  if (!eid) {
    eid = process.env.ENTERPRISEID
  }
  let key = `getPeopleImage_${eid}`;
  return new Promise(async function (resolve, reject) {
    let value = Cache.get(key);
    if (value) {
      resolve(value);
    }
    else {
      let token = await CommonService._getADFSToken('read_profilepicture read_search read_stream write_stream')      
      const options = {
        url: process.env.PEOPLE_PICTURE_URL + eid,
        headers: {
          'Authorization': `Bearer ${token}`
        },
        encoding: null
      }
      request.get(options, function (error, response, body) {                
        if (response && response.statusCode != 200) {
          let img = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAACWCAIAAACzY+a1AAAABGdBTUEAALGPC/xhBQAAAAlwSFlzAAAOwgAADsIBFShKgAAAABh0RVh0U29mdHdhcmUAcGFpbnQubmV0IDQuMS41ZEdYUgAABn5JREFUeF7tnaFy4zAQhu9VD5WFhoWahoaGB/cBws1DCsMzhZ1O75/zTidTN7Jky/vvKvuBm+tdakv6vNJKsp0/X4FzQqF7QqF7QqF7QqF7QqF7QqF7QqF7QqF7QqF7QqF7QqF7QqF7QqF7QqF7WlN4u936/5xOp+Md+HH4d3xAPtoKLSiEGEja7XYvLy9/M8DH8GH8Cn5RDuEZxwpfX1+7rhMtC8BBcCg5qEP8Kbxer4fDITPg8sEBcVgcXE7jB08K0b77/V6afDVwCl8ifShEDoIQkTZWAafzkvg4UHg+n6t3mzngpDi1FMIwphUiDqokLEtAAYyHo12Fl8tls9lIQ1JBMVAYKZY9jCpkdZ6PsNypWlSIWZq0nDFsTh/NKTTrb8CgRVsKjfsbsGbRkMK+76WRzGMqu7Gi8Hq9mspf0qCodlZwrCjcbrfSPE5AgaXobEwoPB6P0jCuQLGlAlT4Ch0NgWMsDIp8he660HssdKdkhS5mEWnocwymwtvt5igLfQSqwF0HZyo8nU7SDM5BRaRKDJgKjWxELAcVkSoxoClsYBS8hzgi0hTS93LrgupIxdThKMT4L1VvCFZSw1HYWC86wOpLOQob60UHWH0pR2ED08ExqJRUTxeCwsvlIpVuDsqSKUFhMzP6MZQ5PkGh8n3ZmqBqUklFCAp3u53UuDlQNamkIgSFrneX0lD2nggKpbqNIpVUJBRWRiqpSCisjFRSkVBYGamkIqGwMlJJRUJhZaSSioTCykglFSEobOZ+izGUOzAICmN1pi4EhQovHmHxLGuksVNRF4JC1w9RpKG81I2gEEiNm0OqpwtHYZMZDSWXARyFTQ6HlIEQcBRer1epd0OwHt3mKASNbfwSHzSkKYxnKmpBU/j+/t7M3aTcRwxpCoHTtySM4b43gabw8/OzjUDkhiBgRiFoIBDpry5hKhwC0fXeEwrPDUFAjkJwPp+lPRxi4SWlZIUIRPzp9Fk14pO99/CjEHjsTi10oQMmFAJ3T6zZeZ+lCYVDd+povYa4FjPGShQOuJhj0GcRP7ClEBi/swbFk4KawZxCYNaiQX/AokJgcFw0Nf7dY1QhsPNtIyiG2e8ZAXYVgre3N/rOMApg/LvwTCscIKap1pLPXzGt8OPjY/gL5tHKN73hdHYm72kcROE3fd8rrMPhFJQ7emfjSeEA2neliMRhfckb8KdwACnG4XCoEpQ4CA5lPGdJ4FXhNxixTqdT13VFMxB8GL+CX/Qy4CVwr/Ce2+2GnhBzcGSSALGFvhHgL8O/4L/wASObRLVoSuFzYk4hQgThgvFpv9+bCheEL7pfxLS1lRpDCpFQ/FjgtpPf46qSMv0HBbOzZGpC4VjePRjJiOGIa+jRIp8RkWSFQ7cpTfIYSmOlL6xvUDZu18pUCCtFMwE1kcOFVVQ2jJGsmSVH4ZI1T4jEfG6lrhUFy4m8R0C8HEgRgsKcnjMHtDV6sCouEUC4LKpsbOEgyssFqgrRUmvs/yGgcVmU5q4oDK6AWqt0P9AMRz2FaK+i0WUe8HG/HANwXoyg8sPx2HXd7D68CJxFJ5FWUog2lZo9E7hkFea1qyvElahz1Ztl7Sx6XYUY2NcY/NyBzEtaZAVWVAh/CoOfF9azuJbC8DcGHdIaCc4qCsPfI9awWF9h+EtT3WJlheEvh7qPB9dUGP7yqZjdVFOIziHmD0UcKy3CVVMY/mZQZdZfR+GSDZpnBuMORh9pxLlUUIhLSUoUlLNZ/OaMpQojhVnOwgR1qcIYAquw5KXQixQip5IiBMtATzb71pv5CtGFyvmDGuzmvmB/vsLoQqszb44xUyH6bjltUA90pzOy0zkKcZrIQlfiUP7FXXMUPueNMGqU5jXFCnECOVWwDqV5TbHCWEtToOi+tzKFEYI6FAVimcIIQTXyA7FAYYSgJvl7wgUKYzlNmczUtEBhzAWVydzWz1UYm4L6bPK+JT9XYefzqyS8k/MIeJbCSGRY5CQ1WQpjUZvI5MJ3lsLYVyIyuQM1rRBXgRwsYDDZl04rjFyUC+ZyYuIB0wpjUY1O+l7TaYVrvBAiKCI9x59QGNMJC6Q3LiYUxkBogfRwOKEw7rEwQmI4nFD45O8bsUNipW1CoRwgYJPIaFIKI5exQyKjSSns+14OELDZbrdiZURKYaxum0KsjEgpjDstTCFWRqQUxozCFI/uaUspjBmFKUKhe0Khe35/mPvr6x8bWrLAOoMBjgAAAABJRU5ErkJggg==";
          resolve(img);
        }
        if (body) {      
          var bytes = new Uint8Array(body);    
          let uri = 'data:image/png;base64,'+encode(bytes);                
          resolve(uri);
        }
      });
    }
  });
}

// public method for encoding an Uint8Array to base64
function encode (input) {
  var keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
  var output = "";
  var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
  var i = 0;

  while (i < input.length) {
      chr1 = input[i++];
      chr2 = i < input.length ? input[i++] : Number.NaN; // Not sure if the index 
      chr3 = i < input.length ? input[i++] : Number.NaN; // checks are needed here

      enc1 = chr1 >> 2;
      enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
      enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
      enc4 = chr3 & 63;

      if (isNaN(chr2)) {
          enc3 = enc4 = 64;
      } else if (isNaN(chr3)) {
          enc4 = 64;
      }
      output += keyStr.charAt(enc1) + keyStr.charAt(enc2) +
                keyStr.charAt(enc3) + keyStr.charAt(enc4);
  }
  return output;
}

// const _userDBGroups = (eid) => {
//   if (!eid) {
//     eid = process.env.ENTERPRISEID
//   }
//   return new Promise(function (resolve, reject) {
//     var res = commonRepository.getUserRole(eid);
//     try {
//       resolve(res);
//     } catch (err) {
//       return reject(err);
//     }
//   })
// }

const _getMMCLinkItems = (linkCategory) => {
  return new Promise(function (resolve, reject) {
    var res = commonRepository.getMMCLinkItems(linkCategory);
    try {
      resolve(res);
      res.catch(err);
    } catch (err) {
      return reject(err);
    }
  })
}

//this function will return all features with Enabled set to FALSE. If feature is not included in the return by default it's enabled
const _getDisabledFeatures = (featureGroup) => {
  return new Promise(async function (resolve, reject) {
    let filter =  `GroupName = '${featureGroup}' AND Enabled = false AND RoleName IS NULL`;
    let result;
    /*
    
    //if there is a role to be included then logic below will be used
    if (role) {
      //query all features with Enabled equal to FALSE and with (RoleName equal to role passed or RoleName is empty)
      //also include in the query all features with Enabled equal to TRUE and RoleName equal to role passed.
      //results are ordered by Enabled status (FALSE first then TRUE) to ensure that all FALSE will be processed first
      //before TRUE
      filter = `${filter} AND ( (Enabled = false AND (RoleName = '${role}' OR RoleName IS NULL)) OR (Enabled = true 
      AND RoleName = '${role}') )`
    }
    else {
      //query all features with Enable equal to FALSE and RoleName is null.
      filter = `${filter} AND Enabled = false AND RoleName IS NULL`;
    }
    */
    try {
      let res = await commonRepository.getDisabledFeatures(filter);  
      if (!res) {
        result = null;
      } 
      else {
        result = [];
        res = JSON.parse(JSON.stringify(res));
        //results are ordered by Enabled status. FALSE first then TRUE.
        res.forEach(row => {
          //push to array all features with Enabled equal to FALSE
          if(!row.Enabled) {
            result.push({FeatureName: row.FeatureName, Enabled: row.Enabled});
          }
          else {
            //if there are features with Enabled equal to TRUE (all have role values. see query above), remove it from the list
            //of disabled features (array). This will override the feature's root Enabled setting/
            result = result.filter(r => r.FeatureName.toLowerCase() !== row.FeatureName.toLowerCase());
          }
        });
        //if none left after adding and removing, reset result to null
        if(result.length === 0){
          result = null;
        }
      }
      console.log('_getDisabledFeatures', result)
      resolve(result);
    } catch (err) {
      console.log('_getDisabledFeatures', err);
      return reject(err);
    }
  })
}

// const _getPeopleImageThumbnail = (peopleKey,eid) => {

//   if (!eid) {
//     eid = process.env.ENTERPRISEID
//   }
//   let key = `getPeopleImageThumbnail_${peopleKey}`;
//   let value = Cache.get(key);
//   if (value == undefined) {
//     // key not found
//     return new Promise(function (resolve, reject) {
//       axios.get("http://thumbnail.accenture.com/" + peopleKey + ".jpg", {
//       responseType: 'arraybuffer'
//       })
//        .then(response => {
//           Cache.set(key, response.data, OneDay);
//          resolve(response.data);
//        })
//        .catch(error1 => {
//           resolve(_getPeopleImage(eid));
//         });

//     });
//   } else {
//     return Promise.resolve(value);
//   }
// }

let CommonService = {
  _getLastAccessClient,
  _postLastAccessClient,
  _getMasterClientList,
  _getCustomerList,
  _getContractList,
  _getContractListByMClient,
  _getURL,
  // _userAADGroups,
  // _userDBGroups,
  _getAADToken,
  _getADFSToken,
  // _getTokenEID,
  _user,
  _userProfile,
  _getPeopleImage,
  _getUserRoles,
  // _getMRDRPeoplePicker,
  _getAADPeoplePicker,
  _userMRDRLocation,
  _getMMCLinkItems,
  _getAADUserDetail,
  _getTokenDetail,
  _profile,
  _getMRDRUserDetail,
  _getDisabledFeatures
  // _getPeopleImageThumbnail
}

module.exports = CommonService;
