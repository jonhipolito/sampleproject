'use strict';

const SpannerDB = require('../configs/db.connection');


const getLastAccessClient = async () => {

  let database = new CommonRepository.SpannerDB();

  const queryOne = {
    sql: `SELECT * FROM LastAccessClientLog WHERE UserNm = '${process.env.ENTERPRISEID}' LIMIT 1`
  };

  try {
    // Read #1, using SQL
    const [qOneRows] = await database.run(queryOne);

    //console.log('Successfully executed read-only transaction.');
    return qOneRows;

  } catch (err) {

    //console.error('ERROR:', err);        

  } finally {
    // Close the database when finished.
    await database.close();
  }
}
const updateLastAccessClientLog = async (model) => {
  let database = new CommonRepository.SpannerDB();
  const LastAccessClientLogTable = database.table('LastAccessClientLog');

  try {

    let commitTimestamp = await LastAccessClientLogTable.update(model);
    return commitTimestamp[0];
  } catch (err) {
    return new Error(err);
  } finally {
    // Close the database when finished.
    await database.close();
  }
}
const insertLastAccessClientLog = async (model) => {
  let database = new CommonRepository.SpannerDB();
  const LastAccessClientLogTable = database.table('LastAccessClientLog');

  try {

    let commitTimestamp = await LastAccessClientLogTable.insert(model);
    return commitTimestamp[0];

  } catch (err) {
    return new Error(err);
  } finally {
    // Close the database when finished.
    await database.close();
  }
}
const getMasterClientList = async () => {

  let database = new CommonRepository.SpannerDB();

  const queryOne = {
    sql: `SELECT mc.MasterClientNbr, CONCAT(mc.MasterClientNm, ' - ', mc.MasterClientNbr) AS MasterClientNm
    , CAST(sec.IsGlobalCM = 'Y' AS STRING) AS IsGlobalCM
    FROM MMCSecurityData  sec
    INNER JOIN MasterClient mc
    ON sec.MasterClientNbr = mc.MasterClientNbr
    WHERE RTRIM(sec.EnterpriseId) = '${process.env.ENTERPRISEID}'
    GROUP BY mc.MasterClientNbr, mc.MasterClientNm, sec.IsGlobalCM
    ORDER BY mc.MasterClientNm`
  };

  

  try {
    // Read #1, using SQL
    const [qOneRows] = await database.run(queryOne);

    //console.log('Successfully executed read-only transaction.');        
    return qOneRows;

  } catch (err) {

    //console.error('ERROR:', err);

    //return reject(err);

  } finally {
    // Close the database when finished.
    await database.close();
  }
}
const getCustomerList = async (selectedMCNbr) => {
  let database = new CommonRepository.SpannerDB();



  //get selected Master Client Nbr
  const queryOne = {
    sql: `SELECT CustomerNbr, CONCAT(CustomerNm, ' - ', CustomerNbr) AS CustomerNm FROM Customer WHERE MasterClientNbr = '` + selectedMCNbr + `' ORDER BY LOWER(CustomerNm) ASC`
  };

  try {
    // Read #1, using SQL
    const [qOneRows] = await database.run(queryOne);

    //console.log('Successfully executed read-only transaction.');
    return qOneRows;

  } catch (err) {

    //console.error('ERROR:', err);        

  } finally {
    // Close the database when finished.
    await database.close();
  }

}
const getContractList = async (selectedFCNbr) => {
  let database = new CommonRepository.SpannerDB();

  //get selected CustomerNbr
  //var selectedFCNbr = '223';
  const query = {
    sql: `SELECT ContractNbr, CONCAT(ContractNm, ' - ', ContractNbr) AS ContractNm, CustomerNbr FROM Contract WHERE CustomerNbr = '` + selectedFCNbr + `' ORDER BY LOWER(ContractNm) ASC`,
  };
  try {
    // Read #1, using SQL
    const [qOneRows] = await database.run(query);

    //console.log('Successfully executed read-only transaction.');        
    return qOneRows;
  } catch (err) {

    // console.error('ERROR:', err);        

  } finally {
    // Close the database when finished.
    await database.close();
  }
}
const getContractListByMClient = async (selectedMCNbr) => {
  let database = new CommonRepository.SpannerDB();

  const query = {
    //sql: `SELECT ContractNbr, CONCAT(ContractNm, ' - ', ContractNbr) AS ContractNm, CustomerNbr, CustomerNm FROM Contract INNER JOIN Customer FC USING(CustomerNbr) WHERE MasterClientNbr = '` + selectedMCNbr + `' ORDER BY LOWER(ContractNm) ASC`,
    sql: `SELECT ContractNbr, CONCAT(ContractNm, ' - ', ContractNbr) AS ContractNm, CustomerNbr FROM Contract 
    WHERE CustomerNbr IN (SELECT CustomerNbr FROM Customer AS cus WHERE MasterClientNbr = '` + selectedMCNbr + `') ORDER BY LOWER(ContractNm) ASC`,
  };
  try {
    // Read #1, using SQL
    const [qOneRows] = await database.run(query);

    //console.log('Successfully executed read-only transaction.');        
    return qOneRows;
  } catch (err) {

    // console.error('ERROR:', err);        

  } finally {
    // Close the database when finished.
    await database.close();
  }
}
const getURL = async (description) => {
  let database = new CommonRepository.SpannerDB();

  const query = {
    sql: `SELECT URL FROM MMCLink WHERE LinkDescription = '${description}'`
  };

  try {

    const [result] = await database.run(query);

    return result;

  } catch (err) {

    // console.error('ERROR:', err); 
    //return new Error(err);


  } finally {
    await database.close();
  }

}

const getUserRole = async (EnterpriseId) => {
  let database = new CommonRepository.SpannerDB();
  const query = {
    sql: `SELECT PrimaryDecodeTxt 
          FROM UserRole UR 
          INNER JOIN CodeDetail CD 
          ON CD.CodeTxt = UR.UserRoleCd
          WHERE EnterpriseID = '${EnterpriseId}'`,
  };
  try {
    const [rows] = await database.run(query);
    return rows;
  } catch (err) {
    // console.error('ERROR:', err);
  } finally {
    await database.close();
  }
}

const getMMCLinkItems = async (linkCategory) => {
  const database = new CommonRepository.SpannerDB();

  const mmcLinkItemsquery = `SELECT LinkDescription
                                  ,URL
                                FROM MMCLink
                                WHERE LinkCategory = '${linkCategory}'
                                ORDER BY LinkOrderNbr`;

  try {
    let [mmcLinkItemsRows] = await database.run(mmcLinkItemsquery);
    return mmcLinkItemsRows;
  } catch (err) {
    // return new Error(err);
  } finally {
    // Close the database when finished.
    await database.close();
  }
}

const getDisabledFeatures = async (filter) => {
    const database = new CommonRepository.SpannerDB();
    const query = {
        sql: `SELECT DISTINCT FeatureName, Enabled FROM FeatureManagement WHERE ${filter} ORDER BY Enabled`

    }
    console.log('SQL', query);
    try {
        const [qRows] = await database.run(query);
        return qRows;
    } catch (err) {
    } finally {
        await database.close();
    }
};

const CommonRepository = {
  getLastAccessClient,
  updateLastAccessClientLog,
  insertLastAccessClientLog,
  getMasterClientList,
  getCustomerList,
  getContractList,
  getContractListByMClient,
  getURL,
  getUserRole,
  getMMCLinkItems,
  getDisabledFeatures,
  SpannerDB
}
module.exports = CommonRepository

