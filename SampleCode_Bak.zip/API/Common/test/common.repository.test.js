process.env.NODE_ENV = 'test';
const uuid = require('uuidv4');
const commonRepository = require('../server/common.repository');
const sinon = require('sinon');
const chai = require('chai');
const should = chai.should();
const expect = require('chai').expect;
require('dotenv').config(); // Loads .env (for local)    
const sandbox = require('sinon').createSandbox();
const SpannerDB = require('../configs/db.connection');

class SpannerMock {
    SpannerMock(){}
    run() {
        return Promise.resolve([{Column1: "Sample DB Return"}]);
    }
    table() {
        return {
            update() {
                return Promise.resolve([{commitTimestamp: new Date()}]);
            },
            insert() {
                return Promise.resolve([{commitTimestamp: new Date()}]);
            }
        };
    }
    close() {}
}
class SpannerErrorMock {
    SpannerErrorMock(){}
    run() {
        throw Error("Database not found");
    }

    table() {
        return {
            update() {
                throw Error("Database not found");
            },
            insert() {
                throw Error("Database not found");
            }
        };
    }
    close() {}
}
describe('Testing Common Repository', () => {

    describe('getLastAccessClient', () => {
        describe('getLastAccessClient - success', () => {
            before(() => {                                
                sandbox.stub(commonRepository, 'SpannerDB').value(SpannerMock);
            });
    
            after(() => {
                sandbox.restore();
            });

            it("should return Last Access Client json", async function () {                
                var res = await commonRepository.getLastAccessClient();
                try {
                    assert(res);
                } catch (err) {
                    // console.log(err);
                }
            });
        });

        describe('getLastAccessClient - error', () => {
            before(() => {                                
                sandbox.stub(commonRepository, 'SpannerDB').value(SpannerErrorMock);
            });
    
            after(() => {
                sandbox.restore();
            });

            it("should throw an error", async function () {
                try {
                    await commonRepository.getLastAccessClient();                    
                } catch (err) {
                    expect(err).to.have.string('Database not found');
                }
            });
        });
     });

    describe('updateLastAccessClientLog success', () => {
        before(() => {                                
            sandbox.stub(commonRepository, 'SpannerDB').value(SpannerMock);            
        });

        after(() => {
            sandbox.restore();            
        });
        it("should update last access client json", async function () {
            var obj = [{ LastAccessClientLogKey:"51e0485c-be8a-443d-879c-e52aef2630dd",
            ContractCd:"0594849599", CreateDttm:"2019-04-17T09:42:03.085000000Z",
            CreateUserId:"emmanuel.p.teofisto", FinancialClientCd:"CSP1",
            MasterClientCd:"JP00001", UpdateDttm:"2019-04-17T09:42:03.085000000Z",
            UpdateUserId:"emmanuel.p.teofisto",UserNm:"emmanuel.p.teofisto" }];

            var result = await commonRepository.updateLastAccessClientLog(obj);

            result.should.have.property('commitTimestamp');
            result.should.be.an('object');
        });

    });
    describe('insertLastAccessClientLog Error', () => {
        before(() => {                                
            sandbox.stub(commonRepository, 'SpannerDB').value(SpannerErrorMock);
        });

        after(() => {
            sandbox.restore();
        });
        it("should insert last access client json", async function () {
            var obj = [{ LastAccessClientLogKey:"51e0485c-be8a-443d-879c-e52aef2630dd",
            ContractCd:"0594849599", CreateDttm:"2019-04-17T09:42:03.085000000Z",
            CreateUserId:"emmanuel.p.teofisto", FinancialClientCd:"CSP1",
            MasterClientCd:"JP00001", UpdateDttm:"2019-04-17T09:42:03.085000000Z",
            UpdateUserId:"emmanuel.p.teofisto",UserNm:"emmanuel.p.teofisto" }];

            commonRepository.updateLastAccessClientLog(obj).catch((error) => {
                error.should.be.an('object');
            });
        });
    });    

    describe('insertLastAccessClientLog success', () => {
        before(() => {                                
            sandbox.stub(commonRepository, 'SpannerDB').value(SpannerMock);
        });

        after(() => {
            sandbox.restore();
        });
        it("should insert last access client json", async function () {
            var obj = [{ LastAccessClientLogKey: uuid(),
            ContractCd:"0594849599", CreateDttm:"2019-04-17T09:42:03.085000000Z",
            CreateUserId:process.env.ENTERPRISEID, FinancialClientCd:"CSP1",
            MasterClientCd:"JP00001", UpdateDttm:"2019-04-17T09:42:03.085000000Z",
            UpdateUserId:process.env.ENTERPRISEID ,UserNm: process.env.ENTERPRISEID }];

            var result = await commonRepository.insertLastAccessClientLog(obj);

            result.should.have.property('commitTimestamp');
            result.should.be.an('object');


        });

    });

    describe('insertLastAccessClientLog Error', () => {
        before(() => {                                
            sandbox.stub(commonRepository, 'SpannerDB').value(SpannerErrorMock);
        });

        after(() => {
            sandbox.restore();
        });
        it("should insert last access client json", async function () {
            var obj = [{ LastAccessClientLogKey: uuid(),
            ContractCd:"0594849599", CreateDttm:"2019-04-17T09:42:03.085000000Z",
            CreateUserId:process.env.ENTERPRISEID, FinancialClientCd:"CSP1",
            MasterClientCd:"JP00001", UpdateDttm:"2019-04-17T09:42:03.085000000Z",
            UpdateUserId:process.env.ENTERPRISEID ,UserNm: process.env.ENTERPRISEID }];

            commonRepository.insertLastAccessClientLog(obj).catch((error) => {
                error.should.be.an('object');
            });
        });
    });    
    describe('getMasterClientList', () => {
        describe('getMasterClientList - success', () => {
            before(() => {                                
                sandbox.stub(commonRepository, 'SpannerDB').value(SpannerMock);
            });
    
            after(() => {
                sandbox.restore();
            });
            it("should return Master Client List json", async function () {
                var res = await commonRepository.getMasterClientList();

                try {
                    assert(res);
                } catch (err) {
                    // console.log(err);
                }
            });

            it('should return the length of Master Client List not zero', async function () {
                var res = await commonRepository.getMasterClientList();

                try{
                    assert.notEqual(res.length, 0);
                } catch(err) {
                    // console.log(err);
                }
            });
        });

        describe('getMasterClientList - error', () => {
            before(() => {                                
                sandbox.stub(commonRepository, 'SpannerDB').value(SpannerErrorMock);
            });
    
            after(() => {
                sandbox.restore();
            });

            it("should throw an error", async function () {
                try {
                    await commonRepository.getMasterClientList();
                } catch (err) {
                    expect(err).to.have.string('Database not found');
                }
            });
        });
    });

    describe('getCustomerList', () => {
        describe('getCustomerList - success', () => {
            before(() => {                                
                sandbox.stub(commonRepository, 'SpannerDB').value(SpannerMock);
            });
    
            after(() => {
                sandbox.restore();
            });
            it("should return Customer List json", async function () {
                let selectedMCNbr = '1800002';
                var res = await commonRepository.getCustomerList(selectedMCNbr);

                try {
                    assert(res);
                } catch (err) {
                    // console.log(err);
                }
            });

            it('should return the length of Customer List not zero', async function () {
                let selectedMCNbr = '1800002';
                var res = await commonRepository.getCustomerList(selectedMCNbr);

                try{
                    assert.notEqual(res.length, 0);
                } catch(err) {
                    // console.log(err);
                }
            });
        });

        describe('getCustomerList - error', () => {
            before(() => {                                
                sandbox.stub(commonRepository, 'SpannerDB').value(SpannerErrorMock);
            });
    
            after(() => {
                sandbox.restore();
            });

            it("should throw an error", async function () {
                let selectedMCNbr = '1800002';
                try {
                    await commonRepository.getCustomerList(selectedMCNbr);
                } catch (err) {
                    expect(err).to.have.string('Database not found');
                }
            });
        });
    });

    describe('getContractList', () => {
        describe('getContractList - success', () => {
            before(() => {                                
                sandbox.stub(commonRepository, 'SpannerDB').value(SpannerMock);
            });
    
            after(() => {
                sandbox.restore();
            });
            it("should return Contract List json", async function () {
                let selectedFCNbr = 'CSP7';
                var res = await commonRepository.getContractList(selectedFCNbr);

                try {
                    assert(res);
                } catch (err) {
                    // console.log(err);
                }
            });

            it('should return the length of Contract List not zero', async function () {
                let selectedFCNbr = 'CSP7';
                var res = await commonRepository.getContractList(selectedFCNbr);

                try{
                    assert.notEqual(res.length, 0);
                } catch(err) {
                    // console.log(err);
                }
            });
        });

        describe('getContractList - error', () => {
            before(() => {                                
                sandbox.stub(commonRepository, 'SpannerDB').value(SpannerErrorMock);
            });
    
            after(() => {
                sandbox.restore();
            });

            it("should throw an error", async function () {
                let selectedFCNbr = 'CSP7';
                try {
                    await commonRepository.getContractList(selectedFCNbr);
                } catch (err) {
                    expect(err).to.have.string('Database not found');
                }
            });
        });
    });

    describe('getContractListByMClient', () => {
        describe('getContractListByMClient - success', () => {
            before(() => {                                
                sandbox.stub(commonRepository, 'SpannerDB').value(SpannerMock);
            });
    
            after(() => {
                sandbox.restore();
            });
            it("should return Contract List by MC json", async function () {
                let mc = '1800002';
                var res = await commonRepository.getContractListByMClient(mc);

                // res.should.not.equal(null);
                try{
                    assert(res);
                } catch(err) {
                    // console.log(err);
                }
            });

            it('should return the length of Contract List by MC not zero', async function () {
                let mc = '1800002';
                var res = await commonRepository.getContractListByMClient(mc);

                try{
                    assert.notEqual(res.length, 0);
                } catch(err) {
                    // console.log(err);
                }
            });
        });

        describe('getContractListByMClient - error', () => {
            before(() => {                                
                sandbox.stub(commonRepository, 'SpannerDB').value(SpannerErrorMock);
            });
    
            after(() => {
                sandbox.restore();
            });

            it("should throw an error", async function () {
                let mc = '1800002';
                try {
                    await commonRepository.getContractListByMClient(mc);
                } catch (err) {
                    expect(err).to.have.string('Database not found');
                }
            });
        });
    });

    describe('getURL', () => {
        describe('getURL - success', () => {
            before(() => {                                
                sandbox.stub(commonRepository, 'SpannerDB').value(SpannerMock);
            });
    
            after(() => {
                sandbox.restore();
            });
            it("should return URL json", async function () {
                let description = 'Onboarding';
                var res = await commonRepository.getURL(description);
                try {
                    assert(res);
                } catch (err) {
                    // console.log(err);
                }
            });
        });

        describe('getURL - error', () => {
            before(() => {                                
                sandbox.stub(commonRepository, 'SpannerDB').value(SpannerErrorMock);
            });
    
            after(() => {
                sandbox.restore();
            });

            it("should throw an error", async function () {
                let description = 'Onboarding';
                try {
                    await commonRepository.getURL(description);
                } catch (err) {
                    expect(err).to.have.string('Database not found');
                }
            });
        });
    });

    describe('getUserRole', () => {
        describe('getUserRole - success', () => {
            before(() => {                                
                sandbox.stub(commonRepository, 'SpannerDB').value(SpannerMock);
            });
    
            after(() => {
                sandbox.restore();
            });

            it("should return user roles json", async function () {
                let eid = 'revo.b.espinosa';
                var res = await commonRepository.getUserRole(eid);

                try{
                    assert(res);
                } catch(err) {
                    // console.log(err);
                }
            });

            it('should return the length of user roles list not zero', async function () {
                let eid = 'revo.b.espinosa';
                var res = await commonRepository.getUserRole(eid);

                try{
                    assert.notEqual(res.length, 0);
                } catch(err) {
                    // console.log(err);
                }
            });
        });

        describe('getUserRole - error', () => {
            before(() => {                                
                sandbox.stub(commonRepository, 'SpannerDB').value(SpannerErrorMock);
            });
    
            after(() => {
                sandbox.restore();
            });

            it("should throw an error", async function () {
                let eid = 'revo.b.espinosa';
                try {
                    await commonRepository.getUserRole(eid);
                } catch (err) {
                    expect(err).to.have.string('Database not found');
                }
            });
        });
    });
    
    describe('getMMCLinkItems', () => {
        describe('getMMCLinkItems - success', () => {
            before(() => {                                
                sandbox.stub(commonRepository, 'SpannerDB').value(SpannerMock);
            });
    
            after(() => {
                sandbox.restore();
            });
            it('should return MMC link items as json', async function () {
                let linkCategory = 'AppFinderItems';

                var result = await commonRepository.getMMCLinkItems(linkCategory);
                
                try{
                    assert(result);
                } catch(err) {
                    // console.log(err);
                }
            });
            
            it('should return the length of MMC link items not zero', async function () {
                let linkCategory = 'AppFinderItems';

                var result = await commonRepository.getMMCLinkItems(linkCategory);

                try{
                    assert.notEqual(result.length, 0);
                } catch(err) {
                    // console.log(err);
                }
            });
        });

        describe('getMMCLinkItems - error', () => {
            before(() => {                                                
                sandbox.stub(commonRepository, 'SpannerDB').value(SpannerErrorMock);
            });
    
            after(() => {
                sandbox.restore();
            });

            it("should throw an error", async function () {
                let linkCategory = 'AppFinderItems';                
                try {
                    await commonRepository.getMMCLinkItems(linkCategory);
                } catch (err) {
                    expect(err).to.have.string('Database not found');
                }
            });
        });
    });

    describe('getDisabledFeatures', () => {
        describe('getDisabledFeatures - success', () => {
            before(() => {                                
                sandbox.stub(commonRepository, 'SpannerDB').value(SpannerMock);
            });
    
            after(() => {
                sandbox.restore();
            });

            it("should return Last Access Client json", async function () {                
                var res = await commonRepository.getDisabledFeatures(`GroupName = 'HealthScore' AND Enabled = false'`);
                try {
                    assert(res);
                } catch (err) {
                    // console.log(err);
                }
            });
        });

        describe('getDisabledFeatures - error', () => {
            before(() => {                                
                sandbox.stub(commonRepository, 'SpannerDB').value(SpannerErrorMock);
            });
    
            after(() => {
                sandbox.restore();
            });

            it("should throw an error", async function () {
                try {
                    await commonRepository.getDisabledFeatures(`GroupName = 'HealthScore' AND Enabled = false'`);
                } catch (err) {
                    expect(err).to.have.string('Database not found');
                }
            });
        });
     });
});