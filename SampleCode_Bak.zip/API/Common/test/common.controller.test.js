process.env.NODE_ENV = 'test';
const commonController = require('../server/common.controller');
const commonService = require('../server/common.service');
const sinon = require('sinon');
const chai = require('chai');
const should = chai.should();
const expect = require('chai').expect;
const assert = require('chai').assert;


describe('Testing Common Controller', () => {
    var res = {
        writeHead: () => res,
        end: () => res,
        send: () => res,
        next: () => res,
        status: () => res
    };
    var req = new Object();
    describe('Get Last Access Test Success', () => {
        var mySpy;
        before(() => {
            sinon.stub(commonService, '_getLastAccessClient').returns(new Promise((resolve, reject) => {
                resolve('get success');
            }));
            mySpy = sinon.spy(res, 'send');
        })

        after(() => {
            commonService._getLastAccessClient.restore();
            mySpy.restore();
        })

        it("should send a message after get last access", async function () {
            await commonController.getLastAccessClient(req, res, {});
            expect(mySpy.called).is.true;
        });

    });

    describe('Get Last Access Test Error', () => {
        var mySpy;
        before(() => {
            sinon.stub(commonService, '_getLastAccessClient').returns(new Promise(function (resolve, reject) {
                throw new Error('Fake Service Error');
            }));
            mySpy = sinon.spy(res, 'send');
        })

        after(() => {
            commonService._getLastAccessClient.restore();
            mySpy.restore();
        })

        it("should return an error", async function () {
            try {
                return await commonController.getLastAccessClient(req, res, {});
            }
            catch (err) {
                return expect(mySpy.called).is.true;
            }


        });

    });


    describe('Post Last Access Test Success', () => {
        var mySpy
        before(() => {
            sinon.stub(commonService, '_postLastAccessClient').returns(new Promise((resolve, reject) => {
                resolve('insert success');
            }));
            mySpy = sinon.spy(res, 'send');
        })

        after(() => {
            commonService._postLastAccessClient.restore();
            mySpy.restore();
        })

        it("should send a message after insert last access", async function () {
            await commonController.postLastAccessClient(req, res, {});
            expect(mySpy.called).is.true
        });

    });


    describe('Post Last Access Test Error', () => {
        var mySpy;
        before(() => {
            sinon.stub(commonService, '_postLastAccessClient').returns(new Promise(function (resolve, reject) {
                throw new Error('Fake Service Error');
            }));
            mySpy = sinon.spy(res, 'send');
        })

        after(() => {
            commonService._postLastAccessClient.restore();
            mySpy.restore();
        })

        it("should return an error", async function () {
            try {
                return await commonController.postLastAccessClient(req, res, {});
            }
            catch (err) {
                return expect(mySpy.called).is.true;
            }
        });

    });


    describe('Get MasterClientList Test Success', () => {
        var mySpy;
        before(() => {
            sinon.stub(commonService, '_getMasterClientList').returns(new Promise((resolve, reject) => {
                resolve('get success');
            }));
            mySpy = sinon.spy(res, 'send');
        })

        after(() => {
            commonService._getMasterClientList.restore();
            mySpy.restore();
        })

        it("should send a message after get Master Client List", async function () {

            await commonController.getMasterClientList(req, res, {});
            expect(mySpy.called).is.true

        });

    });


    describe('Get MasterClientList Test Error', () => {
        var mySpy;
        before(() => {
            sinon.stub(commonService, '_getMasterClientList').returns(new Promise(function (resolve, reject) {
                throw new Error('Fake Service Error');
            }));
            mySpy = sinon.spy(res, 'send');
        })

        after(() => {
            commonService._getMasterClientList.restore();
            mySpy.restore();
        })

        it("should return an error", async function () {
            try {
                return commonController.getMasterClientList(req, res, {});
            }
            catch (err) {
                return expect(mySpy.called).is.true;
            }
        });

    });


    describe('Get Customer List Test Success', () => {
        var mySpy;
        before(() => {
            sinon.stub(commonService, '_getCustomerList').returns(new Promise((resolve, reject) => {
                resolve('get success');
            }));
            mySpy = sinon.spy(res, 'send');
        })

        after(() => {
            commonService._getCustomerList.restore();
            mySpy.restore();
        })

        it("should send a message after get Customer List", async function () {
            req = { params: { id: 123 } }
            await commonController.getCustomerList(req, res, {});
            expect(mySpy.called).is.true
        });

    });


    describe('Get Customer List Test Error', () => {
        var mySpy;
        before(() => {
            sinon.stub(commonService, '_getCustomerList').returns(new Promise(function (resolve, reject) {
                throw new Error('Fake Service Error');
            }));
            mySpy = sinon.spy(res, 'send');
        })

        after(() => {
            commonService._getCustomerList.restore();
            mySpy.restore();
        })

        it("should return an error", async function () {
            try {
                req = { params: { id: 123 } }
                await commonController.getCustomerList(req, res, {});
            }
            catch (err) {
                return expect(mySpy.called).is.true;
            }
        });

    });


    describe('Get Contract List Test Success', () => {
        var mySpy;
        before(() => {
            sinon.stub(commonService, '_getContractList').returns(new Promise((resolve, reject) => {
                resolve('get success');
            }));
            mySpy = sinon.spy(res, 'send');
        })

        after(() => {
            commonService._getContractList.restore();
            mySpy.restore();
        })

        it("should send a message after get Contract List", async function () {
            req = { params: { id: 123 } }
            await commonController.getContractList(req, res, {});
            expect(mySpy.called).is.true
        });

    });


    describe('Get Contract List Test Error', () => {
        var mySpy;
        before(() => {
            sinon.stub(commonService, '_getContractList').returns(new Promise(function (resolve, reject) {
                throw new Error('Fake Service Error');
            }));
            mySpy = sinon.spy(res, 'send');
        })

        after(() => {
            commonService._getContractList.restore();
            mySpy.restore();
        })

        it("should return an error", async function () {
            try {
                await commonController.getContractList(req, res, {});
            }
            catch (err) {
                return expect(mySpy.called).is.true;
            }
        });

    });

    describe('Get URL Test Success', () => {
        var mySpy;
        before(() => {
            sinon.stub(commonService, '_getURL').returns(new Promise((resolve, reject) => {
                resolve('get success');
            }));
            mySpy = sinon.spy(res, 'send');
        })

        after(() => {
            commonService._getURL.restore();
            mySpy.restore();
        })

        it("should send a message after get URL", async function () {
            req = {
                params: {
                    description: 'description'
                }
            }
            await commonController.getURL(req, res, {});
            expect(mySpy.called).is.true
        });

    });

    describe('Get URL Test Error', () => {
        var mySpy;
        before(() => {
            sinon.stub(commonService, '_getURL').returns(new Promise(function (resolve, reject) {
                throw new Error('Fake Service Error');
            }));
            mySpy = sinon.spy(res, 'send');
        })

        after(() => {
            commonService._getURL.restore();
            mySpy.restore();
        })

        it("should return an error", async function () {
            try {
                await commonController.getURL(req, res, {});
            }
            catch (err) {
                return expect(mySpy.called).is.true;
            }
        });

    });

    describe('Get MMC Link Items Test Success', () => {
        var mySpy;
        before(() => {
            sinon.stub(commonService, '_getMMCLinkItems').returns(new Promise((resolve, reject) => {
                resolve('get success');
            }));
            mySpy = sinon.spy(res, 'send');
        })

        after(() => {
            commonService._getMMCLinkItems.restore();
            mySpy.restore();
        })

        it("should send the list of MMC link items", async function () {
            req = { params: { linkCategory: 'AppFinderItems' } };
            await commonController.getMMCLinkItems(req, res, {});
            expect(mySpy.called).is.true
        });
    });

    describe('Get MMC Link Items Test Error', () => {
        before(() => {
            sinon.stub(commonService, '_getMMCLinkItems').returns(new Promise(function (resolve, reject) {
                throw new Error('Fake Service Error');
            }));
            mySpy = sinon.spy(res, 'send');
        })

        after(() => {
            commonService._getMMCLinkItems.restore();
            mySpy.restore();
        })

        it("should return an error", async function () {
            req = { params: { linkCategory: 'AppFinderItems' } };
            try {
                await commonController.getMMCLinkItems(req, res, {});
            }
            catch (err) {
                return expect(mySpy.called).is.true;
            }
        });
    });

    describe('Get People Image Test Success', () => {
        var mySpy;
        before(() => {
            sinon.stub(commonService, '_getPeopleImage').returns(new Promise((resolve, reject) => {
                resolve('get success');
            }));
            process.env.ENTERPRISEID = 'e.i.d';
            mySpy = sinon.spy(res, 'end');
        })

        after(() => {
            commonService._getPeopleImage.restore();
            mySpy.restore();
        })

        it("should send people image data", async function () {
            req = ({
                params: { enterpriseId: "e.i.d" }
            });
            await commonController.getPeopleImage(req, res, {});
            return expect(mySpy.called).is.true;
        });

        it("should send people image data with no eid", async function () {
            req = ({
                params: {}
            });
            await commonController.getPeopleImage(req, res, {});
            return expect(mySpy.called).is.true;
        });

    });
    describe('Get People Image Test Error', () => {
        var mySpy;
        before(() => {
            sinon.stub(commonService, '_getPeopleImage').returns(new Promise(function (resolve, reject) {
                throw new Error('Fake Service Error');
            }));
            process.env.ENTERPRISEID = 'e.i.d';
            mySpy = sinon.spy(res, 'send');
        })

        after(() => {
            commonService._getPeopleImage.restore();
            mySpy.restore();
        })

        it("should send people image data", async function () {
            req = ({
                params: { enterpriseId: "e.i.d" }
            });            
            try {
                await commonController.getPeopleImage(req, res, {});
            }
            catch (err) {
                return expect(mySpy.called).is.true;
            }
        });


    });
    describe('Get People Image Test with no Service data Success', () => {
        var mySpy;
        before(() => {
            sinon.stub(commonService, '_getPeopleImage').returns(new Promise((resolve, reject) => {
                resolve(null);
            }));
            mySpy = sinon.spy(res, 'send');
        })

        after(() => {
            commonService._getPeopleImage.restore();
            mySpy.restore();
        })

        it("should send people image data", async function () {
            req = ({
                params: { enterpriseId: "e.i.d" }
            })

            await commonController.getPeopleImage(req, res, {});
            expect(mySpy.called).is.true
        });
    });

    describe('Get Contract List By MC Test Success', () => {
        var mySpy;
        before(() => {
            sinon.stub(commonService, '_getContractListByMClient').returns(new Promise((resolve, reject) => {
                resolve('get success');
            }));
            mySpy = sinon.spy(res, 'send');
        })

        after(() => {
            commonService._getContractListByMClient.restore();
            mySpy.restore();
        })

        it("should send a message after get Contract List By MC", async function () {
            req = ({
                params: { id: "1" }
            })
            await commonController.getContractListByMClient(req, res, {});
            expect(mySpy.called).is.true
        });

    });

    describe('Get Contract List By MC Test Error', () => {
        var mySpy;
        before(() => {
            sinon.stub(commonService, '_getContractListByMClient').returns(new Promise(function (resolve, reject) {
                throw new Error('Fake Service Error');
            }));
            mySpy = sinon.spy(res, 'send');
        })

        after(() => {
            commonService._getContractListByMClient.restore();
            mySpy.restore();
        })

        it("should return an error", async function () {
            req = ({
                params: { id: "1" }
            })
            try {
                await commonController.getContractListByMClient(req, res, {});
            }
            catch (err) {
                return expect(mySpy.called).is.true;
            }
        });

    });

    describe('Get User MRDR Location Test Success', () => {
        var mySpy;
        before(() => {
            sinon.stub(commonService, '_userMRDRLocation').returns(new Promise((resolve, reject) => {
                resolve('get success');
            }));
            mySpy = sinon.spy(res, 'send');
        })

        after(() => {
            commonService._userMRDRLocation.restore();
            mySpy.restore();
        })

        //With EID
        it("should send a message after get User MRDR Location", async function () {
            req = ({
                params: { enterpriseId: "sample.user" }
            })
            await commonController.userMRDRLocation(req, res, {});
            expect(mySpy.called).is.true
        });

        //With null EID
        it("should send a message after get User MRDR Location", async function () {
            req = ({
                params: { enterpriseId: null }
            })
            await commonController.userMRDRLocation(req, res, {});
            expect(mySpy.called).is.true
        });
    });

    describe('Get User Profile Test Success', () => {
        var mySpy;
        before(() => {
            sinon.stub(commonService, '_userProfile').returns(new Promise((resolve, reject) => {
                resolve('get user profile');
            }));
            mySpy = sinon.spy(res, 'send');
        })

        after(() => {
            commonService._userProfile.restore();
            mySpy.restore();
        })

        it("should send a message after get User Profile", async function () {
            req = ({
                params: { enterpriseId: 'revo.b.espinosa' },
                headers: {}
            })

            await commonController.userProfile(req, res, {});
            expect(mySpy.called).is.true
        });

        it("should not send a message after get User Profile", async function () {
            req = ({
                params: { enterpriseId: '' },
                headers: { authorization: '234872973b98sdf9872' }
            })
            await commonController.userProfile(req, res, {});
            expect(mySpy.called).is.true
        });
    });

    describe('Get People Picker Test Success', () => {
        var mySpy;
        before(() => {
            sinon.stub(commonService, '_getAADPeoplePicker').returns(new Promise((resolve, reject) => {
                resolve('get success');
            }));
            mySpy = sinon.spy(res, 'send');
        })

        after(() => {
            commonService._getAADPeoplePicker.restore();
            mySpy.restore();
        })

        it("should send a message after get people picker", async function () {
            req = ({
                query: {
                    filter: 'sample filter',
                    count: 0
                }
            })
            await commonController.peoplepicker(req, res, {});
            expect(mySpy.called).is.true
        });

    });

    describe('Get People Picker Test Error', () => {
        var mySpy;
        before(() => {
            sinon.stub(commonService, '_getAADPeoplePicker').returns(new Promise(function (resolve, reject) {
                throw new Error('Fake Service Error');
            }));
            mySpy = sinon.spy(res, 'send');
        })

        after(() => {
            commonService._getAADPeoplePicker.restore();
            mySpy.restore();
        })

        it("should return an error", async function () {
            req = ({
                query: {
                    filter: 'sample filter',
                    count: '1'
                }
            })

            try {
                await commonController.peoplepicker(req, res, {});
            }
            catch (err) {
                return expect(mySpy.called).is.true;
            }
        });
    });

    describe('Get Disabled Features Test Success', () => {
        var mySpy;
        beforeEach(() => {
            
        });

        afterEach(() => {
            commonService._getDisabledFeatures.restore();
            mySpy.restore();
        });

        it("should send a message after get last access", async function () {
            sinon.stub(commonService, '_getDisabledFeatures').returns(new Promise((resolve, reject) => {
                resolve('get success');
            }));
            mySpy = sinon.spy(res, 'send');

            req = ({
                params: { featureGroup: 'HealthScore' }
            })
            await commonController.getDisabledFeatures(req, res, {});
            expect(mySpy.called).is.true;
        });

        it("should return an error", async function () {
            sinon.stub(commonService, '_getDisabledFeatures').rejects('error')
            mySpy = sinon.spy(res, 'send');
            req = ({
                params: { featureGroup: 'HealthScore' }
            })
            try {
                await commonController.getDisabledFeatures(req, res, {});
            }
            catch (err) {
                expect(err.name).eql('error');
            }
        });
    });
});
