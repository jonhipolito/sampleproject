process.env.NODE_ENV = 'test';

const commonRepository = require('../server/common.repository');
const commonService = require('../server/common.service');
const sinon = require('sinon');
const chai = require('chai');
const should = chai.should();
const expect = require('chai').expect;
const axios = require('axios');
//var MockAdapter = require('axios-mock-adapter');
//var mock = new MockAdapter(axios);
const request = require('request');
const NodeCache = require("node-cache");
const Cache = new NodeCache({
    stdTTL: 1800,
    checkperiod: 340
});
describe('Testing Common Service', () => {

    describe('_getLastAccessClient Test Success', () => {
        before(() => {
            sinon.stub(commonRepository, 'getLastAccessClient').returns('test last access');
        })

        after(() => {
            commonRepository.getLastAccessClient.restore();
        })

        it("should successfully get last access client", function (done) {
            commonService._getLastAccessClient()
                .then(message => {                    
                    expect(message).to.be.eql('test last access')
                })
                .finally(done())

        });

    });


    describe('_getLastAccessClient Test Error', () => {
        before(() => {
            sinon.stub(commonRepository, 'getLastAccessClient').rejects(new Error('Fake Repository Error'));
        })

        after(() => {
            commonRepository.getLastAccessClient.restore();
        })

        it("should return an error", function (done) {
            commonService._getLastAccessClient()
                .catch(error => {                    
                    expect(error.message).to.be.eql('Fake Repository Error')
                })
                .finally(done())

        });

    });

    describe('_postLastAccessClient Test Update Success', () => {
        before(async () => {
            // var obj = [];
            // obj = await commonRepository.getLastAccessClient();
            var arryObj = (
                [
                    {
                        LastAccessClientLogKey: "c21d9e73-8aa4-48ef-9945-aa200bfa019a",
                        ContractCd: "9940219095",
                        CreateDttm: "2019-06-27 20:37:48.442-07",
                        CreateUserId: "T27354.ORION.017",
                        FinancialClientCd: "10000112",
                        MasterClientCd: "1800002",
                        UpdateDttm: "2019-06-27 20:37:48.442-07",
                        UpdateUserId: "T27354.ORION.017",
                        UserNm: "T27354.ORION.017"
                    }
                ]
            );

            sinon.stub(commonRepository, 'getLastAccessClient').returns(arryObj);
        })

        after(() => {
            commonRepository.getLastAccessClient.restore();
        })

        it("should update last access client", function () {
            var body = { con: "0594849599", fc: "CSP1", mc: "JP00001" }

            commonService._postLastAccessClient(body)
                .then(message => {                                        
                    expect(message).to.be.eql('updated last access client log')
                })
                .catch(error => {
                    console.log(error);
                })
        });

    });

    describe('_postLastAccessClient Test Insert Success', () => {
        before(() => {
            var obj = { length: '0' };
            sinon.stub(commonRepository, 'getLastAccessClient').returns(obj);
        })

        after(() => {
            commonRepository.getLastAccessClient.restore();
        })

        it("should insert last access client", function (done) {
            var body = { con: "0594849599", fc: "CSP1", mc: "JP00001" }

            commonService._postLastAccessClient(body)
                .then(message => {                    
                    expect(message).to.be.eql('inserted updated last access client log')
                })
                .finally(done())
        });

    });



    describe('_getMasterClientList Test Success', () => {
        before(() => {
            sinon.stub(commonRepository, 'getMasterClientList').returns('test master client list');
        })

        after(() => {
            commonRepository.getMasterClientList.restore();
        })

        it("should successfully get master client list", function (done) {
            commonService._getMasterClientList()
                .then(message => {                    
                    expect(message).to.be.eql('test master client list')
                })
                .finally(done())

        });

    });

    // describe('_getMasterClientList Test Error', () => {
    //     before(() => {
    //         sinon.stub(commonService, '_getMasterClientList').rejects(new Error('Fake Repository Error'));
    //     })

    //     after(() => {
    //         commonService._getMasterClientList.restore();
    //     })

    //     it("should return an error", function (done) {
    //         commonService._getMasterClientList()
    //         .catch(error => {
    //             console.log(error.message);
    //             error.message.should.eql('Fake Repository Error');
    //         })
    //         .finally(done())

    //     });

    // });


    describe('_getCustomerList Test Success', () => {
        before(() => {
            sinon.stub(commonRepository, 'getCustomerList').returns('test customer list');
        })

        after(() => {
            commonRepository.getCustomerList.restore();
        })

        it("should successfully get customer list", function (done) {
            let selectedMCNbr = '1800002';

            commonService._getCustomerList(selectedMCNbr)
                .then(message => {                    
                    expect(message).to.be.eql('test customer list')
                })
                .finally(done())

        });

    });


    describe('_getContractList Test Success', () => {
        before(() => {
            sinon.stub(commonRepository, 'getContractList').returns('test Contract list');
        })

        after(() => {
            commonRepository.getContractList.restore();
        })

        it("should successfully get Contract list", function (done) {
            let selectedFCNbr = '10000112';

            commonService._getContractList(selectedFCNbr)
                .then(message => {                    
                    expect(message).to.be.eql('test Contract list')
                })
                .finally(done())

        });

    });


    describe('_getURL Test Success', () => {
        before(() => {
            sinon.stub(commonRepository, 'getURL').returns('test URL');
        })

        after(() => {
            commonRepository.getURL.restore();
        })

        it("should successfully get URL", function (done) {
            commonService._getURL()
                .then(message => {                    
                    expect(message).to.be.eql('test URL')
                })
                .finally(done())

        });

    });

    describe('_getURL Test Error', () => {
        before(() => {
            //sinon.stub(commonRepository, 'getURL').rejects(new Error('Fake Repository Error'));
            process.env.UNIT_TEST_DATABASE_ID = '';
        })

        after(() => {
            // commonRepository.getURL.restore();
            process.env.UNIT_TEST_DATABASE_ID = 'mmcunittestdb';
        })

        it("should return an error", function () {
            let description = 'OnBoarding';

            commonService._getURL(description)
                .catch(error => {
                    expect(error.message).to.be.eql('A name is required to access a Database object.')                    
                })

        });

    });

    describe('_userProfile Test Success', () => {
        let user = {
            EnterpriseId: "kevin.d.borromeo",
            Details: {
                FirstName: "Kevin",
                LastName: "Borromeo",
                DisplayName: "Borromeo, Kevin D.",
                Email: "kevin.d.borromeo@accenture.com"
            }
        }
        var arryObj = (
            [
                [
                    {
                        name: "PrimaryDecodeTxt",
                        value: "GlobalCMLead"
                    }
                ]
            ]
        );
        before(() => {
            sinon.stub(commonService, '_user').returns(user);
            sinon.stub(commonService, '_profile').returns(arryObj);
        })

        after(() => {
            commonService._user.restore();
            commonService._profile.restore();
        })
        it("should successfully return User Profile", function (done) {
            let token = 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IkhCeGw5bUFlNmd4YXZDa2NvT1UyVEhzRE5hMCIsImtpZCI6IkhCeGw5bUFlNmd4YXZDa2NvT1UyVEhzRE5hMCJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTU2MTY5MzQ4LCJuYmYiOjE1NTYxNjkzNDgsImV4cCI6MTU1NjE3MzI0OCwiYWlvIjoiQVZRQXEvOExBQUFBcUdEa0Q5U3Jzb3B0cmFjWGpFZElkamxkMnlvTjlLbXFLZWd1N294UmlacE1JUjJxQVNYOW5SSERlSGhaQVgvZHRxODZ5NDk3K1VVQXhPblBGMi90R2NGajVYR3d5MEt0YkJzaWlKOStiNUk9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkFub3JhIiwiZ2l2ZW5fbmFtZSI6IkNpbmR5IE1hcmllIiwiaXBhZGRyIjoiMTcwLjI1Mi4xNjAuMSIsIm5hbWUiOiJBw7FvcmEsIENpbmR5IE1hcmllIEwuIiwibm9uY2UiOiJhYzBjYWEyYi0zNDI2LTRkNGEtOWU5Zi1lNWI4NTNiMDg0OWUiLCJvaWQiOiI2ZWRiYmUxNi0zYWQxLTRkNDItYjVkMy04ZmQ1OGJhYzQ2NDkiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTMxODI5ODUiLCJzdWIiOiJqcERVRFJoU0MtNzhnRHotUE1PZXF3eGYzRlVyNnlTejByMEV5U25XemhzIiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJjaW5keS5tYXJpZS5sLmFub3JhQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXBuIjoiY2luZHkubWFyaWUubC5hbm9yYUBkcy5kZXYuYWNjZW50dXJlLmNvbSIsInV0aSI6IjlTaE02LUFPeDBPV0xIZlU4ZTZCQUEiLCJ2ZXIiOiIxLjAifQ.a8IZbaAx6FMaWFtisz_D9q4I8Kj77j1DSFMxEpDpG5BSUEPh1fsyxGwoRzBdgWOGtk4Pw4S_AF1QAi5KUvw1ugoRXY6DnLhAfSDsXk0Ics1fqhX0s_7COv5Fg2-I-1arxWILKbFzoFPFb7NjpWdSxYiICq7x2-q6zkAfbhcbSvT9CAk1LTLN5rZ0JPtKSqLA_jco0CacFTzXlXEfVMSPiYdk6J-KP3_heYCZVD_Maj7ip5k0JJeFw0M-3cXJfx1XWrOCSQ1wWcGgCwJd3bXWXLNeHodZM7NDraTQQBngANqlDmQCy3kR9ytYgD02S_jEIKextVb_vdUU-ho-fCNA7Q';
            let eid = 'revo.b.espinosa@accenture.com';

            commonService._userProfile(token, eid)
                .then(message => {
                    expect(message).to.be.not.null
                })
                .finally(done())
        });

        it("should successfully return User Profile without eid", function (done) {
            let token = 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IkhCeGw5bUFlNmd4YXZDa2NvT1UyVEhzRE5hMCIsImtpZCI6IkhCeGw5bUFlNmd4YXZDa2NvT1UyVEhzRE5hMCJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTU2MTY5MzQ4LCJuYmYiOjE1NTYxNjkzNDgsImV4cCI6MTU1NjE3MzI0OCwiYWlvIjoiQVZRQXEvOExBQUFBcUdEa0Q5U3Jzb3B0cmFjWGpFZElkamxkMnlvTjlLbXFLZWd1N294UmlacE1JUjJxQVNYOW5SSERlSGhaQVgvZHRxODZ5NDk3K1VVQXhPblBGMi90R2NGajVYR3d5MEt0YkJzaWlKOStiNUk9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkFub3JhIiwiZ2l2ZW5fbmFtZSI6IkNpbmR5IE1hcmllIiwiaXBhZGRyIjoiMTcwLjI1Mi4xNjAuMSIsIm5hbWUiOiJBw7FvcmEsIENpbmR5IE1hcmllIEwuIiwibm9uY2UiOiJhYzBjYWEyYi0zNDI2LTRkNGEtOWU5Zi1lNWI4NTNiMDg0OWUiLCJvaWQiOiI2ZWRiYmUxNi0zYWQxLTRkNDItYjVkMy04ZmQ1OGJhYzQ2NDkiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTMxODI5ODUiLCJzdWIiOiJqcERVRFJoU0MtNzhnRHotUE1PZXF3eGYzRlVyNnlTejByMEV5U25XemhzIiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJjaW5keS5tYXJpZS5sLmFub3JhQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXBuIjoiY2luZHkubWFyaWUubC5hbm9yYUBkcy5kZXYuYWNjZW50dXJlLmNvbSIsInV0aSI6IjlTaE02LUFPeDBPV0xIZlU4ZTZCQUEiLCJ2ZXIiOiIxLjAifQ.a8IZbaAx6FMaWFtisz_D9q4I8Kj77j1DSFMxEpDpG5BSUEPh1fsyxGwoRzBdgWOGtk4Pw4S_AF1QAi5KUvw1ugoRXY6DnLhAfSDsXk0Ics1fqhX0s_7COv5Fg2-I-1arxWILKbFzoFPFb7NjpWdSxYiICq7x2-q6zkAfbhcbSvT9CAk1LTLN5rZ0JPtKSqLA_jco0CacFTzXlXEfVMSPiYdk6J-KP3_heYCZVD_Maj7ip5k0JJeFw0M-3cXJfx1XWrOCSQ1wWcGgCwJd3bXWXLNeHodZM7NDraTQQBngANqlDmQCy3kR9ytYgD02S_jEIKextVb_vdUU-ho-fCNA7Q';
            let eid = '';

            commonService._userProfile(token, eid)
                .then(message => {                    
                    expect(message).to.be.not.null
                })
                .finally(done())
        });
    });

    describe('_profile  Test Success', () => {
        var arryObj = ["GlobalCMLead"]
        
        before(() => {
            sinon.stub(commonService, '_getUserRoles').returns(arryObj);
        })

        after(() => {
            commonService._getUserRoles.restore();
        })

        it("should successfully get user roles", function (done) {
            let eid = 'revo.b.espinosa@accenture.com';

            commonService._profile(eid)
                .then(message => {                                      
                    expect(message).to.be.eql(arryObj)
                })
                .finally(done())
        });
    });

    describe('_profile Null Test Success', () => {
        var arryObj = null
        
        before(() => {
            sinon.stub(commonService, '_getUserRoles').returns(arryObj);
        })

        after(() => {
            commonService._getUserRoles.restore();
        })

        it("should successfully get user roles", function (done) {
            let eid = 'revo.b.espinosa@accenture.com';

            commonService._profile(eid)
                .then(message => {                    
                    expect(message).to.be.eql(arryObj)
                })
                .finally(done())
        });
    });
    describe('_getUserRoles Null Test Success', () => {
        var arryObj = null
        before(() => {
            sinon.stub(commonRepository, 'getUserRole').returns(arryObj);
        })

        after(() => {
            commonRepository.getUserRole.restore();
        })

        it("should successfully get user roles", function (done) {
            let eid = 'revo.b.espinosa';

            commonService._getUserRoles(eid)
                .then(message => {
                    expect(message).to.be.null
                })
                .finally(done())
        });
    });
    describe('_getUserRoles Test Success', () => {
        var arryObj = (
            [
                [
                    {
                        name: "PrimaryDecodeTxt",
                        value: "GlobalCMLead"
                    }
                ]
            ]
        );
        before(() => {
            sinon.stub(commonRepository, 'getUserRole').returns(arryObj);
        })

        after(() => {
            commonRepository.getUserRole.restore();
        })

        it("should successfully get user roles", function (done) {
            let eid = 'revo.b.espinosa';

            commonService._getUserRoles(eid)
                .then(message => {                    
                    expect(message).to.be.eql([arryObj[0][0].value])
                })
                .finally(done())
        });
    });

    describe('_getContractListByMClient Test Success', () => {
        before(() => {
            sinon.stub(commonRepository, 'getContractListByMClient').returns('test Contract list by MC');
        })

        after(() => {
            commonRepository.getContractListByMClient.restore();
        })

        it("should successfully get Contract list by MC", function (done) {
            let selectedMCNbr = '1800002';

            commonService._getContractListByMClient(selectedMCNbr)
                .then(message => {                    
                    expect(message).to.be.eql('test Contract list by MC')
                })
                .finally(done())

        });

    });


    describe('_user Test Success', () => {
        let userDetail = { "userPrincipalName": "kevin.d.borromeo@accenture.com", "givenName": "Kevin", "surname": "Borromeo", "displayName": "Borromeo, Kevin D.", "userPrincipalName": "kevin.d.borromeo@accenture.com" }
        before(() => {
            sinon.stub(commonService, '_getAADUserDetail').returns(userDetail);
        })

        after(() => {
            commonService._getAADUserDetail.restore();
        })
        it("should successfully call get User with token and EID", function (done) {
            let token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSIsImtpZCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTYyODM2NjEzLCJuYmYiOjE1NjI4MzY2MTMsImV4cCI6MTU2Mjg0MDUxMywiYWlvIjoiQVZRQXEvOE1BQUFBb3dHaUNnUndBS0pTdWNXUlRIcWxremlHVmNhM3dZSDgrTmhpY2RydnZ2RldRTEZoOXZTOUlqTDJMWGpiakJGdS9ncmZRbmlzdldxcmNteXBsUmdtOGhUU21XNDVhN1FrY2Z4RDBmK2J4RzA9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkNoYW4gQmFxdWVybyIsImdpdmVuX25hbWUiOiJWaWMgQnJhbmRvbiIsImlwYWRkciI6IjE3MC4yNTEuNDguMjE3IiwibmFtZSI6IkNoYW4gQmFxdWVybywgVmljIEIuIEQuIiwibm9uY2UiOiJkYmI4MzQ2MS0xMzMwLTQ4M2ItODkyMS1hN2RlZjBlMjkzN2MiLCJvaWQiOiIxM2EyMTI1ZS1iMDkxLTRjM2QtYmI1OC04OWJmNjVmZWViOWMiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTM5MTI3NzYiLCJzdWIiOiJ4dUFqWVA3MkxTeTEtQzFiN2E3WDVZYjlHdzh5VmpCVW8tZTRmekt5VUZ3IiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJ2aWMuYi5kLmNoYW4uYmFxdWVyb0Bkcy5kZXYuYWNjZW50dXJlLmNvbSIsInVwbiI6InZpYy5iLmQuY2hhbi5iYXF1ZXJvQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXRpIjoiRVJ6MmMweEJORUs0eE8yTU9RUVZBQSIsInZlciI6IjEuMCJ9.af3j_MSgSZIQgvztdOK1tMwc78fDAyPeLMJSZ7sSrSuxymYuRurtd1Opbz2Trd7JmNFu0Nr9WDAqB1uM2feOFb8_I2ogoCTIxHeq6oFFc5_nG1l2qU61L9OvCNRiayYtgdkuyefPGBDsR9ukz7MjRgr8XHSdfuxB1OGgZmBgYJ_9A2cRXQjzTKAQbrM6fxprBS0X8lNcHVpIGHE4v2bcinNOH_Orvsms5b0K2uCB1GSa_c6PLYUoOKAq5HrZvHgBubfYSazFI3kuiH2gKtK3gI9aa4_H5Jx8qm1fqg0PbAvtO_6nV4LKamJDMhttqtwfea2fCF0ZYssTYThnmMBBYg';
            let eid = 'emmanuel.p.teofisto';

            commonService._user(token, eid)
                .then(message => {                    
                    expect(message.EnterpriseId).to.be.eql(userDetail.userPrincipalName.split('@')[0])
                })
                .finally(done())

        });

        it("should successfully call get User with token and null EID", function (done) {
            let token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSIsImtpZCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTYyODM2NjEzLCJuYmYiOjE1NjI4MzY2MTMsImV4cCI6MTU2Mjg0MDUxMywiYWlvIjoiQVZRQXEvOE1BQUFBb3dHaUNnUndBS0pTdWNXUlRIcWxremlHVmNhM3dZSDgrTmhpY2RydnZ2RldRTEZoOXZTOUlqTDJMWGpiakJGdS9ncmZRbmlzdldxcmNteXBsUmdtOGhUU21XNDVhN1FrY2Z4RDBmK2J4RzA9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkNoYW4gQmFxdWVybyIsImdpdmVuX25hbWUiOiJWaWMgQnJhbmRvbiIsImlwYWRkciI6IjE3MC4yNTEuNDguMjE3IiwibmFtZSI6IkNoYW4gQmFxdWVybywgVmljIEIuIEQuIiwibm9uY2UiOiJkYmI4MzQ2MS0xMzMwLTQ4M2ItODkyMS1hN2RlZjBlMjkzN2MiLCJvaWQiOiIxM2EyMTI1ZS1iMDkxLTRjM2QtYmI1OC04OWJmNjVmZWViOWMiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTM5MTI3NzYiLCJzdWIiOiJ4dUFqWVA3MkxTeTEtQzFiN2E3WDVZYjlHdzh5VmpCVW8tZTRmekt5VUZ3IiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJ2aWMuYi5kLmNoYW4uYmFxdWVyb0Bkcy5kZXYuYWNjZW50dXJlLmNvbSIsInVwbiI6InZpYy5iLmQuY2hhbi5iYXF1ZXJvQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXRpIjoiRVJ6MmMweEJORUs0eE8yTU9RUVZBQSIsInZlciI6IjEuMCJ9.af3j_MSgSZIQgvztdOK1tMwc78fDAyPeLMJSZ7sSrSuxymYuRurtd1Opbz2Trd7JmNFu0Nr9WDAqB1uM2feOFb8_I2ogoCTIxHeq6oFFc5_nG1l2qU61L9OvCNRiayYtgdkuyefPGBDsR9ukz7MjRgr8XHSdfuxB1OGgZmBgYJ_9A2cRXQjzTKAQbrM6fxprBS0X8lNcHVpIGHE4v2bcinNOH_Orvsms5b0K2uCB1GSa_c6PLYUoOKAq5HrZvHgBubfYSazFI3kuiH2gKtK3gI9aa4_H5Jx8qm1fqg0PbAvtO_6nV4LKamJDMhttqtwfea2fCF0ZYssTYThnmMBBYg';
            let eid = null;

            commonService._user(token, eid)
                .then(message => {
                    expect(message.EnterpriseId).to.not.be.null
                })
                .finally(done())

        });
    });

    describe('_getMRDRUserDetail - Null Test Success', () => {
        let mrdrData = {
            value: [{
                "EnterpriseId": "kevin.d.borromeo",
                "FirstName": "Kevin",
                "MiddleInitial": "D.",
                "LastName": "Borromeo",
                "displayName": "Borromeo, Kevin D.",
                "InternetMail": "kevin.d.borromeo@accenture.com",
                "CountryName": "Philippines",
                "CountryKey": "PH",
                "GeographicUnitDescription": "",
                "GeographicUnitCode": ""
            }]
        }
        before(() => {
            sinon.stub(request, 'get').yields(null, null, null);
            let token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSIsImtpZCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTYyODM2NjEzLCJuYmYiOjE1NjI4MzY2MTMsImV4cCI6MTU2Mjg0MDUxMywiYWlvIjoiQVZRQXEvOE1BQUFBb3dHaUNnUndBS0pTdWNXUlRIcWxremlHVmNhM3dZSDgrTmhpY2RydnZ2RldRTEZoOXZTOUlqTDJMWGpiakJGdS9ncmZRbmlzdldxcmNteXBsUmdtOGhUU21XNDVhN1FrY2Z4RDBmK2J4RzA9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkNoYW4gQmFxdWVybyIsImdpdmVuX25hbWUiOiJWaWMgQnJhbmRvbiIsImlwYWRkciI6IjE3MC4yNTEuNDguMjE3IiwibmFtZSI6IkNoYW4gQmFxdWVybywgVmljIEIuIEQuIiwibm9uY2UiOiJkYmI4MzQ2MS0xMzMwLTQ4M2ItODkyMS1hN2RlZjBlMjkzN2MiLCJvaWQiOiIxM2EyMTI1ZS1iMDkxLTRjM2QtYmI1OC04OWJmNjVmZWViOWMiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTM5MTI3NzYiLCJzdWIiOiJ4dUFqWVA3MkxTeTEtQzFiN2E3WDVZYjlHdzh5VmpCVW8tZTRmekt5VUZ3IiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJ2aWMuYi5kLmNoYW4uYmFxdWVyb0Bkcy5kZXYuYWNjZW50dXJlLmNvbSIsInVwbiI6InZpYy5iLmQuY2hhbi5iYXF1ZXJvQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXRpIjoiRVJ6MmMweEJORUs0eE8yTU9RUVZBQSIsInZlciI6IjEuMCJ9.af3j_MSgSZIQgvztdOK1tMwc78fDAyPeLMJSZ7sSrSuxymYuRurtd1Opbz2Trd7JmNFu0Nr9WDAqB1uM2feOFb8_I2ogoCTIxHeq6oFFc5_nG1l2qU61L9OvCNRiayYtgdkuyefPGBDsR9ukz7MjRgr8XHSdfuxB1OGgZmBgYJ_9A2cRXQjzTKAQbrM6fxprBS0X8lNcHVpIGHE4v2bcinNOH_Orvsms5b0K2uCB1GSa_c6PLYUoOKAq5HrZvHgBubfYSazFI3kuiH2gKtK3gI9aa4_H5Jx8qm1fqg0PbAvtO_6nV4LKamJDMhttqtwfea2fCF0ZYssTYThnmMBBYg';
            sinon.stub(commonService, '_getADFSToken').returns(token);
        })

        after(() => {
            request.get.restore();
            commonService._getADFSToken.restore();
        })
        it("should successfully get User MRDR Details", function (done) {
            let eid = 'emmanuel.p.teofisto';

            commonService._getMRDRUserDetail(eid)
                .then(message => {
                    expect(message).to.be.null;
                })
                .finally(done())

        });
    });

    describe('_getMRDRUserDetail - No Cache Test Success', () => {
        let mrdrData = {
            value: [{
                "EnterpriseId": "kevin.d.borromeo",
                "FirstName": "Kevin",
                "MiddleInitial": "D.",
                "LastName": "Borromeo",
                "displayName": "Borromeo, Kevin D.",
                "InternetMail": "kevin.d.borromeo@accenture.com",
                "CountryName": "Philippines",
                "CountryKey": "PH",
                "GeographicUnitDescription": "",
                "GeographicUnitCode": ""
            }]
        }
        before(() => {
            sinon.stub(request, 'get').yields(null, null, JSON.stringify(mrdrData));
            let token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSIsImtpZCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTYyODM2NjEzLCJuYmYiOjE1NjI4MzY2MTMsImV4cCI6MTU2Mjg0MDUxMywiYWlvIjoiQVZRQXEvOE1BQUFBb3dHaUNnUndBS0pTdWNXUlRIcWxremlHVmNhM3dZSDgrTmhpY2RydnZ2RldRTEZoOXZTOUlqTDJMWGpiakJGdS9ncmZRbmlzdldxcmNteXBsUmdtOGhUU21XNDVhN1FrY2Z4RDBmK2J4RzA9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkNoYW4gQmFxdWVybyIsImdpdmVuX25hbWUiOiJWaWMgQnJhbmRvbiIsImlwYWRkciI6IjE3MC4yNTEuNDguMjE3IiwibmFtZSI6IkNoYW4gQmFxdWVybywgVmljIEIuIEQuIiwibm9uY2UiOiJkYmI4MzQ2MS0xMzMwLTQ4M2ItODkyMS1hN2RlZjBlMjkzN2MiLCJvaWQiOiIxM2EyMTI1ZS1iMDkxLTRjM2QtYmI1OC04OWJmNjVmZWViOWMiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTM5MTI3NzYiLCJzdWIiOiJ4dUFqWVA3MkxTeTEtQzFiN2E3WDVZYjlHdzh5VmpCVW8tZTRmekt5VUZ3IiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJ2aWMuYi5kLmNoYW4uYmFxdWVyb0Bkcy5kZXYuYWNjZW50dXJlLmNvbSIsInVwbiI6InZpYy5iLmQuY2hhbi5iYXF1ZXJvQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXRpIjoiRVJ6MmMweEJORUs0eE8yTU9RUVZBQSIsInZlciI6IjEuMCJ9.af3j_MSgSZIQgvztdOK1tMwc78fDAyPeLMJSZ7sSrSuxymYuRurtd1Opbz2Trd7JmNFu0Nr9WDAqB1uM2feOFb8_I2ogoCTIxHeq6oFFc5_nG1l2qU61L9OvCNRiayYtgdkuyefPGBDsR9ukz7MjRgr8XHSdfuxB1OGgZmBgYJ_9A2cRXQjzTKAQbrM6fxprBS0X8lNcHVpIGHE4v2bcinNOH_Orvsms5b0K2uCB1GSa_c6PLYUoOKAq5HrZvHgBubfYSazFI3kuiH2gKtK3gI9aa4_H5Jx8qm1fqg0PbAvtO_6nV4LKamJDMhttqtwfea2fCF0ZYssTYThnmMBBYg';
            sinon.stub(commonService, '_getADFSToken').returns(token);
        })

        after(() => {
            request.get.restore();
            commonService._getADFSToken.restore();
        })
        it("should successfully get User MRDR Details", function (done) {
            let eid = 'emmanuel.p.teofisto';

            commonService._getMRDRUserDetail(eid)
                .then(message => {
                    expect(message).to.be.eql(mrdrData.value[0]);
                })
                .finally(done())

        });
    });

    describe('_getMRDRUserDetail - With Cache Test Success', () => {
        let mrdrData = {
            value: [{
                "EnterpriseId": "kevin.d.borromeo",
                "FirstName": "Kevin",
                "MiddleInitial": "D.",
                "LastName": "Borromeo",
                "displayName": "Borromeo, Kevin D.",
                "InternetMail": "kevin.d.borromeo@accenture.com",
                "CountryName": "Philippines",
                "CountryKey": "PH",
                "GeographicUnitDescription": "",
                "GeographicUnitCode": ""
            }]
        }
        before(() => {
            let token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSIsImtpZCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTYyODM2NjEzLCJuYmYiOjE1NjI4MzY2MTMsImV4cCI6MTU2Mjg0MDUxMywiYWlvIjoiQVZRQXEvOE1BQUFBb3dHaUNnUndBS0pTdWNXUlRIcWxremlHVmNhM3dZSDgrTmhpY2RydnZ2RldRTEZoOXZTOUlqTDJMWGpiakJGdS9ncmZRbmlzdldxcmNteXBsUmdtOGhUU21XNDVhN1FrY2Z4RDBmK2J4RzA9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkNoYW4gQmFxdWVybyIsImdpdmVuX25hbWUiOiJWaWMgQnJhbmRvbiIsImlwYWRkciI6IjE3MC4yNTEuNDguMjE3IiwibmFtZSI6IkNoYW4gQmFxdWVybywgVmljIEIuIEQuIiwibm9uY2UiOiJkYmI4MzQ2MS0xMzMwLTQ4M2ItODkyMS1hN2RlZjBlMjkzN2MiLCJvaWQiOiIxM2EyMTI1ZS1iMDkxLTRjM2QtYmI1OC04OWJmNjVmZWViOWMiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTM5MTI3NzYiLCJzdWIiOiJ4dUFqWVA3MkxTeTEtQzFiN2E3WDVZYjlHdzh5VmpCVW8tZTRmekt5VUZ3IiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJ2aWMuYi5kLmNoYW4uYmFxdWVyb0Bkcy5kZXYuYWNjZW50dXJlLmNvbSIsInVwbiI6InZpYy5iLmQuY2hhbi5iYXF1ZXJvQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXRpIjoiRVJ6MmMweEJORUs0eE8yTU9RUVZBQSIsInZlciI6IjEuMCJ9.af3j_MSgSZIQgvztdOK1tMwc78fDAyPeLMJSZ7sSrSuxymYuRurtd1Opbz2Trd7JmNFu0Nr9WDAqB1uM2feOFb8_I2ogoCTIxHeq6oFFc5_nG1l2qU61L9OvCNRiayYtgdkuyefPGBDsR9ukz7MjRgr8XHSdfuxB1OGgZmBgYJ_9A2cRXQjzTKAQbrM6fxprBS0X8lNcHVpIGHE4v2bcinNOH_Orvsms5b0K2uCB1GSa_c6PLYUoOKAq5HrZvHgBubfYSazFI3kuiH2gKtK3gI9aa4_H5Jx8qm1fqg0PbAvtO_6nV4LKamJDMhttqtwfea2fCF0ZYssTYThnmMBBYg';
            sinon.stub(commonService, '_getADFSToken').returns(token);
        })

        after(() => {
            commonService._getADFSToken.restore();
        })
        it("should successfully get User MRDR Details", function (done) {
            let eid = 'emmanuel.p.teofisto';

            commonService._getMRDRUserDetail(eid)
                .then(message => {                    
                    expect(message).to.be.eql(mrdrData.value[0]);
                })
                .finally(done())

        });
    });

    describe('_userMRDRLocation Test Success', () => {
        let mrdrData = {
            "EnterpriseId": "kevin.d.borromeo",
            "FirstName": "Kevin",
            "MiddleInitial": "D.",
            "LastName": "Borromeo",
            "displayName": "Borromeo, Kevin D.",
            "InternetMail": "kevin.d.borromeo@accenture.com",
            "CountryName": "Philippines",
            "CountryKey": "PH",
            "GeographicUnitDescription": "",
            "GeographicUnitCode": ""
        }
        before(() => {
            sinon.stub(commonService, '_getMRDRUserDetail').returns(mrdrData);
        })

        after(() => {
            commonService._getMRDRUserDetail.restore();
        })
        it("should successfully call get User MRDR Location", function (done) {
            let eid = 'emmanuel.p.teofisto';

            commonService._userMRDRLocation(eid)
                .then(message => {
                    expect(message.EnterpriseId).to.be.eql(mrdrData.EnterpriseId);                    
                })
                .finally(done())

        });
    });

    describe('_userMRDRLocation - Not Found Test Success', () => {

        before(() => {
            sinon.stub(commonService, '_getMRDRUserDetail').returns(null);
        })

        after(() => {
            commonService._getMRDRUserDetail.restore();
        })
        it("should successfully call get User MRDR Location", function (done) {
            let eid = 'emmanuel.p.teofisto';

            commonService._userMRDRLocation(eid)
                .then(message => {
                    expect(message).to.have.a.property('EnterpriseId');
                })
                .finally(done())

        });
    });

    describe('_getAADPeoplePicker Null Body Test Success', () => {
        let eids = {
            value: [
                { "mail": "kevin.d.borromeo@accenture.com" },
                { "mail": "kevin.d.borromeo2@accenture.com" }
            ]
        }
        before(() => {
            sinon.stub(request, 'get').yields(null, null, null);
            let token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSIsImtpZCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTYyODM2NjEzLCJuYmYiOjE1NjI4MzY2MTMsImV4cCI6MTU2Mjg0MDUxMywiYWlvIjoiQVZRQXEvOE1BQUFBb3dHaUNnUndBS0pTdWNXUlRIcWxremlHVmNhM3dZSDgrTmhpY2RydnZ2RldRTEZoOXZTOUlqTDJMWGpiakJGdS9ncmZRbmlzdldxcmNteXBsUmdtOGhUU21XNDVhN1FrY2Z4RDBmK2J4RzA9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkNoYW4gQmFxdWVybyIsImdpdmVuX25hbWUiOiJWaWMgQnJhbmRvbiIsImlwYWRkciI6IjE3MC4yNTEuNDguMjE3IiwibmFtZSI6IkNoYW4gQmFxdWVybywgVmljIEIuIEQuIiwibm9uY2UiOiJkYmI4MzQ2MS0xMzMwLTQ4M2ItODkyMS1hN2RlZjBlMjkzN2MiLCJvaWQiOiIxM2EyMTI1ZS1iMDkxLTRjM2QtYmI1OC04OWJmNjVmZWViOWMiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTM5MTI3NzYiLCJzdWIiOiJ4dUFqWVA3MkxTeTEtQzFiN2E3WDVZYjlHdzh5VmpCVW8tZTRmekt5VUZ3IiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJ2aWMuYi5kLmNoYW4uYmFxdWVyb0Bkcy5kZXYuYWNjZW50dXJlLmNvbSIsInVwbiI6InZpYy5iLmQuY2hhbi5iYXF1ZXJvQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXRpIjoiRVJ6MmMweEJORUs0eE8yTU9RUVZBQSIsInZlciI6IjEuMCJ9.af3j_MSgSZIQgvztdOK1tMwc78fDAyPeLMJSZ7sSrSuxymYuRurtd1Opbz2Trd7JmNFu0Nr9WDAqB1uM2feOFb8_I2ogoCTIxHeq6oFFc5_nG1l2qU61L9OvCNRiayYtgdkuyefPGBDsR9ukz7MjRgr8XHSdfuxB1OGgZmBgYJ_9A2cRXQjzTKAQbrM6fxprBS0X8lNcHVpIGHE4v2bcinNOH_Orvsms5b0K2uCB1GSa_c6PLYUoOKAq5HrZvHgBubfYSazFI3kuiH2gKtK3gI9aa4_H5Jx8qm1fqg0PbAvtO_6nV4LKamJDMhttqtwfea2fCF0ZYssTYThnmMBBYg';
            sinon.stub(commonService, '_getAADToken').returns(token);
        });

        after(() => {
            request.get.restore();
            commonService._getAADToken.restore();
        })
        it("should successfully get AAD People Picker", function (done) {
            let filter = 'kevin.d.borromeo1';

            commonService._getAADPeoplePicker(filter)
                .then(message => {
                    expect(message).to.be.null;
                })
                .finally(done())

        });
    });

    describe('_getAADPeoplePicker No Value Test Success', () => {
        let eids = { value: [] }
        before(() => {
            sinon.stub(request, 'get').yields(null, null, JSON.stringify(eids));
            let token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSIsImtpZCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTYyODM2NjEzLCJuYmYiOjE1NjI4MzY2MTMsImV4cCI6MTU2Mjg0MDUxMywiYWlvIjoiQVZRQXEvOE1BQUFBb3dHaUNnUndBS0pTdWNXUlRIcWxremlHVmNhM3dZSDgrTmhpY2RydnZ2RldRTEZoOXZTOUlqTDJMWGpiakJGdS9ncmZRbmlzdldxcmNteXBsUmdtOGhUU21XNDVhN1FrY2Z4RDBmK2J4RzA9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkNoYW4gQmFxdWVybyIsImdpdmVuX25hbWUiOiJWaWMgQnJhbmRvbiIsImlwYWRkciI6IjE3MC4yNTEuNDguMjE3IiwibmFtZSI6IkNoYW4gQmFxdWVybywgVmljIEIuIEQuIiwibm9uY2UiOiJkYmI4MzQ2MS0xMzMwLTQ4M2ItODkyMS1hN2RlZjBlMjkzN2MiLCJvaWQiOiIxM2EyMTI1ZS1iMDkxLTRjM2QtYmI1OC04OWJmNjVmZWViOWMiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTM5MTI3NzYiLCJzdWIiOiJ4dUFqWVA3MkxTeTEtQzFiN2E3WDVZYjlHdzh5VmpCVW8tZTRmekt5VUZ3IiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJ2aWMuYi5kLmNoYW4uYmFxdWVyb0Bkcy5kZXYuYWNjZW50dXJlLmNvbSIsInVwbiI6InZpYy5iLmQuY2hhbi5iYXF1ZXJvQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXRpIjoiRVJ6MmMweEJORUs0eE8yTU9RUVZBQSIsInZlciI6IjEuMCJ9.af3j_MSgSZIQgvztdOK1tMwc78fDAyPeLMJSZ7sSrSuxymYuRurtd1Opbz2Trd7JmNFu0Nr9WDAqB1uM2feOFb8_I2ogoCTIxHeq6oFFc5_nG1l2qU61L9OvCNRiayYtgdkuyefPGBDsR9ukz7MjRgr8XHSdfuxB1OGgZmBgYJ_9A2cRXQjzTKAQbrM6fxprBS0X8lNcHVpIGHE4v2bcinNOH_Orvsms5b0K2uCB1GSa_c6PLYUoOKAq5HrZvHgBubfYSazFI3kuiH2gKtK3gI9aa4_H5Jx8qm1fqg0PbAvtO_6nV4LKamJDMhttqtwfea2fCF0ZYssTYThnmMBBYg';
            sinon.stub(commonService, '_getAADToken').returns(token);
        });

        after(() => {
            request.get.restore();
            commonService._getAADToken.restore();
        })
        it("should successfully get AAD People Picker", function (done) {
            let filter = 'kevin.d.borromeo2';

            commonService._getAADPeoplePicker(filter)
                .then(message => {
                    expect(message).to.be.eql([]);
                })
                .finally(done())

        });
    });

    describe('_getAADPeoplePicker Incorrect property Test Success', () => {
        let eids = {
            value: [
                { "notmail": "kevin.d.borromeo@accenture.com" },
                { "notmail": "kevin.d.borromeo2@accenture.com" }
            ]
        }
        before(() => {
            sinon.stub(request, 'get').yields(null, null, JSON.stringify(eids));
            let token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSIsImtpZCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTYyODM2NjEzLCJuYmYiOjE1NjI4MzY2MTMsImV4cCI6MTU2Mjg0MDUxMywiYWlvIjoiQVZRQXEvOE1BQUFBb3dHaUNnUndBS0pTdWNXUlRIcWxremlHVmNhM3dZSDgrTmhpY2RydnZ2RldRTEZoOXZTOUlqTDJMWGpiakJGdS9ncmZRbmlzdldxcmNteXBsUmdtOGhUU21XNDVhN1FrY2Z4RDBmK2J4RzA9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkNoYW4gQmFxdWVybyIsImdpdmVuX25hbWUiOiJWaWMgQnJhbmRvbiIsImlwYWRkciI6IjE3MC4yNTEuNDguMjE3IiwibmFtZSI6IkNoYW4gQmFxdWVybywgVmljIEIuIEQuIiwibm9uY2UiOiJkYmI4MzQ2MS0xMzMwLTQ4M2ItODkyMS1hN2RlZjBlMjkzN2MiLCJvaWQiOiIxM2EyMTI1ZS1iMDkxLTRjM2QtYmI1OC04OWJmNjVmZWViOWMiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTM5MTI3NzYiLCJzdWIiOiJ4dUFqWVA3MkxTeTEtQzFiN2E3WDVZYjlHdzh5VmpCVW8tZTRmekt5VUZ3IiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJ2aWMuYi5kLmNoYW4uYmFxdWVyb0Bkcy5kZXYuYWNjZW50dXJlLmNvbSIsInVwbiI6InZpYy5iLmQuY2hhbi5iYXF1ZXJvQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXRpIjoiRVJ6MmMweEJORUs0eE8yTU9RUVZBQSIsInZlciI6IjEuMCJ9.af3j_MSgSZIQgvztdOK1tMwc78fDAyPeLMJSZ7sSrSuxymYuRurtd1Opbz2Trd7JmNFu0Nr9WDAqB1uM2feOFb8_I2ogoCTIxHeq6oFFc5_nG1l2qU61L9OvCNRiayYtgdkuyefPGBDsR9ukz7MjRgr8XHSdfuxB1OGgZmBgYJ_9A2cRXQjzTKAQbrM6fxprBS0X8lNcHVpIGHE4v2bcinNOH_Orvsms5b0K2uCB1GSa_c6PLYUoOKAq5HrZvHgBubfYSazFI3kuiH2gKtK3gI9aa4_H5Jx8qm1fqg0PbAvtO_6nV4LKamJDMhttqtwfea2fCF0ZYssTYThnmMBBYg';
            sinon.stub(commonService, '_getAADToken').returns(token);
        });

        after(() => {
            request.get.restore();
            commonService._getAADToken.restore();
        })
        it("should successfully get AAD People Picker", function (done) {
            let filter = 'kevin.d.borromeo3';

            commonService._getAADPeoplePicker(filter)
                .then(message => {
                    expect(message).to.be.eql([]);
                })
                .finally(done())

        });
    });
    describe('_getAADPeoplePicker & No Cache Test Success', () => {
        let eids = {
            value: [
                { "mail": "kevin.d.borromeo@accenture.com" },
                { "mail": "kevin.d.borromeo2@accenture.com" }
            ]
        }
        before(() => {
            sinon.stub(request, 'get').yields(null, null, JSON.stringify(eids));
            let token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSIsImtpZCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTYyODM2NjEzLCJuYmYiOjE1NjI4MzY2MTMsImV4cCI6MTU2Mjg0MDUxMywiYWlvIjoiQVZRQXEvOE1BQUFBb3dHaUNnUndBS0pTdWNXUlRIcWxremlHVmNhM3dZSDgrTmhpY2RydnZ2RldRTEZoOXZTOUlqTDJMWGpiakJGdS9ncmZRbmlzdldxcmNteXBsUmdtOGhUU21XNDVhN1FrY2Z4RDBmK2J4RzA9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkNoYW4gQmFxdWVybyIsImdpdmVuX25hbWUiOiJWaWMgQnJhbmRvbiIsImlwYWRkciI6IjE3MC4yNTEuNDguMjE3IiwibmFtZSI6IkNoYW4gQmFxdWVybywgVmljIEIuIEQuIiwibm9uY2UiOiJkYmI4MzQ2MS0xMzMwLTQ4M2ItODkyMS1hN2RlZjBlMjkzN2MiLCJvaWQiOiIxM2EyMTI1ZS1iMDkxLTRjM2QtYmI1OC04OWJmNjVmZWViOWMiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTM5MTI3NzYiLCJzdWIiOiJ4dUFqWVA3MkxTeTEtQzFiN2E3WDVZYjlHdzh5VmpCVW8tZTRmekt5VUZ3IiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJ2aWMuYi5kLmNoYW4uYmFxdWVyb0Bkcy5kZXYuYWNjZW50dXJlLmNvbSIsInVwbiI6InZpYy5iLmQuY2hhbi5iYXF1ZXJvQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXRpIjoiRVJ6MmMweEJORUs0eE8yTU9RUVZBQSIsInZlciI6IjEuMCJ9.af3j_MSgSZIQgvztdOK1tMwc78fDAyPeLMJSZ7sSrSuxymYuRurtd1Opbz2Trd7JmNFu0Nr9WDAqB1uM2feOFb8_I2ogoCTIxHeq6oFFc5_nG1l2qU61L9OvCNRiayYtgdkuyefPGBDsR9ukz7MjRgr8XHSdfuxB1OGgZmBgYJ_9A2cRXQjzTKAQbrM6fxprBS0X8lNcHVpIGHE4v2bcinNOH_Orvsms5b0K2uCB1GSa_c6PLYUoOKAq5HrZvHgBubfYSazFI3kuiH2gKtK3gI9aa4_H5Jx8qm1fqg0PbAvtO_6nV4LKamJDMhttqtwfea2fCF0ZYssTYThnmMBBYg';
            sinon.stub(commonService, '_getAADToken').returns(token);
        });

        after(() => {
            request.get.restore();
            commonService._getAADToken.restore();
        })
        it("should successfully get AAD People Picker", function (done) {
            let filter = 'kevin.d.borromeo';

            commonService._getAADPeoplePicker(filter)
                .then(message => {                    
                    expect(message.length).to.be.eql(eids.value.length)
                })
                .finally(done())

        });
    });

    describe('_getAADPeoplePicker & With Cache Test Success', () => {
        let eids = {
            value: [
                { "mail": "kevin.d.borromeo@accenture.com" },
                { "mail": "kevin.d.borromeo2@accenture.com" }
            ]
        }
        before(() => {
            let token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSIsImtpZCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTYyODM2NjEzLCJuYmYiOjE1NjI4MzY2MTMsImV4cCI6MTU2Mjg0MDUxMywiYWlvIjoiQVZRQXEvOE1BQUFBb3dHaUNnUndBS0pTdWNXUlRIcWxremlHVmNhM3dZSDgrTmhpY2RydnZ2RldRTEZoOXZTOUlqTDJMWGpiakJGdS9ncmZRbmlzdldxcmNteXBsUmdtOGhUU21XNDVhN1FrY2Z4RDBmK2J4RzA9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkNoYW4gQmFxdWVybyIsImdpdmVuX25hbWUiOiJWaWMgQnJhbmRvbiIsImlwYWRkciI6IjE3MC4yNTEuNDguMjE3IiwibmFtZSI6IkNoYW4gQmFxdWVybywgVmljIEIuIEQuIiwibm9uY2UiOiJkYmI4MzQ2MS0xMzMwLTQ4M2ItODkyMS1hN2RlZjBlMjkzN2MiLCJvaWQiOiIxM2EyMTI1ZS1iMDkxLTRjM2QtYmI1OC04OWJmNjVmZWViOWMiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTM5MTI3NzYiLCJzdWIiOiJ4dUFqWVA3MkxTeTEtQzFiN2E3WDVZYjlHdzh5VmpCVW8tZTRmekt5VUZ3IiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJ2aWMuYi5kLmNoYW4uYmFxdWVyb0Bkcy5kZXYuYWNjZW50dXJlLmNvbSIsInVwbiI6InZpYy5iLmQuY2hhbi5iYXF1ZXJvQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXRpIjoiRVJ6MmMweEJORUs0eE8yTU9RUVZBQSIsInZlciI6IjEuMCJ9.af3j_MSgSZIQgvztdOK1tMwc78fDAyPeLMJSZ7sSrSuxymYuRurtd1Opbz2Trd7JmNFu0Nr9WDAqB1uM2feOFb8_I2ogoCTIxHeq6oFFc5_nG1l2qU61L9OvCNRiayYtgdkuyefPGBDsR9ukz7MjRgr8XHSdfuxB1OGgZmBgYJ_9A2cRXQjzTKAQbrM6fxprBS0X8lNcHVpIGHE4v2bcinNOH_Orvsms5b0K2uCB1GSa_c6PLYUoOKAq5HrZvHgBubfYSazFI3kuiH2gKtK3gI9aa4_H5Jx8qm1fqg0PbAvtO_6nV4LKamJDMhttqtwfea2fCF0ZYssTYThnmMBBYg';
            sinon.stub(commonService, '_getAADToken').returns(token);
        });

        after(() => {
            commonService._getAADToken.restore();
        })
        it("should successfully get AAD People Picker", function (done) {
            let filter = 'kevin.d.borromeo';

            commonService._getAADPeoplePicker(filter)
                .then(message => {                    
                    expect(message.length).to.be.not.null;
                })
                .finally(done())

        });
    });

    describe('_getPeopleImage - No Cache Test Success', () => {
        let image = { data: "image" };
        before(() => {
            sinon.stub(axios, 'get').resolves(image);
        });

        after(() => {
            axios.get.restore();
        })

        it("should successfully get People Image", function (done) {
            commonService._getPeopleImage("kevin.d.borromeo")
                .then(message => {                    
                    expect(message).to.be.eql(image.data)
                })
                .finally(done())
        });

    });

    describe('_getPeopleImage - With Cache Test Success', () => {
        it("should successfully get People Image", function (done) {
            let image = { data: "image" };
            commonService._getPeopleImage("kevin.d.borromeo")
                .then(message => {
                    expect(message).to.be.eql(image.data)
                })
                .finally(done())
        });

    });

    describe('_getPeopleImage Test Error', () => {
        before(() => {
            let image = { data: "image" };
            sinon.stub(axios, 'get').rejects("Error");
        });

        after(() => {
            axios.get.restore();
        })

        it("should catch People Image error", function (done) {
            commonService._getPeopleImage(null)
                .catch(message => {
                    expect(message).to.not.be.null
                })
                .finally(done())
        });

    });


    describe('_getMMCLinkItems Test Success', () => {
        before(() => {
            sinon.stub(commonRepository, 'getMMCLinkItems').returns('test');
        })

        after(() => {
            commonRepository.getMMCLinkItems.restore();
        })

        it("should successfully get MMC link items", function (done) {
            let linkCategory = 'AppFinderItems';

            commonService._getMMCLinkItems(linkCategory)
                .then(message => {                    
                    expect(message).to.be.eql('test')
                })
                .finally(done())

        });

    });

    describe('_getMMCLinkItems Test Error', () => {
        before(() => {
            sinon.stub(commonRepository, 'getMMCLinkItems').rejects(new Error('Fake Repository Error'));
        })

        after(() => {
            commonRepository.getMMCLinkItems.restore();
        })

        it("should return an error", function () {
            commonService._getMMCLinkItems('')
                .catch(error => {                    
                    expect(error.message).to.be.eql('Fake Repository Error')
                })

        });

    });

    describe('_getADFSToken - No Cache Test Success', () => {
        let token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSIsImtpZCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTYyODM2NjEzLCJuYmYiOjE1NjI4MzY2MTMsImV4cCI6MTU2Mjg0MDUxMywiYWlvIjoiQVZRQXEvOE1BQUFBb3dHaUNnUndBS0pTdWNXUlRIcWxremlHVmNhM3dZSDgrTmhpY2RydnZ2RldRTEZoOXZTOUlqTDJMWGpiakJGdS9ncmZRbmlzdldxcmNteXBsUmdtOGhUU21XNDVhN1FrY2Z4RDBmK2J4RzA9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkNoYW4gQmFxdWVybyIsImdpdmVuX25hbWUiOiJWaWMgQnJhbmRvbiIsImlwYWRkciI6IjE3MC4yNTEuNDguMjE3IiwibmFtZSI6IkNoYW4gQmFxdWVybywgVmljIEIuIEQuIiwibm9uY2UiOiJkYmI4MzQ2MS0xMzMwLTQ4M2ItODkyMS1hN2RlZjBlMjkzN2MiLCJvaWQiOiIxM2EyMTI1ZS1iMDkxLTRjM2QtYmI1OC04OWJmNjVmZWViOWMiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTM5MTI3NzYiLCJzdWIiOiJ4dUFqWVA3MkxTeTEtQzFiN2E3WDVZYjlHdzh5VmpCVW8tZTRmekt5VUZ3IiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJ2aWMuYi5kLmNoYW4uYmFxdWVyb0Bkcy5kZXYuYWNjZW50dXJlLmNvbSIsInVwbiI6InZpYy5iLmQuY2hhbi5iYXF1ZXJvQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXRpIjoiRVJ6MmMweEJORUs0eE8yTU9RUVZBQSIsInZlciI6IjEuMCJ9.af3j_MSgSZIQgvztdOK1tMwc78fDAyPeLMJSZ7sSrSuxymYuRurtd1Opbz2Trd7JmNFu0Nr9WDAqB1uM2feOFb8_I2ogoCTIxHeq6oFFc5_nG1l2qU61L9OvCNRiayYtgdkuyefPGBDsR9ukz7MjRgr8XHSdfuxB1OGgZmBgYJ_9A2cRXQjzTKAQbrM6fxprBS0X8lNcHVpIGHE4v2bcinNOH_Orvsms5b0K2uCB1GSa_c6PLYUoOKAq5HrZvHgBubfYSazFI3kuiH2gKtK3gI9aa4_H5Jx8qm1fqg0PbAvtO_6nV4LKamJDMhttqtwfea2fCF0ZYssTYThnmMBBYg';
        before(() => {
            let response = {
                statusCode: 201,
            }
            let body = {
                access_token: token
            }
            sinon.stub(request, 'post').yields(null, response, JSON.stringify(body));
        })

        after(() => {
            request.post.restore();
        })

        it("should return a token", function () {
            commonService._getADFSToken()
                .then(message => {                    
                    expect(message).to.be.eql(token)
                });

        });

    });

    describe('_getADFSToken - No Cache Test 2 Success', () => {
        let token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSIsImtpZCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTYyODM2NjEzLCJuYmYiOjE1NjI4MzY2MTMsImV4cCI6MTU2Mjg0MDUxMywiYWlvIjoiQVZRQXEvOE1BQUFBb3dHaUNnUndBS0pTdWNXUlRIcWxremlHVmNhM3dZSDgrTmhpY2RydnZ2RldRTEZoOXZTOUlqTDJMWGpiakJGdS9ncmZRbmlzdldxcmNteXBsUmdtOGhUU21XNDVhN1FrY2Z4RDBmK2J4RzA9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkNoYW4gQmFxdWVybyIsImdpdmVuX25hbWUiOiJWaWMgQnJhbmRvbiIsImlwYWRkciI6IjE3MC4yNTEuNDguMjE3IiwibmFtZSI6IkNoYW4gQmFxdWVybywgVmljIEIuIEQuIiwibm9uY2UiOiJkYmI4MzQ2MS0xMzMwLTQ4M2ItODkyMS1hN2RlZjBlMjkzN2MiLCJvaWQiOiIxM2EyMTI1ZS1iMDkxLTRjM2QtYmI1OC04OWJmNjVmZWViOWMiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTM5MTI3NzYiLCJzdWIiOiJ4dUFqWVA3MkxTeTEtQzFiN2E3WDVZYjlHdzh5VmpCVW8tZTRmekt5VUZ3IiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJ2aWMuYi5kLmNoYW4uYmFxdWVyb0Bkcy5kZXYuYWNjZW50dXJlLmNvbSIsInVwbiI6InZpYy5iLmQuY2hhbi5iYXF1ZXJvQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXRpIjoiRVJ6MmMweEJORUs0eE8yTU9RUVZBQSIsInZlciI6IjEuMCJ9.af3j_MSgSZIQgvztdOK1tMwc78fDAyPeLMJSZ7sSrSuxymYuRurtd1Opbz2Trd7JmNFu0Nr9WDAqB1uM2feOFb8_I2ogoCTIxHeq6oFFc5_nG1l2qU61L9OvCNRiayYtgdkuyefPGBDsR9ukz7MjRgr8XHSdfuxB1OGgZmBgYJ_9A2cRXQjzTKAQbrM6fxprBS0X8lNcHVpIGHE4v2bcinNOH_Orvsms5b0K2uCB1GSa_c6PLYUoOKAq5HrZvHgBubfYSazFI3kuiH2gKtK3gI9aa4_H5Jx8qm1fqg0PbAvtO_6nV4LKamJDMhttqtwfea2fCF0ZYssTYThnmMBBYg';
        before(() => {
            let response = {
                statusCode: 200,
            }
            let body = {
                access_token: token
            }
            sinon.stub(request, 'post').yields(null, response, JSON.stringify(body));
        })

        after(() => {
            request.post.restore();
        })

        it("should return a token", function () {
            commonService._getADFSToken()
                .then(message => {                    
                    expect(message).to.be.eql(token)
                });

        });

    });
    describe('_getADFSToken - With Cache Test Success', () => {
        let token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSIsImtpZCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTYyODM2NjEzLCJuYmYiOjE1NjI4MzY2MTMsImV4cCI6MTU2Mjg0MDUxMywiYWlvIjoiQVZRQXEvOE1BQUFBb3dHaUNnUndBS0pTdWNXUlRIcWxremlHVmNhM3dZSDgrTmhpY2RydnZ2RldRTEZoOXZTOUlqTDJMWGpiakJGdS9ncmZRbmlzdldxcmNteXBsUmdtOGhUU21XNDVhN1FrY2Z4RDBmK2J4RzA9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkNoYW4gQmFxdWVybyIsImdpdmVuX25hbWUiOiJWaWMgQnJhbmRvbiIsImlwYWRkciI6IjE3MC4yNTEuNDguMjE3IiwibmFtZSI6IkNoYW4gQmFxdWVybywgVmljIEIuIEQuIiwibm9uY2UiOiJkYmI4MzQ2MS0xMzMwLTQ4M2ItODkyMS1hN2RlZjBlMjkzN2MiLCJvaWQiOiIxM2EyMTI1ZS1iMDkxLTRjM2QtYmI1OC04OWJmNjVmZWViOWMiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTM5MTI3NzYiLCJzdWIiOiJ4dUFqWVA3MkxTeTEtQzFiN2E3WDVZYjlHdzh5VmpCVW8tZTRmekt5VUZ3IiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJ2aWMuYi5kLmNoYW4uYmFxdWVyb0Bkcy5kZXYuYWNjZW50dXJlLmNvbSIsInVwbiI6InZpYy5iLmQuY2hhbi5iYXF1ZXJvQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXRpIjoiRVJ6MmMweEJORUs0eE8yTU9RUVZBQSIsInZlciI6IjEuMCJ9.af3j_MSgSZIQgvztdOK1tMwc78fDAyPeLMJSZ7sSrSuxymYuRurtd1Opbz2Trd7JmNFu0Nr9WDAqB1uM2feOFb8_I2ogoCTIxHeq6oFFc5_nG1l2qU61L9OvCNRiayYtgdkuyefPGBDsR9ukz7MjRgr8XHSdfuxB1OGgZmBgYJ_9A2cRXQjzTKAQbrM6fxprBS0X8lNcHVpIGHE4v2bcinNOH_Orvsms5b0K2uCB1GSa_c6PLYUoOKAq5HrZvHgBubfYSazFI3kuiH2gKtK3gI9aa4_H5Jx8qm1fqg0PbAvtO_6nV4LKamJDMhttqtwfea2fCF0ZYssTYThnmMBBYg';
        before(() => {
            let response = {
                statusCode: 200,
            }
            let body = {
                access_token: token
            }
            sinon.stub(request, 'post').yields(null, response, JSON.stringify(body));
        })

        after(() => {
            request.post.restore();
        })

        it("should return a token", function () {
            commonService._getADFSToken()
                .then(message => {                    
                    expect(message).to.be.eql(token)
                });

        });

    });

    describe('_getAADToken - No Cache Test Success', () => {
        let token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSIsImtpZCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTYyODM2NjEzLCJuYmYiOjE1NjI4MzY2MTMsImV4cCI6MTU2Mjg0MDUxMywiYWlvIjoiQVZRQXEvOE1BQUFBb3dHaUNnUndBS0pTdWNXUlRIcWxremlHVmNhM3dZSDgrTmhpY2RydnZ2RldRTEZoOXZTOUlqTDJMWGpiakJGdS9ncmZRbmlzdldxcmNteXBsUmdtOGhUU21XNDVhN1FrY2Z4RDBmK2J4RzA9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkNoYW4gQmFxdWVybyIsImdpdmVuX25hbWUiOiJWaWMgQnJhbmRvbiIsImlwYWRkciI6IjE3MC4yNTEuNDguMjE3IiwibmFtZSI6IkNoYW4gQmFxdWVybywgVmljIEIuIEQuIiwibm9uY2UiOiJkYmI4MzQ2MS0xMzMwLTQ4M2ItODkyMS1hN2RlZjBlMjkzN2MiLCJvaWQiOiIxM2EyMTI1ZS1iMDkxLTRjM2QtYmI1OC04OWJmNjVmZWViOWMiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTM5MTI3NzYiLCJzdWIiOiJ4dUFqWVA3MkxTeTEtQzFiN2E3WDVZYjlHdzh5VmpCVW8tZTRmekt5VUZ3IiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJ2aWMuYi5kLmNoYW4uYmFxdWVyb0Bkcy5kZXYuYWNjZW50dXJlLmNvbSIsInVwbiI6InZpYy5iLmQuY2hhbi5iYXF1ZXJvQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXRpIjoiRVJ6MmMweEJORUs0eE8yTU9RUVZBQSIsInZlciI6IjEuMCJ9.af3j_MSgSZIQgvztdOK1tMwc78fDAyPeLMJSZ7sSrSuxymYuRurtd1Opbz2Trd7JmNFu0Nr9WDAqB1uM2feOFb8_I2ogoCTIxHeq6oFFc5_nG1l2qU61L9OvCNRiayYtgdkuyefPGBDsR9ukz7MjRgr8XHSdfuxB1OGgZmBgYJ_9A2cRXQjzTKAQbrM6fxprBS0X8lNcHVpIGHE4v2bcinNOH_Orvsms5b0K2uCB1GSa_c6PLYUoOKAq5HrZvHgBubfYSazFI3kuiH2gKtK3gI9aa4_H5Jx8qm1fqg0PbAvtO_6nV4LKamJDMhttqtwfea2fCF0ZYssTYThnmMBBYg';
        before(() => {
            let response = {
                statusCode: 201,
            }
            let body = {
                access_token: token
            }
            sinon.stub(request, 'post').yields(null, response, JSON.stringify(body));
        })

        after(() => {
            request.post.restore();
        })

        it("should return a token", function () {
            commonService._getAADToken()
                .then(message => {                    
                    expect(message).to.be.eql(token)
                });

        });

    });

    describe('_getAADToken - No Cache Test Success 2', () => {
        let token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSIsImtpZCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTYyODM2NjEzLCJuYmYiOjE1NjI4MzY2MTMsImV4cCI6MTU2Mjg0MDUxMywiYWlvIjoiQVZRQXEvOE1BQUFBb3dHaUNnUndBS0pTdWNXUlRIcWxremlHVmNhM3dZSDgrTmhpY2RydnZ2RldRTEZoOXZTOUlqTDJMWGpiakJGdS9ncmZRbmlzdldxcmNteXBsUmdtOGhUU21XNDVhN1FrY2Z4RDBmK2J4RzA9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkNoYW4gQmFxdWVybyIsImdpdmVuX25hbWUiOiJWaWMgQnJhbmRvbiIsImlwYWRkciI6IjE3MC4yNTEuNDguMjE3IiwibmFtZSI6IkNoYW4gQmFxdWVybywgVmljIEIuIEQuIiwibm9uY2UiOiJkYmI4MzQ2MS0xMzMwLTQ4M2ItODkyMS1hN2RlZjBlMjkzN2MiLCJvaWQiOiIxM2EyMTI1ZS1iMDkxLTRjM2QtYmI1OC04OWJmNjVmZWViOWMiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTM5MTI3NzYiLCJzdWIiOiJ4dUFqWVA3MkxTeTEtQzFiN2E3WDVZYjlHdzh5VmpCVW8tZTRmekt5VUZ3IiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJ2aWMuYi5kLmNoYW4uYmFxdWVyb0Bkcy5kZXYuYWNjZW50dXJlLmNvbSIsInVwbiI6InZpYy5iLmQuY2hhbi5iYXF1ZXJvQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXRpIjoiRVJ6MmMweEJORUs0eE8yTU9RUVZBQSIsInZlciI6IjEuMCJ9.af3j_MSgSZIQgvztdOK1tMwc78fDAyPeLMJSZ7sSrSuxymYuRurtd1Opbz2Trd7JmNFu0Nr9WDAqB1uM2feOFb8_I2ogoCTIxHeq6oFFc5_nG1l2qU61L9OvCNRiayYtgdkuyefPGBDsR9ukz7MjRgr8XHSdfuxB1OGgZmBgYJ_9A2cRXQjzTKAQbrM6fxprBS0X8lNcHVpIGHE4v2bcinNOH_Orvsms5b0K2uCB1GSa_c6PLYUoOKAq5HrZvHgBubfYSazFI3kuiH2gKtK3gI9aa4_H5Jx8qm1fqg0PbAvtO_6nV4LKamJDMhttqtwfea2fCF0ZYssTYThnmMBBYg';
        before(() => {
            let response = {
                statusCode: 200,
            }
            let body = {
                access_token: token
            }
            sinon.stub(request, 'post').yields(null, response, JSON.stringify(body));
        })

        after(() => {
            request.post.restore();
        })

        it("should return a token", function () {
            commonService._getAADToken()
                .then(message => {                    
                    expect(message).to.be.eql(token)
                });

        });

    });
    describe('_getAADToken - With Cache Test Success', () => {
        let token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSIsImtpZCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTYyODM2NjEzLCJuYmYiOjE1NjI4MzY2MTMsImV4cCI6MTU2Mjg0MDUxMywiYWlvIjoiQVZRQXEvOE1BQUFBb3dHaUNnUndBS0pTdWNXUlRIcWxremlHVmNhM3dZSDgrTmhpY2RydnZ2RldRTEZoOXZTOUlqTDJMWGpiakJGdS9ncmZRbmlzdldxcmNteXBsUmdtOGhUU21XNDVhN1FrY2Z4RDBmK2J4RzA9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkNoYW4gQmFxdWVybyIsImdpdmVuX25hbWUiOiJWaWMgQnJhbmRvbiIsImlwYWRkciI6IjE3MC4yNTEuNDguMjE3IiwibmFtZSI6IkNoYW4gQmFxdWVybywgVmljIEIuIEQuIiwibm9uY2UiOiJkYmI4MzQ2MS0xMzMwLTQ4M2ItODkyMS1hN2RlZjBlMjkzN2MiLCJvaWQiOiIxM2EyMTI1ZS1iMDkxLTRjM2QtYmI1OC04OWJmNjVmZWViOWMiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTM5MTI3NzYiLCJzdWIiOiJ4dUFqWVA3MkxTeTEtQzFiN2E3WDVZYjlHdzh5VmpCVW8tZTRmekt5VUZ3IiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJ2aWMuYi5kLmNoYW4uYmFxdWVyb0Bkcy5kZXYuYWNjZW50dXJlLmNvbSIsInVwbiI6InZpYy5iLmQuY2hhbi5iYXF1ZXJvQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXRpIjoiRVJ6MmMweEJORUs0eE8yTU9RUVZBQSIsInZlciI6IjEuMCJ9.af3j_MSgSZIQgvztdOK1tMwc78fDAyPeLMJSZ7sSrSuxymYuRurtd1Opbz2Trd7JmNFu0Nr9WDAqB1uM2feOFb8_I2ogoCTIxHeq6oFFc5_nG1l2qU61L9OvCNRiayYtgdkuyefPGBDsR9ukz7MjRgr8XHSdfuxB1OGgZmBgYJ_9A2cRXQjzTKAQbrM6fxprBS0X8lNcHVpIGHE4v2bcinNOH_Orvsms5b0K2uCB1GSa_c6PLYUoOKAq5HrZvHgBubfYSazFI3kuiH2gKtK3gI9aa4_H5Jx8qm1fqg0PbAvtO_6nV4LKamJDMhttqtwfea2fCF0ZYssTYThnmMBBYg';
        before(() => {
            let response = {
                statusCode: 200,
            }
            let body = {
                access_token: token
            }
            sinon.stub(request, 'post').yields(null, response, JSON.stringify(body));
        })

        after(() => {
            request.post.restore();
        })

        it("should return a token", function () {
            commonService._getAADToken()
                .then(message => {                    
                    expect(message).to.be.eql(token)
                });

        });

    });

    describe('_getAADUserDetail - Null Test Success', () => {
        let token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSIsImtpZCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTYyODM2NjEzLCJuYmYiOjE1NjI4MzY2MTMsImV4cCI6MTU2Mjg0MDUxMywiYWlvIjoiQVZRQXEvOE1BQUFBb3dHaUNnUndBS0pTdWNXUlRIcWxremlHVmNhM3dZSDgrTmhpY2RydnZ2RldRTEZoOXZTOUlqTDJMWGpiakJGdS9ncmZRbmlzdldxcmNteXBsUmdtOGhUU21XNDVhN1FrY2Z4RDBmK2J4RzA9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkNoYW4gQmFxdWVybyIsImdpdmVuX25hbWUiOiJWaWMgQnJhbmRvbiIsImlwYWRkciI6IjE3MC4yNTEuNDguMjE3IiwibmFtZSI6IkNoYW4gQmFxdWVybywgVmljIEIuIEQuIiwibm9uY2UiOiJkYmI4MzQ2MS0xMzMwLTQ4M2ItODkyMS1hN2RlZjBlMjkzN2MiLCJvaWQiOiIxM2EyMTI1ZS1iMDkxLTRjM2QtYmI1OC04OWJmNjVmZWViOWMiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTM5MTI3NzYiLCJzdWIiOiJ4dUFqWVA3MkxTeTEtQzFiN2E3WDVZYjlHdzh5VmpCVW8tZTRmekt5VUZ3IiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJ2aWMuYi5kLmNoYW4uYmFxdWVyb0Bkcy5kZXYuYWNjZW50dXJlLmNvbSIsInVwbiI6InZpYy5iLmQuY2hhbi5iYXF1ZXJvQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXRpIjoiRVJ6MmMweEJORUs0eE8yTU9RUVZBQSIsInZlciI6IjEuMCJ9.af3j_MSgSZIQgvztdOK1tMwc78fDAyPeLMJSZ7sSrSuxymYuRurtd1Opbz2Trd7JmNFu0Nr9WDAqB1uM2feOFb8_I2ogoCTIxHeq6oFFc5_nG1l2qU61L9OvCNRiayYtgdkuyefPGBDsR9ukz7MjRgr8XHSdfuxB1OGgZmBgYJ_9A2cRXQjzTKAQbrM6fxprBS0X8lNcHVpIGHE4v2bcinNOH_Orvsms5b0K2uCB1GSa_c6PLYUoOKAq5HrZvHgBubfYSazFI3kuiH2gKtK3gI9aa4_H5Jx8qm1fqg0PbAvtO_6nV4LKamJDMhttqtwfea2fCF0ZYssTYThnmMBBYg';
        before(() => {
            sinon.stub(commonService, '_getAADToken').returns(token);
            sinon.stub(request, 'get').yields(null, null, null);
        })

        after(() => {
            commonService._getAADToken.restore();
            request.get.restore();
        })

        it("should return an error", function () {
            commonService._getAADUserDetail('kevin.d.borromeo')
                .then((data) => {
                    expect(data).to.be.null;
                })

        });

    });

    describe('_getAADUserDetail - No Cache Test Success', () => {
        let token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSIsImtpZCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTYyODM2NjEzLCJuYmYiOjE1NjI4MzY2MTMsImV4cCI6MTU2Mjg0MDUxMywiYWlvIjoiQVZRQXEvOE1BQUFBb3dHaUNnUndBS0pTdWNXUlRIcWxremlHVmNhM3dZSDgrTmhpY2RydnZ2RldRTEZoOXZTOUlqTDJMWGpiakJGdS9ncmZRbmlzdldxcmNteXBsUmdtOGhUU21XNDVhN1FrY2Z4RDBmK2J4RzA9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkNoYW4gQmFxdWVybyIsImdpdmVuX25hbWUiOiJWaWMgQnJhbmRvbiIsImlwYWRkciI6IjE3MC4yNTEuNDguMjE3IiwibmFtZSI6IkNoYW4gQmFxdWVybywgVmljIEIuIEQuIiwibm9uY2UiOiJkYmI4MzQ2MS0xMzMwLTQ4M2ItODkyMS1hN2RlZjBlMjkzN2MiLCJvaWQiOiIxM2EyMTI1ZS1iMDkxLTRjM2QtYmI1OC04OWJmNjVmZWViOWMiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTM5MTI3NzYiLCJzdWIiOiJ4dUFqWVA3MkxTeTEtQzFiN2E3WDVZYjlHdzh5VmpCVW8tZTRmekt5VUZ3IiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJ2aWMuYi5kLmNoYW4uYmFxdWVyb0Bkcy5kZXYuYWNjZW50dXJlLmNvbSIsInVwbiI6InZpYy5iLmQuY2hhbi5iYXF1ZXJvQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXRpIjoiRVJ6MmMweEJORUs0eE8yTU9RUVZBQSIsInZlciI6IjEuMCJ9.af3j_MSgSZIQgvztdOK1tMwc78fDAyPeLMJSZ7sSrSuxymYuRurtd1Opbz2Trd7JmNFu0Nr9WDAqB1uM2feOFb8_I2ogoCTIxHeq6oFFc5_nG1l2qU61L9OvCNRiayYtgdkuyefPGBDsR9ukz7MjRgr8XHSdfuxB1OGgZmBgYJ_9A2cRXQjzTKAQbrM6fxprBS0X8lNcHVpIGHE4v2bcinNOH_Orvsms5b0K2uCB1GSa_c6PLYUoOKAq5HrZvHgBubfYSazFI3kuiH2gKtK3gI9aa4_H5Jx8qm1fqg0PbAvtO_6nV4LKamJDMhttqtwfea2fCF0ZYssTYThnmMBBYg';
        before(() => {
            sinon.stub(commonService, '_getAADToken').returns(token);
            sinon.stub(request, 'get').yields(null, null, '{"userPrincipalName": "kevin.d.borromeo@accenture.com", "givenName": "Kevin", "surname": "Borromeo", "displayName": "Borromeo, Kevin D.", "userPrincipalName": "kevin.d.borromeo@accenture.com"}');
        })

        after(() => {
            commonService._getAADToken.restore();
            request.get.restore();
        })

        it("should return an error", function () {
            commonService._getAADUserDetail('kevin.d.borromeo')
            .then((data) => {
                expect(data).to.be.not.null;
            })

        });

    });

    describe('_getAADUserDetail - Cache Test Success', () => {
        let token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSIsImtpZCI6InU0T2ZORlBId0VCb3NIanRyYXVPYlY4NExuWSJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTYyODM2NjEzLCJuYmYiOjE1NjI4MzY2MTMsImV4cCI6MTU2Mjg0MDUxMywiYWlvIjoiQVZRQXEvOE1BQUFBb3dHaUNnUndBS0pTdWNXUlRIcWxremlHVmNhM3dZSDgrTmhpY2RydnZ2RldRTEZoOXZTOUlqTDJMWGpiakJGdS9ncmZRbmlzdldxcmNteXBsUmdtOGhUU21XNDVhN1FrY2Z4RDBmK2J4RzA9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkNoYW4gQmFxdWVybyIsImdpdmVuX25hbWUiOiJWaWMgQnJhbmRvbiIsImlwYWRkciI6IjE3MC4yNTEuNDguMjE3IiwibmFtZSI6IkNoYW4gQmFxdWVybywgVmljIEIuIEQuIiwibm9uY2UiOiJkYmI4MzQ2MS0xMzMwLTQ4M2ItODkyMS1hN2RlZjBlMjkzN2MiLCJvaWQiOiIxM2EyMTI1ZS1iMDkxLTRjM2QtYmI1OC04OWJmNjVmZWViOWMiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTM5MTI3NzYiLCJzdWIiOiJ4dUFqWVA3MkxTeTEtQzFiN2E3WDVZYjlHdzh5VmpCVW8tZTRmekt5VUZ3IiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJ2aWMuYi5kLmNoYW4uYmFxdWVyb0Bkcy5kZXYuYWNjZW50dXJlLmNvbSIsInVwbiI6InZpYy5iLmQuY2hhbi5iYXF1ZXJvQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXRpIjoiRVJ6MmMweEJORUs0eE8yTU9RUVZBQSIsInZlciI6IjEuMCJ9.af3j_MSgSZIQgvztdOK1tMwc78fDAyPeLMJSZ7sSrSuxymYuRurtd1Opbz2Trd7JmNFu0Nr9WDAqB1uM2feOFb8_I2ogoCTIxHeq6oFFc5_nG1l2qU61L9OvCNRiayYtgdkuyefPGBDsR9ukz7MjRgr8XHSdfuxB1OGgZmBgYJ_9A2cRXQjzTKAQbrM6fxprBS0X8lNcHVpIGHE4v2bcinNOH_Orvsms5b0K2uCB1GSa_c6PLYUoOKAq5HrZvHgBubfYSazFI3kuiH2gKtK3gI9aa4_H5Jx8qm1fqg0PbAvtO_6nV4LKamJDMhttqtwfea2fCF0ZYssTYThnmMBBYg';
        before(() => {
            sinon.stub(commonService, '_getAADToken').returns(token);
            //sinon.stub(NodeCache, 'get').returns({EnterpriseID: "kevin.d.borromeo"});            
        })

        after(() => {
            commonService._getAADToken.restore();
            //NodeCache.get.restore();
        })

        it("should return an error", function () {
            commonService._getAADUserDetail('kevin.d.borromeo')
            .then((data) => {
                expect(data).to.be.not.null;
            })

        });

    });


    describe('_getDisabledFeatures Test Success', () => {
        afterEach(() => {
            commonRepository.getDisabledFeatures.restore();
        })

        it("should successfully get 1 disabled feature", function (done) {
            sinon.stub(commonRepository, 'getDisabledFeatures').returns([{FeatureName: "app-contract-qa", Enabled: false}, {FeatureName: "app-contract-cm", Enabled: true}]);
            commonService._getDisabledFeatures()
                .then(message => {                    
                    expect(message.length).to.be.eql(1)
                })
                .finally(done())
        });

        it("should successfully get empty feature when 2 same feature with different Enabled Status", function (done) {
            sinon.stub(commonRepository, 'getDisabledFeatures').returns([{FeatureName: "app-contract-qa", Enabled: false}, {FeatureName: "app-contract-qa", Enabled: true}]);
            commonService._getDisabledFeatures()
                .then(message => {                    
                    expect(message).to.be.eql(null)
                })
                .finally(done())
        });

        it("should successfully get empty feature", function (done) {
            sinon.stub(commonRepository, 'getDisabledFeatures').returns(null);
            commonService._getDisabledFeatures()
                .then(message => {                    
                    expect(message).to.be.eql(null)
                })
                .finally(done())
        });

    });


    describe('_getDisabledFeatures Test Error', () => {
        before(() => {
            sinon.stub(commonRepository, 'getDisabledFeatures').rejects(new Error('Fake Repository Error'));
        })

        after(() => {
            commonRepository.getDisabledFeatures.restore();
        })

        it("should return an error", function (done) {
            commonService._getDisabledFeatures()
                .catch(error => {                    
                    expect(error.message).to.be.eql('Fake Repository Error')
                })
                .finally(done())

        });

    });

});