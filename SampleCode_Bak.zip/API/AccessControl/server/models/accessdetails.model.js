'use strict';

const Pages = require('./pages.model');
const SubPages = require('./subpages.model');

module.exports = function(mod, obj, subPages) { 
    this.Module = mod;
    this.Pages = [];
    this.SubPages = [];
    obj.forEach(element => {
        this.Pages.push(new Pages(element))
    });
    subPages.forEach(element => {
        this.SubPages.push(new SubPages(element))
    });
}