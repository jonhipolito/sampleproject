'use strict';

module.exports = function(obj) {  
    this.Page = obj.PageNm;
    this.IsReadOnly = obj.IsReadOnly;
    this.IsDefaultPage = obj.IsDefaultPage;
    this.Order = obj.Placement;
    this.Link = obj.Link;
}