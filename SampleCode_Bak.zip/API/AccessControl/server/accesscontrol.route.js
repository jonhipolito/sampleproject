'use strict';

const express = require('express');
const router = express.Router();
const accessControlController = require('./accesscontrol.controller');

router.get('/getAccessDetails', accessControlController.getAccessDetails);
router.get('/HasMasterClientAccess/:MasterClientNbr', accessControlController.hasMasterClientAccess);
router.get('/HasCustomerAccess/:CustomerNbr', accessControlController.hasCustomerAccess);
router.get('/HasContractAccess/:ContractNbr', accessControlController.hasContractAccess);
module.exports = router;