'use strict';

const cors = (req, res, next) => {
    if(process.env.NODE_ENV === 'production'){
        let origin = req.header('host').toLowerCase().endsWith(".accenture.com") > -1 ? req.headers.origin : '';        
        res.header("Access-Control-Allow-Origin", origin);    
        res.header("Access-Control-Max-Age", 86400);
    }
    else {
        res.header("Access-Control-Allow-Origin", "*");
    }    
        res.header("Cache-Control", "no-cache, no-store");
        res.header(
            "Access-Control-Allow-Headers",
            "Origin, X-Requested-With, Content-Type, Accept, Authorization"
        );
        
        if (req.method === 'OPTIONS') {
            res.header("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE");
            return res.status(200).json({});
        }
        // console.log('CORS ADDED TO HEADER');
        next();
};

module.exports = { cors }