'use strict';

const accessControlService = require('./accesscontrol.service');

const getAccessDetails = (req, res, next) => {
    accessControlService._getAccessDetails(req)
        .then(data => {
            res.status(200).json({
                data: data
            });
        })
        .catch(error => {
            const err = new Error(error);
            next(err);
        })
}

const hasMasterClientAccess = (req, res, next) => {
    commonService._hasMasterClientAccess(req.params.MasterClientNbr)
        .then(data => {
            res.send(data);
        });
}

const hasCustomerAccess = (req, res, next) => {
    commonService._hasCustomerAccess(req.params.CustomerNbr)
        .then(data => {
            res.send(data);
        });
}

const hasContractAccess = (req, res, next) => {
    commonService._hasContractAccess(req.params.ContractNbr)
        .then(data => {
            res.send(data);
        });
}

module.exports = {
    getAccessDetails,    
    hasMasterClientAccess,
    hasCustomerAccess,
    hasContractAccess
}