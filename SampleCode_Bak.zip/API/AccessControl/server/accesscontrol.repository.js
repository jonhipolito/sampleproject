'use strict';

const SpannerDB = require('../configs/db.connection');

const getCMAccess = async (enterpriseId) => {
  const database = new SpannerDB();

  const accessquery = `SELECT COUNT(MasterClientNbr) AS AccessCount FROM MMCSecurityData WHERE EnterpriseId = '${enterpriseId}'`;

  const pagesquery = `SELECT m.ModuleNm, p.PageNm, ac.IsReadOnly, ac.IsDefaultPage, p.Placement, p.Link 
                              FROM Module m 
                              INNER JOIN Page p ON m.ModuleCd = p.ModuleCd
                              INNER JOIN AccessControl ac on p.PageCd = ac.PageCd 
                              WHERE ac.ADGroup = 'Legal.GLN.CM.All'
                              ORDER BY ModuleNm, Placement ASC`;

  const subpagesquery = `SELECT m.ModuleNm, p.PageCd, sp.SubPageNm, sp.Placement, sp.Link
                              FROM Module m 
                              INNER JOIN Page p ON m.ModuleCd = p.ModuleCd
                              INNER JOIN AccessControl ac on p.PageCd = ac.PageCd 
                              INNER JOIN SubPage sp ON p.PageCd = sp.PageCd
                              WHERE ac.ADGroup = 'Legal.GLN.CM.All'
                              ORDER BY ModuleNm, Placement ASC`

  try {
    let [accessCount] = await database.run(accessquery);

    if (accessCount[0].toJSON().AccessCount > 0) {

      let rows = {};

      let [accessRowsRes] = await database.run(pagesquery);
      let [subPagesRes] = await database.run(subpagesquery);

      rows.accessRows = accessRowsRes;
      rows.subPages = subPagesRes;

      return rows;
    }
    else {
      return [];
    };

  } catch (err) {
    return new Error(err);
  } finally {
    // Close the database when finished.
    await database.close();
  }
}

const getRoleBasedAccess = async (enterpriseId) => {
  const database = new SpannerDB();

  const accessquery = `SELECT m.ModuleNm, p.PageNm, ac.IsReadOnly, ac.IsDefaultPage, p.Placement, p.Link 
    FROM Module m 
    INNER JOIN Page p ON m.ModuleCd = p.ModuleCd
    INNER JOIN AccessControl ac on p.PageCd = ac.PageCd 
    WHERE ac.ADGroup IN 
      (SELECT ADGroup 
        FROM IndividualAccessControl_Temp 
        WHERE EnterpriseId = '${enterpriseId}')
    ORDER BY ModuleNm, Placement ASC`;

  try {
    let [accessRows] = await database.run(accessquery);
    if (accessRows.length > 0) {
      return accessRows;
    } else {
      return null;
    }
  } catch (err) {
    return new Error(err);
  } finally {
    // Close the database when finished.
    await database.close();
  }
}

const hasMasterClientAccess = async (MasterClientNbr, EnterpriseId) => {
  let database = new SpannerDB();
  const query = {
    sql: `SELECT MasterClientNbr FROM MMCSecurityData WHERE EnterpriseId = '${EnterpriseId}' AND MasterClientNbr = '${MasterClientNbr}' LIMIT 1`
  };
  try {
    const [result] = await database.run(query);
    return result;
  } catch (err) {
    console.error('ERROR:', err);
  } finally {
    await database.close();
  }
}

const hasCustomerAccess = async (CustomerNbr, EnterpriseId) => {
  let database = new SpannerDB();
  const query = {
    sql: `SELECT MasterClientNbr FROM MMCSecurityData WHERE EnterpriseId = '${EnterpriseId}' AND MasterClientNbr IN (SELECT MasterClientNbr FROM CUSTOMER WHERE CustomerNbr = '${CustomerNbr}') LIMIT 1`
  };
  try {
    const [result] = await database.run(query);
    return result;
  } catch (err) {
    console.error('ERROR:', err);
  } finally {
    await database.close();
  }
}

const hasContractAccess = async (ContractNbr, EnterpriseId) => {
  let database = new SpannerDB();
  const query = {
    sql: `SELECT MasterClientNbr FROM MMCSecurityData WHERE EnterpriseId = '${EnterpriseId}' AND MasterClientNbr IN (SELECT MasterClientNbr FROM CUSTOMER WHERE CustomerNbr IN (SELECT CustomerNbr FROM Contract WHERE ContractNbr = '${ContractNbr}')) LIMIT 1`
  };
  try {
    const [result] = await database.run(query);
    return result;
  } catch (err) {
    console.error('ERROR:', err);
  } finally {
    await database.close();
  }
}

module.exports = {
  getCMAccess,
  getRoleBasedAccess,
  hasMasterClientAccess,
  hasCustomerAccess,
  hasContractAccess
}