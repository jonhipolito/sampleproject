'use strict';

const axios = require('axios');
const AccessDetails = require('./models/accessdetails.model');
const accessControlRepository = require('./accesscontrol.repository');
const request = require('request');
const _ = require('lodash');

const NodeCache = require("node-cache");
const ttl = 60 * 60 * 1; // cache for 1 Hour
const cache = new NodeCache({ stdTTL: ttl, checkperiod: ttl * 0.2 });

const _getAccessDetails = (req) => {
  return new Promise(async function (resolve, reject) {
    let accessDetails;
    try {
      accessDetails = getAccessDetailsJson(await accessControlRepository.getCMAccess(process.env.ENTERPRISEID));
      resolve(accessDetails);
    } catch (err) {
      console.error('ERROR:', err);
      return reject(err);
    } finally {
      /*
      if (accessDetails && accessDetails.length != 0) {
        //callAuditLog(req);
      }
      */
    }
  })
}

const getAccessDetailsJson = (queryResult) => {

  let accessDetails_Array = [], jsonArray = [], jsonArraySubPages = [];
  if (queryResult.accessRows && queryResult.accessRows.length > 0) {
    queryResult.accessRows.forEach(row => {
      let eachJSONRow = JSON.parse(JSON.stringify(row));
      jsonArray.push(eachJSONRow);
    });
  }

  if (queryResult.subPages && queryResult.subPages.length > 0) {
    queryResult.subPages.forEach(row => {
      let eachJSONRow = JSON.parse(JSON.stringify(row));
      jsonArraySubPages.push(eachJSONRow);
    });
  }

  let uniqVal = _.uniqBy(_.map(jsonArray, 'ModuleNm'));

  uniqVal.forEach(mod => {
    accessDetails_Array.push(new AccessDetails(mod, _.uniqBy(jsonArray.filter(x => x.ModuleNm == mod), 'Placement'), _.uniqBy(jsonArraySubPages.filter(x => x.ModuleNm == mod), 'Placement')))
  });

  return accessDetails_Array;
}

const _hasMasterClientAccess = async (MasterClientNbr) => {
  var acc = Cache.get(`${process.env.ENTERPRISEID}-${MasterClientNbr}`);
  if (acc != null) {
    return acc;
  }
  else {
    var res = await commonRepository.hasMasterClientAccess(MasterClientNbr, process.env.ENTERPRISEID);
    acc = res && res.length > 0;
    Cache.set(`${process.env.ENTERPRISEID}-${MasterClientNbr}`, acc, 300);
    return acc;
  }  
}

const _hasCustomerAccess = async (CustomerNbr) => {
  let acc = Cache.get(`${process.env.ENTERPRISEID}-${CustomerNbr}`);
  if (acc != null) {
    return acc;
  }
  else {
    var res = await commonRepository.hasCustomerAccess(CustomerNbr, process.env.ENTERPRISEID);
    acc = res && res.length > 0;
    Cache.set(`${process.env.ENTERPRISEID}-${CustomerNbr}`, acc, 300);
    return acc;
  }
}

const _hasContractAccess = async (ContractNbr) => {
  let acc = Cache.get(`${process.env.ENTERPRISEID}-${ContractNbr}`);
  if (acc != null) {
    return acc;
  }
  else {
    var res = await commonRepository.hasContractAccess(ContractNbr, process.env.ENTERPRISEID);
    acc = res && res.length > 0;
    Cache.set(`${process.env.ENTERPRISEID}-${ContractNbr}`, acc, 300);
    return acc;
  }  
}

module.exports = {
  _getAccessDetails,
  _hasMasterClientAccess,
  _hasCustomerAccess,
  _hasContractAccess
}
