process.env.NODE_ENV = 'test';

const should = require('chai').should();
const expect = require('chai').expect;
const assert = require('chai').assert;
const sinon = require('sinon');
const accessControlRepository = require('../server/accesscontrol.repository');
const accessControlService = require('../server/accesscontrol.service');

describe('Testing AccessControl Service', () => {
    describe('_getPeopleImage', () => {
        describe('_getPeopleImage - success', () => {
            let env;
            before(() => {
                env = Object.assign({}, process.env);
            })

            after(() => {
                process.env = env;
            })

            it("should return user image", async function () {
                const result = accessControlService._getPeopleImage();
                assert.isNotNull(result);
            });
        });

        describe('_getPeopleImage - error', () => {
            let env;
            before(() => {
                env = Object.assign({}, process.env);
                process.env.UNIT_TEST_DATABASE_ID = '';
            });

            after(() => {
                process.env = env;
                process.env.UNIT_TEST_DATABASE_ID = 'mmcunittestdb';
            });

            it("should return error", async function () {
                process.env.DOMAIN = 'DS';

                try {
                    accessControlService._getPeopleImage();
                } catch (err) {
                    console.log("err: " + err);
                    expect(err).to.have.string('error');
                }
            });
        });
    });

    describe('_getAccessDetails', () => {
        describe('_getAccessDetails - success', () => {
            describe('', () => {
                var req;
                before(() => {
                    req = ({
                        body: { objectname: "Home Page", eventtypename: "Visit" },
                        headers: { authorization: "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IkhCeGw5bUFlNmd4YXZDa2NvT1UyVEhzRE5hMCIsImtpZCI6IkhCeGw5bUFlNmd4YXZDa2NvT1UyVEhzRE5hMCJ9.eyJhdWQiOiJiOGI5MGVkNS00YmZkLTRjYzgtOTNlMS1kZDRjZmU5YjMzYmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwiaWF0IjoxNTU2MTY5MzQ4LCJuYmYiOjE1NTYxNjkzNDgsImV4cCI6MTU1NjE3MzI0OCwiYWlvIjoiQVZRQXEvOExBQUFBcUdEa0Q5U3Jzb3B0cmFjWGpFZElkamxkMnlvTjlLbXFLZWd1N294UmlacE1JUjJxQVNYOW5SSERlSGhaQVgvZHRxODZ5NDk3K1VVQXhPblBGMi90R2NGajVYR3d5MEt0YkJzaWlKOStiNUk9IiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJmYW1pbHlfbmFtZSI6IkFub3JhIiwiZ2l2ZW5fbmFtZSI6IkNpbmR5IE1hcmllIiwiaXBhZGRyIjoiMTcwLjI1Mi4xNjAuMSIsIm5hbWUiOiJBw7FvcmEsIENpbmR5IE1hcmllIEwuIiwibm9uY2UiOiJhYzBjYWEyYi0zNDI2LTRkNGEtOWU5Zi1lNWI4NTNiMDg0OWUiLCJvaWQiOiI2ZWRiYmUxNi0zYWQxLTRkNDItYjVkMy04ZmQ1OGJhYzQ2NDkiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtODYxNTY3NTAxLTQxMzAyNzMyMi0xODAxNjc0NTMxLTMxODI5ODUiLCJzdWIiOiJqcERVRFJoU0MtNzhnRHotUE1PZXF3eGYzRlVyNnlTejByMEV5U25XemhzIiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidW5pcXVlX25hbWUiOiJjaW5keS5tYXJpZS5sLmFub3JhQGRzLmRldi5hY2NlbnR1cmUuY29tIiwidXBuIjoiY2luZHkubWFyaWUubC5hbm9yYUBkcy5kZXYuYWNjZW50dXJlLmNvbSIsInV0aSI6IjlTaE02LUFPeDBPV0xIZlU4ZTZCQUEiLCJ2ZXIiOiIxLjAifQ.a8IZbaAx6FMaWFtisz_D9q4I8Kj77j1DSFMxEpDpG5BSUEPh1fsyxGwoRzBdgWOGtk4Pw4S_AF1QAi5KUvw1ugoRXY6DnLhAfSDsXk0Ics1fqhX0s_7COv5Fg2-I-1arxWILKbFzoFPFb7NjpWdSxYiICq7x2-q6zkAfbhcbSvT9CAk1LTLN5rZ0JPtKSqLA_jco0CacFTzXlXEfVMSPiYdk6J-KP3_heYCZVD_Maj7ip5k0JJeFw0M-3cXJfx1XWrOCSQ1wWcGgCwJd3bXWXLNeHodZM7NDraTQQBngANqlDmQCy3kR9ytYgD02S_jEIKextVb_vdUU-ho-fCNA7Q" }
                    });
                    var queryResultArray = [];
                    var arrObj = [];
                    let jsonString = [`{"ModuleNm":"Account","PageNm":"Home","IsReadOnly":true,"IsDefaultPage":true,"Placement":1}`];
                    let jsonObject = JSON.parse(jsonString);
                    for (var k in jsonObject) {
                        if (jsonObject.hasOwnProperty(k)) {
                            arrObj.push({ name: jsonObject[k], value: k });
                        }
                    }
                    queryResultArray.push(arrObj);
                    sinon.stub(accessControlRepository, 'getAccessDetails').returns(queryResultArray);
                })
                after(() => {
                    accessControlRepository.getAccessDetails.restore();
                    req = "";
                })

                it("should get and return user access details", function (done) {

                    accessControlService._getAccessDetails(req);
                    done();
                });
            });
        });

        // describe('_getAccessDetails - error', () => {
        //     describe('', () => {
        //         var req1;
        //         before(() => {
        //             req1 = ({
        //                 body: { objectname: "Home Page", eventtypename: "Visit" },
        //                 headers: { authorization: "Bearer " }
        //             });

        //             var queryResultArray = [];
        //             var arrObj = [];
        //             let jsonString = [`{"ModuleNm":"Account","PageNm":"Home","IsReadOnly":true,"IsDefaultPage":true,"Placement":1}`];
        //             let jsonObject = JSON.parse(jsonString);
        //             for (var k in jsonObject) {
        //                 if (jsonObject.hasOwnProperty(k)) {
        //                     arrObj.push({name: jsonObject[k], value: k});
        //                 }
        //             }
        //             queryResultArray.push(arrObj);
        //             sinon.stub(accessControlRepository, 'getAccessDetails').returns(queryResultArray);
        //         });

        //         after(() => {
        //             accessControlRepository.getAccessDetails.restore();
        //             req1 = "";
        //         });

        //         it("should return error", function (done) {
        //             process.env.UNIT_TEST_DATABASE_ID = 'unit test';

        //             accessControlService._getAccessDetails(req1);
        //             done();
        //         });
        //     });
        // });

        describe('_getAccessDetails - error', () => {
            before(() => {
                sinon.stub(accessControlRepository, 'getAccessDetails').rejects(new Error('Fake Repository Error'));
            })

            after(() => {
                accessControlRepository.getAccessDetails.restore();
            })

            it("should return an error", function (done) {
                accessControlService._getAccessDetails()
                    .catch(error => {
                        error.message.should.eql('Fake Repository Error');
                    })
                    .finally(done());
            });

        });
    });
});