process.env.NODE_ENV = 'test';

const should = require('chai').should();
const expect = require('chai').expect;
const assert = require('chai').assert;
const sinon = require('sinon');
const accessControlService = require('../server/accesscontrol.service');
const accessControlController = require('../server/accesscontrol.controller');

describe.skip('Testing AccessControl Controller', () => {

    describe('GET getAccessDetails - successfull', () => {

        before(() => {
            sinon.stub(accessControlService, '_getAccessDetails').returns(new Promise((resolve, reject) => {
                resolve('unit test');
            }));
        })

        after(() => {
            accessControlService._getAccessDetails.restore();
        })

        it("should send a message after successful get", function () {
            var req = new Object();
            var res = new Object();

            res.send = function (val) {
                val.should.have.property('message');
                val.should.have.property('message').eql('unit test');
            }

            accessControlController.getAccessDetails(req, res, {});
        });
    });

    describe('GET getPeopleImage - successfull', () => {

        before(() => {
            sinon.stub(accessControlService, '_getPeopleImage').returns(new Promise((resolve, reject) => {
                resolve('unit test');
            }));
        })

        after(() => {
            accessControlService._getPeopleImage.restore();
        })

        it("should send a message after successful get", function (done) {
            var req = new Object();
            var res = new Object();

            res.send = function (val) {
                val.should.have.property('message');
                val.should.have.property('message').eql('unit test');
            }

            accessControlController.getPeopleImage(req, res, {});
            done();
        });
    });


});