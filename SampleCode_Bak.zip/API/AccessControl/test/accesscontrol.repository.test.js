process.env.NODE_ENV = 'test';

require('dotenv').config(); // Loads .env (for local)
const should = require('chai').should();
const expect = require('chai').expect;
const assert = require('chai').assert;
const accessControlRepository = require('../server/accesscontrol.repository');

describe('Testing AccessControl Repository', () => {
    describe('getAccessDetails', () => {
        describe.skip('getAccessDetails - successfully', () => {

            it("should return user access details as json", async function () {

                const eid = process.env.ENTERPRISEID.toLowerCase(); // ensure the eid has entry in IndividualAccessControl_Temp table

                var result = await accessControlRepository.getAccessDetails(eid);
                result.should.not.equal(null);
            });

            it("should return user access details as null or blank", async function () {

                const eidStr = 'test.user';
                const eid = eidStr.toLowerCase(); //process.env.ENTERPRISEID.toLowerCase(); // ensure the eid has NO entry in IndividualAccessControl_Temp table

                var result = await accessControlRepository.getAccessDetails(eid);

                expect(result).to.equal(null);
            });
        });

        describe('getAccessDetails - error', () => {
            let env;
            before(() => {
                env = Object.assign({}, process.env);
            })
    
            after(() => {
                process.env = env;
            })

            it("should throw an error", async function () {
                process.env.DATABASE_ID = 'unittest'; // alter the database config to throw an error
                const eid = process.env.ENTERPRISEID.toLowerCase();

                try {
                    await accessControlRepository.getAccessDetails(eid);
                } catch (err) {
                    expect(err).to.have.string('Database not found');
                }
            });
        });
    });
});