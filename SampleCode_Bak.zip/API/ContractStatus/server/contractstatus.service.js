'use strict';

//MODELS
const contractStatusItem = require('./models/contractstatus.model');

const uuid = require('uuidv4');
const _ = require('lodash');
const contractStatusRepository = require('./contractstatus.repository');
const NodeCache = require("node-cache");
const ttl = 60 * 60 * 1; // cache for 1 Hour
const cache = new NodeCache({ stdTTL: ttl, checkperiod: ttl * 0.2 });

const _getContractStatus = (clientNbr, customerNbr, contractNbr) => {
  var data;
  return new Promise(async (resolve, reject) => {
    var res = await contractStatusRepository.getContractStatus(clientNbr, customerNbr, contractNbr);
    try {

      data = [{
        ContractNbr: contractNbr,
        CustomerNbr: customerNbr,
        ClientNbr: clientNbr,
        items: null
      }];

      if(res){
        let resParse = JSON.parse(JSON.stringify(res));
        data[0].items = resParse;
      } 
      
      resolve(data);
      res.catch(err);
    } catch (err) {
      return reject(err);
    }
  });
}

const _createContractStatus = (model) => {
  return new Promise(async function (resolve, reject) {
    try {

      model.startdt = getTimestamp(model.startdt);
      model.enddt = getTimestamp(model.enddt);
      model.expectedsigndt = getTimestamp(model.expectedsigndt);
      let contractModel = new contractStatusItem(model);

      var res = contractStatusRepository.createContractStatus(contractModel);
      resolve(res);
    } catch (err) {
      console.log(err);
      return new Error(err);
    }
  })
}

const _updateContractStatus = (model) => {
  return new Promise(async function (resolve, reject) {
    try {
      model.startdt = getTimestamp(model.startdt);
      model.enddt = getTimestamp(model.enddt);
      model.expectedsigndt = getTimestamp(model.expectedsigndt);
      let contractModel = new contractStatusItem(model);
      if(model.contractkey) {
        contractModel.ContractingStatusKey = model.contractkey;
        contractModel.StartDt = model.startdt;
        contractModel.ContractNbr = model.conNbr;
        contractModel.CustomerNbr = model.fcNbr;
        contractModel.MasterClientNbr = model.mcNbr;
        contractModel.CreateUserId = model.userEid;
        contractModel.UpdateUserId = model.userEid;
        contractModel.CreateDttm = model.CreateDttm; //Declare to the initialize create dttm
      }
      var res = contractStatusRepository.updateContractStatus(contractModel);
      resolve(res);
    } catch (err) {
      console.log(err);
      return new Error(err);
    }
  })
}

const getTimestamp = (object) => {
  var timestamp;
  try {
    if(object) {
      var date = new Date(object);
      var month = date.getMonth() + 1; //months from 1-12
      var day = date.getDate();
      var year = date.getFullYear();
      var timestamp = `${year}-${month}-${day}T00:00:00.00Z`;
      return timestamp;
    } else {
      return null; 
    }
  } catch (error) {
    console.log(error);
  }
}

const _deleteItem = async (body) => {
  try {
    await contractStatusRepository.deleteContractStatus(body.ContractingStatusKeys);
    return;
  } catch (err) {
    console.error('ERROR:', err);
    return reject(err);
  }
}

const _updateTimeStamp = async (body) => {
  try {
    await contractStatusRepository.updateTimeStamp(body.ContractingStatusKey, body.UpdateDttm);
    return;
  } catch (err) {
    console.error('ERROR:', err);
    return reject(err);
  } finally {

  }

}

const _getServiceGroup = () => {
  var data;
  return new Promise(async (resolve, reject) => {
    var res = await contractStatusRepository.getServiceGroup();
    try {
      if(res) {
        let resParse = JSON.parse(JSON.stringify(res));
        data = resParse;
      }
      resolve(data);
      res.catch(err);
    } catch (err) {
      return reject(err);
    }
  });
}

const _getStatusValues = () => {
  var data;
  return new Promise(async (resolve, reject) => {
    var res = await contractStatusRepository.getStatusValues();
    try {
      if(res) {
        let resParse = JSON.parse(JSON.stringify(res));
        data = resParse;
      }
      resolve(data);
      res.catch(err);
    } catch (err) {
      return reject(err);
    }
  });
}



module.exports = {
  _getContractStatus,
  _createContractStatus,
  _updateContractStatus,
  _deleteItem,
  _updateTimeStamp,
  _getServiceGroup,
  _getStatusValues
}
