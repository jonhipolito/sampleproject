'use strict';

const contractStatusService = require('./contractstatus.service');

//Consume the data and transform the api
const getContractStatus = (req, res, next) => {
    contractStatusService._getContractStatus(req.params.clientNbr, req.params.customerNbr, req.params.contractNbr)
        .then(message => {
            res.send({
                data: message
            });       
        })
        .catch(error => {
            const err = new Error(error);
            next(err);
        })
}

const addContractStatus = (req, res, next) => {
    contractStatusService._createContractStatus(req.body)
    .then(message => {
        res.send({
            data: message
        });
    })
    .catch(error => {
        const err = new Error(error);
        next(err);
    })
}

const deleteContractStatus = (req, res, next) => {
    contractStatusService._deleteItem(req.body)
        .then(message => {
            res.send({
                data: message
            });
        })
        .catch(error => {
            const err = new Error(error);
            next(err);
        })
}

const updateContractStatus = (req, res, next) => {
    contractStatusService._updateContractStatus(req.body)
        .then(message => {
            res.send({
                data: message
            });
        })
        .catch(error => {
            const err = new Error(error);
            next(err);
        })
}

const updateTimeStamp = (req, res, next) => {
    contractStatusService._updateTimeStamp(req.body)
        .then(message => {
            res.send({
                data: message
            });
        })
        .catch(error => {
            const err = new Error(error);
            next(err);
        })
}

const getServiceGroup = (req, res, next) => {
    contractStatusService._getServiceGroup()
        .then(message => {
            res.send({
                data: message
            });       
        })
        .catch(error => {
            const err = new Error(error);
            next(err);
        })
}

const getStatusValues = (req, res, next) => {
    contractStatusService._getStatusValues()
        .then(message => {
            res.send({
                data: message
            });       
        })
        .catch(error => {
            const err = new Error(error);
            next(err);
        })
}

module.exports = {
    getContractStatus,
    addContractStatus,
    updateContractStatus,
    deleteContractStatus,
    updateTimeStamp,
    getServiceGroup,
    getStatusValues
}
