'use strict';

const uuid = require('uuidv4');

module.exports = function (responseTime, responseObj) {
    this.responseTime = responseTime;
    this.responseObj = responseObj;
}   
