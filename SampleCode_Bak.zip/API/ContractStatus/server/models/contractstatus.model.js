'use strict';

const uuid = require('uuidv4');

module.exports = function (obj) {
    this.ContractingStatusKey = uuid();
    this.ContractingStatusNm = obj.contractname;
    this.ContractType = obj.contracttype ? obj.contracttype : null;
    this.Status = obj.status ? obj.status : null;
    this.TotalVal = obj.totalvalue ? obj.totalvalue : null;
    this.ServiceGrp = obj.servicegroup ? obj.servicegroup : null;
    this.StartDt = obj.startdt ? obj.startdt : null;
    this.EndDt = obj.enddt ? obj.enddt : null;
    this.ExpectedSgnDt  = obj.expectedsigndt ? obj.expectedsigndt : null;
    this.OpportunityId = obj.oppurtunityid ? obj.oppurtunityid : null;
    this.ContractNbr = obj.conNbr;
    this.CustomerNbr = obj.fcNbr ? obj.fcNbr : null;
    this.MasterClientNbr = obj.mcNbr;
    this.CreateDttm = 'spanner.commit_timestamp()';
    this.CreateUserId = obj.userEid ? obj.userEid : null;
    this.UpdateDttm = 'spanner.commit_timestamp()';
    this.UpdateUserId = obj.userEid ? obj.userEid : null;
    this.Comments = obj.comments ? obj.comments : null;
}   
