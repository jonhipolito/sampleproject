'use strict';
// const axios = require('axios');

const SpannerDB = require('../configs/db.connection');
const responseObject = require('./models/contractstatus.response.model');
const serviceGroupId = 1031;
const statusId = 1034;

const createContractStatus = async (model) => {
    let database = new SpannerDB();
    const ContractStatusTable = database.table('ContractingStatus');
    
    try {       
        var contractStatus = await ContractStatusTable.insert(model);
        let responseObj = new responseObject(contractStatus[0], model);
        return responseObj;
    } catch (err) {
        console.log(err);
        return new Error(err);
    } finally {
        // Close the database when finished.
        await database.close();
    }
}

const deleteContractStatus = async (keys) => {
    let database = new SpannerDB();
    const ContractingStatusTable = database.table('ContractingStatus');

    try {
        await ContractingStatusTable.deleteRows(keys);
        return;
    } catch (err) {
        console.log(err);
        return new Error(err);
    } finally {
        await database.close();
    }
}

const updateContractStatus = async (model) => {
    let database = new SpannerDB();
    const ContractStatusTable = database.table('ContractingStatus');
    
    try {       
        var contractStatus = await ContractStatusTable.update(model);
        let responseObj = new responseObject(contractStatus[0], model);
        return responseObj;
    } catch (err) {
        console.log(err);
        return new Error(err);
    } finally {
        // Close the database when finished.
        await database.close();
    }
}

const updateTimeStamp = async (key, date) => {
    return await new Promise(async (resolve) => {
        try {
            let database = new SpannerDB();
            let script = `UPDATE ContractingStatus 
                SET UpdateDttm = '${date}'
                WHERE ContractingStatusKey = '${key}'`
            await database.runTransaction(async (err, transaction) => {
                await transaction.runUpdate(script);
                await transaction.commit();
                resolve();
                await database.close();
            });
        } catch (err) {
            console.log("updateTimeStamp Error: ", err);
        } finally {
        }
    });
}

const getContractStatus = async (clientNbr, customerNbr, contractNbr) => {
    const database = new SpannerDB();

    var constractStatusQuery = await getQuery(clientNbr, customerNbr, contractNbr);

    try {
        let [contractStatus] = await database.run(constractStatusQuery);
        if (contractStatus.length > 0) {
            return contractStatus;
        } else {
            return null;
        }
    } catch (err) {
        return new Error(err);
    } finally {
        await database.close();
    }
}

const getQuery = async (clientNbr, customerNbr, contractNbr) => {
    var query;

    if (contractNbr != 0) {
        // Initial query for Contract Details
        query = `SELECT ContractingStatusKey AS contractkey,
                    ContractingStatusNm AS contractname,
                    cs.ContractType AS contracttype,
                    cs.Status AS status ,
                    cs.TotalVal AS totalvalue,
                    cs.ServiceGrp AS servicegroup,
                    DATE(cs.ExpectedSgnDt,'+00:00') as expectedsigndt,
                    DATE(cs.StartDt,'+00:00') as startdt, 
                    DATE(cs.EndDt,'+00:00') as enddt,
                    cs.OpportunityId AS oppurtunityid,
                    cs.CreateDttm AS CreateDttm,
                    cs.UpdateDttm AS recentupdate,
                    cs.ContractNbr AS conNbr,
                    cs.CustomerNbr AS fcNbr,
                    cs.MasterClientNbr AS mcNbr,
                    cs.Comments AS comments
                    FROM ContractingStatus AS cs
                    WHERE cs.ContractNbr = '${contractNbr}'
                    `;
    } else if (customerNbr != 0){
        // Initial query for Financial Client Details
        query = `SELECT ContractingStatusKey AS contractkey,
                    ContractingStatusNm AS contractname,
                    cs.ContractType AS contracttype,
                    cs.Status AS status ,
                    cs.TotalVal AS totalvalue,
                    cs.ServiceGrp AS servicegroup,
                    DATE(cs.ExpectedSgnDt,'+00:00') as expectedsigndt,
                    DATE(cs.StartDt,'+00:00') as startdt, 
                    DATE(cs.EndDt,'+00:00') as enddt,
                    cs.OpportunityId AS oppurtunityid,
                    cs.CreateDttm AS CreateDttm,
                    cs.UpdateDttm AS recentupdate,
                    cs.ContractNbr AS conNbr,
                    cs.CustomerNbr AS fcNbr,
                    cs.MasterClientNbr AS mcNbr,
                    cs.Comments AS comments
                    FROM ContractingStatus AS cs
                    WHERE cs.CustomerNbr = '${customerNbr}'
                    `;
    } else if (clientNbr != 0){
        // Initial query for Master Client Details
        query = `SELECT ContractingStatusKey AS contractkey,
                    ContractingStatusNm AS contractname,
                    cs.ContractType AS contracttype,
                    cs.Status AS status ,
                    cs.TotalVal AS totalvalue,
                    cs.ServiceGrp AS servicegroup,
                    DATE(cs.ExpectedSgnDt,'+00:00') as expectedsigndt,
                    DATE(cs.StartDt,'+00:00') as startdt, 
                    DATE(cs.EndDt,'+00:00') as enddt,
                    cs.OpportunityId AS oppurtunityid,
                    cs.CreateDttm AS CreateDttm,
                    cs.UpdateDttm AS recentupdate,
                    cu.CustomerNm as financialclient,
                    cs.ContractNbr AS conNbr,
                    cs.CustomerNbr AS fcNbr,
                    cs.MasterClientNbr AS mcNbr,
                    cs.Comments AS comments
                    FROM ContractingStatus AS cs
                    LEFT JOIN Customer AS cu
                    ON cs.CustomerNbr = cu.CustomerNbr
                    WHERE cs.MasterClientNbr = '${clientNbr}'
                    `;            
    } else {
        query = null;
    }
    return query;
}

const getServiceGroup = async (clientNbr, customerNbr, contractNbr) => {
    const database = new SpannerDB();

    var serviceGroupQuery = `SELECT CD.CodeDetailId AS id, 
                            CD.PrimaryDecodeTxt AS value 
                            FROM CodeHeader CH 
                            INNER JOIN 
                            CodeDetail CD 
                            ON CH.CodeHeaderId = CD.CodeHeaderId 
                            WHERE CD.CodeHeaderId = ${serviceGroupId}`;

    try {
        let [serviceGroup] = await database.run(serviceGroupQuery);
        if (serviceGroup.length > 0) {
            return serviceGroup;
        } else {
            return null;
        }
    } catch (err) {
        return new Error(err);
    } finally {
        await database.close();
    }
}

const getStatusValues = async () => {
    const database = new SpannerDB();

    var statusQuery = `SELECT CD.CodeDetailId AS id, 
                        CD.PrimaryDecodeTxt AS value ,
                        CD.SecondaryDecodeTxt as color
                        FROM CodeHeader CH 
                        INNER JOIN 
                        CodeDetail CD 
                        ON CH.CodeHeaderId = CD.CodeHeaderId 
                        WHERE CD.CodeHeaderId = ${statusId}`;

    try {
        let [status] = await database.run(statusQuery);
        if (status.length > 0) {
            return status;
        } else {
            return null;
        }
    } catch (err) {
        return new Error(err);
    } finally {
        await database.close();
    }
}




module.exports = {
    getContractStatus,
    createContractStatus,
    deleteContractStatus,
    updateContractStatus,
    updateTimeStamp,
    getServiceGroup,
    getStatusValues
}