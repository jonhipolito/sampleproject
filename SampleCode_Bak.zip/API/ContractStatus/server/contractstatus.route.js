'use strict';

const express = require('express');

const contractStatusController = require('./contractstatus.controller');

const router = express.Router();

router.get('/getContractStatus/:clientNbr/:customerNbr/:contractNbr', contractStatusController.getContractStatus);
router.put('/updateContractStatus/:contractkey', contractStatusController.updateContractStatus);
router.post('/saveContractStatus', contractStatusController.addContractStatus);
router.post('/deleteContractStatus', contractStatusController.deleteContractStatus);
router.post('/updateTimeStamp', contractStatusController.updateTimeStamp);
router.get('/getServiceGroup', contractStatusController.getServiceGroup);
router.get('/getStatusValues', contractStatusController.getStatusValues);

module.exports = router;