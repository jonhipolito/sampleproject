process.env.NODE_ENV = 'test';
const contractStatusRepository = require('../server/contractstatus.repository');
const contractStatusService = require('../server/contractstatus.service');
const sinon = require('sinon');
const chai = require('chai');
const should = chai.should();
const expect = require('chai').expect;

describe('Testing Contract Status Service', () => {

    describe('_getContractStatus Test Success', () => {
        before(() => {
            sinon.stub(contractStatusRepository, 'getContractStatus').returns('test get details info');
        })

        after(() => {
            contractStatusRepository.getContractStatus.restore();
        })

        it("should successfully get contract status info", function (done) {
            contractStatusService._getContractStatus(1000, 1000, 5)
            .then(message => {
                message.should.eql('test get contract status info');
            })
            .finally(done())

        });

    });

});