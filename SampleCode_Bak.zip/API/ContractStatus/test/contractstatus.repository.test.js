process.env.NODE_ENV = 'test';
const uuid = require('uuidv4');
const contractStatusRepository = require('../server/contractstatus.repository');
// const sinon = require('sinon');
const chai = require('chai');
const should = chai.should();
// const expect = require('chai').expect;
require('dotenv').config(); // Loads .env (for local)    

describe('Testing Contract Status Repository', () => {
});