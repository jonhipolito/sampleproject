process.env.NODE_ENV = 'test';
const contractStatusController = require('../server/contractstatus.controller');
const contractStatusService = require('../server/contractstatus.service');
const sinon = require('sinon');
const chai = require('chai');
const should = chai.should();
const expect = require('chai').expect;

var sinonChai = require('sinon-chai');
chai.use(sinonChai);
const nextSpy = sinon.spy();
const sendSpy = sinon.spy();
const serviceMock = sinon.stub();

describe('Testing Contract Status Controller', () => {

    describe('getContractStatus Test', () => {
        const csServiceMethodStub = sinon.stub(contractStatusService, '_getContractStatus');
        
        beforeEach(function(done) {
            done();
        });

        afterEach(function(done) {
          sendSpy.resetHistory();
          nextSpy.resetHistory();
          csServiceMethodStub.reset();
          done();
        });

        after(() => {
            csServiceMethodStub.restore();
        })
        
        it('should call service and return data', async () => {
            csServiceMethodStub.resolves([])
            const req = ({params :{clientNbr:'1', customerNbr:'1', contractNbr:'1'}});
            const res = { send: sendSpy };
            await contractStatusController.getContractStatus(req, res, nextSpy);
            expect(sendSpy).to.have.been.calledWith({ data: [] });
        });

        it('should handle error returned by service', async () => {
            csServiceMethodStub.rejects('error');
            const req = ({params :{clientNbr:'1', customerNbr:'1', contractNbr:'1'}});
            const res = {};
            await contractStatusController.getContractStatus(req, res, nextSpy);
            return csServiceMethodStub().catch((error) => {
                expect(error.name).eql('error');
            });
        });
    });

    describe('addContractStatus Test', () => {
        const csServiceMethodStub = sinon.stub(contractStatusService, '_createContractStatus');
        
        beforeEach(function(done) {
            done();
        });

        afterEach(function(done) {
          sendSpy.resetHistory();
          nextSpy.resetHistory();
          csServiceMethodStub.reset();
          done();
        });

        after(() => {
            csServiceMethodStub.restore();
        })
        
        it('should call service and return data', async () => {
            csServiceMethodStub.resolves([])
            const req = ({params :{ContractingStatusKey: 'f94393ec-77c7-4fbf-8bc5-bd70552e502d',
            ContractingStatusNm: 'try',
            ContractType: null,
            Status: 'Ready For Signature',
            TotalVal: null,
            ServiceGrp: null,
            StartDt: null,
            EndDt: null,
            ExpectedSgnDt: '2019-10-29T00:00:00.00Z',
            OpportunityId: null,
            ContractNbr: '100211',
            CustomerNbr: '10000112',
            MasterClientNbr: '1800002',
            CreateDttm: 'spanner.commit_timestamp()',
            CreateUserId: 'ben.c.villanueva.iii',
            UpdateDttm: 'spanner.commit_timestamp()',
            UpdateUserId: 'ben.c.villanueva.iii' }});
            const res = { send: sendSpy };
            await contractStatusController.addContractStatus(req, res, nextSpy);
            expect(sendSpy).to.have.been.calledWith({ data: [] });
        });

        it('should handle error returned by service', async () => {
            csServiceMethodStub.rejects('error');
            const req = ({params :{ContractingStatusKey: 'f94393ec-77c7-4fbf-8bc5-bd70552e502d',
            ContractingStatusNm: 'try',
            ContractType: null,
            Status: 'Ready For Signature',
            TotalVal: null,
            ServiceGrp: null,
            StartDt: null,
            EndDt: null,
            ExpectedSgnDt: '2019-10-29T00:00:00.00Z',
            OpportunityId: null,
            ContractNbr: '100211',
            CustomerNbr: '10000112',
            MasterClientNbr: '1800002',
            CreateDttm: 'spanner.commit_timestamp()',
            CreateUserId: 'ben.c.villanueva.iii',
            UpdateDttm: 'spanner.commit_timestamp()',
            UpdateUserId: 'ben.c.villanueva.iii' }});
            const res = {};
            await contractStatusController.addContractStatus(req, res, nextSpy);
            return csServiceMethodStub().catch((error) => {
                expect(error.name).eql('error');
            });
        });
    });

    describe('deleteContractStatus Test', () => {
        const csServiceMethodStub = sinon.stub(contractStatusService, '_deleteItem');
        
        beforeEach(function(done) {
            done();
        });

        afterEach(function(done) {
          sendSpy.resetHistory();
          nextSpy.resetHistory();
          csServiceMethodStub.reset();
          done();
        });

        after(() => {
            csServiceMethodStub.restore();
        })
        
        it('should call service and return data', async () => {
            csServiceMethodStub.resolves([])
            const req = ({params :{ContractingStatusKeys:'1'}});
            const res = { send: sendSpy };
            await contractStatusController.deleteContractStatus(req, res, nextSpy);
            expect(sendSpy).to.have.been.calledWith({ data: [] });
        });

        it('should handle error returned by service', async () => {
            csServiceMethodStub.rejects('error');
            const req = ({params :{ContractingStatusKeys:'1'}});
            const res = {};
            await contractStatusController.deleteContractStatus(req, res, nextSpy);
            return csServiceMethodStub().catch((error) => {
                expect(error.name).eql('error');
            });
        });
    });


    describe('updateContractStatus Test', () => {
        const csServiceMethodStub = sinon.stub(contractStatusService, '_updateContractStatus');
        
        beforeEach(function(done) {
            done();
        });

        afterEach(function(done) {
          sendSpy.resetHistory();
          nextSpy.resetHistory();
          csServiceMethodStub.reset();
          done();
        });

        after(() => {
            csServiceMethodStub.restore();
        })
        
        it('should call service and return data', async () => {
            csServiceMethodStub.resolves([])
            const req = ({params :{ContractingStatusNm:"CS"}});
            const res = { send: sendSpy };
            await contractStatusController.updateContractStatus(req, res, nextSpy);
            expect(sendSpy).to.have.been.calledWith({ data: [] });
        });

        it('should handle error returned by service', async () => {
            csServiceMethodStub.rejects('error');
            const req = ({params :{ContractingStatusNm:"CS"}});
            const res = {};
            await contractStatusController.updateContractStatus(req, res, nextSpy);
            return csServiceMethodStub().catch((error) => {
                expect(error.name).eql('error');
            });
        });
    });

    describe('updateTimeStamp Test', () => {
        const csServiceMethodStub = sinon.stub(contractStatusService, '_updateTimeStamp');
        let currentDate = new Date().toJSON("YYYY-MM-DD HH:mm Z");
        
        beforeEach(function(done) {
            done();
        });

        afterEach(function(done) {
          sendSpy.resetHistory();
          nextSpy.resetHistory();
          csServiceMethodStub.reset();
          done();
        });

        after(() => {
            csServiceMethodStub.restore();
        })
        
        it('should call service and return data', async () => {
            csServiceMethodStub.resolves([])
            const req = ({params :{ContractingStatusKey:'1', UpdateDttm: currentDate}});
            const res = { send: sendSpy };
            await contractStatusController.updateTimeStamp(req, res, nextSpy);
            expect(sendSpy).to.have.been.calledWith({ data: [] });
        });

        it('should handle error returned by service', async () => {
            csServiceMethodStub.rejects('error');
            const req = ({params :{ContractingStatusKey:'1', UpdateDttm: currentDate}});
            const res = {};
            await contractStatusController.updateTimeStamp(req, res, nextSpy);
            return csServiceMethodStub().catch((error) => {
                expect(error.name).eql('error');
            });
        });
    });


    describe('getServiceGroup Test', () => {
        const csServiceMethodStub = sinon.stub(contractStatusService, '_getServiceGroup');
        
        beforeEach(function(done) {
            done();
        });

        afterEach(function(done) {
          sendSpy.resetHistory();
          nextSpy.resetHistory();
          csServiceMethodStub.reset();
          done();
        });

        after(() => {
            csServiceMethodStub.restore();
        })
        
        it('should call service and return data', async () => {
            csServiceMethodStub.resolves([])
            const req = ({params :{}});
            const res = { send: sendSpy };
            await contractStatusController.getServiceGroup(req, res, nextSpy);
            expect(sendSpy).to.have.been.calledWith({ data: [] });
        });

        it('should handle error returned by service', async () => {
            csServiceMethodStub.rejects('error');
            const req = ({params :{}});
            const res = {};
            await contractStatusController.getServiceGroup(req, res, nextSpy);
            return csServiceMethodStub().catch((error) => {
                expect(error.name).eql('error');
            });
        });
    });


    describe('getStatusValues Test', () => {
        const csServiceMethodStub = sinon.stub(contractStatusService, '_getStatusValues');
        
        beforeEach(function(done) {
            done();
        });

        afterEach(function(done) {
          sendSpy.resetHistory();
          nextSpy.resetHistory();
          csServiceMethodStub.reset();
          done();
        });

        after(() => {
            csServiceMethodStub.restore();
        })
        
        it('should call service and return data', async () => {
            csServiceMethodStub.resolves([])
            const req = ({params :{}});
            const res = { send: sendSpy };
            await contractStatusController.getStatusValues(req, res, nextSpy);
            expect(sendSpy).to.have.been.calledWith({ data: [] });
        });

        it('should handle error returned by service', async () => {
            csServiceMethodStub.rejects('error');
            const req = ({params :{}});
            const res = {};
            await contractStatusController.getStatusValues(req, res, nextSpy);
            return csServiceMethodStub().catch((error) => {
                expect(error.name).eql('error');
            });
        });
    });

});