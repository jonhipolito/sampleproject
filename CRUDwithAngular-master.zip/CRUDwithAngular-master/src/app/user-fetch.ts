
export class UserFetch {
  constructor( public id = 0, public name = '', public model='') {}
}

