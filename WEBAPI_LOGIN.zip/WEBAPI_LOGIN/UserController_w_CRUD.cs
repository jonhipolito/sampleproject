﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using EmployeeDataModel;
using System.Net.Http;
using System.Net;
using System.Threading;

namespace WebAPIDemo.Controllers
{
    //[HTTPS]
    public class UserController : ApiController
    {
        private EmployeeDataModel.Entities _context = new EmployeeDataModel.Entities();

        //[HttpGet]
        [Authehtication]
        public HttpResponseMessage GetLoadUser(string user)
        {
            //return _context.UserAccessDatas.Take(20).ToList();

            string usernm = Thread.CurrentPrincipal.Identity.Name;
            string[] username = user.Split(':');
            string str1 = username[0];
            string str2 = username[0];

            if (user == str2)
            {
                return Request.CreateResponse(HttpStatusCode.OK, _context.UserAccessDatas.Take(10));
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.Unauthorized, user);
            }
        }

        public UserAccessData GetUserId(int id)
        {
            //using (EmployeeDataModel.Entities _context = new EmployeeDataModel.Entities())
            //{
                return _context.UserAccessDatas.Where(x => x.UserAccessDetailId == id).FirstOrDefault();
            //}
        }

        public HttpResponseMessage Post([FromBody] UserAccessData user)
        {
            _context.UserAccessDatas.Add(user);
            _context.SaveChanges();

             return Request.CreateResponse(HttpStatusCode.OK, "POSTED");
        }

        public HttpResponseMessage Delete(int id)
        {
            try
            {
                var idfound = _context.UserAccessDatas.FirstOrDefault(x => x.UserAccessDetailId == id);

                if (idfound != null)
                {
                    _context.UserAccessDatas.Remove(idfound);
                    _context.SaveChanges();
                    return Request.CreateResponse(HttpStatusCode.OK, "DELETED");
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound, "NOT FOUND");
                }
            }
            catch (System.Exception ex)
            {

                return Request.CreateResponse(HttpStatusCode.BadRequest, "BadRequest");
            }     
        }


        public HttpResponseMessage Put(int id, [FromUri] UserAccessData user)
        {
            try
            {
                var idfound = _context.UserAccessDatas.FirstOrDefault(x => x.UserAccessDetailId == id);

                if (idfound != null)
                {
                    idfound.EnterpriseId = user.EnterpriseId;
                    _context.SaveChanges();
                    return Request.CreateResponse(HttpStatusCode.OK, "UPDATED");
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound, "NOT FOUND");
                }
            }
            catch (System.Exception ex)
            {

                return Request.CreateResponse(HttpStatusCode.BadRequest, "BadRequest");
            }
        }
    
}
}
