﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace EmployeeService.Controllers
{
    //[Authorize]
    public class EmployeesController : ApiController
    {
        private JON_DBEntities _context = new JON_DBEntities();
        public IEnumerable<UserAccessDetail> Get()
        {
            return _context.UserAccessDetails.Take(10);
        }
    }
}
